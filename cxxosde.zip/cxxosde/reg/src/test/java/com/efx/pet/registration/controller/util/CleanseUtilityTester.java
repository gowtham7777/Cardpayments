package com.efx.pet.registration.controller.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CleanseUtilityTester {

  @Test
  public void escapeXSSPatterns() {
    String vulnerable = "\"<p>&please<script></script><p>&lt;a href=&quot;#&quot; onclick=&quot;alert(1)&quot;&gt;WORK&lt;/a&gt;</p>\";";
    String clean = CleanseUtility.stripXSSVulnerabilities(vulnerable);
    assertEquals("\"&pleaseWORK\";", clean);
  }
}
