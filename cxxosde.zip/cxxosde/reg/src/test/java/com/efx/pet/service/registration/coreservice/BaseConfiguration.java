package com.efx.pet.service.registration.coreservice;

import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

@Configuration
@ComponentScan("com.efx.pet")
public class BaseConfiguration {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(BaseConfiguration.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "BaseConfiguration");

  @Value("${http_proxy.host}")
  private String proxyHost;

  @Value("${http_proxy.port}")
  private int proxyPort;

    @Bean(name="restTemplate")
    public RestTemplate restTemplate() {
      try {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        Proxy proxy= new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
        if(proxy!=null) {
        requestFactory.setProxy(proxy);
        return new RestTemplate(requestFactory);
        }
    }catch(final Exception ex) {
      final String message = "Exception in setting proxy";
      LOGGER.error(message, ex);
      AUDITOR.recordError("BaseConfiguration", AuditEventStatus.END_FAIL, message);
  }
      return null;
}
}
