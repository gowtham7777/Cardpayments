package com.efx.pet.service.registration.controller;

import com.efx.pet.service.configuration.TestProfileConfig;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {HealthCheckController.class, TestProfileConfig.class})
public class HealthCheckControllerTest {

    @Autowired
    HealthCheckController controllerUnderTest;

    MockMvc mockMvc;

    @MockBean
    BuildProperties buildProperties;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    @Test
    public void testHealthCheck_Success() throws Exception {
        when(buildProperties.getGroup()).thenReturn("com.efx.gcs.pet.lockandalerts");
        when(buildProperties.getArtifact()).thenReturn("pet-channel-web-consumer-registration");
        when(buildProperties.getTime()).thenReturn(Instant.now());
        when(buildProperties.getVersion()).thenReturn("mock-getVersion");
        
        mockMvc.perform(get("/rest/1.0/healthCheck")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"status\":\"OK\"")))
                .andExpect(content().string(containsString("version")))
                .andExpect(content().string(containsString("com.efx.gcs.pet.lockandalerts")))
                .andExpect(content().string(containsString("pet-channel-web-consumer-registration")));
    }
}
