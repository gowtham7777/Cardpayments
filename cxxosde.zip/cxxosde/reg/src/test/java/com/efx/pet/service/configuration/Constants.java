package com.efx.pet.service.configuration;

/**
 * Created by rrk4 on 10/30/2017.
 */
public class Constants {

	public static final String SPRING_PROFILE_TEST = "test";
	public static final String GENERATE_QUIZ_SUCCESS_KBA_PACKAGE_PATH = "exampleKbaPackage_GenerateQuizResponseSuccess.xml";
	public static final String GENERATE_QUIZ_INVALID_KBA_PACKAGE_PATH = "exampleKbaPackage_GenerateQuizResponseInvalid.xml";
	public static final String GENERATE_QUIZ_EID_SYSTEM_ERROR_KBA_PACKAGE_PATH = "exampleKbaPackage_GenerateQuizResponseEidSystemError.xml";
	public static final String GENERATE_QUIZ_FAILURE_KBA_PACKAGE_PATH = "exampleKbaPackage_GenerateQuizResponseFailure.xml";
	public static final String CONSUMER_PATH = "exampleConsumer.json";
	public static final String PHONE_NUMBER_KEY = "phoneNumber";
    public static final String EMAIL_KEY = "email";
    public static final String PTP_PIN_KEY = "pin";
	public static final String GENERATE_QUIZ_SUCCESS_KBA_RESPONSE_PATH = "exampleKbaResponse_GenerateQuizSuccess.json";
	public static final String GENERATE_QUIZ_FAILURE_KBA_RESPONSE_PATH = "exampleKbaResponse_GenerateQuizFailure.json";
	public static final String SAVE_CONSUMER_ENDPOINT = "/rest/1.0/saveConsumer";
	public static final String CREATE_ACCOUNT_ENDPOINT = "/rest/1.0/createAccount";
    public static final String INITIATE_EMERGENCY_BREAK_ENDPOINT = "/rest/1.0/initiateEmergencyBreak";
	public static final String GET_QUIZ_ENDPOINT = "/rest/3.0/getQuiz";
	public static final String APPLICATION_JSON_UTF8 = "application/json;charset=utf-8";
	public static final String SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH = "exampleKbaPackage_SubmitAnswersSuccess.json";
    public static final String SUBMIT_ANSWERS_FAILURE_KBA_PACKAGE_PATH = "exampleKbaPackage_SubmitAnswersFailure.json";
    public static final String SUBMIT_ANSWERS_ENDPOINT = "/rest/3.0/submitAnswers";
	public static final String SUBMIT_ANSWERS_SUCCESS_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersSuccess.json";
	public static final String SUBMIT_ANSWERS_SUCCESS_TID_FLOW_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersSuccess_TidFlow.json";
	public static final String SUBMIT_ANSWERS_ERROR_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersError.json";
    public static final String SUBMIT_ANSWERS_ERROR_TIMEDOUT_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersErrorTimedOut.json";
    public static final String SUBMIT_ANSWERS_ERROR_VALIDATION_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersErrorValidation.json";
    public static final String SUBMIT_ANSWERS_ELIGIBILITY_FAIL_KBA_RESPONSE_PATH = "exampleKbaResponse_SubmitAnswersEligibilityFail.json";
    public static final String OTP_ENROLL_ENDPOINT = "/rest/2.0/enrollOTP";
	public static final String OTP_VALIDATE_PIN_ENDPOINT = "/rest/2.0/validatePin";
	public static final String ENROLL_OTP_SUCCESS_OTP_RESPONSE_PATH = "exampleOtpResponse_EnrollOtpSuccess.json";
	public static final String ENROLL_OTP_FAILURE_CONSUMER_NOT_IN_SESSION = "exampleOtpResponse_EnrollOtpFailure_ConsumerNotInSession.json";
	public static final String VALIDATE_PIN_SUCCESS_OTP_RESPONSE_PATH = "exampleOtpResponse_ValidatePinSuccess.json";
	public static final String VALIDATE_PIN_FAILURE_NO_PIN_IN_REQUEST = "exampleOtpResponse_ValidatePinFailure_RequestWithoutPin.json";
	public static final String VALIDATE_PIN_FAILURE_TRANSACTION_KEY_NOT_IN_SESSION = "exampleOtpResponse_ValidatePinFailure_TransactionKeyNotInSession.json";
	public static final String AGENT_BEGIN_PROXY_ENDPOINT = "/rest/1.0/beginProxy";
	public static final String AGENT_BEGIN_PROXY_PARAM = "proxy";
	public static final String INITIATE_PTP_ENDPOINT = "/rest/1.0/initiatePtp";
	public static final String VALIDATE_PTP_ENDPOINT = "/rest/1.0/submitPtp";
	public static final String GET_PRODUCT_BY_ID_ENDPOINT = "/rest/1.0/offer/product";
	public static final String GET_SSO_DETAILS_ENDPOINT = "/rest/1.0/ssoDetails";
    public static final String PTP_MESSAGE_PATH = "examplePtpMessage.json";
	public static final String PTP_VALIDATION_REQUEST_PATH = "examplePtpValidationRequest.json";
	public static final String INITIATE_PTP_SUCCESS_RESPONSE_PATH = "examplePtpResponse_InitiatePtpSuccess.json";
	public static final String VALIDATE_PTP_SUCCESS_RESPONSE_PATH = "examplePtpResponse_ValidatePtpSuccess.json";
    public static final String VALIDATE_PTP_RETRY_RESPONSE_PATH = "examplePtpResponse_ValidatePtpRetry.json";
    public static final String VALIDATE_PTP_EXPIRE_RESPONSE_PATH = "examplePtpResponse_ValidatePtpExpire.json";
	public static final String INITIATE_PTP_SYSTEM_ERROR_RESPONSE_PATH = "examplePtpResponse_InitiatePtpSystemError.json";
	public static final String PTP_VALIDATION_ERROR_RESPONSE_PATH = "examplePtpResponse_ValidationError.json";
	public static final String PTP_RECAPTCHA_ERROR_RESPONSE_PATH = "examplePtpResponse_ReCaptchaError.json";
	public static final String EBREAK_PROCESS_QUEUE_ENDPOINT = "/rest/1.0/processEmergencyBreakQueue";
	public static final String EBREAK_GET_JOB_STATUS_ENDPOINT = "/rest/1.0/getJobStatus";
    public static final String EBREAK_GET_ACTIVE_JOB_THREADS_ENDPOINT = "/rest/1.0/getActiveJobThreads";
	public static final String SESSION_TIMEOUT_ENDPOINT = "/rest/1.0/timeout";
	public static final String SESSION_KEEPALIVE_ENDPOINT = "/rest/1.0/keepalive";
	public static final String EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US = "examplePartnerTenantResponse_MY-EFX-US.json";
	public static final String EXAMPLE_PARTNER_TENANT_RESPONSE_LockAlert = "examplePartnerTenantResponse_LockAlert.json";
	public static final String EXAMPLE_PARTNER_TENANT_RESPONSE_UCSC = "examplePartnerTenantResponse_UCSC.json";
	public static final String EXAMPLE_ELIGIBILITY_SERVICE_IDP_RESPONSE_PTP_SUBMIT_PIN_PASS = "exampleIdpResponseDataResponse_PTP_SUBMIT_PIN_With_Status_PASS.json";
	public static final String EXAMPLE_ELIGIBILITY_SERVICE_IDP_RESPONSE_PTP_SUBMIT_PIN_FAIL = "exampleIdpResponseDataResponse_PTP_SUBMIT_PIN_With_Status_FAIL.json";
	public static final String GET_PRODUCT_BY_ID_SUCCESS = "exampleShoppingCart_getProductById_success.json";
	public static final String GET_PRODUCT_BY_ID_VALIDATION_ERROR = "exampleShoppingCart_getProductById_valerror.json";
	public static final String GET_PRODUCT_BY_ID_NOT_FOUND = "exampleShoppingCart_getProductById_notfound.json";
	public static final String GET_PRODUCT_BY_ID_SYSTEM_ERROR = "exampleShoppingCart_getProductById_systemErr.json";
	public static final String GET_SSO_DETAILS_SUCCESS = "example_ssoDetails_success.json";
	public static final String GET_SSO_DETAILS_FAILURE_4XX = "example_ssoDetails_systemError4xx.json";
    public static final String GET_SSO_DETAILS_WITH_UPSELLSKUID_SUCCESS = "example_ssoDetails_with_upsellSkuId_success.json";
    public static final String GET_SSO_DETAILS_FAILURE = "example_ssoDetails_systemError.json";
	public static final String GET_PRODUCT_BY_ID_NO_TERM_SUCCESS = "exampleShoppingCart_getProductById_No_term_success.json";
}
