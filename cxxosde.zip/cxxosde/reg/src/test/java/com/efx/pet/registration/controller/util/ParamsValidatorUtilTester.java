package com.efx.pet.registration.controller.util;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ParamsValidatorUtilTester {
  @Test
  public void testIsValidCampaignCode_NullCampaignCode() {
    String CampaignCode = null;
    assertFalse("isValidCampaignCode method returns true for a null Campaign Code", ParamsValidatorUtil.isValidCampaignCode(CampaignCode));
  }

  @Test
  public void testIsValidCampaignCode_EmptyCampaignCode() {
    String CampaignCode = "";
    assertFalse("isValidCampaignCode method returns true for a empty Campaign Code", ParamsValidatorUtil.isValidCampaignCode(CampaignCode));
  }

  @Test
  public void testIsValidCampaignCode_InvalidCampaignCode() {
    String CampaignCode = "invalid_";
    assertFalse("isValidCampaignCode method returns true for an invalid Campaign Code", ParamsValidatorUtil.isValidCampaignCode(CampaignCode));
  }

  @Test
  public void testIsValidCampaignCode_ValidCampaignCode() {
    String CampaignCode = "W20upd01";
    assertTrue("isValidCampaignCode method returns false for a valid Campaign Code", ParamsValidatorUtil.isValidCampaignCode(CampaignCode));
  }
}
