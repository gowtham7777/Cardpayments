package com.efx.pet.service.registration.controller;

import static org.mockito.Matchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.order.mgmt.OrderMgmtService;
import com.efx.pet.order.mgmt.domain.OrderMgmtException;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse.StatusCode;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {ShoppingCartController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
  "product.page:https://www.equifax.com/personal/products/",
})
public class ShoppingCartControllerTest {

  @Autowired
  private ShoppingCartController controllerUnderTest;

  private MockMvc mockMvc;

  @MockBean
  private SessionUtil sessionUtil;

  @MockBean
  private OrderMgmtService orderMgmtService;

  @Before
  public void setup() throws OrderMgmtException {
    this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
  }


  @Test
  public void testGetProductById_success() throws Exception {
    ProductOfferResponse productOfferResponse = JsonUtils.fromSanitizedJson(
        TestHelper.prettyToCompactJson(
            TestHelper.fetchClassPathFile(Constants.GET_PRODUCT_BY_ID_SUCCESS)),
        ProductOfferResponse.class);
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenReturn(productOfferResponse);
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(Long.valueOf(1));
    String responseString = testGetProductEndpoint(status().isOk(), Constants.GET_PRODUCT_BY_ID_SUCCESS, consumerContext);
    ProductOfferResponse filteredResponse = JsonUtils.fromSanitizedJson(responseString, ProductOfferResponse.class);
    Assert.assertEquals("Equifax Complete &trade; Premier Plan", filteredResponse.getProductOfferDetails().getProductName());
  }

  @Test
  public void testGetProductById_No_Term_success() throws Exception {
    ProductOfferResponse productOfferResponse = JsonUtils.fromSanitizedJson(
        TestHelper.prettyToCompactJson(
            TestHelper.fetchClassPathFile(Constants.GET_PRODUCT_BY_ID_NO_TERM_SUCCESS)),
        ProductOfferResponse.class);
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenReturn(productOfferResponse);
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(Long.valueOf(1));
    String responseString = testGetProductEndpoint(status().isOk(), Constants.GET_PRODUCT_BY_ID_NO_TERM_SUCCESS, consumerContext);
    ProductOfferResponse filteredResponse = JsonUtils.fromSanitizedJson(responseString, ProductOfferResponse.class);
    Assert.assertEquals("Equifax Complete &trade; Premier Plan", filteredResponse.getProductOfferDetails().getProductName());
    Assert.assertNull(filteredResponse.getProductOfferDetails().getProductTerm());
  }
  
  @Test
  public void testGetProductById_validation_Error() throws Exception {
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(null);
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenThrow(new OrderMgmtException(StatusCode.VALIDATION_ERROR, "Invalid ConsumerContext"));
    testGetProductEndpoint(status().isBadRequest(), Constants.GET_PRODUCT_BY_ID_VALIDATION_ERROR,
        consumerContext);
  }


  @Test
  public void testGetProduct_not_found() throws Exception {
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenThrow(new OrderMgmtException(StatusCode.NOT_FOUND, "Product not found"));
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(Long.valueOf(2));
    testGetProductEndpoint(status().isNotFound(), Constants.GET_PRODUCT_BY_ID_NOT_FOUND,
        consumerContext);
  }

  @Test
  public void testGetProduct_system_error() throws Exception {
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenThrow(new OrderMgmtException(StatusCode.SYSTEM_ERROR, "Unknown error"));
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(Long.valueOf(12345667));
    testGetProductEndpoint(status().isInternalServerError(),
        Constants.GET_PRODUCT_BY_ID_SYSTEM_ERROR, consumerContext);
  }

  @Test
  public void testGetProduct_Unknown_error() throws Exception {
    Mockito.when(orderMgmtService.getProductBySkuId(any(ConsumerContext.class)))
        .thenThrow(new RuntimeException("I/O Error connecting to the host"));
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setUpsellSkuId(Long.valueOf(12345667));
    testGetProductEndpoint(status().isInternalServerError(),
        Constants.GET_PRODUCT_BY_ID_SYSTEM_ERROR, consumerContext);
  }

  @Test
    public void whenRedirectToProductPage_thenExpectRedirectUrl() throws Exception {
    ConsumerContext consumerContext = new ConsumerContext("1111", "2222");
    HashMap<String, Object> sessionattr = new HashMap<String, Object>();
    sessionattr.put(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    mockMvc.perform(get("/rest/1.0/redirectToProductPage").header(CommonConstants.CONSUMER_CONTEXT, consumerContext).sessionAttrs(sessionattr))
      .andExpect(status().is3xxRedirection())
      .andExpect(redirectedUrl("https://www.equifax.com/personal/products/"));
  }


  private String testGetProductEndpoint(ResultMatcher expectStatus,
      String fileContentsExpectMatchResponse, ConsumerContext consumerContext) throws Exception {
    HashMap<String, Object> sessionattr = new HashMap<String, Object>();
    sessionattr.put(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    MvcResult result = mockMvc
        .perform(get(Constants.GET_PRODUCT_BY_ID_ENDPOINT).sessionAttrs(sessionattr)
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(expectStatus)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();
    String responseString = result.getResponse().getContentAsString();
    Assert.assertEquals(TestHelper.prettyToCompactJson(
        TestHelper.fetchClassPathFile(fileContentsExpectMatchResponse)), responseString);
    return responseString;
  }
}
