package com.efx.pet.service.registration.coreservice;

import static org.junit.Assert.assertNotNull;

import com.efx.pet.authentication.credentials.client.CredentialsOpenFeignClient;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.efx.pet.authentication.credentials.exception.CredentialsClientException;
import com.efx.pet.authentication.domain.enums.CredentialsStatusEnum;
import com.efx.pet.authentication.domain.request.CredentialsCreateRequest;
import com.efx.pet.authentication.domain.response.CredentialsResponse;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.test.common.TestConfigurationBase;
import com.efx.pet.utility.utils.JsonUtils;

/**
 * Created by lxg90 on 7/3/2018.
 */
@ActiveProfiles(Constants.SPRING_PROFILE_TEST)
@RunWith(SpringJUnit4ClassRunner.class)
@EnableFeignClients
public class AuthGatewayTest extends TestConfigurationBase {

  @Autowired
  private CredentialsOpenFeignClient credentialFeignClient;

  @Before
  public void setUp() throws Exception {
      System.setProperty("com.efx.pet.authentication.gateway.credentials.uri.base",
        "https://aptu2lc9a009.app.c9.equifax.com:9780");
  }
  /**
   * This is used to test Auth-Gateway end2end locally to verify Auth-Geteway service,
   * commented our during jenkin build
   */
  @Ignore
  @Test
  public void testAuthGateway() {
    System.out.println("Start testing AuthGateway...");
    CredentialsCreateRequest request = new CredentialsCreateRequest();
    request.setCustomerKey("f25e8c70-69b1-4a29-9aa8-6f86e5cde3a112");
    request.setPassword("Ilosde0fasdf@");
    request.setUserName("lpg0714444@gmail.com");
    System.out.println("CreateAccountRequest : " + JsonUtils.toJson(request));
    ResponseEntity<CredentialsResponse> response = null;
    try {
      response = credentialFeignClient.create(request);
      if (response != null && response.getBody() != null &&
        response.getBody().getCredentialsStatus() != null) {
        System.out.println("CreateAccount Response : " + JsonUtils.toJson(response));
        CredentialsStatusEnum status = response.getBody().getCredentialsStatus();
        System.out.println("CreateAccount Response Status: " + status);
      }
      assertNotNull(response);
      assertNotNull(response.getBody());
      System.out.println("Result: " + response.getBody());
    } catch (CredentialsClientException e) {
      System.out.println("Exception=========");
      System.out.println("Status : " + e.getMessage());
      if (e.getCredentialsStatusEnum() == CredentialsStatusEnum.CUSTOMERKEY_ALREADY_EXISTS){
        System.out.println("Status: " + CredentialsStatusEnum.CUSTOMERKEY_ALREADY_EXISTS);
      } else if (e.getStatus() == HttpStatus.BAD_REQUEST.value()) {
        System.out.println("Status: BAD_REQUEST");
      }
    }
  }

  @Ignore
  @Test
  public void testAgetCredentials() {
    System.out.println("Start testing testAgetCredentials...");
    ResponseEntity<CredentialsResponse> response = null;
    try {
      response = credentialFeignClient.getCredentials("33e05562-12e0-4d31-8725-cc7f9b2a06bc");
      System.out.println("CreateAccountResponse : " + JsonUtils.toJson(response));
      if (response != null && response.getBody() != null &&
        response.getBody().getCredentialsStatus() != null) {
        System.out.println("CreateAccount Response : " + JsonUtils.toJson(response));
        CredentialsStatusEnum status = response.getBody().getCredentialsStatus();
        System.out.println("CreateAccount Response Status: " + status);
      }
      assertNotNull(response);
      assertNotNull(response.getBody());
      System.out.println("Result: " + response.getBody());
    } catch (CredentialsClientException e) {
      System.out.println("Exception=========");
      System.out.println("Status : " + e.getStatus());
      if (e.getCredentialsStatusEnum() == CredentialsStatusEnum.CUSTOMER_NOT_FOUND) {
        System.out.println("Status: " + CredentialsStatusEnum.CUSTOMER_NOT_FOUND);
      } else if (e.getStatus() == HttpStatus.BAD_REQUEST.value()) {
        System.out.println("Status: BAD_REQUEST");
      }
    }
  }

  @Ignore
  @Test
  public void testExistAccount() {
    System.out.println("Start testing AuthGateway getCredentials...");
    CredentialsCreateRequest request = new CredentialsCreateRequest();
    request.setCustomerKey("");
    request.setPassword("Ilosde0fasdf@");
    request.setUserName("lpg0726001@gmail.com");
    System.out.println("CreateAccountRequest : " + JsonUtils.toJson(request));
    ResponseEntity<CredentialsResponse> response = null;
    try {
      response = credentialFeignClient.create(request);
      if (response != null && response.getBody() != null &&
        response.getBody().getCredentialsId() != null) {
        System.out.println("CreateAccount Response : " + JsonUtils.toJson(response));
        CredentialsStatusEnum status = response.getBody().getCredentialsStatus();
        System.out.println("CreateAccount Response Status: " + status);
      }
      assertNotNull(response);
      assertNotNull(response.getBody());
      System.out.println("Result: " + response.getBody());
    }
    catch (CredentialsClientException ex){
      String msg = ex.getMessage();
      if (ex.getCredentialsStatusEnum() == CredentialsStatusEnum.CUSTOMERKEY_ALREADY_EXISTS) {
        System.out.println("UserAccountResponse.CUSTOMERKEY_ALREADY_EXISTS");
      } else if (ex.getStatus() == HttpStatus.BAD_REQUEST.value()) {
        System.out.println("UserAccountResponse.BAD_REQUEST");
      } else {
        System.out.println("UserAccountResponse.SYSTEM_ERROR");
      }
    }
    catch (Exception ex) {
      System.out.println("UserAccountResponse.SYSTEM_ERROR");
    }
    finally {
      try {
        response = credentialFeignClient.getCredentials(request.getCustomerKey());
        if (response.getStatusCode() == HttpStatus.OK) {
          System.out.println("getCredentials Response : " + JsonUtils.toJson(response));
        } else {
          System.out.println("Not found: " + JsonUtils.toJson(response));
        }
      } catch (CredentialsClientException e) {
        System.out.println("Exception=========");
        System.out.println("Status : " + e.getStatus());
        if (e.getCredentialsStatusEnum() == CredentialsStatusEnum.CUSTOMER_NOT_FOUND) {
          System.out.println("Status: " + CredentialsStatusEnum.CUSTOMER_NOT_FOUND);
        } else if (e.getStatus() == HttpStatus.BAD_REQUEST.value()) {
          System.out.println("Status: BAD_REQUEST");
        }
      }
      catch (Exception ex) {
        System.out.println("System Error");
      }
    }
  }
}
