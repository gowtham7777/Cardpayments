package com.efx.pet.service.configuration;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.mockito.Mockito;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.efx.pet.client.eligibility.EligibilityServiceClient;
import com.efx.pet.order.mgmt.OrderMgmtService;
import com.efx.pet.utility.ConsumerValidator;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.client.partnertenant.PartnerTenantLookupServiceClient;
import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.helper.PtpIdProofingHelper;
import com.efx.pet.service.idproofing.processor.IdpProcessor;
import com.efx.pet.service.partnertenant.entity.PartnerTenant;
import com.efx.pet.service.partnertenant.operations.PartnerTenantResponse;
import com.efx.pet.service.partnertenant.operations.ServiceResponse;
import com.efx.pet.service.policies.PoliciesService;
import com.efx.pet.service.registration.ReCaptchaService;
import com.efx.pet.service.registration.controller.processor.CreateAccountProcessor;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.flow.FlowValidator;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.AccountSetupMessageUtility;
import com.efx.pet.utility.cache.Cache;
import com.efx.pet.utility.cache.redis.util.PiiToHashUtility;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by rrk4 on 10/28/2017.
 */

@Profile(Constants.SPRING_PROFILE_TEST)
@Configuration
public class TestProfileConfig {
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(TestProfileConfig.class);

	@Bean
	@Primary
	public SessionUtil sessionUtil() {
		return mock(SessionUtil.class);
	}

	@Bean
	public ObtainIpUtility obtainIpUtility() {
		return mock(ObtainIpUtility.class);
	}

	@Bean
	public FlowValidator flowValidator() {
		return mock(FlowValidator.class);
	}

	@Bean
    public OrderMgmtService orderManagementService() {
        return mock(OrderMgmtService.class);
	}

	@Bean
    public EncryptUtility encryptUtility() {
        return mock(EncryptUtility.class);
	}

	@Bean
    public CreateAccountProcessor createAccountProcessor() {
        return mock(CreateAccountProcessor.class);
	}

	@Bean
    public PiiToHashUtility piiToHashUtility() {
        return mock(PiiToHashUtility.class);
	}

	@Bean
    public RegistrationService registrationService() {
        return mock(RegistrationService.class);
	}

	@Bean
    public IdProofingService idProofingService() {
        return mock(IdProofingService.class);
	}

	@Bean
	public Cache cache() {
        return mock(Cache.class);
	}

	@Bean
	public BuildProperties buildProperties(){
		return mock(BuildProperties.class);
	}

    @Bean
    @Primary
    public PartnerTenantLookupServiceClient partnerTenantLookupClient() throws Exception {
    	LOGGER.debug("Mock PartnerTenantLookupServiceClient as well as response, needed across all spring boot tests.");
    	PartnerTenantLookupServiceClient partnerTenantLookupServiceClient = Mockito.mock(PartnerTenantLookupServiceClient.class);
    	PartnerTenantResponse partnerTenantResponse = new PartnerTenantResponse();
    	partnerTenantResponse.setServiceStatus(ServiceResponse.Status.SUCCESS);
    	String partnerTenantResponseJson = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US));
    	ObjectMapper mapper = new ObjectMapper();
    	List<PartnerTenant> partnerTenants = new ArrayList<PartnerTenant>();
    	partnerTenants.add(mapper.readValue(partnerTenantResponseJson, PartnerTenant.class));
    	partnerTenantResponse.setPartnerTenants(partnerTenants);
    	when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);
        return partnerTenantLookupServiceClient;
	}

	@Bean
	public ConsumerService consumerService(){
		return mock(ConsumerService.class);
	}

	@Bean
	public EligibilityServiceClient eligibilityServiceClient(){
		return mock(EligibilityServiceClient.class);
	}

	@Bean
	public ConsumerValidator consumerValidator(){
		return mock(ConsumerValidator.class);
	}

	@Bean
	public IdpProcessor idpProcessor(){
		return mock(IdpProcessor.class);
	}

	@Bean
	public AccountSetupMessageUtility accountSetupMessageUtility(){
		return mock(AccountSetupMessageUtility.class);
	}

	@Bean
	public PtpIdProofingHelper ptpIdProofingHelper(){
		return mock(PtpIdProofingHelper.class);
	}

	@Bean
	public PartnerTenantClient partnerTenantClient(){
		return mock(PartnerTenantClient.class);
	}

	@Bean
	public ReCaptchaService reCaptchaService(){
		return mock(ReCaptchaService.class);
	}
	
	@Bean
	public PoliciesService policiesService() { 
		return mock(PoliciesService.class);
	}
}
