package com.efx.pet.service.registration.flow;

import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.registration.controller.KbaController;
import com.efx.pet.service.registration.controller.OTPController;
import com.efx.pet.service.registration.controller.SingleSignOnController;
import com.efx.pet.service.registration.controller.processor.SingleSignOnProcessor;
import com.efx.pet.service.registration.filter.DomainFilter;
import com.efx.pet.service.registration.filter.HTMLResponseFilter;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import static org.mockito.Mockito.mock;

@EnableWebMvc
@TestConfiguration
@EnableConfigurationProperties(value = FlowMapProperties.class)
public class WebConfiguration {
  @Bean
  public IdProofingService idProofingService() {
    return mock(IdProofingService.class);
  }

  @Bean
  public SessionUtil sessionUtil() {
    return mock(SessionUtil.class);
  }

  @Bean
  public EncryptUtility encryptUtility() {
    return mock(EncryptUtility.class);
  }

  @Bean
  public OTPController OTPController() {
    return new OTPController();
  }

  @Bean
  public KbaController kbaController() {
    return new KbaController();
  }

  @Bean
  public WebConfigTest.TestApplication testApplication(){
    return new WebConfigTest.TestApplication();
  }

  @Bean
  public SingleSignOnController singleSignOnController(){
    return new SingleSignOnController(mock(SingleSignOnProcessor.class));
  }
  @Bean
  public HTMLResponseFilter HTMLResponseFilter(){
  return mock(HTMLResponseFilter.class);
}
  @Bean
  public DomainFilter DomainFilter(){
    return mock(DomainFilter.class);
  }

  @Bean
  public FlowValidator FlowValidator(){
    return new FlowValidator();
  }

  @Bean
  public FlowInterceptorFilter FlowInterceptorFilter(){
    return new FlowInterceptorFilter();
  }

  @Bean
  public ServletWebServerFactory ServletWebServerFactory(){
    return new TomcatServletWebServerFactory();
  }

  @Bean
  public PropertySourcesPlaceholderConfigurer PropertySourcesPlaceholderConfigurer(){
    return new PropertySourcesPlaceholderConfigurer();
  }
}
