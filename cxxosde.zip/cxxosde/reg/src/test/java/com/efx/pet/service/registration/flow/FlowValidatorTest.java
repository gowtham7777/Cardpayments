package com.efx.pet.service.registration.flow;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;


@RunWith(MockitoJUnitRunner.class)
public class FlowValidatorTest {

    @InjectMocks
    private FlowValidator flowValidator;

    @Mock
    private FlowMapProperties flowMapProps;

    Map<String, String> formattedURIMap = new HashMap<>();

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        formattedURIMap.put("/api/page2", "/api/page1");
        formattedURIMap.put("/api/page3", "/api/page2");
        ReflectionTestUtils.setField(flowValidator, "formattedURIMap", formattedURIMap);
    }

    @Test
    public void testIsThisRequestAllowed() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page2", "/api/page1");
        assertTrue(proceed);
    }

    @Test
    public void testIsThisRequestAllowedNotIntheFlow() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page10", "/api/page1");
        assertTrue(proceed);
    }

    @Test
    public void testIsThisRequestAllowedFalse() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page3", "/api/page1");
        assertFalse(proceed);
    }

    @Test
    public void testIsThisRequestAllowedFalseRequestURINull() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page3", null);
        assertFalse(proceed);
    }

    @Test
    public void testIsThisRequestAllowedFalseRequestURIEmpty() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page3", "");
        assertFalse(proceed);
    }

    @Test
    public void testIsThisRequestAllowedFlowURIEmpty() {
        boolean proceed = flowValidator.isThisRequestAllowed("/api/page2", "/api/page1");
        assertTrue(proceed);
    }
}
