package com.efx.pet.service.registration.controller;

import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.TestProfileConfig;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.servlet.http.HttpServletRequest;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {CustomErrorController.class, TestProfileConfig.class})
public class CustomErrorControllerTest {

  @Autowired
  private CustomErrorController controllerUnderTest;

  @MockBean
  private SessionUtil sessionUtil;

  private MockMvc mockMvc;

  @Before
  public void setup() {
    this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
  }

  @Test
  public void testRenderErrorPageInvalidateSession() throws Exception {

    mockMvc.perform(get("/error"))
      .andReturn();

    verify(sessionUtil, times(1)).invalidateSession(any(HttpServletRequest.class));
  }

  @Test
  public void testRenderErrorPageHttpStatus4xxError() throws Exception {

    mockMvc.perform(get("/error")
      .requestAttr("javax.servlet.error.status_code", HttpStatus.UNAUTHORIZED.value()))
      .andExpect(status().isOk())
      .andExpect(view().name("html/error/4xx.html"))
      .andReturn();

    verify(sessionUtil, times(1)).invalidateSession(any(HttpServletRequest.class));
  }

  @Test
  public void testRenderErrorPageHttpStatus5xxError() throws Exception {

    mockMvc.perform(get("/error")
      .requestAttr("javax.servlet.error.status_code", HttpStatus.INTERNAL_SERVER_ERROR.value()))
      .andExpect(status().isOk())
      .andExpect(view().name("html/system-error.html"))
      .andReturn();

    verify(sessionUtil, times(1)).invalidateSession(any(HttpServletRequest.class));
  }

  @Test
  public void testRenderErrorPageHttpStatusGenericError() throws Exception {

    mockMvc.perform(get("/error"))
      .andExpect(status().isOk())
      .andExpect(view().name("/error/generic.html"))
      .andReturn();

    verify(sessionUtil, times(1)).invalidateSession(any(HttpServletRequest.class));
  }
}
