package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.KbaPackage;
import com.efx.pet.domain.OtpMethod;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.registration.OTPResponse;
import com.efx.pet.service.registration.OTPResponse.StatusCode;
import com.efx.pet.service.registration.domain.EnrollOTPRequest;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.service.registration.domain.OTPConsumer;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.domain.tid.common.IDPData;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {OTPController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
	"com.efx.pet.service.registration.otp.resend.max.count:2",
	"com.efx.pet.service.registration.otp.retry.max.count:3"
})
public class OTPControllerTest {

    private MockMvc mockMvc;

    @Autowired
    OTPController controllerUnderTest;

    @MockBean
    IdProofingService idProofingService;

    @MockBean
    EncryptUtility encryptUtility;

    @MockBean
    SessionUtil sessionUtil;

    @Before
    public void setup() {
      this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    /*
     * Tests for enrollOtp endpoint
     */

    @Test
    public void testEnrollOtp_throwsRuntimeException_SystemError() throws Exception {
      Mockito.when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenThrow(new RuntimeException());
      MvcResult result = testEnrollOtp(status().isInternalServerError());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_consumerIsNull_returnsEnrollOtpSystemError() throws Exception {
      HashMap<String, Object> sessionattr = new HashMap<String, Object>();
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      sessionattr.put(CommonConstants.CONSUMER_DATA, getEncryptedConsumer());
      sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

      MvcResult result = mockMvc.perform(post(Constants.OTP_ENROLL_ENDPOINT).sessionAttrs(sessionattr)
          .contentType(MediaType.APPLICATION_JSON)
          .content(testEnrollOTPRequest_getBlankPinTypeString()))
          .andExpect(status().isInternalServerError())
          .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
          .andReturn();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_otpMethodIsNull_returnsEnrollOtpSystemError() throws Exception {
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      MvcResult result = testEnrollOtp(status().isInternalServerError(), getEncryptedConsumer());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_otpMethodIsEmailText_blankPinType_returnsEnrollOtpSystemError() throws Exception {
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      MvcResult result = testEnrollOtp(status().isInternalServerError(), getEncryptedConsumer());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_otpMethodIsEmailText_EmailPinType_returnsEnrollOtpSystemError() throws Exception {
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      HashMap<String, Object> sessionattr = new HashMap<String, Object>();
      sessionattr.put(CommonConstants.CONSUMER_DATA, getEncryptedConsumer());
      sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
      MvcResult result = mockMvc.perform(post(Constants.OTP_ENROLL_ENDPOINT).sessionAttrs(sessionattr)
        .contentType(MediaType.APPLICATION_JSON)
        .content(testEnrollOTPRequest_getPinTypeString(OtpMethod.EMAIL.toString())))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_otpMethodIsEmailText_TextPinType_returnsEnrollOtpSystemError() throws Exception {
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      HashMap<String, Object> sessionattr = new HashMap<String, Object>();
      sessionattr.put(CommonConstants.CONSUMER_DATA, getEncryptedConsumer());
      sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
      MvcResult result = mockMvc.perform(post(Constants.OTP_ENROLL_ENDPOINT).sessionAttrs(sessionattr)
        .contentType(MediaType.APPLICATION_JSON)
        .content(testEnrollOTPRequest_getPinTypeString(OtpMethod.EMAIL.toString())))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_otpMethodIsEmailText_TextPinType_returnsEnrollOtpSuccess() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      MvcResult result = testEnrollOtp(status().isOk(), getEncryptedConsumer(), OtpMethod.EMAIL.toString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_RESEND_ALLOWED_INIT, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsOtpEnrollSuccess_otpResendAllowedInit_textPinType_returnsEnrollOtpResendAllowedInit() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      MvcResult result = testEnrollOtp(status().isOk(), testEnrollOtp_createEncryptedConsumerWithOtpEmailMethodAndOtpResendCount(0), OtpMethod.TEXT.toString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_RESEND_ALLOWED_INIT, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsKbaGetQuizSuccessOtpPinInitiationFail() throws Exception {
      KbaPackage kbaPackage = new KbaPackage();
      kbaPackage.setQuizIdentifier("1");
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_INITIATION_FAIL, false, kbaPackage);
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
      MvcResult result = testEnrollOtp();
      KbaResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
      Assert.assertEquals(KbaResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_INITIATION_FAIL, response.getStatusCode());
      Assert.assertNotNull(response.getQuizIdentifier());
    }

    @Test
    public void testEnrollOtp_returnsOtpEnrollSuccess_otpResendMaxedOut_returnsEnrollOtpResendMax() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(2, null));
      MvcResult result = testEnrollOtp(testEnrollOtp_createEncryptedConsumerWithOtpEmailMethodAndOtpResendCount(2));
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_RESEND_MAX, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsOtpEnrollSuccess_otpResendAllowedInit_returnsEnrollOtpResendAllowedInit() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testEnrollOtp(testEnrollOtp_createEncryptedConsumerWithOtpEmailMethodAndOtpResendCount(0));
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_RESEND_ALLOWED_INIT, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsOtpEnrollSuccess_otpResendAllowed_returnsEnrollOtpResendAllowed() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(1, null));
      MvcResult result = testEnrollOtp(testEnrollOtp_createEncryptedConsumerWithOtpEmailMethodAndOtpResendCount(1));
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_RESEND_ALLOWED, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsPinToPostPrimarySuccess() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY, false);
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testEnrollOtp();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.PIN_TO_POST_PRIMARY, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsKbaQuizError() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR, false);
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testEnrollOtp(status().isAccepted());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.KBA_QUIZ_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsNull_SystemError() throws Exception {
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(null);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testEnrollOtp(status().isInternalServerError());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testEnrollOtp_returnsUnknownStatus_SystemError() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.ELIGIBILITY_CHECK_NO_HIT, false); //synonymous with unknown
      when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testEnrollOtp(status().isInternalServerError());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.ENROLL_OTP_SYSTEM_ERROR, response.getStatusCode());
    }


    /*
     * Tests for validatePin endpoint
     */

    @Test
    public void testValidatePin_invalidPin_ValidationError() throws Exception {
      // OTPConsumer does not have pin
      String otpConsumerString = TestHelper.prettyToCompactJson(JsonUtils.toJson(new OTPConsumer()));
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testValidatePin(status().isBadRequest(), otpConsumerString);
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_ERROR, response.getStatusCode());
    }

    @Test
    public void testValidatePin_missingOtpTransactionKey_SystemError() throws Exception {
      // Consumer does not have transactionKey
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testValidatePin(status().isInternalServerError(), testValidatePin_getSuccessfulOtpConsumerString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testValidatePin_throwsRuntimeException_SystemError() throws Exception {
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenThrow(new RuntimeException());
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testValidatePin(status().isInternalServerError(), testValidatePin_getSuccessfulOtpConsumerString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testValidatePin_returnsNull_SystemError() throws Exception {
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(null);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testValidatePin(status().isInternalServerError(), testValidatePin_getSuccessfulOtpConsumerString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testValidatePin_returnsErrorStatus_SystemError() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.ID_PROOFING_SYSTEM_ERROR);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, null));
      MvcResult result = testValidatePin(status().isInternalServerError(), testValidatePin_getSuccessfulOtpConsumerString());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
    }

    @Test
    public void testValidatePin_returnsOtpValidatePinSuccessWithActivationUrl() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_VALIDATE_PIN_SUCCESS);
      String activationURL = "testActivationUrl";
      idProofingResponse.setActivationUrl(activationURL);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, "key"));
      MvcResult result = testValidatePin();
      Mockito.verify(sessionUtil, Mockito.times(1)).invalidateSession(result.getRequest());
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_PIN_SUCCESS, response.getStatusCode());
      Assert.assertEquals(activationURL, response.getDestinationUrl());

    }

    @Test
    public void testValidatePin_returnsOtpValidatePinSuccessWithoutActivationUrl() throws Exception {
	    IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_VALIDATE_PIN_SUCCESS);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, "key"));
      MvcResult result = testValidatePin();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Mockito.verify(sessionUtil, Mockito.times(0)).invalidateSession(result.getRequest());
      Assert.assertEquals(StatusCode.OTP_VALIDATE_PIN_SUCCESS, response.getStatusCode());
      Assert.assertNull(response.getDestinationUrl());
    }

    @Test
    public void testValidatePin_returnsOtpValidateResubmitWithResendMax() throws Exception {
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, "key"));

      MvcResult result = testValidatePin();
      OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
      Assert.assertEquals(StatusCode.OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX, response.getStatusCode());
    }

    @Test
    public void testValidatePin_returnsKbaGetQuizSuccessOtpPinRetryMax() throws Exception {
      KbaPackage kbaPackage = new KbaPackage();
      kbaPackage.setQuizIdentifier("1");
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_RETRY_MAX, false, kbaPackage);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, "key"));
      MvcResult result = testValidatePin();
      KbaResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
      Assert.assertEquals(KbaResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_RETRY_MAX, response.getStatusCode());
      Assert.assertNotNull(response.getQuizIdentifier());
    }

    @Test
    public void testValidatePin_returnsKbaGetQuizSuccessOtpPinValidationFailUnknown() throws Exception {
      KbaPackage kbaPackage = new KbaPackage();
      kbaPackage.setQuizIdentifier("1");
      IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_VALIDATION_FAIL_UNKNOWN, false, kbaPackage);
      when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
        .thenReturn(getPlainConsumer(0, "key"));
      MvcResult result = testValidatePin();
      KbaResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
      Assert.assertEquals(KbaResponse.StatusCode.KBA_GET_QUIZ_SUCCESS_OTP_PIN_VALIDATION_FAIL_UNKNOWN, response.getStatusCode());
      Assert.assertNotNull(response.getQuizIdentifier());
    }

  @Test
  public void testValidatePin_unhandledException_SystemError() throws Exception {
    String otpConsumerString = TestHelper.prettyToCompactJson(JsonUtils.toJson("{"));
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(otpConsumerString);
    MvcResult result = testValidatePin(status().isInternalServerError(), otpConsumerString);
    OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
    Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
  }

  @Test
  public void testValidatePin_returnsPinToPostPrimarySuccess() throws Exception {
	  IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY, false);
    when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(getPlainConsumer(0, "key"));
    MvcResult result = testValidatePin();
    OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
    Assert.assertEquals(StatusCode.PIN_TO_POST_PRIMARY, response.getStatusCode());
  }

  @Test
  public void testValidatePin_returnsKbaQuizError() throws Exception {
	  IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR, false);
    when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(getPlainConsumer(0, "key"));
    MvcResult result = testValidatePin(status().isAccepted(), testValidatePin_getSuccessfulOtpConsumerString());
    OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
    Assert.assertEquals(StatusCode.KBA_QUIZ_ERROR, response.getStatusCode());
  }

  @Test
  public void testValidatePin_returnsUnknownStatus_SystemError() throws Exception {
	  IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.ELIGIBILITY_CHECK_NO_HIT, false); //synonymous with unknown
    when(idProofingService.validateOtp(any(String.class), any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(getPlainConsumer(0, "key"));
    MvcResult result = testValidatePin(status().isInternalServerError(), testValidatePin_getSuccessfulOtpConsumerString());
    OTPResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), OTPResponse.class);
    Assert.assertEquals(StatusCode.OTP_VALIDATE_SYSTEM_ERROR, response.getStatusCode());
  }

  /*
   * Helper methods for testing enrollOtp endpoint
   */

    public MvcResult testEnrollOtp() throws Exception {
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      String encryptedConsumer = "ENC(" + consumerString + ")";
      return testEnrollOtp(status().isOk(), encryptedConsumer);
    }

    public MvcResult testEnrollOtp(String encryptedConsumer) throws Exception {
      return testEnrollOtp(status().isOk(), encryptedConsumer);
    }

    public MvcResult testEnrollOtp(ResultMatcher expectStatus) throws Exception {
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      String encryptedConsumer = "ENC(" + consumerString + ")";
      return testEnrollOtp(expectStatus, encryptedConsumer);
    }

    public MvcResult testEnrollOtp(ResultMatcher expectStatus, String encryptedConsumer) throws Exception {
      return testEnrollOtp(expectStatus, encryptedConsumer, null);
    }

    public MvcResult testEnrollOtp(ResultMatcher expectStatus, String encryptedConsumer, String pinType) throws Exception {
      HashMap<String, Object> sessionattr = new HashMap<String, Object>();
      sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
      sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
      sessionattr.put(CommonConstants.IDP_DATA, new IDPData());

      return mockMvc.perform(post(Constants.OTP_ENROLL_ENDPOINT).sessionAttrs(sessionattr)
        .contentType(MediaType.APPLICATION_JSON)
        .content(StringUtils.isBlank(pinType)? testEnrollOTPRequest_getBlankPinTypeString(): testEnrollOTPRequest_getPinTypeString(pinType)))
        .andExpect(expectStatus)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
    }

    public String testEnrollOtp_createEncryptedConsumerWithOtpEmailMethodAndOtpResendCount(Integer otpResendCount) throws Exception {
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      Consumer consumer = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(consumerString), Consumer.class);
      if (otpResendCount == null){
        consumer.setOtpResendCount(null);
      } else {
        consumer.setOtpResendCount(otpResendCount.byteValue());
      }
      return "ENC(" + JsonUtils.toJson(consumer) + ")";
    }

    /*
     * Helper methods for testing validatePin endpoint
     */

    public MvcResult testValidatePin() throws Exception {
      return testValidatePin(status().isOk(), testValidatePin_getSuccessfulOtpConsumerString());
    }

    public MvcResult testValidatePin(ResultMatcher expectStatus, String otpConsumerString) throws Exception {
      HashMap<String, Object> sessionattr = new HashMap<String, Object>();
      sessionattr.put(CommonConstants.CONSUMER_DATA, getEncryptedConsumer());
      sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
      sessionattr.put(CommonConstants.IDP_DATA, new IDPData());

      return mockMvc.perform(post(Constants.OTP_VALIDATE_PIN_ENDPOINT)
        .sessionAttrs(sessionattr)
        .contentType(MediaType.APPLICATION_JSON)
        .content(otpConsumerString)
      )
        .andExpect(expectStatus)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
    }


    public String testValidatePin_getSuccessfulOtpConsumerString() throws Exception {
      OTPConsumer otpConsumer = new OTPConsumer();
      otpConsumer.setPin("012340");
      return TestHelper.prettyToCompactJson(JsonUtils.toJson(otpConsumer));
    }

    public Consumer testValidatePin_getSuccessfulConsumer() throws Exception {
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
      consumer.setOtpTransactionKey("testOtpTransactionKey");
      return consumer;
    }

    public String testEnrollOTPRequest_getPinTypeString(String pinType) throws Exception {
        EnrollOTPRequest otpRequest = new EnrollOTPRequest();
        if(StringUtils.isNotBlank(pinType))
        	otpRequest.setPinType(pinType);
        return TestHelper.prettyToCompactJson(JsonUtils.toJson(otpRequest));
      }

    public String testEnrollOTPRequest_getBlankPinTypeString() throws Exception {
    	return testEnrollOTPRequest_getPinTypeString(null);
      }

    public String getPlainConsumer(Integer count, String key) throws Exception {
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
      consumer.setConsumerKey("newTestConsumerKey");
      consumer.setOtpResendCount(count.byteValue());
      if (StringUtils.isNotEmpty(key)) {
        consumer.setOtpTransactionKey(key);
      }
      return JsonUtils.toJson(consumer);
    }

    public String getEncryptedConsumer() throws Exception {
      return "ENC(" + TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)) + ")";
    }

    private ConsumerContext createMockConsumerContext() {
      ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
      consumerContext.setPartnerId("EFX-DIRECT-US");
      consumerContext.setTenantId("EFX-US");
      consumerContext.setChannel(ChannelEnum.DESKTOP);
      consumerContext.setDefaultLocale("en");
      return consumerContext;
    }
}
