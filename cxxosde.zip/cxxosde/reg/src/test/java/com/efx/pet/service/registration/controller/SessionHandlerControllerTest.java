package com.efx.pet.service.registration.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.utility.CommonConstants;

/*
 * Created by rrk4 on 12/15/2017.
 */

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {SessionHandlerController.class})
public class SessionHandlerControllerTest {

	@Autowired
	private SessionHandlerController controllerUnderTest;

	private MockMvc mockMvc;

	@Before
	public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
	}

	@Test
	public void testTimeOutSuccess() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		MvcResult result = mockMvc.perform(get(Constants.SESSION_TIMEOUT_ENDPOINT)
				.sessionAttrs(sessionattr))
				.andExpect(status().isOk())
				.andReturn();
		Assert.assertNull("Current session is not null", result.getRequest().getSession(false));
	}

	@Test
	public void testKeepAliveSuccess() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		mockMvc.perform(get(Constants.SESSION_KEEPALIVE_ENDPOINT)
				.sessionAttrs(sessionattr))
				.andExpect(status().isOk())
				.andReturn();
	}

    private ConsumerContext createMockConsumerContext() {
        ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
        consumerContext.setPartnerId("EFX-DIRECT-US");
        consumerContext.setTenantId("EFX-US");
        consumerContext.setDefaultLocale("en");
        return consumerContext;
      }
}
