package com.efx.pet.service.registration.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.domain.sso.SingleSignOnDetails;
import com.efx.domain.sso.TokenInfo;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.registration.controller.processor.SingleSignOnProcessor;
import com.efx.pet.service.registration.domain.SingleSignOnResponse.StatusCode;
import com.efx.pet.service.registration.exception.SingleSignOnException;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.utils.SanitizedJsonUtils;


@RunWith(MockitoJUnitRunner.class)
public class SingleSignOnControllerTest {

  MockMvc mockMvc;
  SingleSignOnProcessor singleSignOnProcessor;
  SingleSignOnController controllerUnderTest;

  @Before
  public void setup() {
    this.singleSignOnProcessor = Mockito.mock(SingleSignOnProcessor.class);
    this.controllerUnderTest = new SingleSignOnController(singleSignOnProcessor);
    this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
  }

  @Test
  public void test_success_tokenDetails() throws Exception {
    ConsumerContext consumerContext = createMockConsumerContext();
    when(singleSignOnProcessor.getDecryptedConsumer(any(String.class))).thenReturn(mockConsumer());
    when(singleSignOnProcessor.mapResponse(any(Consumer.class), any(ConsumerContext.class))).thenReturn(mockResponse());

    String responseString = testSingleSignOnDetailsEndpoint(status().isOk(), Constants.GET_SSO_DETAILS_SUCCESS, consumerContext);

    Assert.assertNotNull(responseString);
  }

  @Test
  public void test_success_tokenDetails_with_upsellSkuId() throws Exception {
    ConsumerContext consumerContext = createMockConsumerContextWithUpsellSkuId();
    when(singleSignOnProcessor.getDecryptedConsumer(any(String.class))).thenReturn(mockConsumer());
    when(singleSignOnProcessor.mapResponse(any(Consumer.class), any(ConsumerContext.class))).thenReturn(mockResponseWithUpsellSkuId());

    String responseString = testSingleSignOnDetailsEndpoint(status().isOk(), Constants.GET_SSO_DETAILS_WITH_UPSELLSKUID_SUCCESS, consumerContext);

    Assert.assertNotNull(responseString);
  }

  @Test
  public void test_exceptionHandler5xx() throws Exception {
    ConsumerContext consumerContext = createMockConsumerContext();
    when(singleSignOnProcessor.getDecryptedConsumer(any(String.class))).thenReturn(mockConsumer());
    doThrow(new SingleSignOnException(StatusCode.SSO_SYSTEM_ERROR, "mock-error")).when(singleSignOnProcessor)
        .mapResponse(any(Consumer.class), any(ConsumerContext.class));

    String responseString = testSingleSignOnDetailsEndpoint(status().isInternalServerError(),
        Constants.GET_SSO_DETAILS_FAILURE, consumerContext);

    Assert.assertNotNull(responseString);
  }

  @Test
  public void test_exceptionHandler4xx() throws Exception {
    ConsumerContext consumerContext = createMockConsumerContext();
    when(singleSignOnProcessor.getDecryptedConsumer(any(String.class))).thenReturn(mockConsumer());
    doThrow(new SingleSignOnException(StatusCode.SSO_VALIDATION_ERROR, "mock-error")).when(singleSignOnProcessor)
        .mapResponse(any(Consumer.class), any(ConsumerContext.class));

    String responseString = testSingleSignOnDetailsEndpoint(status().is4xxClientError(),
        Constants.GET_SSO_DETAILS_FAILURE_4XX, consumerContext);

    Assert.assertNotNull(responseString);
  }

  private String testSingleSignOnDetailsEndpoint(ResultMatcher expectStatus,
      String fileContentsExpectMatchResponse, ConsumerContext consumerContext) throws Exception {
    HashMap<String, Object> sessionattr = new HashMap<String, Object>();
    sessionattr.put(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    sessionattr.put(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    MvcResult result = mockMvc
        .perform(get(Constants.GET_SSO_DETAILS_ENDPOINT).sessionAttrs(sessionattr)
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(expectStatus)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();
    String responseString = result.getResponse().getContentAsString();
    Assert.assertEquals(TestHelper.prettyToCompactJson(
        TestHelper.fetchClassPathFile(fileContentsExpectMatchResponse)), TestHelper.prettyToCompactJson(responseString));
    return responseString;
  }

  private ConsumerContext createMockConsumerContextWithUpsellSkuId() {
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setPartnerId("EFX-DIRECT-US");
    consumerContext.setTenantId("EFX-US");
    consumerContext.setChannel(ChannelEnum.DESKTOP);
    consumerContext.setDefaultLocale("en");
    consumerContext.setSkuId(123L);
    consumerContext.setUpsellSkuId(10999L);

    return consumerContext;
  }

  private ConsumerContext createMockConsumerContext() {
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setPartnerId("EFX-DIRECT-US");
    consumerContext.setTenantId("EFX-US");
    consumerContext.setAgentId("agent123");
    consumerContext.setChannel(ChannelEnum.DESKTOP);
    consumerContext.setDefaultLocale("en");
    consumerContext.setIntent("SECURITY_FREEZE");
    consumerContext.setSkuId(123L);
    return consumerContext;
	}


  private SingleSignOnDetails mockResponse() {
	  SingleSignOnDetails mockDetails = new SingleSignOnDetails();
	  mockDetails.setEncryptedData(mockEncryptedConsumer());
	  mockDetails.setTokenInfo(mockTokenInfo());
	  return mockDetails;
  }

  private SingleSignOnDetails mockResponseWithUpsellSkuId() {
    SingleSignOnDetails mockDetails = new SingleSignOnDetails();
    mockDetails.setEncryptedData(mockEncryptedConsumer());
    mockDetails.setTokenInfo(mockTokenInfo());
    mockDetails.setUpsellSkuId(10999L);
    return mockDetails;
  }

  private Consumer mockConsumer() throws Exception {
	  String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
	  Consumer consumer = SanitizedJsonUtils.fromJson(consumerString, Consumer.class);
	  consumer.setConsumerKey("e4a98146-46f6-47ad-8170-d35a2f49091e");
	  consumer.setPassword("Pa$sw0rd1");
	  return consumer;
  }

  private TokenInfo mockTokenInfo() {
    return TokenInfo.builder().accessToken("mockAccessToken").refreshToken("mockRefreshToken").build();
  }

  private String mockEncryptedConsumer () {
	  return "AZWYLxjGlAA+IEGyNc5gkOZAJoskG9YFqXoZzWe6GnlbDVoHgCh1bgRXfn+cSazhb+bIQo1CPsmISc+O1F4erqpR8CqKq2LekXWIM1c6WqQwF9M6SiTUOiy8rTSl0N+RLfGH2u9HEX9llAd/FoU8wdzE8y/knglM/fUfTYUoSTKDkSbbH5coqJX7Kcz6jsEivzr+/g4/jF0trnWrrZSntI1B7UCVQRx4guYkRuRlV5oqx4rahOQl/lV4g9cWM2wMjI1LymyTsEvIf4ds0ezvhUxGIQSNqDFsG5Y2Up1xWYiCL8wCysF9TtGV+WEnhT+fwEnwePHxJ0P95CY3twfHe6yUPuhmeoYvY9NP57yuqDzzJWhimoqlvXy0xa5OXjtv01aXSZYLklKzofxf6aTcF+YXZH8VuaGMpvD9kbC1Bw5fuK5KoZlVG4YeSYhdgCUc";
  }
}
