package com.efx.pet.service.registration.controller;

import static com.efx.pet.utility.CommonConstants.DEFAULT_CAMPAIGNCODE;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Currency;
import java.util.Locale;

import com.efx.pet.service.registration.util.DecryptionServiceUtil;
import com.efx.pet.utility.QueryParamEnums;
import com.efx.pet.utility.service.AppUtilService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.domain.partnertenant.PartnerTenantData;
import com.efx.pet.domain.partnertenant.Settings;
import com.efx.pet.order.mgmt.OrderMgmtService;
import com.efx.pet.order.mgmt.domain.OrderMgmtException;
import com.efx.pet.order.mgmt.domain.ProductOfferDetails;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse.StatusCode;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.registration.AnalyticsConfigResponse;
import com.efx.pet.service.registration.AppConfigResponse;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.utils.JsonUtils;

@RunWith(SpringRunner.class)
@TestPropertySource("classpath:test_environment.properties")
@ContextConfiguration(classes = {TestProfileConfig.class, LandingPageController.class})
public class LandingPageControllerTest {

  private static final String TENANT_PARTNER = "MY-EFX-US";

  private MockMvc mockMvc;

  @Autowired
  private LandingPageController controllerUnderTest;

  @MockBean
  private DecryptionServiceUtil decryptionServiceUtil;

  @MockBean
  private PartnerTenantClient partnerTenantClient;

  private MockHttpServletRequest mockHttpServletRequest;

  @MockBean
  private OrderMgmtService orderManagementService;

  @MockBean
  private AppUtilService appUtilService;

  @MockBean
  private SessionUtil sessionUtil;

  private ConsumerContext mockConsumerContext;

  /*
   * @MockBean private TouClientImpl touClientImpl;
   */

  @Before
  public void setup() throws CoreServiceClientException {
    this.mockHttpServletRequest = new MockHttpServletRequest();
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../MY-EFX-US/index.html");
    mockConsumerContext = createMockConsumerContext();
    this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
  }

  private static final String REDIRECT_URL = "/rest/1.0/redirectPartnerTenant";
  private static final String REDIRECT_PIN_URL = "/rest/1.0/pin";
  private static final String SESSIONID = "123-asd";
  private static final String CONVERSATIONID = "sdf-345";
  private static final String LIFT_ID = "45476c0f-94d5-3517-83e3-fffa716c64c9";
  private static final String LIFT_ID_KEY = "liftId";
  private static final String LIFT_INTENT = "TEMP_FREEZE_LOCK_LIFT";

  @Test
  public void testRedirectPartnerTenant__Regulatory_WithoutParams() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL)
        .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
        .andExpect(MockMvcResultMatchers.status().isFound())
        .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html"))
        .andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull(consumerContext);
    Assert.assertNull(consumerContext.getUpsellSkuId());
    Assert.assertEquals(DEFAULT_CAMPAIGNCODE,consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertNull(consumerContext.getIntent());
  }

  @Test
  public void testRedirectPartnerTenant_Regulatory() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL).param("intent", "SECURITY_FREEZE")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html")).andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull(consumerContext);
    Assert.assertNull(consumerContext.getUpsellSkuId());
    Assert.assertEquals(DEFAULT_CAMPAIGNCODE, consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertEquals("SECURITY_FREEZE", consumerContext.getIntent());
  }

  @Test
  public void testRedirectPartnerTenant_Regulatory_InvalidIntent() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL).param("intent", "UNKNOWN_INTENT")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound()).andReturn();

    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull(consumerContext);
    Assert.assertNull(consumerContext.getUpsellSkuId());
    Assert.assertEquals(DEFAULT_CAMPAIGNCODE,consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertNull(consumerContext.getIntent());
  }

  @Test
  public void testRedirectPartnerTenant_NonRegulatory_ValidCampaignCode() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL).param("externalProductReference", "123").param("campaignCode", "testCampaign")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html")).andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertEquals("123", consumerContext.getUpsellSkuId().toString());
    Assert.assertEquals("testCampaign", consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertNull(consumerContext.getIntent());
  }

  @Test
  public void testRedirectPartnerTenant_NonRegulatory_InvalidCampaignCode() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/");
    mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL).param("externalProductReference", "123").param("campaignCode", "ABC*20_")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/#/call-center-generic")).andReturn();
  }

  @Test
  public void testRedirectPartnerTenant_WithInvitationId() throws Exception {
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL)
      .param("externalProductReference", "123")
      .param("invitationId", "123-456")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../MY-EFX-US/index.html"))
      .andReturn();
    ConsumerContext consumerContext =
      (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertEquals("123", consumerContext.getUpsellSkuId().toString());
    Assert.assertNotNull(consumerContext.getQueryParamsMap());
    Assert.assertEquals("123-456", consumerContext.getQueryParamsMap().get(QueryParamEnums.INVITATIONID.value()));
  }

  @Test
  public void testRedirectPartnerTenant_WithOfferCode() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(decryptionServiceUtil.decryptOfferCode(any(), any())).thenReturn("TestValue");
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL)
      .param("externalProductReference", "123")
      .param("offerCode", "hQIOA2RdRSpx2eXcEAf8COWKf9BgtaTwzyumfRtTsZRWsTKFwR3Q+zdapQvkly2HqsK0oOuo8kf/IgLLX6xX0/752iJbdWSh0OAh9td7x0wZTv4xsRQYm24tXxcS1gjZ5tQk/7+pil9cdQomQewrsZUR7Xu7daH6TQ2rA/PO0yIshNdsfP/6i0kYreqlato18iGNu4KAZoiaWxHUVqFr0dGcpcZnG+NDljd++h5V0oaUkpmy+OWP3PCUbYGx36pTwizKZjHOhpnsRMdtik6pqfVJcDg7CWNba33gvrqDHLT124FMljCK1HVT05eX6Z+C3xTlUuBYIqQa6ahQU8iC1vScUxDB6PhxEwdR4j6ptgf5AcyroRXTfoKxnbqbDQd09NvxIw8wBZqcUtYgkDQDBEPQLq0wBRFTO21a5NEqRgRPASFv3LC/D0nx1KM4KH165Ukel3bxbC1womjs238+kHYqZZuaG5Xc/WpA9yTF7VwKHzpML4BfNcxItAtsLvwRFurhUuF9smIyPWwkDVJaJSZOU3GCiK543bakStRRRDTXtGAd6l4KUp9Qi2uJdrlpr8d0SQSpdlNPtF4gHw/E4Kwo1krUfjhjsk8Q/BnWoa3+V7Tr/kYCF29zGwJx6wdQjzetzzPV51JVswTE161KKDVwoGJaHEzS7j3jApxFlbnXJD3zZXm00iBctrUB3b18o9JCAXff/ywFv+JBA8WURqxUqIz5+1hDWmxPKbqQ7O81k9IrWFh+DZ8KtrlAC75c7yZ3yhbfCaeIXmZ5BADnYoWUBEzf=4eri")
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html"))
      .andReturn();

    ConsumerContext consumerContext =
      (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertEquals("123", consumerContext.getUpsellSkuId().toString());
    Assert.assertNotNull(consumerContext.getQueryParamsMap());
    Assert.assertEquals("TestValue", consumerContext.getQueryParamsMap().get(QueryParamEnums.OFFERCODE.value()));
  }

  @Test
  public void testRedirectPartnerTenant_WithLiftId() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_URL)
      .param("intent", LIFT_INTENT)
      .param(LIFT_ID_KEY, LIFT_ID)
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html"))
      .andReturn();

    ConsumerContext consumerContext =
      (ConsumerContext) result.getRequest().getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull(consumerContext);
    Assert.assertNotNull(consumerContext.getQueryParamsMap());
    Assert.assertEquals(LIFT_ID, consumerContext.getQueryParamsMap().get(QueryParamEnums.LIFTID.value()));
    Assert.assertEquals(LIFT_INTENT, consumerContext.getIntent());
  }

  @Test
  public void testAnalyticsConfig() throws Exception {
    String userAgent = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
    mockHttpServletRequest.addHeader(HttpHeaders.USER_AGENT, userAgent);
    ConsumerContext consumerContext = new ConsumerContext("6LeyhS8UAAAAAOKY7IX5dgdkkStjzZChXtbV7Cj6", "Sfder23sfdf");
    mockHttpServletRequest.getSession(true);
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    mockHttpServletRequest.addPreferredLocale(Locale.US);
    ResponseEntity<?>  responseEntity = controllerUnderTest.analyticsConfig(mockHttpServletRequest);

    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getEfxSessionID());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getCampaignSourceCode());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getEnsightenUrl());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getiOvationUrl());
  }

  @Test
  public void testAnalyticsConfig_withEmptyConsumerContext() throws Exception {
    String userAgent = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
    mockHttpServletRequest.addHeader(HttpHeaders.USER_AGENT, userAgent);
    mockHttpServletRequest.getSession(true);
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, null);
    mockHttpServletRequest.addPreferredLocale(Locale.US);
    ResponseEntity<?>  responseEntity = controllerUnderTest.analyticsConfig(mockHttpServletRequest);

    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertNull(((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getEfxSessionID());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getCampaignSourceCode());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getEnsightenUrl());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getiOvationUrl());
  }

  @Test
  public void testAnalyticsConfig_withCampaignCode() throws Exception {
    String userAgent = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
    mockHttpServletRequest.addHeader(HttpHeaders.USER_AGENT, userAgent);
    ConsumerContext consumerContext = new ConsumerContext("6LeyhS8UAAAAAOKY7IX5dgdkkStjzZChXtbV7Cj6", "Sfder23sfdf");
    mockHttpServletRequest.getSession(true);
    consumerContext.getQueryParamsMap().put(QueryParamEnums.CAMPAIGNCODE.value(),"testCode");
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    mockHttpServletRequest.addPreferredLocale(Locale.US);
    ResponseEntity<?>  responseEntity = controllerUnderTest.analyticsConfig(mockHttpServletRequest);

    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertNotNull(((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getEfxSessionID());
    Assert.assertEquals("testCode",((AnalyticsConfigResponse) responseEntity.getBody()).getDataLayer().getPage().getAttributes().getCampaignSourceCode());
  }

  @Test
  public void testAppConfig_withCampaignCode() throws Exception {
    Assert.assertNotNull(mockMvc);
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.getQueryParamsMap().put(QueryParamEnums.CAMPAIGNCODE.value(),"testCode");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    Assert.assertNotNull(appConfigResponse.getSupportedLocales());
    Assert.assertEquals("en", appConfigResponse.getDefaultLocale());
    Assert.assertEquals("testCode", appConfigResponse.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    assertNull(appConfigResponse.getProductTermsUrl());
    assertNull(appConfigResponse.getProductTermsVersion());
  }

  @Test
  public void testAppConfig_NoCampaignCodeInput() throws Exception {
    Assert.assertNotNull(mockMvc);
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?> responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    Assert.assertNotNull(appConfigResponse.getSupportedLocales());
    Assert.assertEquals("en", appConfigResponse.getDefaultLocale());
    Assert.assertEquals("Web", appConfigResponse.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    assertNull(appConfigResponse.getProductTermsUrl());
    assertNull(appConfigResponse.getProductTermsVersion());
  }

  @Test
  public void testAppConfigForUpSell() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse());
    Mockito.when(appUtilService.isTouDisabled(any())).thenReturn(false);
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    Assert.assertNotNull(appConfigResponse.getSupportedLocales());
    Assert.assertEquals("en", appConfigResponse.getDefaultLocale());
    assertEquals(new Long(10098), appConfigResponse.getProductOfferDetails().getId());
    assertNotNull(appConfigResponse.getProductTermsUrl());
    assertNotNull(appConfigResponse.getProductTermsVersion());
    Assert.assertNull(appConfigResponse.getProductOfferDetails().getTrialOffer());
    assertEquals("test.product.url", appConfigResponse.getProductTermsUrl());
    assertEquals("1.0", appConfigResponse.getProductTermsVersion());
    assertFalse(appConfigResponse.isTouDisabled());
  }

  @Test
  public void testAppConfigForUpSell_DisableTOU() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse());
    Mockito.when(appUtilService.isTouDisabled(any())).thenReturn(true);
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    Assert.assertNotNull(appConfigResponse.getSupportedLocales());
    Assert.assertEquals("en", appConfigResponse.getDefaultLocale());
    assertEquals(new Long(10098), appConfigResponse.getProductOfferDetails().getId());
    assertNotNull(appConfigResponse.getProductTermsUrl());
    assertNotNull(appConfigResponse.getProductTermsVersion());
    Assert.assertNull(appConfigResponse.getProductOfferDetails().getTrialOffer());
    assertEquals("test.product.url", appConfigResponse.getProductTermsUrl());
    assertEquals("1.0", appConfigResponse.getProductTermsVersion());
    assertTrue(appConfigResponse.isTouDisabled());
  }

  @Test
  public void testAppConfigForUpSell_NoSuccessCode() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse_NoSuccessCode());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }

  @Test
  public void testAppConfigForUpSell_SuccessCode_NoProductData() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse_NoProductData());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }

  @Test
  public void testAppConfigForUpSell_NoSuccessCode_NoProductData() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse_NoSuccessCode_NoProductData());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }

  @Test
  public void testAppConfigForUpSell_OrderMgmtException() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenThrow(OrderMgmtException.class);
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());

  }

  @Test
  public void testAppConfigForUpSell_EmptyUpSellSKU() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }


  @Test
  public void testAppConfig_ConsumerContext_Sets_SkuId_From_Config() throws Exception {

    //Given skuId has not established
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");

    //SkuId is present in partnerTenant
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    //When appConfig is requested
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);

    //SkuId would use one from config
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals("2345", consumerContext.getSkuId().toString());
  }

  @Test
  public void testAppConfig_SkuId_Sets_by_RedirectPartnerTenant() throws Exception {

    //Given skuId already established in consumerContext through RedirectPartnerTenant
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setSkuId(9999L);

    //And skuId also present in PartnerTenant Config
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    //When appConfig is requested
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);

    //SkuId would still use the established one passed down
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals("9999", consumerContext.getSkuId().toString());
  }

  @Test
  public void testAppConfig_Intent_and_LiftId_Sets_by_RedirectPartnerTenant() throws Exception {

    //Given intent and liftId already established in consumerContext through RedirectPartnerTenant
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setIntent(LIFT_INTENT);
    consumerContext.getQueryParamsMap().put(LIFT_ID_KEY, LIFT_ID);

    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    //When appConfig is requested
    ResponseEntity<?> responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    AppConfigResponse response = (AppConfigResponse) responseEntity.getBody();

    //intent and liftId would be present in the appConfig and still present in consumerContext
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(LIFT_INTENT, consumerContext.getIntent());
    Assert.assertEquals(LIFT_ID, consumerContext.getQueryParamsMap().get(LIFT_ID_KEY));
    Assert.assertNotNull(response);
    Assert.assertNotNull(response.getQueryParamsMap());
    Assert.assertEquals(LIFT_INTENT, response.getQueryParamsMap().get(QueryParamEnums.INTENT.value()));
    Assert.assertEquals(LIFT_ID, response.getQueryParamsMap().get(LIFT_ID_KEY));
  }

  @Test
  public void testAppConfig_SkuIdNotPresentInConsumerContext_ShouldError() throws Exception {

    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());

    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setSkuId(null);

    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }

  @Test
  public void testAppConfig_withOfferCode() throws Exception {
    String OFFER_CODE = "testCode";
    Assert.assertNotNull(mockMvc);
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123", "sdf-345");
    consumerContext.getQueryParamsMap().put(QueryParamEnums.OFFERCODE.value(), OFFER_CODE);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    Mockito.when(orderManagementService.getProductByOfferCode(any())).thenReturn(mockProductOfferResponse());
    ResponseEntity<?> responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Mockito.verify(orderManagementService, Mockito.times(1)).getProductByOfferCode(any());
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    Assert.assertEquals(OFFER_CODE, appConfigResponse.getQueryParamsMap().get(QueryParamEnums.OFFERCODE.value()));
  }


  @Test
  public void testAppConfigForUpSellWithProductDisplayFeature() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd","sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponseWithProductDisplayFeatures());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(appConfigResponse);
    assertEquals(new Long(10098), appConfigResponse.getProductOfferDetails().getId());
    Assert.assertNull(appConfigResponse.getProductOfferDetails().getTrialOffer());
    assertEquals("VANTAGE_SCORE_MONITORING", appConfigResponse.getProductOfferDetails().getProductFeatureNameForDisplay());
  }

  @Test
  public void testAppConfigForOfferCodeWithProductDisplayFeature() throws Exception {
    String OFFER_CODE = "testCode";
    Assert.assertNotNull(mockMvc);
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123", "sdf-345");
    consumerContext.getQueryParamsMap().put(QueryParamEnums.OFFERCODE.value(), OFFER_CODE);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    Mockito.when(orderManagementService.getProductByOfferCode(any())).thenReturn(mockProductOfferResponseWithProductDisplayFeatures());
    ResponseEntity<?> responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Mockito.verify(orderManagementService, Mockito.times(1)).getProductByOfferCode(any());
    Assert.assertNotNull(appConfigResponse);
    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    Assert.assertEquals(TENANT_PARTNER, appConfigResponse.getTenantPartner());
    assertEquals(new Long(10098), appConfigResponse.getProductOfferDetails().getId());
    assertEquals("VANTAGE_SCORE_MONITORING", appConfigResponse.getProductOfferDetails().getProductFeatureNameForDisplay());
  }


  @Test
  public void testAppConfigWithTrialSkuId() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd","sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenReturn(mockProductOfferResponse_WithTrialOffer());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    assertNotNull(responseEntity);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    assertNotNull(appConfigResponse);
    assertEquals(new Long(10098), appConfigResponse.getProductOfferDetails().getId());
    assertNotNull(appConfigResponse.getProductOfferDetails().getTrialOffer());
    Assert.assertEquals("DAYS", appConfigResponse.getProductOfferDetails().getTrialOffer().getTrialOfferTerm());
    Assert.assertEquals(Integer.valueOf(7), appConfigResponse.getProductOfferDetails().getTrialOffer().getTrialOfferPeriod());
    Assert.assertEquals(new BigDecimal("0.0"), appConfigResponse.getProductOfferDetails().getTrialOffer().getAmount());
    Assert.assertEquals(Currency.getInstance("USD"), appConfigResponse.getProductOfferDetails().getTrialOffer().getCurrency());
  }

  @Test
  public void testAppConfig_TrialSkuIdNotPresentInProduct_ShouldError() throws Exception {
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123-asd", "sdf-345");
    consumerContext.setUpsellSkuId(123456L);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Mockito.when(orderManagementService.getProductBySkuId(any())).thenThrow(OrderMgmtException.class);

    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }

  @Test
  public void testAppConfigForOfferCodeWithNoOfferCodeFound() throws Exception {
    String OFFER_CODE = "testCode";
    Assert.assertNotNull(mockMvc);
    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
    ConsumerContext consumerContext = new ConsumerContext("123", "sdf-345");
    consumerContext.getQueryParamsMap().put(QueryParamEnums.OFFERCODE.value(), OFFER_CODE);
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    Mockito.when(orderManagementService.getProductByOfferCode(any())).thenThrow(OrderMgmtException.class);
    ResponseEntity<?> responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
    Assert.assertNotNull(responseEntity);
    Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
  }



  @Test
  public void testRedirectPtpSubmit() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    mockMvc.perform(MockMvcRequestBuilders.get(REDIRECT_PIN_URL)
      .sessionAttr(CommonConstants.CONSUMER_CONTEXT, mockConsumerContext))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html#/ptp-submit-pin"))
      .andReturn();
  }

  @Test
  public void testAppConfigForCallCenterServiceDetails() throws Exception {
	    Mockito.when(partnerTenantClient.getPartnerTenantData()).thenReturn(getMockPartnerTenantData());
	    ConsumerContext consumerContext = new ConsumerContext(SESSIONID,CONVERSATIONID);
	    Mockito.when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
	    mockHttpServletRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

	    ResponseEntity<?>  responseEntity = controllerUnderTest.appConfig(mockHttpServletRequest);
	    Assert.assertNotNull(responseEntity);
	    Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	    Assert.assertEquals(AppConfigResponse.class, responseEntity.getBody().getClass());

	    AppConfigResponse appConfigResponse = (AppConfigResponse) responseEntity.getBody();
	    Assert.assertNotNull(appConfigResponse);
	    assertEquals("testPhoneNumber", appConfigResponse.getCallCenterDetails().getCallCenterPhoneNumber());
	    assertEquals("testCallCenterMessage", appConfigResponse.getCallCenterDetails().getCallCenterTimeMessage());
	    assertEquals("testptpmessage", appConfigResponse.getCallCenterDetails().getPtpCallCenterMessage());
  }

  private PartnerTenantData getMockPartnerTenantData() {
    PartnerTenantData partnerTenantData = new PartnerTenantData();
    partnerTenantData.setDefaultLocale("en");
    partnerTenantData.setSupportedLocales(new ArrayList<String>());
    partnerTenantData.setPartnerId("EFX-DIRECT");
    return partnerTenantData;
  }

  private Settings getMockPartnerSettings() {
    Settings settings = new Settings();
    settings.setSkuId("2345");
    settings.setIntentList(new ArrayList<String>(Arrays.asList("FRAUD_ALERT", "SECURITY_FREEZE", "DISPUTE", LIFT_INTENT)));
    return settings;
  }

  private ProductOfferResponse mockProductOfferResponse() {
    String productOfferRes = "{\r\n" +
      "      \"skuId\":10098,\r\n" +
      "      \"productName\":\"Equifax Credit Monitor™\",\r\n" +
      "      \"productCode\":\"ECM\",\r\n" +
      "      \"deliveryChannel\":\"ONLINE\",\r\n" +
      "      \"shortDescription\":\"•\\tDaily access to your VantageScore® credit score and Equifax Credit report •\\tDaily Equifax credit report monitoring and alerts to key changes •\\tEasily lock your Equifax credit report and be alerted if an attempt to access it is blocked\",\r\n" +
      "      \"longDescription\":\"<p>The credit scores provided are based on the VantageScore 3.0 credit score based on Equifax data. Third parties use many different types of credit scores and are likely to use a different type of credit score to assess your creditworthiness. </p>\",\r\n" +
      "      \"retailPrice\":{\"amount\":5.0,\"currency\":\"USD\"},\r\n" +
      "      \"term\":\"MONTHLY\"\r\n" +
      "      }";
    ProductOfferResponse response = new ProductOfferResponse(StatusCode.SUCCESS);
    ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
    response.setProductOfferDetails(productDetails);
    return response;
  }

  private ProductOfferResponse mockProductOfferResponse_WithTrialOffer() {
    String productOfferRes = "{\r\n" +
      "      \"skuId\":10098,\r\n" +
      "      \"productName\":\"Equifax Credit Monitor™\",\r\n" +
      "      \"productCode\":\"ECM\",\r\n" +
      "      \"deliveryChannel\":\"ONLINE\",\r\n" +
      "      \"shortDescription\":\"•\\tDaily access to your VantageScore® credit score and Equifax Credit report •\\tDaily Equifax credit report monitoring and alerts to key changes •\\tEasily lock your Equifax credit report and be alerted if an attempt to access it is blocked\",\r\n" +
      "      \"longDescription\":\"<p>The credit scores provided are based on the VantageScore 3.0 credit score based on Equifax data. Third parties use many different types of credit scores and are likely to use a different type of credit score to assess your creditworthiness. </p>\",\r\n" +
      "      \"retailPrice\":{\"amount\":5.0,\"currency\":\"USD\"},\r\n" +
      "      \"trialOffer\":{\"amount\":0.0,\"currency\":\"USD\",\"trialOfferPeriod\":\"7\",\"trialOfferTerm\":\"DAYS\"},\r\n" +
      "      \"term\":\"MONTHLY\"\r\n" +
      "      }";
    ProductOfferResponse response = new ProductOfferResponse(StatusCode.SUCCESS);
    ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
    response.setProductOfferDetails(productDetails);
    return response;
  }

  private ProductOfferResponse mockProductOfferResponse_NoSuccessCode() {
    String productOfferRes = "{\r\n" +
      "      \"skuId\":10098,\r\n" +
      "      \"productName\":\"Equifax Credit Monitor™\",\r\n" +
      "      \"productCode\":\"ECM\",\r\n" +
      "      \"deliveryChannel\":\"ONLINE\",\r\n" +
      "      \"shortDescription\":\"•\\tDaily access to your VantageScore® credit score and Equifax Credit report •\\tDaily Equifax credit report monitoring and alerts to key changes •\\tEasily lock your Equifax credit report and be alerted if an attempt to access it is blocked\",\r\n" +
      "      \"longDescription\":\"<p>The credit scores provided are based on the VantageScore 3.0 credit score based on Equifax data. Third parties use many different types of credit scores and are likely to use a different type of credit score to assess your creditworthiness. </p>\",\r\n" +
      "      \"retailPrice\":{\"amount\":5.0,\"currency\":\"USD\"},\r\n" +
      "      \"term\":\"MONTHLY\"\r\n" +
      "      }";
    ProductOfferResponse response = new ProductOfferResponse(StatusCode.SYSTEM_ERROR);
    ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
    response.setProductOfferDetails(productDetails);
    return response;
  }

  private ProductOfferResponse mockProductOfferResponseWithProductDisplayFeatures() {
	  String productOfferRes = "{\r\n" +
	  		"      \"skuId\":10098,\r\n" +
	  		"      \"productName\":\"Equifax Credit Monitor™\",\r\n" +
	  		"      \"productCode\":\"ECM\",\r\n" +
	  		"      \"deliveryChannel\":\"ONLINE\",\r\n" +
	  		"      \"shortDescription\":\"•\\tDaily access to your VantageScore® credit score and Equifax Credit report •\\tDaily Equifax credit report monitoring and alerts to key changes •\\tEasily lock your Equifax credit report and be alerted if an attempt to access it is blocked\",\r\n" +
	  		"      \"longDescription\":\"<p>The credit scores provided are based on the VantageScore 3.0 credit score based on Equifax data. Third parties use many different types of credit scores and are likely to use a different type of credit score to assess your creditworthiness. </p>\",\r\n" +
	  		"      \"retailPrice\":{\"amount\":5.0,\"currency\":\"USD\"},\r\n" +
	  		"      \"term\":\"MONTHLY\",\r\n" +
	  		"      \"productFeatureNameForDisplay\":\"VANTAGE_SCORE_MONITORING\"\r\n" +
	  		"      }";
	  ProductOfferResponse response = new ProductOfferResponse(StatusCode.SUCCESS);
	  ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
	  response.setProductOfferDetails(productDetails);
	  return response;
  }


  private ProductOfferResponse mockProductOfferResponse_NoProductData() {
    String productOfferRes = null;
    ProductOfferResponse response = new ProductOfferResponse(StatusCode.SUCCESS);
    ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
    response.setProductOfferDetails(productDetails);
    return response;
  }

  private ProductOfferResponse mockProductOfferResponse_NoSuccessCode_NoProductData() {
    String productOfferRes = null;
    ProductOfferResponse response = new ProductOfferResponse(StatusCode.VALIDATION_ERROR);
    ProductOfferDetails productDetails = JsonUtils.fromJson(productOfferRes, ProductOfferDetails.class);
    response.setProductOfferDetails(productDetails);
    return response;
  }

  private ConsumerContext createMockConsumerContext() {
		ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		consumerContext.setPartnerId("EFX-DIRECT-US");
		consumerContext.setTenantId("EFX-US");
		consumerContext.setChannel(ChannelEnum.DESKTOP);
		consumerContext.setDefaultLocale("en");
		return consumerContext;
	}
}
