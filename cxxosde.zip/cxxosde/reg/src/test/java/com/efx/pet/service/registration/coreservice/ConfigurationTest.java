//package com.efx.pet.service.registration.coreservice;
//import static org.mockito.Matchers.any;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.test.context.ActiveProfiles;
//
//import com.efx.pet.service.client.partnertenant.PartnerTenantLookupServiceClient;
//import com.efx.pet.service.configuration.Constants;
//import com.efx.pet.service.partnertenant.entity.PartnerTenant;
//import com.efx.pet.service.partnertenant.operations.PartnerTenantResponse;
//import com.efx.pet.service.partnertenant.operations.ServiceResponse;
//import com.efx.pet.test.common.TestConfigurationBase;
//import com.efx.pet.test.common.TestHelper;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@ActiveProfiles(Constants.SPRING_PROFILE_TEST)
//public class ConfigurationTest extends TestConfigurationBase {
//
//  @Mock
//  @Qualifier("partnerTenantLookupServiceClient")
//  PartnerTenantLookupServiceClient partnerTenantLookupServiceClient;
//
//  @InjectMocks
//  PartnerTenantClient partnerTenantClient = new PartnerTenantClient();
//
//
//  @Before
//  public void setUp() throws Exception {
//	  PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE);
//	  doNothing().when(partnerTenantLookupServiceClient).setUrl(Mockito.any(String.class));
//	  when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);
//	  partnerTenantClient.setPartnerAlias("some_alias");
//	  partnerTenantClient.init();
//  }
//
//  @Test
//  public void testConfigurationLoad() throws Exception {
//    Assert.assertNotNull(partnerTenantClient);
//  }
//
//  private PartnerTenantResponse mockPartnerTenantResponse(String partnerTenantResponseFileName) throws Exception {
//	    PartnerTenantResponse partnerTenantResponse = new PartnerTenantResponse();
//	    partnerTenantResponse.setServiceStatus(ServiceResponse.Status.SUCCESS);
//	    String partnerTenantResponseJson = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(partnerTenantResponseFileName));
//	    ObjectMapper mapper = new ObjectMapper();
//	    List<PartnerTenant> partnerTenants = new ArrayList<PartnerTenant>();
//	    partnerTenants.add(mapper.readValue(partnerTenantResponseJson, PartnerTenant.class));
//	    partnerTenantResponse.setPartnerTenants(partnerTenants);
//	    return partnerTenantResponse;
//	  }
//}
