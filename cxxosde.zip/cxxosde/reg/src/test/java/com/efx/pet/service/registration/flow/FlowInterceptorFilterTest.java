package com.efx.pet.service.registration.flow;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.registration.domain.FlowInterceptorException;
import com.efx.pet.utility.CommonConstants;

import net.sf.uadetector.ReadableDeviceCategory;
import net.sf.uadetector.ReadableUserAgent;
import net.sf.uadetector.UserAgentStringParser;
import net.sf.uadetector.service.UADetectorServiceFactory;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {
    "web.flow.enable:true",
})
@ContextConfiguration(classes = {FlowInterceptorFilter.class, TestProfileConfig.class})
public class FlowInterceptorFilterTest {

	@MockBean
	private FlowValidator flowValidator;

	@Autowired
	private FlowInterceptorFilter flowInterceptorFilter;

	private HttpSession session = mock(MockHttpSession.class);

	private HttpServletRequest request = mock(MockHttpServletRequest.class);

	private HttpServletResponse response = mock(MockHttpServletResponse.class);

  private ConsumerContext mockConsumerContext = new ConsumerContext("mockSessionId","mockConversationId");

	@Before
	public void setup() {
		when(request.getSession()).thenReturn(new MockHttpSession());
    when(request.getSession(false)).thenReturn(session);
		when(request.getRequestURI()).thenReturn("URI");
	}

	@Test
	public void testPreHandle() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		boolean interceptor = flowInterceptorFilter.preHandle(request, response, null);
		assertTrue(interceptor);
	}

	@Test
	public void testPreHandleWebFlowFalse() throws Exception {
		ReflectionTestUtils.setField(flowInterceptorFilter, "webFlowEnabled", false);
		boolean interceptor = flowInterceptorFilter.preHandle(request, response, null);
		assertTrue(interceptor);
	}

	@Test(expected = FlowInterceptorException.class)
	public void testPreHandleFalse() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(false);
		flowInterceptorFilter.preHandle(request, response, null);
	}

	@Test
	public void testPreHandle_shouldParseChromeDesktopUserAgentString() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		// Chrome Browser - Desktop
		when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals(ConsumerContext.ChannelEnum.DESKTOP, consumerContext.getChannel());
	}

	@Test
	public void testPreHandle_shouldParseSmartPhoneMobileDeviceUserAgentString() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		// Production - sample value
		when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 7.0; LG-M430 Build/NRD90U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.107 Mobile Safari/537.36");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, consumerContext.getChannel());
	}

	@Test
	public void testPreHandle_shouldParseTabletMobileDeviceUserAgentString() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		// Production - sample value
		when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (iPad; CPU OS 11_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.0 Mobile/15E148 Safari/604.1");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, consumerContext.getChannel());
	}

	@Test
	public void testPreHandle_shouldParseEmulatorMobileDeviceUserAgentString() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		// Emulator - Android Studio
		when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, consumerContext.getChannel());
	}

	@Test
	public void testPreHandle_shouldParseMobileAppHeaderString() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		// Mobile App test
		when(request.getHeader("Mobile-App")).thenReturn("true");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_APP, consumerContext.getChannel());
	}

	@Test
	public void testPreHandle_shouldPopulateContextHost() throws Exception {
		when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
		when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
		when(request.getServerName()).thenReturn("testHost");
		flowInterceptorFilter.preHandle(request, response, null);
		ConsumerContext consumerContext = (ConsumerContext) request.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);
		assertNotNull(consumerContext);
		assertEquals("testHost", consumerContext.getHost());
	}

	@Test
	public void testUserAgentStringParserChannelMapping() throws Exception {
		assertEquals(ConsumerContext.ChannelEnum.DESKTOP, FlowInterceptorFilter.CHANNEL_MAP.get(ReadableDeviceCategory.Category.GAME_CONSOLE));
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP.get(ReadableDeviceCategory.Category.PDA));
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP.get(ReadableDeviceCategory.Category.SMARTPHONE));
		assertEquals(ConsumerContext.ChannelEnum.DESKTOP, FlowInterceptorFilter.CHANNEL_MAP.getOrDefault(ReadableDeviceCategory.Category.UNKNOWN, ConsumerContext.ChannelEnum.DESKTOP));
		assertEquals(ConsumerContext.ChannelEnum.DESKTOP, FlowInterceptorFilter.CHANNEL_MAP.getOrDefault(null, ConsumerContext.ChannelEnum.DESKTOP));

		UserAgentStringParser parser = UADetectorServiceFactory.getResourceModuleParser();
		ReadableUserAgent readableUserAgent;
		ReadableDeviceCategory deviceCategory;

		// Chrome Browser - Desktop
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.PERSONAL_COMPUTER, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.DESKTOP, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

		// Production - sample value
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (Linux; Android 7.0; LG-M430 Build/NRD90U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.107 Mobile Safari/537.36");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.SMARTPHONE, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

		// Production - sample value
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (iPhone; CPU iPhone OS 12_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Mobile/15E148 Safari/604.1");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.SMARTPHONE, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

		// Production - sample value
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (iPad; CPU OS 11_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.0 Mobile/15E148 Safari/604.1");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.TABLET, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

		// Emulator - Android Studio
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (Linux; Android 8.1.0; Android SDK built for x86 Build/OSM1.180201.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.SMARTPHONE, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

		// Emulator - Android Studio
		readableUserAgent = parser.parse(
				"Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
		deviceCategory = readableUserAgent.getDeviceCategory();
		assertEquals(ReadableDeviceCategory.Category.SMARTPHONE, deviceCategory.getCategory());
		assertEquals(ConsumerContext.ChannelEnum.MOBILE_DEVICE, FlowInterceptorFilter.CHANNEL_MAP
				.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));
	}

  @Test
  public void testPreHandle_reset_session_entry_url() throws Exception {
    when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
    when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
    when(request.getServerName()).thenReturn("testHost");
    when(request.getRequestURI()).thenReturn("/rest/1.0/redirectPartnerTenant");
    flowInterceptorFilter.preHandle(request, response, null);
    verify(session,times(1)).invalidate();
  }

  @Test
  public void testPreHandle_reset_session_entry_url_full_url() throws Exception {
    when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
    when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
    when(request.getServerName()).thenReturn("testHost");
    when(request.getRequestURI()).thenReturn("/consumer-registration/rest/1.0/redirectPartnerTenant");
    flowInterceptorFilter.preHandle(request, response, null);
    verify(session,times(1)).invalidate();
  }

  @Test
  public void testPreHandle_not_reset_session_non_entry_url() throws Exception {
    when(flowValidator.isThisRequestAllowed(any(), any())).thenReturn(true);
    when(request.getHeader("User-Agent")).thenReturn("Mozilla/5.0 (Linux; Android 9; Android SDK built for x86 Build/PSR1.180720.061) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36");
    when(request.getServerName()).thenReturn("testHost");
    when(request.getRequestURI()).thenReturn("/rest/1.0/saveConsumer");
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT,mockConsumerContext);
    flowInterceptorFilter.preHandle(request, response, null);
    verify(session,times(0)).invalidate();
  }
}
