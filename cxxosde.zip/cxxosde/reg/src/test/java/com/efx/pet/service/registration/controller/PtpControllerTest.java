package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.atLeastOnce;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.client.eligibility.EligibilityServiceClient;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.customer.entity.CustomerEnums.IdpStatus;
import com.efx.pet.domain.eligibility.operations.IdpResponseDataRequest;
import com.efx.pet.domain.eligibility.operations.IdpResponseDataResponse;
import com.efx.pet.domain.eligibility.operations.ServiceResponse;
import com.efx.pet.domain.partnertenant.Settings;
import com.efx.pet.utility.ConsumerValidator;
import com.efx.pet.service.idproofing.util.PtpMessageUtility;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.idproofing.IdProofingResponse.StatusCode;
import com.efx.pet.service.idproofing.helper.PtpIdProofingHelper;
import com.efx.pet.service.idproofing.processor.IdpProcessor;
import com.efx.pet.service.registration.ReCaptchaService;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.domain.PTPConsumer;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.AccountSetupMessageUtility;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.cache.redis.util.PiiToHashUtility;
import com.efx.pet.utility.configuration.utils.JsonUtils;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {PtpController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
  "com.efx.pet.service.registration.ptp.retry.max.count:3",
  "com.efx.pet.eligibility.user:user",
  "com.efx.pet.eligibility.passphrase:passphrase",
  "com.efx.pet.eligibility.enableBasicAuth:false",

})
public class PtpControllerTest {

    @Autowired
    private PtpController controllerUnderTest;

    private MockMvc mockMvc;

    @MockBean
    private EncryptUtility encryptUtility;

    @MockBean
    private PtpMessageUtility ptpMessageUtility;

    @MockBean
    private SessionUtil sessionUtil;

    @MockBean
    private ReCaptchaService reCaptchaService;

    @MockBean
    private ConsumerService consumerService;

    @MockBean
    private IdProofingService idProofingService;

    @MockBean
    private IdpProcessor idpProcessor;

    @MockBean
    private AccountSetupMessageUtility accountSetupMessageUtility;

    @MockBean
    private EligibilityServiceClient eligibilityServiceClient;

    @MockBean
    private PtpIdProofingHelper ptpIdProofingHelper;

    @MockBean
    private ObtainIpUtility obtainIpUtility;

    @MockBean
    private PiiToHashUtility piiToHashUtility;

    @MockBean
    ConsumerValidator consumerValidator;

    @MockBean
    private PartnerTenantClient partnerTenantClient;

    @Before
    public void setup() {
      this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    /*
     * Tests for InitiatePtp
     */

    @Test
    public void testInitiatePtp_enrollInPtpSuccess_returnsInitiatePtpSuccess() throws Exception {
        Mockito.when(ptpIdProofingHelper.isValidAddress(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        IdProofingResponse idProofingResponse = new IdProofingResponse(StatusCode.PTP_ENROLL_SUCCESS);
        Mockito.when(idProofingService.enrollInPtp(any(Consumer.class), any(ConsumerContext.class), any(String.class), anyBoolean())).thenReturn(idProofingResponse);
        Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));
        Mockito.when(consumerValidator.isValidFirstName(anyString())).thenReturn(true);
        Mockito.when(consumerValidator.isValidLastName(anyString())).thenReturn(true);
        Mockito.when(ptpIdProofingHelper.isValidAddress(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        Settings settings = new Settings();
        settings.setPrintTemplateId("3");
        Mockito.when(partnerTenantClient.getSettings()).thenReturn(settings);
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));

        testInitiatePtpEndpoint(
          consumerString,
          status().isOk(),
          Constants.INITIATE_PTP_SUCCESS_RESPONSE_PATH
        );
        // verify isEmergencyBrakeEnabled input is false
        verify(idProofingService, times(1)).enrollInPtp(any(Consumer.class), any(ConsumerContext.class), eq("3"), eq(false));
    }

    @Test
    public void testInitiatePtp_consumerMissingFields_returnsValidationError() throws Exception {
        Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));
        // Consumer without email
        Mockito.when(consumerValidator.isValidFirstName(anyString())).thenReturn(true);
        Mockito.when(consumerValidator.isValidLastName(anyString())).thenReturn(true);
        String consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)),Constants.EMAIL_KEY);

        testInitiatePtpEndpoint(
            consumerString,
            status().isBadRequest(),
            Constants.PTP_VALIDATION_ERROR_RESPONSE_PATH
        );
    }

    @Test
    public void testInitiatePtp_consumerNotInSession_returnsInitiatePtpSystemError() throws Exception {
        Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

        testInitiatePtpEndpoint(
            null,
            status().isInternalServerError(),
            Constants.INITIATE_PTP_SYSTEM_ERROR_RESPONSE_PATH
        );
    }

    @Test
    public void testInitiatePtp_enrollInPtpError_returnsInitiatePtpSystemError() throws Exception {
        Mockito.when(ptpIdProofingHelper.isValidAddress(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        IdProofingResponse idProofingResponse = new IdProofingResponse(StatusCode.ID_PROOFING_SYSTEM_ERROR);
        Mockito.when(idProofingService.enrollInPtp(any(Consumer.class), any(ConsumerContext.class), any(String.class), anyBoolean())).thenReturn(idProofingResponse);
        Mockito.when(consumerValidator.isValidFirstName(anyString())).thenReturn(true);
        Mockito.when(consumerValidator.isValidLastName(anyString())).thenReturn(true);
        Mockito.when(ptpIdProofingHelper.isValidAddress(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        Settings settings = new Settings();
        settings.setPrintTemplateId("3");
        Mockito.when(partnerTenantClient.getSettings()).thenReturn(settings);
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));

        testInitiatePtpEndpoint(
            consumerString,
            status().isInternalServerError(),
            Constants.INITIATE_PTP_SYSTEM_ERROR_RESPONSE_PATH
        );
    }

    @Test
    public void testInitiatePtp_enrollInPtpThrowsException_returnsInitiatePtpSystemError() throws Exception {
        Mockito.when(ptpIdProofingHelper.isValidAddress(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        Mockito.when(idProofingService.enrollInPtp(any(Consumer.class), any(ConsumerContext.class), any(String.class), anyBoolean())).thenThrow(new IdProofingServiceException("unknown"));
        Mockito.when(consumerValidator.isValidFirstName(anyString())).thenReturn(true);
        Mockito.when(consumerValidator.isValidLastName(anyString())).thenReturn(true);
        Settings settings = new Settings();
        settings.setPrintTemplateId("3");
        Mockito.when(partnerTenantClient.getSettings()).thenReturn(settings);
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));

        testInitiatePtpEndpoint(
            consumerString,
            status().isInternalServerError(),
            Constants.INITIATE_PTP_SYSTEM_ERROR_RESPONSE_PATH
        );
    }

    private void testInitiatePtpEndpoint(String consumerString, ResultMatcher expectStatus, String fileContentsExpectMatchResponse) throws Exception {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, new ConsumerContext("testSessionId","testConversationId"));

        if (!StringUtils.isEmpty(consumerString)) {
            Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
            consumer.setConsumerKey("Desktop");
            String encryptedConsumer = getEncryptedConsumer(consumer);
            Mockito.when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
              .thenReturn(JsonUtils.toJson(consumer));
            sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
        }

        MvcResult result = mockMvc.perform(get(Constants.INITIATE_PTP_ENDPOINT)
            .sessionAttrs(sessionattr)
        )
            .andExpect(expectStatus)
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();
        String ptpResponseString = result.getResponse().getContentAsString();
        Assert.assertEquals(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(fileContentsExpectMatchResponse)), ptpResponseString);
    }

    /*
     * Tests for ValidatePtp
     */

    private void testValidatePtpEndpoint(String ptpValidationRequestString, ResultMatcher expectStatus, String fileContentsExpectMatchResponse, boolean isLastRetry) throws Exception {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, new ConsumerContext("testSessionId","testConversationId"));
        if(isLastRetry) {
        	sessionattr.put(CommonConstants.PTP_REMAINING_ATTEMPTS, new Byte("1"));
        }

        Mockito.when(ptpMessageUtility.getPtpPinPattern()).thenReturn(Pattern.compile("^[ABCDEFGHIJKLMNOPQRSTUVWZYZ0123456789]{10}$"));
        MvcResult result = mockMvc.perform(post(Constants.VALIDATE_PTP_ENDPOINT)
                .sessionAttrs(sessionattr)
                .contentType(MediaType.APPLICATION_JSON)
                .content(ptpValidationRequestString)
        )
                .andExpect(expectStatus)
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        String ptpResponseString = result.getResponse().getContentAsString();
        Assert.assertEquals(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(fileContentsExpectMatchResponse)), ptpResponseString);
    }

    private PTPConsumer getPtpValidationRequest() throws Exception{
        String requestString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.PTP_VALIDATION_REQUEST_PATH));
        return JsonUtils.fromSanitizedJson(requestString, PTPConsumer.class);
    }

    @Test
    public void testValidatePtp_success() throws Exception{
        Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
        Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class))).thenReturn(null);
        Map<String, String> mockCacheMap = new HashMap<String, String>();
        mockCacheMap.put("pin", "A1B2C3D4E5"); // denotes value that matches pin in request at Constants.PTP_VALIDATION_REQUEST_PATH
        Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(mockCacheMap);
        Mockito.when(ptpMessageUtility.checkPinExpiry(any(String.class))).thenReturn(false);
        IdpResponseDataResponse idpResponseDataResponse = new IdpResponseDataResponse();
        idpResponseDataResponse.setOperationStatus(ServiceResponse.Status.SUCCESS);
        Mockito.when(eligibilityServiceClient.saveIdpResponseData(any(IdpResponseDataRequest.class))).thenReturn(idpResponseDataResponse);
        Mockito.doNothing().when(idpProcessor).updateIdProofingStatus(any(IdpStatus.class), any(String.class), any(ConsumerContext.class));
        Mockito.doNothing().when(accountSetupMessageUtility).writeToEmailQ(any(Consumer.class), any(ConsumerContext.class));
        Mockito.doNothing().when(ptpMessageUtility).deletePinFromCache(any(String.class));
        Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

        testValidatePtpEndpoint(
                JsonUtils.toJson(getPtpValidationRequest()),
                status().isOk(),
                Constants.VALIDATE_PTP_SUCCESS_RESPONSE_PATH,
                false
        );
      verify(idpProcessor, atLeastOnce()).updateIdProofingStatus(eq(IdpStatus.PASS), eq("1234"),
        any(ConsumerContext.class));
    }

    @Test
    public void testValidatePtp_success_attempt_again_in_new_session_success() throws Exception{
        Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
        Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class)))
        	.thenReturn(JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.EXAMPLE_ELIGIBILITY_SERVICE_IDP_RESPONSE_PTP_SUBMIT_PIN_PASS)), IdpResponseDataResponse.class));
        Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

        testValidatePtpEndpoint(
                JsonUtils.toJson(getPtpValidationRequest()),
                status().isOk(),
                Constants.VALIDATE_PTP_SUCCESS_RESPONSE_PATH,
                false
        );
    }

  @Test
  public void testValidatePtp_retry() throws Exception{
    Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
    Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class))).thenReturn(null);
    Map<String, String> mockCacheMap = new HashMap<String, String>();
    mockCacheMap.put("pin", "1234");
    Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(mockCacheMap);
    Mockito.when(ptpMessageUtility.checkPinExpiry(any(String.class))).thenReturn(false);

    testValidatePtpEndpoint(
      JsonUtils.toJson(getPtpValidationRequest()),
      status().isOk(),
      Constants.VALIDATE_PTP_RETRY_RESPONSE_PATH,
      false
    );
    verify(idpProcessor, atLeastOnce()).updateIdProofingStatus(eq(IdpStatus.FAIL), eq("1234"),
      any(ConsumerContext.class));
  }

  @Test
  public void testValidatePtp_customer_record_not_found_for_email_retry() throws Exception{
    Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(null);
    Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(null);

    testValidatePtpEndpoint(
      JsonUtils.toJson(getPtpValidationRequest()),
      status().isOk(),
      Constants.VALIDATE_PTP_RETRY_RESPONSE_PATH,
      false
    );
  }

  @Test
  public void testValidatePtp_customer_record_found_but_pin_not_in_cache_retry() throws Exception{
    Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
    Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class))).thenReturn(null);
    Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(null);

    testValidatePtpEndpoint(
      JsonUtils.toJson(getPtpValidationRequest()),
      status().isOk(),
      Constants.VALIDATE_PTP_RETRY_RESPONSE_PATH,
      false
    );
  }

  @Test
  public void testExpiredPin_Exception() throws Exception{
    Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
    Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class))).thenReturn(null);
    Map<String, String> mockCacheMap = new HashMap<String, String>();
    mockCacheMap.put("pin", "1234");
    mockCacheMap.put(PtpMessageUtility.PIN_EXPIRATION_DATE, "1234");
    Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(mockCacheMap);
    Mockito.when(ptpMessageUtility.checkPinExpiry(anyString())).thenReturn(true); // denotes pin has expired
    Mockito.when(eligibilityServiceClient.saveIdpResponseData(any(IdpResponseDataRequest.class))).thenReturn(new IdpResponseDataResponse());
    Mockito.doNothing().when(ptpMessageUtility).deletePinFromCache(any(String.class));
    Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

    testValidatePtpEndpoint(
        JsonUtils.toJson(getPtpValidationRequest()),
        status().isInternalServerError(),
        Constants.VALIDATE_PTP_EXPIRE_RESPONSE_PATH,
        false
      );

    verify(idpProcessor, atLeastOnce()).updateIdProofingStatus(eq(IdpStatus.FAIL), eq("1234"),
      any(ConsumerContext.class));
  }

  @Test
  public void testValidatePtp_last_retry_failure() throws Exception{
    Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
    Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class))).thenReturn(null);
    Map<String, String> mockCacheMap = new HashMap<String, String>();
    mockCacheMap.put("pin", "1234");
    Mockito.when(ptpMessageUtility.readPtpDataFromCache(any(String.class))).thenReturn(mockCacheMap);
    Mockito.when(ptpMessageUtility.checkPinExpiry(any(String.class))).thenReturn(false);
    Mockito.when(eligibilityServiceClient.saveIdpResponseData(any(IdpResponseDataRequest.class))).thenReturn(new IdpResponseDataResponse());
    Mockito.doNothing().when(ptpMessageUtility).deletePinFromCache(any(String.class));
    Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

    testValidatePtpEndpoint(
      JsonUtils.toJson(getPtpValidationRequest()),
      status().isInternalServerError(),
      Constants.VALIDATE_PTP_EXPIRE_RESPONSE_PATH,
      true
    );
    verify(idpProcessor, atLeastOnce()).updateIdProofingStatus(eq(IdpStatus.FAIL), eq("1234"),
      any(ConsumerContext.class));
  }

  @Test
  public void testValidatePtp_terminal_failure_attempt_again_in_new_session_failure() throws Exception{
      Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
      Mockito.when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
      Mockito.when(consumerService.findConsumerByEmail(any(String.class), any(ConsumerContext.class))).thenReturn(getConsumerDetailsList());
      Mockito.when(eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(any(String.class), any(String.class)))
      	.thenReturn(JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.EXAMPLE_ELIGIBILITY_SERVICE_IDP_RESPONSE_PTP_SUBMIT_PIN_FAIL)), IdpResponseDataResponse.class));
      Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));

      testValidatePtpEndpoint(
              JsonUtils.toJson(getPtpValidationRequest()),
              status().isInternalServerError(),
              Constants.VALIDATE_PTP_EXPIRE_RESPONSE_PATH,
              false
      );
  }

    @Test
    public void testValidatePtp_invalidPin_returnsValidationError()  throws Exception{
      Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));
      PTPConsumer request = getPtpValidationRequest();
        request.setPin("tooShort");

        testValidatePtpEndpoint(
                JsonUtils.toJson(request),
                status().isBadRequest(),
                Constants.PTP_VALIDATION_ERROR_RESPONSE_PATH,
                false
        );
    }

    @Test
    public void testValidatePtp_invalidEmail_returnsValidationError()  throws Exception{
    	Mockito.doNothing().when(sessionUtil).invalidateSession(any(HttpServletRequest.class));
        PTPConsumer request = getPtpValidationRequest();
        request.setEmail("wrong.com");

        testValidatePtpEndpoint(
                JsonUtils.toJson(request),
                status().isBadRequest(),
                Constants.PTP_VALIDATION_ERROR_RESPONSE_PATH,
                false
        );
    }

    @Test
    public void testValidatePtp_invalidReCaptchaResponse_returnsValidationError()  throws Exception{
        Mockito.when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(false);

        testValidatePtpEndpoint(
                JsonUtils.toJson(getPtpValidationRequest()),
                status().isOk(),
                Constants.PTP_RECAPTCHA_ERROR_RESPONSE_PATH,
                false
        );
    }

    private Consumer getConsumerDetailsList(){
    	Consumer consumer = new Consumer();
    	consumer.setConsumerKey("1234");
    	consumer.setFirstName("testFirstName");
    	return consumer;
    }
    public String getPlainConsumer() throws Exception {
      return JsonUtils.toJson(getConsumerDetailsList());
    }

    public String getEncryptedConsumer(Consumer consumer) throws Exception {
      return "ENC(" + JsonUtils.toJson(consumer) + ")";
    }
}
