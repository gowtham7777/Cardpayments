package com.efx.pet.service.registration.controller;

import static com.efx.pet.utility.CommonConstants.DEFAULT_CAMPAIGNCODE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.pet.service.registration.util.DecryptionServiceUtil;
import com.efx.pet.utility.QueryParamEnums;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.domain.partnertenant.Settings;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.utility.CommonConstants;

/*
 * Created by rrk4 on 12/08/2017.
 */

@WebMvcTest
public class AgentProxyControllerTest {
  private DecryptionServiceUtil decryptionService;
	private MockMvc mockMvc;
	private SessionUtil sessionUtil;
	private PartnerTenantClient partnerTenantClient;
	AgentProxyController controllerUnderTest;
	MockHttpSession session;

	private final String REGULATED_SKU = "2345";

	@Before
	public void setup() throws CoreServiceClientException {
		this.partnerTenantClient = mock(PartnerTenantClient.class);
		this.sessionUtil = mock(SessionUtil.class);
		this.decryptionService= mock(DecryptionServiceUtil.class);
		when(partnerTenantClient.getFrontEndBundleLocation()).thenReturn("any-URL");
		this.controllerUnderTest = new AgentProxyController(sessionUtil, partnerTenantClient, decryptionService);
		this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
		session = new MockHttpSession();
		session.setAttribute(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
	}

  @Test
  public void testBeginProxySuccess_Regulatory() throws Exception {
    final String AGENT_ID = "agent123";
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Assert.assertNotNull(mockMvc);
    MvcResult result = mockMvc
      .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
        .param("campaignCode", "testCampaign")
        .session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html"))
      .andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull("ConsumerContext is null.", consumerContext);
    Assert.assertNotNull("Conversation Id is null", consumerContext.getConversationId());
    Assert.assertNotNull("Session Id is null", consumerContext.getSessionId());
    Assert.assertEquals(AGENT_ID, consumerContext.getAgentId());
    Assert.assertNull(consumerContext.getUpsellSkuId());
    Assert.assertEquals("testCampaign", consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertNull(consumerContext.getIntent());
  }

    @Test
    public void testBeginProxyFailure_InvalidAgentId() throws Exception {
        final String AGENT_ID = "agen*t123!";
        ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
        when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
        Assert.assertNotNull(mockMvc);
        MvcResult result = mockMvc
                .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
                        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
                        .param("campaignCode", "testCampaign")
                        .session(session))
                .andExpect(MockMvcResultMatchers.status().isFound())
                .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html#system-error"))
                .andReturn();
    }

  @Test
  public void testBeginProxySuccess_Regulatory_WithOfferCodeAndType() throws Exception {
    final String AGENT_ID = "agent123";
    Mockito.when(decryptionService.decryptOfferCode(any(), any())).thenReturn("TestValue");
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Assert.assertNotNull(mockMvc);
    MvcResult result = mockMvc
      .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
        .param("campaignCode", "testCampaign")
        .param("offerCode", "hQIOA2RdRSpx2eXcEAf8COWKf9BgtaTwzyumfRtTsZRWsTKFwR3Q+zdapQvkly2HqsK0oOuo8kf/IgLLX6xX0/752iJbdWSh0OAh9td7x0wZTv4xsRQYm24tXxcS1gjZ5tQk/7+pil9cdQomQewrsZUR7Xu7daH6TQ2rA/PO0yIshNdsfP/6i0kYreqlato18iGNu4KAZoiaWxHUVqFr0dGcpcZnG+NDljd++h5V0oaUkpmy+OWP3PCUbYGx36pTwizKZjHOhpnsRMdtik6pqfVJcDg7CWNba33gvrqDHLT124FMljCK1HVT05eX6Z+C3xTlUuBYIqQa6ahQU8iC1vScUxDB6PhxEwdR4j6ptgf5AcyroRXTfoKxnbqbDQd09NvxIw8wBZqcUtYgkDQDBEPQLq0wBRFTO21a5NEqRgRPASFv3LC/D0nx1KM4KH165Ukel3bxbC1womjs238+kHYqZZuaG5Xc/WpA9yTF7VwKHzpML4BfNcxItAtsLvwRFurhUuF9smIyPWwkDVJaJSZOU3GCiK543bakStRRRDTXtGAd6l4KUp9Qi2uJdrlpr8d0SQSpdlNPtF4gHw/E4Kwo1krUfjhjsk8Q/BnWoa3+V7Tr/kYCF29zGwJx6wdQjzetzzPV51JVswTE161KKDVwoGJaHEzS7j3jApxFlbnXJD3zZXm00iBctrUB3b18o9JCAXff/ywFv+JBA8WURqxUqIz5+1hDWmxPKbqQ7O81k9IrWFh+DZ8KtrlAC75c7yZ3yhbfCaeIXmZ5BADnYoWUBEzf=4eri")
        .session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html"))
      .andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull("ConsumerContext is null.", consumerContext);
    Assert.assertNotNull("Conversation Id is null", consumerContext.getConversationId());
    Assert.assertNotNull("Session Id is null", consumerContext.getSessionId());
    Assert.assertEquals(AGENT_ID, consumerContext.getAgentId());
    Assert.assertNull(consumerContext.getUpsellSkuId());
    Assert.assertEquals("testCampaign", consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    Assert.assertEquals("TestValue", consumerContext.getQueryParamsMap().get(QueryParamEnums.OFFERCODE.value()));
    Assert.assertNull(consumerContext.getIntent());
  }

  @Test
  public void testBeginProxySuccess_NonRegulatory() throws Exception {
    final String AGENT_ID = "agent123";
    final String UPSELL_SKUID_VALUE = "9876";
	when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Assert.assertNotNull(mockMvc);

	MvcResult result = mockMvc
      .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
		.param("externalProductReference", UPSELL_SKUID_VALUE)
		.session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("any-URL"))
      .andReturn();

	ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull("ConsumerContext is null.", consumerContext);
    Assert.assertNotNull("Conversation Id is null", consumerContext.getConversationId());
    Assert.assertNotNull("Session Id is null", consumerContext.getSessionId());
    Assert.assertEquals(AGENT_ID, consumerContext.getAgentId());
    Assert.assertEquals(UPSELL_SKUID_VALUE, consumerContext.getUpsellSkuId().toString());
    Assert.assertNull(consumerContext.getIntent());
    Assert.assertEquals(DEFAULT_CAMPAIGNCODE,consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
  }

  @Test
  public void testBeginProxyFailure_Regulatory_ProxyParamMissing() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Assert.assertNotNull(mockMvc);
    mockMvc.perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
      .session(session))
      .andExpect(MockMvcResultMatchers.status().isBadRequest())
      .andReturn();
  }

  @Test
  public void testBeginProxyFailure_Regulatory_ProxyParamValueMissing() throws Exception {
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../UCSC/index.html");
    Assert.assertNotNull(mockMvc);
    mockMvc.perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
      .param(Constants.AGENT_BEGIN_PROXY_PARAM, "")
      .session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../UCSC/index.html#system-error"))
      .andReturn();
  }

  @Test
  public void testBeginProxyFailure_NonRegulatory_InvalidCampaignCode() throws Exception {
    final String AGENT_ID = "agent123";
    final String UPSELL_SKUID_VALUE = "9876";
    final String INVALID_CAMPAIGN_CODE = "ABC_*";
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../MY-EFX-US/index.html");
    when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Assert.assertNotNull(mockMvc);
    mockMvc
      .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
        .param("externalProductReference", UPSELL_SKUID_VALUE)
        .param("campaignCode", INVALID_CAMPAIGN_CODE)
        .session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../MY-EFX-US/index.html#system-error"))
      .andReturn();
  }

  @Test
  public void testBeginProxySuccess_NonRegulatory_ValidCampaignCode() throws Exception {
    final String AGENT_ID = "agent123";
    final String UPSELL_SKUID_VALUE = "9876";
    final String VALID_CAMPAIGN_CODE = "ABC20OFF";
    ReflectionTestUtils.setField(controllerUnderTest, "frontEndBundleLocation", "../../MY-EFX-US/index.html");
    when(partnerTenantClient.getSettings()).thenReturn(getMockPartnerSettings());
    Assert.assertNotNull(mockMvc);
    MvcResult result = mockMvc
      .perform(MockMvcRequestBuilders.get(Constants.AGENT_BEGIN_PROXY_ENDPOINT)
        .param(Constants.AGENT_BEGIN_PROXY_PARAM, AGENT_ID)
        .param("externalProductReference", UPSELL_SKUID_VALUE)
        .param("campaignCode", VALID_CAMPAIGN_CODE)
        .session(session))
      .andExpect(MockMvcResultMatchers.status().isFound())
      .andExpect(MockMvcResultMatchers.redirectedUrl("../../MY-EFX-US/index.html"))
      .andReturn();
    ConsumerContext consumerContext = (ConsumerContext) result.getRequest().getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    Assert.assertNotNull("ConsumerContext is null.", consumerContext);
    Assert.assertNotNull("Conversation Id is null", consumerContext.getConversationId());
    Assert.assertNotNull("Session Id is null", consumerContext.getSessionId());
    Assert.assertEquals(AGENT_ID, consumerContext.getAgentId());
    Assert.assertEquals(UPSELL_SKUID_VALUE, consumerContext.getUpsellSkuId().toString());
    Assert.assertNull(consumerContext.getIntent());
    Assert.assertEquals(VALID_CAMPAIGN_CODE, consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
  }

	private Settings getMockPartnerSettings() {
		Settings settings = new Settings();
		settings.setSkuId(REGULATED_SKU);
		return settings;
	}

	private ConsumerContext createMockConsumerContext() {
		ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		consumerContext.setPartnerId("EFX-DIRECT-US");
		consumerContext.setTenantId("EFX-US");
		consumerContext.setChannel(ChannelEnum.DESKTOP);
		consumerContext.setDefaultLocale("en");
		return consumerContext;
	}
}
