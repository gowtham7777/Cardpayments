package com.efx.pet.service.registration.utils;


import com.efx.pet.service.encryption.DecryptionService;
import com.efx.pet.service.registration.util.DecryptionServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DecryptionServiceUtilTest {

  @InjectMocks
  private DecryptionServiceUtil serviceUtil;
  @Mock
  private DecryptionService decryptionService;

  private String encTest = "hQIOA2RdRSpx2eXcEAf+Mfdo8oMzW4XwJqutaJzKtu2J85cp8WvGTjxvdwMQN96el09c6XBS9b9xzV/CB6BpihfINTsAnFubPtkOiNl8llBYim/xo2Uyn2Ee4znji8y3t8M19Ao1fUJANpV4QDYwazL4u0jMm692jsdMm/C75hbR97rX+ajYJAevrNT5nkQ+N8Z5Ga0x/fcBjlgiYJRdS+gbpvMnTOxAJ8hyJuPEbYq923VyNZ556Di2NG0hpNxLWnqIzJKMes8DcwQi0ZqPV1MmXpOfZYd9n8UX5F7tezDn7CmCTcz2op8HcuHFO87KccIUsFMn+p8ow4IdSrphr7won1rSQ14dgm6d1QG9JwgAgZJ7sqKjaHT774m2m3UE/irxZHEeTVqdGwnO1Vv3FLWlzsz2E8/zGSoq6hRna/kxjqm2B7BaL31Sy506eJFDCQXcH8Kbwlh+1T7XALP1k9ezciwU0Q2LuLdKEClNz7Kp9n2J8VY15gqvmeIXjF1YDgnqUbKhtsORxeexTs2CrL5vWyQv1pysJMnsT7VjHGHfyPdci78429G2srgjk+3Gq9Iuc4cXrxtuVIrLKL9EXDjuYwNXYj0B6erl5K8HNXNz3IeNZtYyA82+jFusHGQszhiU8J87owZYH6+asip9wnF4t+Qp+2E15Nm3v+MUf/Z3HjsGYhQvsBuv9wKiI3CvS9JCASdnly4fYGiPC3TsyJxfmzo46vv1Q0lnya6nYVIHTCMRelPdxVL7lHSGk3WMsOuqFPozX5gjF4K6HWq0FLX3Qsf5=inG4";


  @Test
  public void testSuccessfullyDecrypt() {
    String expectedValue = "TestValue";
    when(decryptionService.decryptLine(any())).thenReturn(expectedValue);
    String currentValue = serviceUtil.decryptOfferCode(encTest, null);
    assertEquals(expectedValue, currentValue);
  }

  @Test
  public void testDecryptWithBadMessage() {
    String expectedValue = "TestValue";
    when(decryptionService.decryptLine(any())).thenThrow(IllegalArgumentException.class);
    String currentValue = serviceUtil.decryptOfferCode(encTest, null);
    assertNotEquals(expectedValue,currentValue);
    assertNull(currentValue);
  }


}
