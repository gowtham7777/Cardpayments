package com.efx.pet.service.registration.coreservice;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.efx.pet.client.customer.CustomerServiceClient;
import com.efx.pet.domain.customer.entity.Address;
import com.efx.pet.domain.customer.entity.CustomerAccount;
import com.efx.pet.domain.customer.entity.CustomerContext;
import com.efx.pet.domain.customer.entity.CustomerEnums;
import com.efx.pet.domain.customer.entity.CustomerMessageEnum;
import com.efx.pet.domain.customer.entity.CustomerSubject;
import com.efx.pet.domain.customer.operations.CustomerRequest;
import com.efx.pet.domain.customer.operations.CustomerResponse;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.test.common.TestConfigurationBase;
import com.efx.pet.utility.utils.JsonUtils;

/**
 * Created by lxg90 on 7/14/2018.
 */
@ActiveProfiles(Constants.SPRING_PROFILE_TEST)
@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerServiceTest extends TestConfigurationBase {
  @Value("${com.efx.pet.customer.service.url:}")
  private String url;

  @Autowired
  private CustomerServiceClient customerServiceClient;

  @Ignore
  @Test
  public void testCustomerService() {

    CustomerRequest customerRequest = customerRequestForTesting2();
    customerRequest.setIndirectEnrollmentId("12648");
    customerServiceClient.setUrl(url);
    CustomerResponse customerResponse = null;
    System.out.println("CustomerRequest: " + JsonUtils.toJson(customerRequest));
    try {
      customerResponse = customerServiceClient.saveCustomer(customerRequest);
    }
    catch (HttpClientErrorException ex){
      System.out.println(ex.getMessage());
    }
    catch (Exception e){
      System.out.println(e.getMessage());
    }

    assertNotNull(customerResponse);
    System.out.println("Response: " + customerResponse.toString());
    System.out.println("Status: " + customerResponse.getOperationStatus() +
      " Message: " + customerResponse.getOperationMessage());
  }

  @Ignore
  @Test
  public void testCustomerServiceForExistingCustomer() {

    CustomerRequest customerRequest = customerRequestForTesting2();
    customerRequest.setIndirectEnrollmentId("13428");
    customerServiceClient.setUrl(url);
    CustomerResponse customerResponse = null;
    System.out.println("CustomerRequest: " + JsonUtils.toJson(customerRequest));
    try {
      customerResponse = customerServiceClient.saveCustomer(customerRequest);
      if(customerResponse.getOperationStatus() == CustomerEnums.Status.FAILURE &&
        customerResponse.getOperationMessageCode() != null &&
        customerResponse.getOperationMessageCode().contains(CustomerMessageEnum.CUSTOMER_EXISTS_IEI.getCode())) {
        System.out.println("CustomerResponse existing customerKey: " + customerResponse.getCustomerKey() +
        "for iei: " + customerResponse.getIndirectEnrollmentId());
      }


      if(customerResponse.getOperationStatus() == CustomerEnums.Status.FAILURE) {
        System.out.println(" OperationStatus is FAILURE");
      }

      if(customerResponse.getOperationMessageCode().contains(CustomerMessageEnum.CUSTOMER_EXISTS_IEI.getCode())){
        System.out.println("OperationMessageCode: " + customerResponse.getOperationMessageCode() +
          " CustomerMesageEnum customer_exist_iei: " + CustomerMessageEnum.CUSTOMER_EXISTS_IEI.getCode() + " ");
      }
    }
    catch (HttpClientErrorException ex){
      System.out.println(ex.getMessage());
    }
    catch (Exception e){
      System.out.println(e.getMessage());
    }

    assertNotNull(customerResponse);
    System.out.println("Response: " + customerResponse.toString());
    System.out.println("Status: " + customerResponse.getOperationStatus() +
      " Message: " + customerResponse.getOperationMessage());
  }

  @Ignore
  @Test
  public void  testUpdateEmailByCustomerKey() {
    CustomerRequest customerUpdateRequest = customerRequestForTesting2();
    customerUpdateRequest.setCustomerKey("4f4cb84c-8572-49ce-af99-269d682f69e0");
    CustomerSubject customerSubject = new CustomerSubject();
    customerSubject.setEmailAddress("lpg81001@gmail.com");
    customerUpdateRequest.setCustomerSubject(customerSubject);
    customerServiceClient.setUrl(url);
    CustomerResponse resposne = null;

    try {
      resposne = customerServiceClient.updateCustomer(customerUpdateRequest);

      if(resposne != null){
        System.out.println("Response json format: " + JsonUtils.toJson(resposne));
      }
    }
    catch (Exception ex){
      System.out.println("Exception {}" + ex.getMessage());
    }
  }

  @Ignore
  @Test
  public void  testUpdateEmailByExistingCustomerKey() {
    CustomerRequest customerUpdateRequest = new CustomerRequest();
    customerUpdateRequest.setCustomerKey("4f4cb84c-8572-49ce-af99-269d682f69e0");
    CustomerSubject customerSubject = new CustomerSubject();
    customerSubject.setEmailAddress("lpg81001@gmail.com");
    customerUpdateRequest.setCustomerSubject(customerSubject);
    customerServiceClient.setUrl(url);
    CustomerResponse resposne = null;

    try {
      resposne = customerServiceClient.updateCustomer(customerUpdateRequest);

      if(resposne != null){
        System.out.println("Response json format: " + JsonUtils.toJson(resposne));
      }
    }
    catch (Exception ex){
      System.out.println("Exception {}" + ex.getMessage());
    }
  }

  public CustomerSubject createRequestSubject(){
    CustomerSubject customerSubject = new CustomerSubject();
    customerSubject.setFirstName("GERTRUDE");
    customerSubject.setLastName("HARKENREADEO");
    customerSubject.setDateOfBirth("06/08/1967");
    customerSubject.setSsn("666066112");
    Address addressPrimary = new Address();
    addressPrimary.setAddressLine1("305 LINDEN AV");
    addressPrimary.setCity("Atlanta");
    addressPrimary.setState("GA");
    addressPrimary.setCountry("USA");
    addressPrimary.setZipCode("30316");
    addressPrimary.setAddressType(CustomerEnums.AddressType.CURRENT);
    List<Address> addressList = new ArrayList<>();
    addressList.add(addressPrimary);
    customerSubject.setAddresses(addressList);

    return customerSubject;
  }

  public CustomerSubject createRequestSubjectGlinda(){
    CustomerSubject customerSubject = new CustomerSubject();
    customerSubject.setFirstName("GLINDA");
    customerSubject.setLastName("PWZLDFNXZ");
    customerSubject.setDateOfBirth("01/11/1987");
    customerSubject.setSsn("666292801");
    Address addressPrimary = new Address();
    addressPrimary.setAddressLine1("805 HIGHWAY 67 N");
    addressPrimary.setCity("TUCKERMAN");
    addressPrimary.setState("AR");
    addressPrimary.setCountry("USA");
    addressPrimary.setZipCode("72473");
    addressPrimary.setAddressType(CustomerEnums.AddressType.CURRENT);
    List<Address> addressList = new ArrayList<>();
    addressList.add(addressPrimary);
    customerSubject.setAddresses(addressList);

    return customerSubject;
  }
  /**
   * Use this method JUST to create json request and add them to src/test/resources/request
   **/
  public CustomerRequest customerRequestForTesting() {
    CustomerRequest request = new CustomerRequest();
    CustomerAccount customerAccount = new CustomerAccount();
    customerAccount.setCustomerContext(createCustomerContext());
    customerAccount.setCustomerAccountStatus(CustomerEnums.CustomerAccountStatus.ACTIVE);

    request.setCustomerAccount(customerAccount);
    CustomerSubject customerSubject = new CustomerSubject();
    customerSubject.setFirstName("John");
    customerSubject.setLastName("Doe");
    customerSubject.setDateOfBirth("10/10/1950");
    customerSubject.setEmailAddress(generateRandomEmail());
    customerSubject.setSsn("666645857");
    Address addressPrimary = new Address();
    addressPrimary.setAddressLine1("123 Main St");
    addressPrimary.setAddressLine2("Suite 123");
    addressPrimary.setCity("Alpharetta");
    addressPrimary.setState("GA");
    addressPrimary.setCountry("USA");
    addressPrimary.setZipCode("30005");
    addressPrimary.setAddressType(CustomerEnums.AddressType.CURRENT);
    Address addressPrevious = new Address();
    addressPrevious.setAddressLine1("123 Main St");
    addressPrevious.setAddressLine2("Suite 123");
    addressPrevious.setCity("Alpharetta");
    addressPrevious.setState("GA");
    addressPrevious.setCountry("USA");
    addressPrevious.setZipCode("30005");
    addressPrevious.setAddressType(CustomerEnums.AddressType.PREVIOUS);
    List<Address> addressList = new ArrayList<>();
    addressList.add(addressPrimary);
    addressList.add(addressPrevious);
    customerSubject.setAddresses(addressList);
    request.setCustomerSubject(customerSubject);

    String customerRequest = JsonUtils.toJson(request);
    System.out.println("customerRequest = " + customerRequest);
    return request;
  }

  public CustomerRequest customerRequestForTesting2() {
    CustomerRequest request = new CustomerRequest();
    CustomerAccount customerAccount = new CustomerAccount();
    customerAccount.setCustomerContext(createCustomerContext());
    customerAccount.setCustomerAccountStatus(CustomerEnums.CustomerAccountStatus.ACTIVE);

    request.setCustomerAccount(customerAccount);
    request.setCustomerSubject(createRequestSubjectGlinda());

    String customerRequest = JsonUtils.toJson(request);
    System.out.println("customerRequest = " + customerRequest);
    return request;
  }

  public CustomerRequest customerRequestForTesting3() {
    CustomerRequest request = new CustomerRequest();
    CustomerAccount customerAccount = new CustomerAccount();
    customerAccount.setCustomerContext(createCustomerContext());
    customerAccount.setCustomerAccountStatus(CustomerEnums.CustomerAccountStatus.ACTIVE);

    request.setCustomerAccount(customerAccount);
    request.setCustomerSubject(createRequestSubject());

    String customerRequest = JsonUtils.toJson(request);
    System.out.println("customerRequest = " + customerRequest);
    return request;
  }

  public CustomerContext createCustomerContext() {
    CustomerContext customerContext = new CustomerContext();
    customerContext.setPartnerKey("UCSC");
    customerContext.setTenantKey("EFX-US");
    return customerContext;
  }

  /**
   * Method to generate random String for email address
   *
   * @return
   */

  private String generateRandomEmail() {
    Random random = new Random();
    String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    StringBuilder randomEmail = new StringBuilder();
    while (randomEmail.length() < 5) {
      int index = (int) (random.nextFloat() * alphaNumeric.length());
      randomEmail.append(alphaNumeric.charAt(index));
    }
    randomEmail.append("@gmail.com");
    return randomEmail.toString();

  }
}
