package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.efx.pet.domain.Address;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.EidStatus;
import com.efx.pet.domain.KbaPackage;
import com.efx.pet.domain.ServiceResponse;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.domain.idp.EidCompareResponse;
import com.efx.pet.domain.idp.PhoneVerificationResponse;
import com.efx.pet.domain.idp.PinToPostResponse;
import com.efx.pet.domain.message.EmergencyBreakQueueMessage;
import com.efx.pet.domain.tid.common.IDPData;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.direct.registration.RegistrationResponse;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.direct.registration.RegistrationServiceException;
import com.efx.pet.service.idproofing.FraudEligibilityResponse;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.policies.PoliciesService;
import com.efx.pet.service.idproofing.IdProofingResponse.StatusCode;
import com.efx.pet.service.registration.CreateAccountResponse;
import com.efx.pet.service.registration.controller.processor.CreateAccountProcessor;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.cache.redis.util.PiiToHashUtility;
import com.efx.pet.utility.configuration.utils.JsonUtils;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {CreateAccountController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
	"com.efx.pet.feature.emergencyBreak.enabled:false",
	"aws.sqs.emergency.break.queue.name:queue-name"
})
public class CreateAccountControllerTest {

    private MockMvc mockMvc;

    @MockBean
    ObtainIpUtility obtainIpUtility;

    @MockBean
    EncryptUtility encryptUtility;

    @MockBean
    PiiToHashUtility piiToHashUtility;

    @MockBean
    CreateAccountProcessor createAccountProcessor;

    @MockBean
    SessionUtil sessionUtil;
    
    @MockBean
    RegistrationService registrationService;
    
    @MockBean
    private IdProofingService idProofingService;
    
    @MockBean
    PoliciesService policiesService;
    
    @Autowired
    private CreateAccountController controllerUnderTest;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    /* Testing createAccount endpoint */

    @Test
    public void testCreateAccount_registrationResponseIsNull_returnsCreateAccountSystemError() throws Exception {
        when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).thenReturn(null);
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }
    
    @Test
    public void testCreateAccount_registrationResponseSystemError_returnsCreateAccountSystemError() throws Exception {
        RegistrationResponse response = new RegistrationResponse(RegistrationResponse.StatusCode.CREATE_CREDENTIALS_SYSTEM_ERROR);
        when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).
            thenReturn(response);
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }
    
    @Test
    public void testCreateAccount_createCredentialsThrowsRuntimeException_returnsCreateAccountSystemError() throws Exception {
      when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).thenThrow(new RegistrationServiceException("Unhandled Exception"));
      when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }
    
    @Test
    public void testCreateAccount_success_returnsGetPinStatusCode() throws Exception {
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
            getSuccessfulFraudEligibilityResponse(),
            new IdProofingResponse(StatusCode.GET_PIN_TO_TEXT, false)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");
        
        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.GET_PIN_TO_TEXT
        );
    }
    
    @Test
    public void testCreateAccount_success_returnsCreateAccountSuccess() throws Exception {
    
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
            getSuccessfulFraudEligibilityResponse(),
            new IdProofingResponse(StatusCode.GET_PIN_TO_TEXT, false)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");
        
        
        testCreateAccountEndpoint(
        	getSuccessfulCreateAccountDecisionPolicyContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.GET_PIN_TO_TEXT
        );
    }

    @Test
    public void testCreateAccount_success_returnsCreateAccountSuccess_AgentFlow() throws Exception {

        mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
                new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
                getSuccessfulFraudEligibilityResponse(),
                new IdProofingResponse(StatusCode.GET_PIN_TO_TEXT, false)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");

        testCreateAccountEndpoint(
                getSuccessfulCreateAccountDecisionPolicyContent(),
                getSessionAttrWithAgent(getEncryptedConsumer(true)),
                status().isOk(),
                CreateAccountResponse.StatusCode.GET_PIN_TO_TEXT
        );
    }

    @Test
    public void testCreateAccount_CreateAccountPolicyDecisionNull() throws Exception {
    
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
            getSuccessfulFraudEligibilityResponse(),
            new IdProofingResponse(StatusCode.GET_PIN_TO_TEXT, false)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");
        
        
        testCreateAccountEndpoint(
        	getSuccessfulCreateAccountDecisionPolicyContentNull(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.GET_PIN_TO_TEXT
        );
    }
    
    @Test
    public void testCreateAccount_passwordIsEmpty_returnsValidationErrorStatusCode() throws Exception {
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        sessionattr.put(CommonConstants.CONSUMER_DATA, getEncryptedConsumer(true));

        testCreateAccountEndpoint(
            "{\"username\":\"abc@equifax.com\",\"password\":\"\",\"confirmPassword\":\"abc@equifax.com\"}",
            sessionattr,
            status().isBadRequest(),
            CreateAccountResponse.StatusCode.VALIDATION_ERROR
        );
    }

    @Test
    public void testCreateAccount_fraudEligibilityResponseIsNull_returnsConsumerSavePartialSuccessSystemError() throws Exception {
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
            null,
            null
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR
        );
    }

    @Test
    public void testCreateAccount_emailInUse_returnsDuplicateEnrollmentStatusCode() throws Exception {
        when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).
        	thenReturn(new RegistrationResponse(RegistrationResponse.StatusCode.EMAIL_IN_USE));
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.DUPLICATE_ENROLLMENT
        );
    }
    
    @Test
    public void testCreateAccount_credentialsExist_returnsDuplicateEnrollmentStatusCode() throws Exception {
        when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).
        	thenReturn(new RegistrationResponse(RegistrationResponse.StatusCode.CUSTOMER_CREDENTIALS_EXIST));
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.DUPLICATE_ENROLLMENT
        );
    }

    @Test
    public void testCreateAccount_optPhoneNotEligible_returnsKbaQuizSuccessStatusCode() throws Exception {
    	String kbaPackageXml = TestHelper.fetchClassPathFile(Constants.GENERATE_QUIZ_SUCCESS_KBA_PACKAGE_PATH);
    	KbaPackage kbaPackage = TestHelper.createObjectFromXmlString(kbaPackageXml, KbaPackage.class);
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS, null, "testCuuid"),
            getFraudEligibilityResponse(false, true, true),
            new IdProofingResponse(StatusCode.KBA_QUIZ_SUCCESS, false, kbaPackage)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(Constants.CREATE_ACCOUNT_ENDPOINT)
            .contentType(MediaType.APPLICATION_JSON)
            .content(getSuccessfulCreateAccountContent())
            .sessionAttrs(getSessionAttr(getEncryptedConsumer(false)))
        )
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();

        Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
        KbaResponse kbaResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), KbaResponse.class);
        Assert.assertEquals(KbaResponse.StatusCode.KBA_QUIZ_SUCCESS, kbaResponse.getStatusCode());
        Assert.assertEquals("1", kbaResponse.getQuizIdentifier());
        Assert.assertEquals(4, kbaResponse.getQuestions().size());
    }

    @Test
    public void testCreateAccount_emergencyBreakEnabled_returnsEmergencyBreakOnStatusCode() throws Exception {
        //set isEmergencyBreakEnabled true
        ReflectionTestUtils.setField(controllerUnderTest, "isEmergencyBreakEnabled", "true");
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.EMERGENCY_BREAK_ON
        );

        //set isEmergencyBreakEnabled false for tests after this
        ReflectionTestUtils.setField(controllerUnderTest, "isEmergencyBreakEnabled", "false");
    }

    @Test
    public void testCreateAccount_eidResponseisNoHit_returnsEligibilityCheckNoHitStatusCode() throws Exception {
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
            new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
            getFraudEligibilityResponse(true, false, true),
            new IdProofingResponse(StatusCode.ELIGIBILITY_CHECK_NO_HIT, false)
        );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isAccepted(),
            CreateAccountResponse.StatusCode.ELIGIBILITY_CHECK_NO_HIT
        );
    }


    @Test
    public void testCreateAccount_nullConsumer_returnsCreateAccountSystemError() throws Exception {
        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }
    
    @Test
    public void testCreateAccount_generateQuizFailure_returnsKbaQuizErrorStatusCode() throws Exception {
    	mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
                new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS),
                getFraudEligibilityResponse(false, true, false),
                new IdProofingResponse(StatusCode.KBA_QUIZ_ERROR, false)
            );
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("ip_address");
        when(obtainIpUtility.obtainIpAddressVersion(anyString())).thenReturn("ip_address_version");
        IdProofingResponse idProofingResponse = new IdProofingResponse(StatusCode.KBA_QUIZ_ERROR);
        when(idProofingService.initiateIdProofing(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isAccepted(),
            CreateAccountResponse.StatusCode.KBA_QUIZ_ERROR
        );
    }

    @Test
    public void testCreateAccount_checkFraudEligibilityThrowsRuntimeException_returnsConsumerSavePartialSuccessSystemError() throws Exception {
        when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class))).
    		thenReturn(new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS));
        when(idProofingService.checkFraudEligibility(any(Consumer.class), any(ConsumerContext.class))).thenThrow(new IdProofingServiceException("eligibility_error"));
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            getSuccessfulCreateAccountContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR
        );
    }

    @Test
    public void testCreateAccount_testPasswords() throws Exception {
        String[] invalidPasswords = {"pass", "password123", "PPassword12", "Pass word123",
            "Pass#word123", "Pass%word123", "Pass^word123",
            "Pass&word123", "Pass=word123", "Pass(word123",
            "Pass)word123", "Pass{word123", "Pass}word123",
            "Pwd12@", "Password123!456@789$*",
            "!234Test#", "#Test&!", "Test$&$1", "123QQQ+", "_-testA1()", "_-testA1 ()",
            "", null};

        String[] validPasswords = {"passWord@1234567"};

        // valid username, invalid passwords
        for (String invalidPassword : invalidPasswords) {
            boolean valid = controllerUnderTest.validate(invalidPassword, "username@equifax.com");
            Assert.assertEquals(valid, false);
        }

        // valid username, valid password
        for (String validPassword : validPasswords) {
            boolean valid = controllerUnderTest.validate(validPassword, "username@equifax.com");
            Assert.assertEquals(valid, true);
        }

        // invalid username, valid password
        boolean valid = controllerUnderTest.validate("passWord@1234567", "username");
        Assert.assertEquals(valid, false);
    }

    @Test
    public void testCreateAccount_passwordSameAsUsername() throws Exception {
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
            "{\"username\":\"abc@equifax.com\",\"password\":\"abc@equifax.com\",\"confirmPassword\":\"abc@equifax.com\"}",
            getSessionAttr(getEncryptedConsumer(true)),
            status().isBadRequest(),
            CreateAccountResponse.StatusCode.VALIDATION_ERROR
        );
    }

    /* Testing initiateEmergencyBreak endpoint */

    @Test
    public void testInitiateEmergencyBreak_success_returnsEmergencyBreakP2pOptedIn() throws Exception {
        ResponseEntity<CreateAccountResponse> responseEntity = new ResponseEntity<CreateAccountResponse>(new CreateAccountResponse(CreateAccountResponse.StatusCode.EMERGENCY_BREAK_P2P_OPTED_IN), HttpStatus.OK);
        when(createAccountProcessor.sendMessageToEmergencyBreakQueue(any(EmergencyBreakQueueMessage.class))).thenReturn(responseEntity);
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testInitiateEmergencyBreakEndpoint(
            getSuccessfulInitiateEbreakContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isOk(),
            CreateAccountResponse.StatusCode.EMERGENCY_BREAK_P2P_OPTED_IN
        );
    }

    @Test
    public void testInitiateEmergencyBreak_nullConsumer_returnsCreateAccountSystemError() throws Exception {
        testInitiateEmergencyBreakEndpoint(
            getSuccessfulInitiateEbreakContent(),
            getSessionAttr(),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }

    @Test
    public void testInitiateEmergencyBreak_throwsRuntimeException_returnsCreateAccountSystemError() throws Exception {
        when(createAccountProcessor.sendMessageToEmergencyBreakQueue(any(EmergencyBreakQueueMessage.class))).thenThrow(new RuntimeException());
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testInitiateEmergencyBreakEndpoint(
            getSuccessfulInitiateEbreakContent(),
            getSessionAttr(getEncryptedConsumer(true)),
            status().isInternalServerError(),
            CreateAccountResponse.StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR
        );
    }

    @Test
    public void whenPasswordContainsUsername_receiveBadRequest() throws Exception {
        when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

        testCreateAccountEndpoint(
        "{\"username\":\"myUsERname@equifax.com\",\"password\":\"Containsmyusername1!\",\"confirmPassword\":\"Containsmyusername1!\"}",
        getSessionAttr(getEncryptedConsumer(true)),
        status().isBadRequest(),
        CreateAccountResponse.StatusCode.VALIDATION_ERROR
      );
    }

  @Test
  public void testCreateAccount_failureToSaveTou_returnsPartialSuccessSystemError() throws Exception {
    mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(
      new RegistrationResponse(RegistrationResponse.StatusCode.SAVE_TOU_SYSTEM_ERROR),
      null,
      null
    );
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(getPlainConsumer(true));

    testCreateAccountEndpoint(
      getSuccessfulCreateAccountContent(),
      getSessionAttr(getEncryptedConsumer(true)),
      status().isOk(),
      CreateAccountResponse.StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR
    );
  }

    /* Testing helper methods */

    public void testCreateAccountEndpoint(String content, HashMap<String, Object> sessionattr, ResultMatcher expectStatus, Enum expectResponseStatusCode) throws Exception {
        testEndpoint(Constants.CREATE_ACCOUNT_ENDPOINT, content, sessionattr, expectStatus, expectResponseStatusCode);
    }

    public void testInitiateEmergencyBreakEndpoint(String content, HashMap<String, Object> sessionattr, ResultMatcher expectStatus, Enum expectResponseStatusCode) throws Exception {
        testEndpoint(Constants.INITIATE_EMERGENCY_BREAK_ENDPOINT, content, sessionattr, expectStatus, expectResponseStatusCode);
    }

    public void testEndpoint(String endpoint, String content, HashMap<String, Object> sessionattr, ResultMatcher expectStatus, Enum expectResponseStatusCode) throws Exception {
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(endpoint)
            .contentType(MediaType.APPLICATION_JSON)
            .content(content)
            .sessionAttrs(sessionattr)
        )
            .andExpect(expectStatus)
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();
        CreateAccountResponse createAccountResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), CreateAccountResponse.class);
        Assert.assertEquals(expectResponseStatusCode, createAccountResponse.getStatusCode());
    }

	public void mockCreateCredentialsCheckFraudEligibilityInitiateIdProofingInterfaceMethods(RegistrationResponse registrationResponse,
			FraudEligibilityResponse fraudEligibilityResponse, IdProofingResponse idProofingResponse) throws Exception {
		Mockito.when(registrationService.createCredentials(any(Consumer.class), any(ConsumerContext.class)))
				.thenReturn(registrationResponse);
		Mockito.when(idProofingService.checkFraudEligibility(any(Consumer.class), any(ConsumerContext.class)))
				.thenReturn(fraudEligibilityResponse);
		Mockito.when(idProofingService.initiateIdProofing(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class)))
				.thenReturn(idProofingResponse);
	}

    public static String getSuccessfulCreateAccountContent() {
        return "{\"username\":\"abc@equifax.com\",\"password\":\"pasWord@123\",\"confirmPassword\":\"pasWord@123\",\"blackBox\":\"myIovationDevice\"}";
    }

    public static String getSuccessfulInitiateEbreakContent() {
        return "{\"username\":\"abc@equifax.com\",\"password\":\"pasWord@123\",\"confirmPassword\":\"pasWord@123\",\"blackBox\":\"myIovationDevice\",\"optedForPinToPost\":\"true\"}";
    }

    public String getEncryptedConsumer(Boolean withPhoneNumber) throws Exception {
        return "ENC(" + getPlainConsumer(withPhoneNumber) + ")";
    }
    
    public static String getSuccessfulCreateAccountDecisionPolicyContent() {
        return "{\"username\":\"abc@equifax.com\",\"password\":\"pasWord@123\",\"confirmPassword\":\"pasWord@123\",\"blackBox\":\"myIovationDevice\",\"termsPolicyDecision\":{\"decision\":\"ACCEPTED\",\"policyVersionId\":101,\"policyType\":\"TermsPackage\"}}";
    }

    public static String getSuccessfulCreateAccountDecisionPolicyContentNull() {
        return "{\"username\":\"abc@equifax.com\",\"password\":\"pasWord@123\",\"confirmPassword\":\"pasWord@123\",\"blackBox\":\"myIovationDevice\",\"termsPolicyDecision\": null}";
    }
    
    public String getPlainConsumer(Boolean withPhoneNumber) throws Exception {
        String consumerString;
        if (withPhoneNumber) {
            consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        } else {
            consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)), Constants.PHONE_NUMBER_KEY);
        }
        Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
        consumer.setConsumerKey("newTestConsumerKey");
        return JsonUtils.toJson(consumer);
    }

    public FraudEligibilityResponse getSuccessfulFraudEligibilityResponse() {
        return getFraudEligibilityResponse(true, true, true);
    }

    public FraudEligibilityResponse getFraudEligibilityResponse(Boolean phoneVerificationSuccess, Boolean eidCompareSuccess, Boolean pinToPostSuccess) {
        EidStatus phoneVerificationResponseStatus = phoneVerificationSuccess ? EidStatus.OTP_PHONE_ELIGIBLE : EidStatus.OTP_PHONE_NOT_ELIGIBLE;
        EidStatus eidCompareResponseStatus = eidCompareSuccess ? EidStatus.PASS : EidStatus.NO_HIT;
        EidStatus pinToPostResponseStatus = pinToPostSuccess ? EidStatus.PIN_TO_POST_ELIGIBLE : EidStatus.PIN_TO_POST_NOT_ELIGIBLE;

        IDPData idpData = new IDPData();

        PhoneVerificationResponse phoneVerificationResponse = new PhoneVerificationResponse();
        phoneVerificationResponse.setStatus(phoneVerificationResponseStatus);
        idpData.setPhoneVerificationResponse(phoneVerificationResponse);

        EidCompareResponse eidCompareResponse = new EidCompareResponse();
        eidCompareResponse.setStatus(eidCompareResponseStatus);
        EidCompareResponse.Metadata authMetadata = new EidCompareResponse.Metadata();
        authMetadata.setEligibilityNoHit(!eidCompareSuccess);
        eidCompareResponse.setMetadata(authMetadata);
        idpData.setEidCompareResponse(eidCompareResponse);

        Address address = new Address("addressLine1", "addressLine2", "Alpharetta", "GA", "30005");
        idpData.setStandardCurrentAddress(address);

        PinToPostResponse pinToPostResponse = new PinToPostResponse();
        pinToPostResponse.setStatus(pinToPostResponseStatus);
        idpData.setPinToPostResponse(pinToPostResponse);

        FraudEligibilityResponse fraudEligibilityResponse = new FraudEligibilityResponse(FraudEligibilityResponse.StatusCode.SUCCESS, idpData);
        return fraudEligibilityResponse;
    }

    public HashMap<String, Object> getSessionAttr() {
        return getSessionAttr(null);
    }

    public HashMap<String, Object> getSessionAttr(String encryptedConsumer) {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        if (!StringUtils.isBlank(encryptedConsumer)) {
            sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
        }
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
        sessionattr.put(CommonConstants.IP_ADDRESS, "localhost");
        return sessionattr;
    }

    public HashMap<String, Object> getSessionAttrWithAgent(String encryptedConsumer) {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        if (!StringUtils.isBlank(encryptedConsumer)) {
            sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
        }
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContextWithAgent());
        sessionattr.put(CommonConstants.IP_ADDRESS, "localhost");
        return sessionattr;
    }

    private ConsumerContext createMockConsumerContext() {
		ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		consumerContext.setPartnerId("EFX-DIRECT-US");
		consumerContext.setTenantId("EFX-US");
		consumerContext.setChannel(ChannelEnum.DESKTOP);
		consumerContext.setDefaultLocale("en");
		return consumerContext;
	}

    private ConsumerContext createMockConsumerContextWithAgent() {
        ConsumerContext consumerContext = createMockConsumerContext();
        consumerContext.setAgentId("Agent007");
        return consumerContext;
    }
    
    private ServiceResponse getServiceResponse() { 
    	ServiceResponse response = new ServiceResponse();
    	response.setOperationStatus(ServiceResponse.Status.SUCCESS);
    	response.setHttpStatus(HttpStatus.OK);
    	response.setOperationMessage("operation successful");
    	return response;
    }
    
    private ServiceResponse getServiceResponseFailure() { 
    	ServiceResponse response = new ServiceResponse();
    	response.setOperationStatus(ServiceResponse.Status.FAILURE);
    	response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    	response.setOperationMessage("operation failure");
    	return response;
    }
}
