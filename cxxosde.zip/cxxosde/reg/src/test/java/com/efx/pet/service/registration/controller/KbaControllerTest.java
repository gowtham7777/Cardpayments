package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.KbaPackage;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.service.registration.domain.KbaResponse.StatusCode;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;

/**
 * Created by rrk4 on 10/28/2017.
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {TestProfileConfig.class, KbaController.class})
public class KbaControllerTest {

    @Autowired
    private KbaController controllerUnderTest;

    private MockMvc mockMvc;

    @MockBean
    @Qualifier("idProofingService")
    private IdProofingService idProofingService;

    @MockBean
	private EncryptUtility encryptUtility;

    @Before
    public void setup() {
		this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    @MockBean
    private SessionUtil sessionUtil;

    @Test
    public void testGetKbaQuizSuccess() throws Exception {

        Assert.assertNotNull(mockMvc);

        String kbaPackageXml = TestHelper.fetchClassPathFile(Constants.GENERATE_QUIZ_SUCCESS_KBA_PACKAGE_PATH);
        KbaPackage kbaPackage = TestHelper.createObjectFromXmlString(kbaPackageXml, KbaPackage.class);
        IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_QUIZ_SUCCESS, false, kbaPackage);
        when(idProofingService.startKba(any(Consumer.class), any(ConsumerContext.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        String encryptedConsumer = createEncryptedConsumer(true);
        sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

        MvcResult result = mockMvc.perform(get(Constants.GET_QUIZ_ENDPOINT).sessionAttrs(sessionattr))
                .andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
        Assert.assertEquals(
                TestHelper.prettyToCompactJson(
                        TestHelper.fetchClassPathFile(Constants.GENERATE_QUIZ_SUCCESS_KBA_RESPONSE_PATH)),
                result.getResponse().getContentAsString());
    }

    @Test
    public void testGetKbaQuizFailure_pinToPostIneligible() throws Exception {

        Assert.assertNotNull(mockMvc);

        IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR, false);
        when(idProofingService.startKba(any(Consumer.class), any(ConsumerContext.class))).thenReturn(idProofingResponse);
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        String encryptedConsumer = createEncryptedConsumer(true);
        sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);

        MvcResult result = mockMvc.perform(get(Constants.GET_QUIZ_ENDPOINT).sessionAttrs(sessionattr))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();
        Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
        Assert.assertEquals(
                TestHelper.prettyToCompactJson(
                        TestHelper.fetchClassPathFile(Constants.GENERATE_QUIZ_FAILURE_KBA_RESPONSE_PATH)),
                result.getResponse().getContentAsString());
    }

    @Test
    public void testGetKbaQuizFailure_returnsPinToPostPrimarySuccess() throws Exception {

        Assert.assertNotNull(mockMvc);

        IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY, false);
        when(idProofingService.startKba(any(Consumer.class), any(ConsumerContext.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        String encryptedConsumer = createEncryptedConsumer(true);
        sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

        MvcResult result = mockMvc.perform(get(Constants.GET_QUIZ_ENDPOINT).sessionAttrs(sessionattr))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();
        Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
        KbaResponse response = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
        Assert.assertEquals(KbaResponse.StatusCode.PIN_TO_POST_PRIMARY, response.getStatusCode());
    }

    @Test
    public void testGetKbaQuizFailure_ConsumerNotInSession() throws Exception {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        String encryptedConsumer = createEncryptedConsumer(true);
        sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
        Assert.assertNotNull(mockMvc);

        MvcResult result = mockMvc.perform(get(Constants.GET_QUIZ_ENDPOINT).sessionAttrs(sessionattr)).andExpect(status().isInternalServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();
        Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
        Assert.assertEquals(
                TestHelper.prettyToCompactJson(
                        TestHelper.fetchClassPathFile(Constants.GENERATE_QUIZ_FAILURE_KBA_RESPONSE_PATH)),
                result.getResponse().getContentAsString());
    }

	@Test
	public void testKbaSubmitAnswersSuccess_withActivationUrl() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_SUCCESS);
		String activationURL = "https://www.trustedid.com/";
		idProofingResponse.setActivationUrl(activationURL);
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));

		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_TID_FLOW_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
		 Mockito.verify(sessionUtil, Mockito.times(1)).invalidateSession(result.getRequest());
	}

	@Test
	public void testKbaSubmitAnswersSuccess() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_SUCCESS);
		Mockito.when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));

		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
		Mockito.verify(sessionUtil, Mockito.times(0)).invalidateSession(result.getRequest());
	}

	@Test
	public void testKbaSubmitAnswersFailure_ConsumerNotInSession() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON)
						.sessionAttrs(sessionattr))
				.andExpect(status().isInternalServerError())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ERROR_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswersFailure_ConsumerWithoutTransactionKeyAndQuizAccessedTime() throws Exception {

		Assert.assertNotNull(mockMvc);

		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(false));

		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isInternalServerError())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ERROR_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswersFailure_whenTimeout() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT);
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isAccepted())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ERROR_TIMEDOUT_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswersFailure_whenAnswersInvalid() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR);
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isAccepted())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ERROR_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswersFailure_whenFraudActor() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.KBA_SUCCESS_ELIGIBILITY_FAIL);
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isAccepted())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ELIGIBILITY_FAIL_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswers_returnsPinToPostPrimarySuccess() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		IdProofingResponse idProofingResponse = new IdProofingResponse(
				IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY, false);
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(idProofingResponse);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		KbaResponse response = JsonUtils.fromSanitizedJson(
				TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
		Assert.assertEquals(StatusCode.PIN_TO_POST_PRIMARY, response.getStatusCode());
	}

	@Test
	public void testKbaSubmitAnswersFailure_InvalidKbaRequest() throws Exception {
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_FAILURE_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		Assert.assertEquals(
				TestHelper.prettyToCompactJson(
						TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_ERROR_VALIDATION_KBA_RESPONSE_PATH)),
				result.getResponse().getContentAsString());
	}

	@Test
	public void testKbaSubmitAnswersFailure_whenNullResponse() throws Exception {

		Assert.assertNotNull(mockMvc);

		// Mock
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenReturn(null);
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isInternalServerError())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		KbaResponse response = JsonUtils.fromSanitizedJson(
				TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
		Assert.assertEquals(StatusCode.KBA_SUBMIT_ANSWERS_SYSTEM_ERROR, response.getStatusCode());
	}

	@Test
	public void testKbaSubmitAnswers_whenException_SystemError() throws Exception {
		Assert.assertNotNull(mockMvc);

		// Mock
		when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
				any(KbaPackage.class))).thenThrow(new IdProofingServiceException("some exception"));
		when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
		// Set up valid session attributes
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put(CommonConstants.CONSUMER_DATA, createEncryptedConsumer(true));
		sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());

		// Perform test
		String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
		byte[] kbaPack = kbaPackageJson.getBytes();
		MvcResult result = mockMvc
				.perform(post(Constants.SUBMIT_ANSWERS_ENDPOINT).content(kbaPack)
						.contentType(MediaType.APPLICATION_JSON).sessionAttrs(sessionattr))
				.andExpect(status().isInternalServerError())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andReturn();

		// Validate result
		Assert.assertEquals(Constants.APPLICATION_JSON_UTF8, result.getResponse().getContentType());
		KbaResponse response = JsonUtils.fromSanitizedJson(
				TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), KbaResponse.class);
		Assert.assertEquals(StatusCode.KBA_SUBMIT_ANSWERS_SYSTEM_ERROR, response.getStatusCode());
	}

    public String createEncryptedConsumer(Boolean isSuccessful) throws Exception{
		// We test only class under test. We do not need real value.
        String encryptedConsumer = "ENC(" + plainConsumer(isSuccessful) + ")";
        return encryptedConsumer;
	}

	private String plainConsumer(Boolean isSuccessful) throws Exception {
		String consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
        Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
        if (isSuccessful) {
            consumer.setKbaQuizTransactionKey("testKbaQuizTransactionKey");
            Date lastAccessedTime = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(lastAccessedTime);
            consumer.setQuizLastAccessedTime(lastAccessedTime);
        }
		return JsonUtils.toJson(consumer);
	}

    private ConsumerContext createMockConsumerContext() {
		ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		consumerContext.setPartnerId("EFX-DIRECT-US");
		consumerContext.setTenantId("EFX-US");
		consumerContext.setChannel(ChannelEnum.DESKTOP);
		consumerContext.setDefaultLocale("en");
		return consumerContext;
	}
}
