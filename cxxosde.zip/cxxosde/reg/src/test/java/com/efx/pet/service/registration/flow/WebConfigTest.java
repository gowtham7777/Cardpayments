package com.efx.pet.service.registration.flow;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.KbaPackage;
import com.efx.pet.domain.tid.common.IDPData;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.registration.config.WebConfig;
import com.efx.pet.service.registration.controller.KbaController;
import com.efx.pet.service.registration.controller.OTPController;
import com.efx.pet.service.registration.controller.OTPControllerTest;
import com.efx.pet.service.registration.domain.FlowInterceptorException;
import com.efx.pet.service.registration.domain.OTPConsumer;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.http.HttpServletRequest;

import java.util.Calendar;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebAppConfiguration
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {
  WebConfig.class, WebConfiguration.class
})
@TestPropertySource(properties = {
  "server.servlet.context-path:/consumer-registration",
  "spring.cloud.config.enabled:false",
  "web.flow.enable:true",
  "flow.uri._consumer-registration_rest_1.0_createAccount:/consumer-registration/rest/1.0/createAccount,/consumer-registration/rest/1.0/saveConsumer,/consumer-registration/rest/1.0/keepalive",
  "flow.uri._consumer-registration_rest_2.0_enrollOTP:/consumer-registration/rest/2.0/enrollOTP,/consumer-registration/rest/1.0/createAccount,/consumer-registration/rest/1.0/keepalive",
  "flow.uri._consumer-registration_rest_1.0_ssoDetails:/consumer-registration/rest/2.0/validatePin,/consumer-registration/rest/3.0/submitAnswers,/consumer-registration/rest/1.0/keepalive",
  "flow.uri._consumer-registration_rest_3.0_submitAnswers:/consumer-registration/rest/3.0/getQuiz,/consumer-registration/rest/1.0/createAccount,/consumer-registration/rest/2.0/validatePin,/consumer-registration/rest/2.0/enrollOTP,/consumer-registration/rest/1.0/keepalive"
})
public class WebConfigTest {

  public static final String CONTEXT_PATH = "/consumer-registration";
  public static final String RESPONSE_IN_FILTER = "RESPONSE_IN_FILTER";
  public static final String RESPONSE_OUT_FILTER = "RESPONSE_OUT_FILTER";

  @Autowired
  private WebApplicationContext webApplicationContext;
  MockMvc mockMvc;
  @MockBean
  IdProofingService idProofingService;
  @MockBean
  EncryptUtility encryptUtility;
  @MockBean
  SessionUtil sessionUtil;
  @Autowired
  OTPController OTPController;
  @Autowired
  private KbaController kbaController;
  @Autowired
  TestApplication testApplication;

  @Before
  public void setUp(){
    this.mockMvc = MockMvcBuilders
      .webAppContextSetup(webApplicationContext).build();
  }

  @Test
  public void testInterceptorAllowed() throws Exception {
    IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
    when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(new OTPControllerTest().getPlainConsumer(0, null));
    ConsumerContext consumerContext = createMockConsumerContext();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    session.setAttribute(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    session.setAttribute(CommonConstants.IDP_DATA, new IDPData());
    mockMvc.perform(post(CONTEXT_PATH + Constants.OTP_VALIDATE_PIN_ENDPOINT).contextPath(CONTEXT_PATH)
      .session(session)
      .contentType(MediaType.APPLICATION_JSON)
      .content(testValidatePin_getSuccessfulOtpConsumerString())
    )
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    mockMvc
      .perform(get(CONTEXT_PATH + "/rest/4.0/test").contextPath(CONTEXT_PATH)
        .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andReturn();
    mockMvc
      .perform(get(CONTEXT_PATH + Constants.GET_SSO_DETAILS_ENDPOINT).contextPath(CONTEXT_PATH)
        .session(session)
        .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
  }

  @Test
  public void testInterceptorNotAllowedLastAccessUrlNotMatch() throws Exception {
    ConsumerContext consumerContext = createMockConsumerContext();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    session.setAttribute(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    session.setAttribute(CommonConstants.IDP_DATA, new IDPData());
    MvcResult result = mockMvc
      .perform(get(CONTEXT_PATH + "/rest/1.0/test").contextPath(CONTEXT_PATH)
        .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
      .andReturn();

    String responseString = result.getResponse().getContentAsString();
    assertEquals(RESPONSE_IN_FILTER, responseString);

    assertThatThrownBy(() ->
      mockMvc
        .perform(get(CONTEXT_PATH + Constants.GET_SSO_DETAILS_ENDPOINT).contextPath(CONTEXT_PATH)
        .session(session)
        .contentType(MediaType.APPLICATION_JSON)
        .content(testValidatePin_getSuccessfulOtpConsumerString())
      ))
      .hasCause(new FlowInterceptorException("Requested resource not allowed."));
  }

  @Test
  public void testInterceptorNotAllowedLastUrlNullFilterRest_1_0() {
    ConsumerContext consumerContext = createMockConsumerContext();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    session.setAttribute(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    session.setAttribute(CommonConstants.IDP_DATA, new IDPData());

    assertThatThrownBy(() ->
      mockMvc
        .perform(get(CONTEXT_PATH + Constants.GET_SSO_DETAILS_ENDPOINT).contextPath(CONTEXT_PATH)
          .session(session)
          .contentType(MediaType.APPLICATION_JSON)
          .content(testValidatePin_getSuccessfulOtpConsumerString())
        ))
      .hasCause(new FlowInterceptorException("Requested resource not allowed."));
  }

  @Test
  public void testInterceptorNotAllowedLastUrlNullFilterRest_2_0() throws Exception {
    IdProofingResponse idProofingResponse = new IdProofingResponse(IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS, "transactionKey");
    when(idProofingService.enrollInOtp(any(Consumer.class), any(ConsumerContext.class), any(IDPData.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString()))
      .thenReturn(new OTPControllerTest().getPlainConsumer(0, null));
    ConsumerContext consumerContext = createMockConsumerContext();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    session.setAttribute(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    session.setAttribute(CommonConstants.IDP_DATA, new IDPData());

    assertThatThrownBy(() ->
    mockMvc.perform(post(CONTEXT_PATH + Constants.OTP_ENROLL_ENDPOINT).contextPath(CONTEXT_PATH)
      .session(session)
      .contentType(MediaType.APPLICATION_JSON)
      .content(testValidatePin_getSuccessfulOtpConsumerString())
    ))
      .hasCause(new FlowInterceptorException("Requested resource not allowed."));
  }


  @Test
  public void testInterceptorNotAllowedLastUrlNullFilterRest_3_0() throws Exception {
    IdProofingResponse idProofingResponse = new IdProofingResponse(
      IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_SUCCESS);
    String activationURL = "https://www.trustedid.com/";
    idProofingResponse.setActivationUrl(activationURL);
    when(idProofingService.validateKbaAnswers(any(Consumer.class), any(ConsumerContext.class),
      any(KbaPackage.class))).thenReturn(idProofingResponse);
    when(encryptUtility.decrypt(any(HttpServletRequest.class), anyString())).thenReturn(plainConsumer(true));
    ConsumerContext consumerContext = createMockConsumerContext();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    session.setAttribute(CommonConstants.CONSUMER_DATA, mockEncryptedConsumer());
    session.setAttribute(CommonConstants.IDP_DATA, new IDPData());
    String kbaPackageJson = TestHelper.fetchClassPathFile(Constants.SUBMIT_ANSWERS_SUCCESS_KBA_PACKAGE_PATH);
    byte[] kbaPack = kbaPackageJson.getBytes();

    assertThatThrownBy(() ->
      mockMvc
        .perform(post(CONTEXT_PATH + Constants.SUBMIT_ANSWERS_ENDPOINT).contextPath(CONTEXT_PATH)
          .session(session)
          .content(kbaPack)
          .contentType(MediaType.APPLICATION_JSON)
        .content(testValidatePin_getSuccessfulOtpConsumerString())
      ))
      .hasCause(new FlowInterceptorException("Requested resource not allowed."));
  }

  private String plainConsumer(Boolean isSuccessful) throws Exception {
    String consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)));
    Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
    if (isSuccessful) {
      consumer.setKbaQuizTransactionKey("testKbaQuizTransactionKey");
      Date lastAccessedTime = new Date();
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(lastAccessedTime);
      consumer.setQuizLastAccessedTime(lastAccessedTime);
    }
    return JsonUtils.toJson(consumer);
  }

  public String testValidatePin_getSuccessfulOtpConsumerString() throws Exception {
    OTPConsumer otpConsumer = new OTPConsumer();
    otpConsumer.setPin("012340");
    return TestHelper.prettyToCompactJson(JsonUtils.toJson(otpConsumer));
  }

  private String mockEncryptedConsumer () {
    return "AZWYLxjGlAA+IEGyNc5gkOZAJoskG9YFqXoZzWe6GnlbDVoHgCh1bgRXfn+cSazhb+bIQo1CPsmISc+O1F4erqpR8CqKq2LekXWIM1c6WqQwF9M6SiTUOiy8rTSl0N+RLfGH2u9HEX9llAd/FoU8wdzE8y/knglM/fUfTYUoSTKDkSbbH5coqJX7Kcz6jsEivzr+/g4/jF0trnWrrZSntI1B7UCVQRx4guYkRuRlV5oqx4rahOQl/lV4g9cWM2wMjI1LymyTsEvIf4ds0ezvhUxGIQSNqDFsG5Y2Up1xWYiCL8wCysF9TtGV+WEnhT+fwEnwePHxJ0P95CY3twfHe6yUPuhmeoYvY9NP57yuqDzzJWhimoqlvXy0xa5OXjtv01aXSZYLklKzofxf6aTcF+YXZH8VuaGMpvD9kbC1Bw5fuK5KoZlVG4YeSYhdgCUc";
  }

  private ConsumerContext createMockConsumerContext() {
    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
    consumerContext.setPartnerId("EFX-DIRECT-US");
    consumerContext.setTenantId("EFX-US");
    consumerContext.setAgentId("agent123");
    consumerContext.setChannel(ConsumerContext.ChannelEnum.DESKTOP);
    consumerContext.setDefaultLocale("en");
    consumerContext.setIntent("SECURITY_FREEZE");
    consumerContext.setSkuId(123L);
    return consumerContext;
  }

  @RestController
  @RequestMapping
  public static class TestApplication {

    @GetMapping("/rest/1.0/test")
    public String testInFilter() {
      return RESPONSE_IN_FILTER;
    }

    @GetMapping("/rest/4.0/test")
    public String testOutFilter() {
      return RESPONSE_OUT_FILTER;
    }
  }
}
