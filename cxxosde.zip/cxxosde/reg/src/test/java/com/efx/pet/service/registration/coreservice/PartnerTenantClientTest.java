package com.efx.pet.service.registration.coreservice;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;

import com.efx.pet.domain.partnertenant.PartnerTenantData;
import com.efx.pet.service.client.partnertenant.PartnerTenantLookupServiceClient;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.consumer.PetConsumerClient;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.direct.registration.RegistrationServicePetImpl;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServicePetImpl;
import com.efx.pet.service.partnertenant.entity.PartnerTenant;
import com.efx.pet.service.partnertenant.operations.PartnerTenantResponse;
import com.efx.pet.service.partnertenant.operations.ServiceResponse;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
public class PartnerTenantClientTest {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(PartnerTenantClientTest.class);

  @Mock
  @Qualifier("partnerTenantLookupServiceClient")
  PartnerTenantLookupServiceClient partnerTenantLookupServiceClient;

  @Mock
  ApplicationContext mockApplicationContext;

  @InjectMocks
  PartnerTenantClient partnerTenantClient = new PartnerTenantClient();

  @Before
  public void setup() {
	  partnerTenantClient.setPartnerAlias("some_alias");
  }

  @Test
  public void testConsumerInterface_is_not_null() throws Exception {
	LOGGER.debug("Start of testConsumerInterface_is_not_null()");
	PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US);
	when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);
	when(mockApplicationContext.getBean(any(String.class))).thenReturn(new PetConsumerClient());

	// Re-invoke the post construct method in order to use mock response specific to test
	partnerTenantClient.init();
    ConsumerService consumerService = partnerTenantClient.getConsumerServiceInstance();
    Assert.assertNotNull("ConsumerService is null", consumerService);
	Assert.assertEquals("com.efx.pet.service.consumer.PetConsumerClient", consumerService.getClass().getName());
	LOGGER.debug("End of testConsumerInterface_is_not_null()");
  }

  @Test
  public void testConsumerInterface_is_null() throws Exception {
    LOGGER.debug("Start of testConsumerInterface_is_null()");
    PartnerTenantResponse partnerTenantResponse =
      mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_LockAlert);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);

	  partnerTenantClient.init();
    ConsumerService consumerService = partnerTenantClient.getConsumerServiceInstance();
    Assert.assertNull("ConsumerService is not null", consumerService);
    LOGGER.debug("End of testConsumerInterface_is_null()");
  }

  @Test
  public void testPartnerTenantMap_success() throws Exception {
    LOGGER.debug("Start of testPartnerTenantMap_success()");
    PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);

	  partnerTenantClient.init();
    PartnerTenantData parnterTenantData = partnerTenantClient.getPartnerTenantData();
    Assert.assertNotNull("partnerTenantData is null", parnterTenantData);
    LOGGER.info("testPartnerTenantMapResponse: {}", JsonUtils.toJson(parnterTenantData));
    LOGGER.debug("End of testPartnerTenantMap_success()");
  }

  @Test
  public void testIsValidBundleLocation() {
	  Assert.assertTrue(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../UCSC/index.html"));
	  Assert.assertTrue(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../LA-US/index.html"));
	  Assert.assertTrue(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../MY-EFX-US/index.html"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../UC1SC/index.html"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../UCSC/index1.html"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "..../UCSC/index.html"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "./../UCSC/index.html"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "../../UCSC/index.htm"));
	  Assert.assertFalse(partnerTenantClient.isValidBundleLocation(PartnerTenantClient.FRONT_END_BUNDLE_LOCATION_PATTERN, "UCSCindexhtml"));
  }

  @Test
  public void testGetFrontEndBundleLocation() throws Exception {
    LOGGER.debug("Start of testGetFrontEndBundleLocation()");
    PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);

    partnerTenantClient.init();
    String frontEndBundleLocation = partnerTenantClient.getFrontEndBundleLocation();
    Assert.assertEquals("../../MY-EFX-US/index.html", frontEndBundleLocation);
    LOGGER.debug("End of testGetFrontEndBundleLocation()");
  }

  @Test
  public void testGetRegistrationService() throws Exception {
    LOGGER.debug("Start of testGetRegistrationService()");
    PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);
    when(mockApplicationContext.getBean(any(String.class))).thenReturn(new RegistrationServicePetImpl());

    partnerTenantClient.init();
    RegistrationService registrationService = partnerTenantClient.getRegistrationServiceInstance();
    Assert.assertNotNull("RegistrationService is null", registrationService);
	Assert.assertEquals("com.efx.pet.service.direct.registration.RegistrationServicePetImpl", registrationService.getClass().getName());
    LOGGER.debug("End of testGetRegistrationService()");
  }
  
  @Test
  public void testGetIdProofingService() throws Exception {
    LOGGER.debug("Start of testGetIdProofingService()");
    PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_MY_EFX_US);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);
    when(mockApplicationContext.getBean(any(String.class))).thenReturn(new IdProofingServicePetImpl());

    partnerTenantClient.init();
    IdProofingService idProofingService = partnerTenantClient.getIdProofingServiceInstance();
    Assert.assertNotNull("IdProofingService is null", idProofingService);
	Assert.assertEquals("com.efx.pet.service.idproofing.IdProofingServicePetImpl", idProofingService.getClass().getName());
    LOGGER.debug("End of testGetIdProofingService()");
  }
  
  @Test
  public void testGetIntentList() throws Exception {
    LOGGER.debug("Start of testGetIntentList()");
    PartnerTenantResponse partnerTenantResponse = mockPartnerTenantResponse(Constants.EXAMPLE_PARTNER_TENANT_RESPONSE_UCSC);
    when(partnerTenantLookupServiceClient.findByPartnerAlias(any(String.class))).thenReturn(partnerTenantResponse);

    partnerTenantClient.init();
    Assert.assertNotNull(partnerTenantClient.getSettings());
    Assert.assertNotNull(partnerTenantClient.getSettings().getIntentList());
    Assert.assertEquals("FRAUD_ALERT", partnerTenantClient.getSettings().getIntentList().get(0));
    Assert.assertEquals("SECURITY_FREEZE", partnerTenantClient.getSettings().getIntentList().get(1));
    Assert.assertEquals("DISPUTE", partnerTenantClient.getSettings().getIntentList().get(2));
    LOGGER.debug("End of testGetIntentList()");
  }

  private PartnerTenantResponse mockPartnerTenantResponse(String partnerTenantResponseFileName) throws Exception {
    PartnerTenantResponse partnerTenantResponse = new PartnerTenantResponse();
    partnerTenantResponse.setServiceStatus(ServiceResponse.Status.SUCCESS);
    String partnerTenantResponseJson = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(partnerTenantResponseFileName));
    ObjectMapper mapper = new ObjectMapper();
    List<PartnerTenant> partnerTenants = new ArrayList<PartnerTenant>();
    partnerTenants.add(mapper.readValue(partnerTenantResponseJson, PartnerTenant.class));
    partnerTenantResponse.setPartnerTenants(partnerTenants);
    return partnerTenantResponse;
  }
}