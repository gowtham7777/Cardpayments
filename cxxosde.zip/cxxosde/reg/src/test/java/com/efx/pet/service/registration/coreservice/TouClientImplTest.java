package com.efx.pet.service.registration.coreservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.registration.TouResponse;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {
    "termsOfUse.gateway.url:URL",
    "termsOfUse.api.key:key"
})
@ContextConfiguration(classes = {TouClientImpl.class, TestProfileConfig.class})
public class TouClientImplTest {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(TouClientImplTest.class);
    
    @MockBean
    RestTemplate restTemplate;
    
    @Autowired
    TouClientImpl touClientImpl;
    
    @Test
    public void TouClientImplTest_Success() {
    
	TouResponse mockTouResponse = new TouResponse();
    mockTouResponse.setPrivacyPolicyUrl("http://mock-webcoe-cloudapp.com/web/us/privacy/lock-and-alert-online-privacy-policy");
    mockTouResponse.setPrivacyPolicyVersion("mock-default");
    mockTouResponse.setTermsOfUseUrl("http://mock-webcoe-cloudapp.com/web/us/terms/lock-and-alert");
    mockTouResponse.setTermsOfUseVersion("mock-0917");
    ResponseEntity<TouResponse> mockResponseEntity = new ResponseEntity<TouResponse>(mockTouResponse, HttpStatus.OK);
    
    when(restTemplate.exchange(anyString(),any(HttpMethod.class), any(HttpEntity.class),eq(TouResponse.class))).thenReturn(mockResponseEntity);
    
    TouResponse touResponse = touClientImpl.getTouDetails("EFX","EFX-US");
    assertNotNull(touResponse.getTermsOfUseUrl());
    assertTrue(touResponse.getTermsOfUseUrl().contains("mock"));
    LOGGER.info("TouResponse touResponse inside of TouClientImplTest_Success(): {}",JsonUtils.toJson(touResponse));
    }
}
