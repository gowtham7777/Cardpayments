/**
 *
 */
package com.efx.pet.service.registration.utils;

import com.efx.pet.domain.Consumer;
import com.efx.pet.utility.configuration.utils.JsonUtils;

/**
 * @author Senthil Paramasivam
 *
 */
public class ConsumerTestUtils {
	public static Consumer getConsumer() {
		return JsonUtils.fromSanitizedJson(getConsumerString(), Consumer.class);
	}

	public static String getConsumerString() {
		return "{\"firstName\":\"GER\",\"lastName\":\"HARKENREADEO\"," +
				"\"address\":{\"addressLine1\":\"305 LINDEN BV\",\"cityName\":\"ATLANTA\",\"stateAbbreviation\":\"GA\",\"zipCode\":\"30316\"}," +
				"\"ssn\":\"666066112\",\"dateOfBirth\":\"06/08/1967\",\"email\":\"test@gmail.com\",\"phoneNumber\":\"6781233456\"}";
	}

}
