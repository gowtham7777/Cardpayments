package com.efx.pet.service.registration.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import com.efx.pet.domain.LiftInfoResponse;
import com.efx.pet.domain.LiftMaskedResponse;
import com.efx.pet.domain.LiftResponse;
import com.efx.pet.service.lift.LiftService;
import com.efx.pet.utility.QueryParamEnums;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.domain.ServiceResponse;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {TempFreezeLockLiftController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
    "com.efx.pet.lift.url:http://localhost:8181",
    "com.efx.pet.lift.basic-auth.username:test",
    "com.efx.pat.lift.basic-auth.password:test"
})
public class TempFreezeLockLiftControllerTest {

    private static final String GET_MASKED_CONSUMER_END_POINT = "/rest/1.0/lift-consumer-masked";
    private static final String GET_LIFT_INFO_END_POINT = "/rest/1.0/lift-info";
    private static final String LIFT_ID = "15461df4-b622-3ff3-8294-7f9b71a43b78";
    private static final String LIFT_INTENT = "TEMP_FREEZE_LOCK_LIFT";

    @Autowired
    private TempFreezeLockLiftController controllerUnderTest;

    private MockMvc mockMvc;

    @MockBean
    private LiftService liftService;

    private Gson gson = new Gson();

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }

    @Test
    public void testGetMaskedConsumerSuccess() throws Exception {
        // content of Consumer object's Strings is not important, only the functioning of the endpoint
        LiftMaskedResponse response = convertToMaskedResponse(getLiftResponse());

        Mockito.when(liftService.getMaskedConsumer(Mockito.anyString())).thenReturn(response);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_MASKED_CONSUMER_END_POINT)
            .contentType(MediaType.APPLICATION_JSON)
            .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();
        LiftMaskedResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftMaskedResponse.class);
        assertEquals(ServiceResponse.Status.SUCCESS, liftResponse.getOperationStatus());
        assertEquals(JsonUtils.toJson(response.getConsumer()), JsonUtils.toJson(liftResponse.getConsumer()));
    }

    @Test
    public void testGetMaskedConsumerNotFound() throws Exception {
        LiftMaskedResponse response = new LiftMaskedResponse();
        response.setHttpStatus(HttpStatus.NOT_FOUND);
        response.setOperationMessage("FAILURE");
        response.setOperationStatus(ServiceResponse.Status.FAILURE);
        response.setServiceMessage("FAILURE");
        response.setServiceStatus(ServiceResponse.Status.FAILURE);
        Mockito.when(liftService.getMaskedConsumer(Mockito.anyString())).thenReturn(response);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_MASKED_CONSUMER_END_POINT)
            .contentType(MediaType.APPLICATION_JSON)
            .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
            .andExpect(status().is4xxClientError())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();
        LiftResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftResponse.class);
        assertEquals(ServiceResponse.Status.FAILURE, liftResponse.getOperationStatus());
    }

  @Test
  public void testGetMaskedConsumerEmpty() throws Exception {
    LiftMaskedResponse response = new LiftMaskedResponse();
    response.setHttpStatus(HttpStatus.NO_CONTENT);
    response.setOperationMessage("FAILURE");
    response.setOperationStatus(ServiceResponse.Status.FAILURE);
    response.setServiceMessage("FAILURE");
    response.setServiceStatus(ServiceResponse.Status.FAILURE);
    Mockito.when(liftService.getMaskedConsumer(Mockito.anyString())).thenReturn(response);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_MASKED_CONSUMER_END_POINT)
      .contentType(MediaType.APPLICATION_JSON)
      .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
      .andExpect(status().isNoContent())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    LiftResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftResponse.class);
    assertEquals(ServiceResponse.Status.FAILURE, liftResponse.getOperationStatus());
  }

    @Test
    public void testGetMaskedConsumerException() throws Exception {
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_MASKED_CONSUMER_END_POINT)
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().is5xxServerError())
            .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
            .andReturn();
        LiftResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftResponse.class);
        assertEquals(ServiceResponse.Status.ERROR, liftResponse.getOperationStatus());
    }

  @Test
  public void testGetLiftInfoSuccess() throws Exception {
    LiftInfoResponse response = getLiftInfoResponse();

    Mockito.when(liftService.getLiftInfo(Mockito.anyString())).thenReturn(response);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_LIFT_INFO_END_POINT)
      .contentType(MediaType.APPLICATION_JSON)
      .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
      .andExpect(status().isOk())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    LiftInfoResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftInfoResponse.class);
    assertEquals(ServiceResponse.Status.SUCCESS, liftResponse.getOperationStatus());
    assertEquals(JsonUtils.toJson(liftResponse), JsonUtils.toJson(response));
  }

  @Test
  public void testGetLiftInfoNotFound() throws Exception {
    LiftInfoResponse response = new LiftInfoResponse();
    response.setHttpStatus(HttpStatus.NOT_FOUND);
    response.setOperationMessage("FAILURE");
    response.setOperationStatus(ServiceResponse.Status.FAILURE);
    response.setServiceMessage("FAILURE");
    response.setServiceStatus(ServiceResponse.Status.FAILURE);
    Mockito.when(liftService.getLiftInfo(Mockito.anyString())).thenReturn(response);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_LIFT_INFO_END_POINT)
      .contentType(MediaType.APPLICATION_JSON)
      .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
      .andExpect(status().is4xxClientError())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    LiftInfoResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftInfoResponse.class);
    assertEquals(ServiceResponse.Status.FAILURE, liftResponse.getOperationStatus());
  }

  @Test
  public void testGetLiftInfoEmpty() throws Exception {
    LiftInfoResponse response = new LiftInfoResponse();
    response.setHttpStatus(HttpStatus.NO_CONTENT);
    response.setOperationMessage("FAILURE");
    response.setOperationStatus(ServiceResponse.Status.FAILURE);
    response.setServiceMessage("FAILURE");
    response.setServiceStatus(ServiceResponse.Status.FAILURE);
    Mockito.when(liftService.getLiftInfo(Mockito.anyString())).thenReturn(response);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_LIFT_INFO_END_POINT)
      .contentType(MediaType.APPLICATION_JSON)
      .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
      .andExpect(status().isNoContent())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    LiftInfoResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftInfoResponse.class);
    assertEquals(ServiceResponse.Status.FAILURE, liftResponse.getOperationStatus());
  }

  @Test
  public void testGetLiftInfoException() throws Exception {
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_LIFT_INFO_END_POINT)
      .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().is5xxServerError())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    LiftInfoResponse liftResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), LiftInfoResponse.class);
    assertEquals(ServiceResponse.Status.ERROR, liftResponse.getOperationStatus());
  }

    private ConsumerContext createMockConsumerContext() {
        ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
        consumerContext.setPartnerId("EFX-DIRECT-US");
        consumerContext.setTenantId("EFX-US");
        consumerContext.setChannel(ChannelEnum.DESKTOP);
        consumerContext.setDefaultLocale("en");
        return consumerContext;
    }

    private LiftResponse getLiftResponse() throws Exception {
        LiftResponse response = new LiftResponse();

        response.setHttpStatus(HttpStatus.OK);
        response.setOperationMessage("SUCCESS");
        response.setOperationStatus(ServiceResponse.Status.SUCCESS);
        response.setServiceMessage("SUCCESS");
        response.setServiceStatus(ServiceResponse.Status.SUCCESS);
        response.setConsumer(getPlainConsumerObject(true));

        return response;
    }

    private LiftInfoResponse getLiftInfoResponse() {
        LiftInfoResponse response = new LiftInfoResponse();

        response.setHttpStatus(HttpStatus.OK);
        response.setOperationMessage("SUCCESS");
        response.setOperationStatus(ServiceResponse.Status.SUCCESS);
        response.setServiceMessage("SUCCESS");
        response.setServiceStatus(ServiceResponse.Status.SUCCESS);
        response.setProposedEndLiftDate("12/31/2021");
        response.setCompanyName("JPMorgan Chase&Co");
        response.setProductName("Chase Freedom Credit Card");
        return response;
    }

    private Consumer getPlainConsumerObject(Boolean withPhoneNumber) throws Exception {
        String consumerString;
        if (withPhoneNumber) {
            consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        } else {
            consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)), Constants.PHONE_NUMBER_KEY);
        }
        Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
        consumer.setConsumerKey("newTestConsumerKey");
        return consumer;
    }

    public HashMap<String, Object> getSessionAttr(String encryptedConsumer) {
        HashMap<String, Object> sessionAttributes = new HashMap<>();
        if (!StringUtils.isBlank(encryptedConsumer)) {
            sessionAttributes.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
        }
        ConsumerContext context = createMockConsumerContext();
        context.getQueryParamsMap().put(QueryParamEnums.LIFTID.value(), LIFT_ID);
        context.setIntent(LIFT_INTENT);
        sessionAttributes.put(CommonConstants.CONSUMER_CONTEXT, context);
        sessionAttributes.put(CommonConstants.IP_ADDRESS, "localhost");
        return sessionAttributes;
    }

    public String getEncryptedConsumer(Boolean withPhoneNumber) throws Exception {
        return "ENC(" + getPlainConsumer(withPhoneNumber) + ")";
    }

    public String getPlainConsumer(Boolean withPhoneNumber) throws Exception {
        return JsonUtils.toJson(getPlainConsumerObject(withPhoneNumber));
    }

    public LiftMaskedResponse convertToMaskedResponse(LiftResponse source) {
      return gson.fromJson(gson.toJson(source), LiftMaskedResponse.class);
    }
}
