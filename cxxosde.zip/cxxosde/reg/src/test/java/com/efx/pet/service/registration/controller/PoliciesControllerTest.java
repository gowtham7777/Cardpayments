package com.efx.pet.service.registration.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.domain.PoliciesResponse;
import com.efx.pet.domain.Policy;
import com.efx.pet.domain.ServiceResponse;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.policies.PoliciesService;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.utils.JsonUtils;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {PolicyController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
  "com.efx.pet.service.registration.ptp.retry.max.count:3",
  "com.efx.pet.eligibility.user:user",
  "com.efx.pet.eligibility.passphrase:passphrase",
  "com.efx.pet.eligibility.enableBasicAuth:false",

})
public class PoliciesControllerTest {
	
	private static final String GET_POLICIES_END_POINT = "/rest/1.0/policies";
	
    @Autowired
    private PolicyController controllerUnderTest;

    private MockMvc mockMvc;

    @MockBean
    private PoliciesService policiesService;

    @Before
    public void setup() {
      this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
    }    

    @Test
    public void testLatestPoliciesSuccess() throws Exception {
    	PoliciesResponse response = getPoliciesResponse(); 
    	
    	Mockito.when(policiesService.getLatestPolicies(Mockito.anyString())).thenReturn(response);
        
    	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_POLICIES_END_POINT)
                .contentType(MediaType.APPLICATION_JSON)
                .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
    	PoliciesResponse policiesResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), PoliciesResponse.class);
        assertEquals(policiesResponse.getOperationStatus(), ServiceResponse.Status.SUCCESS);
        assertEquals(policiesResponse.getPolicies().get(0), response.getPolicies().get(0));        
    }
    
    @Test
    public void testLatestPolicieFailure() throws Exception {
    	PoliciesResponse response = new PoliciesResponse(); 
    	response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    	response.setOperationMessage("FAILURE");
    	response.setOperationStatus(ServiceResponse.Status.FAILURE);
    	response.setServiceStatus(ServiceResponse.Status.FAILURE);
    	Mockito.when(policiesService.getLatestPolicies(Mockito.anyString())).thenReturn(response);
        
    	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_POLICIES_END_POINT)
                .contentType(MediaType.APPLICATION_JSON)
                .sessionAttrs(getSessionAttr(getEncryptedConsumer(true))))
                .andExpect(status().is5xxServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
    	PoliciesResponse policiesResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), PoliciesResponse.class);
        assertEquals(policiesResponse.getOperationStatus(), ServiceResponse.Status.FAILURE);      
    }
    
    @Test
    public void testLatestPoliciesException() throws Exception {
    	
    	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(GET_POLICIES_END_POINT)
                .contentType(MediaType.APPLICATION_JSON))
    	        .andExpect(status().is5xxServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
    	PoliciesResponse policiesResponse = JsonUtils.fromSanitizedJson(result.getResponse().getContentAsString(), PoliciesResponse.class);
        assertEquals(policiesResponse.getOperationStatus(), ServiceResponse.Status.ERROR);       
    }
    
    
    
    private PoliciesResponse getPoliciesResponse() { 
    	PoliciesResponse response = new PoliciesResponse();
    	response.setHttpStatus(HttpStatus.OK);
    	response.setOperationMessage("SUCCESS");
    	response.setOperationStatus(ServiceResponse.Status.SUCCESS);
    	response.setServiceStatus(ServiceResponse.Status.SUCCESS);
    	List<Policy> list = new ArrayList<>();
    	Policy policy = new Policy(101l, 1l, "version1", "By clicking the button below I am accepting the Equifax Consumer Services LLC "
    												+ "<a href=''https://www.equifax.com/terms/''", "TermsPackage");
    	list.add(policy);
    	response.setPolicies(list);
    	
    	return response;
    }
    
    public HashMap<String, Object> getSessionAttr() {
        return getSessionAttr(null);
    }

    public HashMap<String, Object> getSessionAttr(String encryptedConsumer) {
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        if (!StringUtils.isBlank(encryptedConsumer)) {
            sessionattr.put(CommonConstants.CONSUMER_DATA, encryptedConsumer);
        }
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext());
        sessionattr.put(CommonConstants.IP_ADDRESS, "localhost");
        return sessionattr;
    }

    private ConsumerContext createMockConsumerContext() {
		ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		consumerContext.setPartnerId("EFX-DIRECT-US");
		consumerContext.setTenantId("EFX-US");
		consumerContext.setChannel(ChannelEnum.DESKTOP);
		consumerContext.setDefaultLocale("en");
		return consumerContext;
	}
    
    public String getEncryptedConsumer(Boolean withPhoneNumber) throws Exception {
        return "ENC(" + getPlainConsumer(withPhoneNumber) + ")";
    }

    public String getPlainConsumer(Boolean withPhoneNumber) throws Exception {
        String consumerString;
        if (withPhoneNumber) {
            consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        } else {
            consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)), Constants.PHONE_NUMBER_KEY);
        }
        Consumer consumer = JsonUtils.fromSanitizedJson(consumerString, Consumer.class);
        consumer.setConsumerKey("newTestConsumerKey");
        return JsonUtils.toJson(consumer);
    }
}
