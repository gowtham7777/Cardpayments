package com.efx.pet.service.registration.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

public class DomainFilterTest {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(DomainFilterTest.class);

  @Test
  public void cleanseHeader_whenGettingHeaderContainingScriptTag() throws IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.addHeader("script","<script>bad stuff</script>valid data");
    CleansedRequest cleansedRequest = new CleansedRequest(request);

    Assert.assertFalse(cleansedRequest.getHeader("script").contains("bad stuff"));
    Assert.assertTrue(cleansedRequest.getHeader("script").contains("valid data"));
    LOGGER.info("Cleansed Header: {}", cleansedRequest.getHeader("script"));
  }

  @Test
  public void cleanseParameter_whenGettingParameterContainingScriptTag() throws IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.addParameter("script","<script>bad stuff</script>valid data");
    CleansedRequest cleansedRequest = new CleansedRequest(request);

    Assert.assertFalse(cleansedRequest.getParameter("script").contains("bad stuff"));
    Assert.assertTrue(cleansedRequest.getParameter("script").contains("valid data"));
    LOGGER.info("Cleansed Parameter: {}", cleansedRequest.getParameter("script"));
  }

  @Test
  public void cleanseParameters_whenGettingParametersContainingScriptTags() throws IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Map<String, String[]> params = new HashMap<>();
    params.put("scripts", new String[]{"<script>bad stuff</script>valid data", "<script>terrible things</script>valid"});
    request.addParameters(params);

    CleansedRequest cleansedRequest = new CleansedRequest(request);
    String[] values = cleansedRequest.getParameterValues("scripts");
    Assert.assertFalse(values[0].contains("bad stuff"));
    Assert.assertTrue(values[0].contains("valid data"));
    Assert.assertFalse(values[1].contains("terrible things"));
    Assert.assertTrue(values[1].contains("valid"));
    LOGGER.info("Cleansed Parameters: {}, {}", values[0], values[1]);
  }

  @Test
  public void test_html_tags_are_allowed() throws IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.addParameter("script","<p> data1 </p> <br/>"
        + "<p> data2 </p> <br/>"
        + "<li> <p> data3 &trade; </p> </li>");
    CleansedRequest cleansedRequest = new CleansedRequest(request);
    System.out.println(cleansedRequest.getParameter("script"));
    Assert.assertFalse(cleansedRequest.getParameter("script").contains("bad stuff"));
    Assert.assertTrue(cleansedRequest.getParameter("script").contains("<p> data1 </p> <br />"));
    Assert.assertTrue(cleansedRequest.getParameter("script").contains("<p> data2 </p> <br />"));
    Assert.assertTrue(cleansedRequest.getParameter("script").contains("<ul><li> <p> data3 ™ </p> </li></ul>"));
    LOGGER.info("Cleansed Parameter: {}", cleansedRequest.getParameter("script"));
  }
}
