package com.efx.pet.service.registration.controller.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.reactive.function.client.WebClient;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

import com.efx.domain.sso.SingleSignOnDetails;
import com.efx.domain.sso.TokenInfo;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ConsumerContext.ChannelEnum;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.registration.exception.SingleSignOnException;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.encryption.Encryptor;
import com.efx.pet.utility.fraudevents.logging.FraudEventLogger;
import com.efx.pet.domain.eligibility.operations.LogFraudEventRequest;
import com.efx.pet.utility.utils.SanitizedJsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class SingleSignOnProcessorTest {

	@Mock
	private EncryptUtility encryptUtility;

	@Mock
	@Qualifier("memberCenterEncryptor")
	private Encryptor encryptor;

	@Mock
	private WebClient client;

	@InjectMocks
	SingleSignOnProcessor singleSignOnProcessor;

	@Mock
	FraudEventLogger fraudEventLogger;

	public static MockWebServer mockBackEnd;

	@BeforeClass
	public static void setUp() throws IOException {
		mockBackEnd = new MockWebServer();
		mockBackEnd.start();
	}

	@Before
	public void initialize() throws JsonProcessingException {
		String baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
		singleSignOnProcessor.webClient = WebClient.create(baseUrl);
	}

	@AfterClass
	public static void tearDown() throws IOException {
		mockBackEnd.shutdown();
	}

	@Test
	public void test_TokenInfoHappyPath() throws Exception {
		String body = mockValidResponse();
		mockBackEnd.enqueue(new MockResponse().setBody(body).addHeader("Content-Type", "application/json"));

		TokenInfo res = singleSignOnProcessor.getOAuthorizedClient(mockConsumer(), createMockConsumerContext());

		assertEquals("accessToken", res.getAccessToken());
		assertEquals(100, res.getExpiresIn());
		assertEquals("refreshToken", res.getRefreshToken());
	}

	@Test(expected = SingleSignOnException.class)
	public void test_TokenInfo4xxResponse() throws Exception {
		mockBackEnd.enqueue(new MockResponse().setResponseCode(401));

		singleSignOnProcessor.getOAuthorizedClient(mockConsumer(), createMockConsumerContext());
	}

	@Test(expected = SingleSignOnException.class)
	public void test_TokenInfo5xxResponse() throws Exception {
		mockBackEnd.enqueue(new MockResponse().setResponseCode(500));

		singleSignOnProcessor.getOAuthorizedClient(mockConsumer(), createMockConsumerContext());
	}

	@Test
	public void test_oAuthToken_success() throws Exception {
		String body = mockValidResponse();
		mockBackEnd.enqueue(new MockResponse().setBody(body).addHeader("Content-Type", "application/json"));
		ConsumerContext mockConsumerContext = createMockConsumerContext();
		singleSignOnProcessor.getOAuthorizedClient(mockConsumer(), mockConsumerContext);

		Mockito.verify(fraudEventLogger, Mockito.times(1)).logMessage(Mockito.any(LogFraudEventRequest.class), Mockito.any(ConsumerContext.class), Mockito.any(String.class));
	}

	@Test(expected=SingleSignOnException.class)
	public void test_DecryptNull() throws SingleSignOnException {
		singleSignOnProcessor.getDecryptedConsumer(null);
	}

	@Test
	public void test_DecryptConsumer_Success() throws Exception {
		when(encryptUtility.decryptConsumer(Mockito.any(String.class))).thenReturn(mockConsumer());
		Consumer consumer = singleSignOnProcessor.getDecryptedConsumer(mockEncryptedConsumer());
		Assert.assertNotNull(consumer);
		Assert.assertEquals(mockConsumer().getConsumerKey(), consumer.getConsumerKey());
	}

	@Test(expected=SingleSignOnException.class)
	public void test_DecryptConsumer_failure() throws Exception {
		when(encryptUtility.decryptConsumer(any(String.class))).thenReturn(null);
		singleSignOnProcessor.getDecryptedConsumer(mockEncryptedConsumer());
	}

	@Test
	public void test_mapResponse_Success() throws Exception {
		String body = mockValidResponse();
		mockBackEnd.enqueue(new MockResponse().setBody(body).addHeader("Content-Type", "application/json"));
		when(encryptUtility.encryptString(any(String.class))).thenReturn(mockEncryptedConsumer());

		SingleSignOnDetails singleSignOnDetails = singleSignOnProcessor.mapResponse(mockConsumer(), createMockConsumerContext());

		Assert.assertNotNull(singleSignOnDetails);
	}

    @Test
    public void test_mapResponse_with_upsellSkuId_Success() throws Exception {
		String body = mockValidResponse();
		mockBackEnd.enqueue(new MockResponse().setBody(body).addHeader("Content-Type", "application/json"));
		when(encryptUtility.encryptString(any(String.class))).thenReturn(mockEncryptedConsumer());

		SingleSignOnDetails singleSignOnDetails = singleSignOnProcessor.mapResponse(mockConsumer(), createMockConsumerContextWithUpsellSkuId());

		Assert.assertNotNull(singleSignOnDetails);
        Assert.assertEquals(10990L, singleSignOnDetails.getUpsellSkuId().longValue());
    }

	 private ConsumerContext createMockConsumerContext() {
		    ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
		    consumerContext.setPartnerId("EFX-DIRECT");
		    consumerContext.setTenantId("EFX-US");
		    consumerContext.setChannel(ChannelEnum.DESKTOP);
		    consumerContext.setDefaultLocale("en");
		    consumerContext.setIntent("SECURITY_FREEZE");
		    consumerContext.setSkuId(123L);
		    return consumerContext;
		}

    private ConsumerContext createMockConsumerContextWithUpsellSkuId() {
        ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
        consumerContext.setPartnerId("EFX-DIRECT");
        consumerContext.setTenantId("EFX-US");
        consumerContext.setChannel(ChannelEnum.DESKTOP);
        consumerContext.setDefaultLocale("en");
        consumerContext.setIntent("SECURITY_FREEZE");
        consumerContext.setSkuId(123L);
        consumerContext.setUpsellSkuId(10990L);
        return consumerContext;
    }

	  private Consumer mockConsumer() throws Exception {
		  String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
		  Consumer consumer = SanitizedJsonUtils.fromJson(consumerString, Consumer.class);
		  consumer.setConsumerKey("e4a98146-46f6-47ad-8170-d35a2f49091e");
		  consumer.setPassword("Pa$sw0rd1");
		  return consumer;
	  }

	  private String mockEncryptedConsumer () {
		  return "AZWYLxjGlAA+IEGyNc5gkOZAJoskG9YFqXoZzWe6GnlbDVoHgCh1bgRXfn+cSazhb+bIQo1CPsmISc+O1F4erqpR8CqKq2LekXWIM1c6WqQwF9M6SiTUOiy8rTSl0N+RLfGH2u9HEX9llAd/FoU8wdzE8y/knglM/fUfTYUoSTKDkSbbH5coqJX7Kcz6jsEivzr+/g4/jF0trnWrrZSntI1B7UCVQRx4guYkRuRlV5oqx4rahOQl/lV4g9cWM2wMjI1LymyTsEvIf4ds0ezvhUxGIQSNqDFsG5Y2Up1xWYiCL8wCysF9TtGV+WEnhT+fwEnwePHxJ0P95CY3twfHe6yUPuhmeoYvY9NP57yuqDzzJWhimoqlvXy0xa5OXjtv01aXSZYLklKzofxf6aTcF+YXZH8VuaGMpvD9kbC1Bw5fuK5KoZlVG4YeSYhdgCUc";
	  }

	  private String mockValidResponse() throws JsonProcessingException {
		Map<String, Object> mapResponse = new LinkedHashMap<>();
		mapResponse.put("access_token", "accessToken");
		mapResponse.put("expires_in", 100);
		mapResponse.put("refresh_token", "refreshToken");
		return new ObjectMapper().writeValueAsString(mapResponse);
	}
}
