package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.InetAddress;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.registration.controller.util.JobStatusUtils;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.registration.EmergencyBreakConstants;
import com.efx.pet.service.registration.controller.processor.EmergencyBreakProcessor;
import com.efx.pet.utility.AsyncJobStatus;
import com.efx.pet.utility.cache.Cache;
import com.efx.pet.utility.utils.JsonUtils;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {TestProfileConfig.class})
public class EmergencyBreakControllerTest {

  private MockMvc mockMvc;

  EmergencyBreakController  controllerUnderTest;

  @MockBean
  private JobStatusUtils jobStatusUtils;

  @MockBean
  private EmergencyBreakProcessor emergencyBreakProcessor;
  
  @MockBean
  Cache cache;

  @Before
  public void setup() {
    this.controllerUnderTest = new EmergencyBreakController(jobStatusUtils, emergencyBreakProcessor);
    ReflectionTestUtils.setField(controllerUnderTest, "cache", cache);
    this.mockMvc = MockMvcBuilders.standaloneSetup(this.controllerUnderTest).build();
  }

  @Test
  public void testProcessMessages_success_returnsJobStatus() throws Exception {
    int numberOfMessagesToProcess = 10;
    AsyncJobStatus jobStatus = mockCreateAndAddToCache(numberOfMessagesToProcess);

    Mockito.doNothing().when(emergencyBreakProcessor).process(eq(numberOfMessagesToProcess), any(AsyncJobStatus.class));

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(Constants.EBREAK_PROCESS_QUEUE_ENDPOINT)
      .param("numberOfMessagesToProcess", Integer.toString(numberOfMessagesToProcess))
      .contentType(MediaType.APPLICATION_JSON)
    )
      .andExpect(status().isOk())
      .andReturn();
    Assert.assertEquals(JsonUtils.toJson(jobStatus), result.getAsyncResult().toString());
  }

  @Test
  public void testGetAsyncJobStatus_success_returnsJobStatus() throws Exception{
    AsyncJobStatus jobStatus = mockCreateAndAddToCache(20);
    when(cache.get(anyString(), anyString(), eq(AsyncJobStatus.class))).thenReturn(jobStatus);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(Constants.EBREAK_GET_JOB_STATUS_ENDPOINT)
      .param("jobId", jobStatus.getId())
      .contentType(MediaType.APPLICATION_JSON)
    )
      .andExpect(status().isOk())
      .andReturn();

      Assert.assertEquals(JsonUtils.toJson(jobStatus), result.getAsyncResult().toString());
  }

  @Test
  public void testGetAsyncJobStatus_jobStatusIsNull_throwsException() throws Exception {
    try {
      mockMvc.perform(MockMvcRequestBuilders.get(Constants.EBREAK_GET_JOB_STATUS_ENDPOINT)
        .param("jobId", "100")
        .contentType(MediaType.APPLICATION_JSON)
      )
        .andExpect(status().isInternalServerError())
        .andReturn();
    } catch (Exception e){
      Assert.assertTrue(e.getMessage().contains("Invalid jobId"));
    }
  }

  @Test
  public void testGetActiveJobThreads_success_returnsActiveJobThreads() throws Exception{
    mockCreateAndAddToCache(30);

    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(Constants.EBREAK_GET_ACTIVE_JOB_THREADS_ENDPOINT))
      .andExpect(status().isOk())
      .andReturn();
    Assert.assertNotNull(result);
  }

  public AsyncJobStatus mockCreateAndAddToCache(int numberOfMessagesToProcess) throws Exception {
    Properties parameters = new Properties();
    parameters.setProperty(EmergencyBreakConstants.CACHE_PARAM_NUMBER_OF_MESSAGES, String.valueOf(numberOfMessagesToProcess));
    AsyncJobStatus jobStatus = new AsyncJobStatus(EmergencyBreakConstants.CACHE_KEY_EMERGENCY_BRAKE, EmergencyBreakController.class.getName());
    jobStatus.setJobParameters(parameters);
    jobStatus.setMachineName(InetAddress.getLocalHost().getHostName());
    Mockito.when(jobStatusUtils.createAndAddToCache(eq(EmergencyBreakConstants.CACHE_KEY_EMERGENCY_BRAKE), eq(EmergencyBreakController.class), any(Properties.class))).thenReturn(jobStatus);

    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
    cache.putAsString(EmergencyBreakConstants.JOB_THREAD, jobStatus.getId(), Thread.currentThread().getName());

    return jobStatus;
  }

}
