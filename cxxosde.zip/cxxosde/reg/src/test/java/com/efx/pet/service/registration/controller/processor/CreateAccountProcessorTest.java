package com.efx.pet.service.registration.controller.processor;

import static org.mockito.Matchers.any;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.message.EmergencyBreakQueueMessage;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.registration.CreateAccountResponse;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.utility.RegistrationPublisher;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {CreateAccountProcessor.class, TestProfileConfig.class})
@TestPropertySource(properties = {
  "aws.sqs.emergency.break.queue.name:queue-name",
  "com.efx.pet.eligibility.user:user",
  "com.efx.pet.eligibility.passphrase:passphrase",
  "com.efx.pet.eligibility.enableBasicAuth:false"
})
public class CreateAccountProcessorTest {

    @Autowired
    private CreateAccountProcessor processorUnderTest;

    @MockBean
    private RegistrationPublisher registrationPublisher;

    /* Tests for sendMessageToEmergencyBreakQueue() */

    @Test
    public void testSendMessageToEmergencyBreakQueue_p2pOptedIn_returnsEmergencyBreakP2pOptedInStatusCode() {
        testSendMessageToEmergencyBreakQueue(true, CreateAccountResponse.StatusCode.EMERGENCY_BREAK_P2P_OPTED_IN);
    }

    @Test
    public void testSendMessageToEmergencyBreakQueue_p2pOptedOut_returnsEmergencyBreakP2pOptedOutStatusCode() {
        testSendMessageToEmergencyBreakQueue(false, CreateAccountResponse.StatusCode.EMERGENCY_BREAK_P2P_OPTED_OUT);
    }

    public void testSendMessageToEmergencyBreakQueue(Boolean isOptedForPinToPost, CreateAccountResponse.StatusCode expectedStatusCode) {
        Mockito.doNothing().when(registrationPublisher).sendMessageToEmergencyBreakQueue(any(EmergencyBreakQueueMessage.class), any(String.class));

        EmergencyBreakQueueMessage ebreakQueueMessage = new EmergencyBreakQueueMessage();
        ebreakQueueMessage.setOptedForPinToPost(isOptedForPinToPost);
        ResponseEntity<CreateAccountResponse> response = processorUnderTest.sendMessageToEmergencyBreakQueue(ebreakQueueMessage);
        Assert.assertEquals(expectedStatusCode, response.getBody().getStatusCode());
    }

    /* Tests for getDeviceFingerPrint() */

    @Test
    public void testGetDeviceFingerPrint_contentHasIovationBlackbox_returnsDeviceFingerPrint() {
        String deviceFingerPrintValue = "testDeviceFingerPrintValue";
        String content = "{\"" + RegistrationConstants.IOVATION_BLACKBOX + "\":\"" + deviceFingerPrintValue + "\"}";
        String response = processorUnderTest.getDeviceFingerPrint(content, getSuccessfulConsumerContext());
        Assert.assertEquals(deviceFingerPrintValue, response);
    }

    public ConsumerContext getSuccessfulConsumerContext() {
        return new ConsumerContext("testSessionId", "testConversationId");
    }

}
