package com.efx.pet.service.registration.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.efx.pet.domain.eligibility.operations.LogFraudEventRequest;
import com.efx.pet.service.lift.LiftService;
import com.efx.pet.utility.fraudevents.logging.FraudEventLogger;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.configuration.Constants;
import com.efx.pet.service.configuration.TestProfileConfig;
import com.efx.pet.service.direct.registration.RegistrationResponse;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.registration.ReCaptchaService;
import com.efx.pet.service.registration.SaveConsumerResponse;
import com.efx.pet.test.common.TestHelper;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.ConsumerValidator;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {RegistrationController.class, TestProfileConfig.class})
@TestPropertySource(properties = {
  "recaptcha.site-key:key",
})
public class RegistrationControllerTest {

	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(RegistrationControllerTest.class);

    private MockMvc mockMvc;

    @Autowired
    private RegistrationController registrationController;

    @MockBean
    private ReCaptchaService reCaptchaService;

    @MockBean
    private EncryptUtility encryptUtility;

    @MockBean
    private RegistrationService registrationService;

    @MockBean
    private ConsumerValidator consumerValidator;

    @MockBean
    private ObtainIpUtility obtainIpUtility;

    @MockBean
    private SessionUtil sessionUtil;

    @MockBean
    private FraudEventLogger fraudEventLogger;

    @MockBean
    private LiftService liftService;

    private String recaptchaSiteKeyName = "siteKey";
    private static final String testCustomerKey = "test-customer-key";
    private static final String testIei = "testIei";
    private static final String testCID = "testCid";
    private static final String LIFT_INTENT = "TEMP_FREEZE_LOCK_LIFT";

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.registrationController).build();
    }

    /* Test saveConsumer endpoint */

    @Test
    public void testSaveConsumer_success_returnsConfirmation() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_success_returnsConfirmation()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS, testIei, testCustomerKey, testCID);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isOk(),
            SaveConsumerResponse.StatusCode.CONFIRMATION,
            null
        );
        LOGGER.debug("End of testSaveConsumer_success_returnsConfirmation()");
    }

  @Test
  public void testSaveConsumer_success_returnsConfirmation_liftFlow() throws Exception {
    LOGGER.debug("Start of testSaveConsumer_success_returnsConfirmation_liftFlow()");
    String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
    when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
    when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
    when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
    RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS, testIei, testCustomerKey, testCID);
    when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);
    when(liftService.getConsumer(any(ConsumerContext.class))).thenReturn(JsonUtils.fromSanitizedJson(consumerString, Consumer.class));

    testSaveConsumerEndpoint(
      true,
      consumerString,
      registrationResponse,
      status().isOk(),
      SaveConsumerResponse.StatusCode.CONFIRMATION,
      LIFT_INTENT
    );
    LOGGER.debug("End of testSaveConsumer_success_returnsConfirmation_liftFlow()");
  }

  @Test
  public void testSaveConsumer_invalidConsumer_returnsValidationError_liftFlow() throws Exception {
    LOGGER.debug("Start of testSaveConsumer_invalidConsumer_returnsValidationError_liftFlow()");
    // Empty Consumer
    Consumer consumer = new Consumer();
    // dummy Consumer is passed to /saveConsumer endpoint during the Lift flow
    String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
    when(liftService.getConsumer(any(ConsumerContext.class))).thenReturn(consumer);
    when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(false);

    testSaveConsumerEndpoint(
      true,
      consumerString,
      null,
      status().isBadRequest(),
      SaveConsumerResponse.StatusCode.VALIDATION_ERROR,
      LIFT_INTENT
    );
    LOGGER.debug("End of testSaveConsumer_invalidConsumer_returnsValidationError_liftFlow()");
  }

    @Test
    public void testSaveConsumer_success_returnsCIDException() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_success_returnsCIDException()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_CID_UNAVAILABLE, testIei, testCustomerKey, null);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isOk(),
            SaveConsumerResponse.StatusCode.CID_UNAVAILABLE,
            null
        );
        LOGGER.debug("End of testSaveConsumer_success_testSaveConsumer_success_returnsCIDException()");
    }

    @Test
    public void testSaveConsumer_null_registrationResponse() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_null_registrationResponse()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(null);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            null,
            status().is5xxServerError(),
            SaveConsumerResponse.StatusCode.SAVE_CONSUMER_SYSTEM_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_null_registrationResponse()");
    }

    @Test
    public void testSaveConsumer_null_iei() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_null_iei()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR, null, testCustomerKey, testCID);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().is5xxServerError(),
            SaveConsumerResponse.StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_null_iei()");
    }

    @Test
    public void testSaveConsumer_systemerror_indirectEnrollment() throws Exception {
      LOGGER.debug("Start of testSaveConsumer_systemerror_indirectEnrollment()");
      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
      when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
      when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
      RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR);
      when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

      testSaveConsumerEndpoint(
        true,
        consumerString,
        registrationResponse,
        status().isInternalServerError(),
        SaveConsumerResponse.StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR,
        null
      );
      LOGGER.debug("End of testSaveConsumer_systemerror_indirectEnrollment()");
    }

    @Test
    public void testSaveConsumer_success_consumerWithoutPhone_returnsConfirmation() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_success_consumerWithoutPhone_returnsConfirmation()");
        String consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)), Constants.PHONE_NUMBER_KEY);
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SUCCESS, testIei, testCustomerKey, testCID);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isOk(),
            SaveConsumerResponse.StatusCode.CONFIRMATION,
            null
        );
        LOGGER.debug("End of testSaveConsumer_success_consumerWithoutPhone_returnsConfirmation()");
    }

    @Test
    public void testSaveConsumer_cidUnavailable() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_cidUnavailable()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_CID_UNAVAILABLE);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isOk(),
            SaveConsumerResponse.StatusCode.CID_UNAVAILABLE,
            null
        );
        LOGGER.debug("End of testSaveConsumer_cidUnavailable()");
    }

    @Test
    public void testSaveConsumer_existingConsumer() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_existingConsumer()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SAVE_CONSUMER_EXIST);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isOk(),
            SaveConsumerResponse.StatusCode.SAVE_CONSUMER_EXIST,
            null
        );
        LOGGER.debug("End of testSaveConsumer_existingConsumer()");
    }

    @Test
    public void testSaveConsumer_error() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_error()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
        RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SAVE_CONSUMER_SYSTEM_ERROR);
        when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            registrationResponse,
            status().isInternalServerError(),
            SaveConsumerResponse.StatusCode.SAVE_CONSUMER_SYSTEM_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_error()");
    }

    @Test
    public void testSaveConsumer_invalidCaptchaResponse_returnsRecaptchaError() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_invalidCaptchaResponse_returnsRecaptchaError()");
        String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
        when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(false);
        when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");

        testSaveConsumerEndpoint(
            false,
            consumerString,
            null,
            status().isOk(),
            SaveConsumerResponse.StatusCode.RECAPTCHA_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_invalidCaptchaResponse_returnsRecaptchaError()");
    }

    @Test
    public void testSaveConsumer_invalidConsumer_returnsValidationError() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_invalidConsumer_returnsValidationError()");
        // Consumer without SSN
        String consumerString = TestHelper.reducedJson(TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH)), "ssn");
        when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(false);

        testSaveConsumerEndpoint(
            true,
            consumerString,
            null,
            status().isBadRequest(),
            SaveConsumerResponse.StatusCode.VALIDATION_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_invalidConsumer_returnsValidationError()");
    }

    @Test
    public void testSaveConsumer_invalidJsonContent_returnsValidationError() throws Exception {
    	LOGGER.debug("Start of testSaveConsumer_invalidJsonContent_returnsValidationError()");
        String consumerString = "{"; // Invalid Json
        testSaveConsumerEndpoint(
            null,
            consumerString,
            null,
            status().isInternalServerError(),
            SaveConsumerResponse.StatusCode.VALIDATION_ERROR,
            null
        );
        LOGGER.debug("End of testSaveConsumer_invalidJsonContent_returnsValidationError()");
    }

    @Test
    public void testSaveConsumer_throwsRuntimeException_returnsSaveConsumerSystemError() throws Exception {
      LOGGER.debug("Start of testSaveConsumer_throwsRuntimeException_returnsSaveConsumerSystemError()");
      when(consumerValidator.isValidConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(true);
      when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(true);
      when(obtainIpUtility.obtainIpAddress(any(HttpServletRequest.class))).thenReturn("IP");
      RegistrationResponse registrationResponse = new RegistrationResponse(RegistrationResponse.StatusCode.SAVE_CONSUMER_EXIST);
      when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);

      Mockito.doThrow(new RuntimeException()).when(encryptUtility).encrypt(any(HttpServletRequest.class), any(String.class), eq(CommonConstants.CONSUMER_DATA));

      String consumerString = TestHelper.prettyToCompactJson(TestHelper.fetchClassPathFile(Constants.CONSUMER_PATH));
      testSaveConsumerEndpoint(
        true,
        consumerString,
        registrationResponse,
        status().isInternalServerError(),
        SaveConsumerResponse.StatusCode.SAVE_CONSUMER_SYSTEM_ERROR,
        null);
      LOGGER.debug("End of testSaveConsumer_throwsRuntimeException_returnsSaveConsumerSystemError()");
    }

    private void testSaveConsumerEndpoint(Boolean isValidReCaptchaResponse, String consumerString, RegistrationResponse registrationResponse, ResultMatcher expectStatus, SaveConsumerResponse.StatusCode responseStatusCode, String intent) throws Exception {
        if (isValidReCaptchaResponse != null)
            when(reCaptchaService.isResponseValid(any(String.class), any(String.class))).thenReturn(isValidReCaptchaResponse);

        if (registrationResponse != null) {
        	when(registrationService.createConsumer(any(Consumer.class), any(ConsumerContext.class))).thenReturn(registrationResponse);
        }
        HashMap<String, Object> sessionattr = new HashMap<String, Object>();
        ConsumerContext context = createMockConsumerContext();
        context.setIntent(intent);
        sessionattr.put(CommonConstants.CONSUMER_CONTEXT, context);

        MvcResult result = mockMvc.perform(post(Constants.SAVE_CONSUMER_ENDPOINT)
              .sessionAttrs(sessionattr)
              .contentType(MediaType.APPLICATION_JSON)
              .content(consumerString)
          )
              .andExpect(expectStatus)
              .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
              .andReturn();

        if (SaveConsumerResponse.StatusCode.RECAPTCHA_ERROR == responseStatusCode || SaveConsumerResponse.StatusCode.VALIDATION_ERROR == responseStatusCode) {
        	// Above expression implies return without registrationService invocation
        	verify(encryptUtility, times(0)).encrypt(any(HttpServletRequest.class), any(String.class), any(String.class));
        } else {
        	ArgumentCaptor<String> argument = ArgumentCaptor.forClass(String.class);
            verify(encryptUtility, times(1)).encrypt(any(HttpServletRequest.class), argument.capture(), any(String.class));
            Consumer consumer = JsonUtils.fromSanitizedJson(argument.getValue(), Consumer.class);
            Assert.assertNotNull(consumer);
            if (SaveConsumerResponse.StatusCode.CONFIRMATION == responseStatusCode) {
            	Assert.assertEquals(testCustomerKey, consumer.getConsumerKey());
            	Assert.assertEquals(testIei, consumer.getIndirectEnrollmentId());
            } else {
            	Assert.assertEquals(null, consumer.getConsumerKey());
            	Assert.assertEquals(null, consumer.getIndirectEnrollmentId());
            }
        }

        SaveConsumerResponse saveConsumerResponse = JsonUtils.fromSanitizedJson(TestHelper.prettyToCompactJson(result.getResponse().getContentAsString()), SaveConsumerResponse.class);
        Assert.assertEquals(responseStatusCode, saveConsumerResponse.getStatusCode());
    }

    /* Test getRecaptchaSiteKeyRestEndpoint endpoint */

    @Test
    public void testGetRecaptchaSiteKeyWithoutParam() throws Exception {

      JSONObject json = new JSONObject();
      json.put(recaptchaSiteKeyName, "key");

      MvcResult result = mockMvc.perform(get("/rest/1.0/captchaSiteKey").sessionAttr(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext()))
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
      Assert.assertEquals(json.toString(), result.getResponse().getContentAsString());
      Mockito.verify(fraudEventLogger, Mockito.times(0)).logMessage(Mockito.any(LogFraudEventRequest.class), Mockito.any(ConsumerContext.class), Mockito.any(String.class));
    }

    @Test
    public void testGetRecaptchaSiteKeyWithPersonalInfoParam() throws Exception {

      JSONObject json = new JSONObject();
      json.put(recaptchaSiteKeyName, "key");

      MvcResult result = mockMvc.perform(
          get("/rest/1.0/captchaSiteKey")
            .param(CommonConstants.PAGE_NAME, CommonConstants.PERSONAL_INFO)
            .sessionAttr(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext())
        )
        .andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andReturn();
      Assert.assertEquals(json.toString(), result.getResponse().getContentAsString());
      Mockito.verify(fraudEventLogger, Mockito.atLeastOnce()).logMessage(Mockito.any(LogFraudEventRequest.class), Mockito.any(ConsumerContext.class), Mockito.any(String.class));
    }

  @Test
  public void testGetRecaptchaSiteKeyWithSomeParam() throws Exception {

    JSONObject json = new JSONObject();
    json.put(recaptchaSiteKeyName, "key");

    MvcResult result = mockMvc.perform(
      get("/rest/1.0/captchaSiteKey")
        .param(CommonConstants.PAGE_NAME, "payment-info")
        .sessionAttr(CommonConstants.CONSUMER_CONTEXT, createMockConsumerContext())
    )
      .andExpect(MockMvcResultMatchers.status().isOk())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andReturn();
    Assert.assertEquals(json.toString(), result.getResponse().getContentAsString());
    Mockito.verify(fraudEventLogger, Mockito.times(0)).logMessage(Mockito.any(LogFraudEventRequest.class), Mockito.any(ConsumerContext.class), Mockito.any(String.class));
  }

    private ConsumerContext createMockConsumerContext() {
        ConsumerContext consumerContext = new ConsumerContext("testSessionId", "testConversationId");
        consumerContext.setPartnerId("EFX-DIRECT-US");
        consumerContext.setTenantId("EFX-US");
        consumerContext.setDefaultLocale("en");
        return consumerContext;
      }
}
