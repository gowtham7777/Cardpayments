package com.efx.pet.service.registration.cookie;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * This class was created due to SonarQube complain
 */
public class DefaultCustomSessionCookieConfigTest {

  DefaultCustomSessionCookieConfig classUnderTest;

  @Before
  public void setUp() {
    classUnderTest = new DefaultCustomSessionCookieConfig();
  }

  @Test
  public void isUseBase64Encoding() {
    assertFalse(classUnderTest.isUseBase64Encoding());
  }

  @Test
  public void setUseBase64Encoding() {
    classUnderTest.setUseBase64Encoding(true);
    assertTrue(classUnderTest.isUseBase64Encoding());
  }

  @Test
  public void setName() {
    classUnderTest.setName("name");
    assertEquals("name", classUnderTest.getName());
  }

  @Test
  public void getName() {
    assertEquals("SESSION", classUnderTest.getName());
  }

  @Test
  public void setDomain() {
    classUnderTest.setDomain("setDomain");
    assertEquals("setDomain", classUnderTest.getDomain());
  }

  @Test
  public void getDomain() {
    assertNull(classUnderTest.getDomain());
  }

  @Test
  public void setPath() {
    classUnderTest.setPath("setPath");
    assertEquals("setPath", classUnderTest.getPath());
  }

  @Test
  public void getPath() {
    assertNull(classUnderTest.getPath());
  }

  @Test
  public void setComment() {
    classUnderTest.setComment("setComment");
    assertEquals("setComment", classUnderTest.getComment());
  }

  @Test
  public void getComment() {
    assertNull(classUnderTest.getComment());
  }

  @Test
  public void setSameSite() {
    classUnderTest.setSameSite("SomethingElse");
    assertEquals("SomethingElse", classUnderTest.getSameSite());
  }

  @Test
  public void getSameSite() {
    assertEquals("None", classUnderTest.getSameSite());
  }

  @Test
  public void setHttpOnly() {
    classUnderTest.setHttpOnly(false);
    assertFalse(classUnderTest.isHttpOnly());
  }

  @Test
  public void isHttpOnly() {
    assertTrue(classUnderTest.isHttpOnly());
  }

  @Test
  public void setSecure() {
    classUnderTest.setSecure(false);
    assertFalse(classUnderTest.isSecure());
  }

  @Test
  public void isSecure() {
    assertTrue(classUnderTest.isSecure());
  }

  @Test
  public void setMaxAge() {
    classUnderTest.setMaxAge(100);
    assertEquals(100, classUnderTest.getMaxAge());
  }

  @Test
  public void getMaxAge() {
    assertEquals(-1, classUnderTest.getMaxAge());
  }
}
