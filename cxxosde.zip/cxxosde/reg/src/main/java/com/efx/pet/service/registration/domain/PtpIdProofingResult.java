package com.efx.pet.service.registration.domain;

import java.io.Serializable;

public class PtpIdProofingResult implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public enum IdProofingStatus {
		PASS,
		FAIL
	}
	
	private IdProofingStatus idProofingStatus;
	private String failureReason; //Optional
	
	public PtpIdProofingResult() {}

	public PtpIdProofingResult(IdProofingStatus idProofingStatus, String failureReason) {
		this.idProofingStatus = idProofingStatus;
		this.failureReason = failureReason;
	}
	
	public IdProofingStatus getIdProofingStatus() {
		return idProofingStatus;
	}
	public void setIdProofingStatus(IdProofingStatus idProofingStatus) {
		this.idProofingStatus = idProofingStatus;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
}
