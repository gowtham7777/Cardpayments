package com.efx.pet.service.registration.controller;

import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static com.efx.pet.service.registration.controller.AuditConstants.EVENT_HEALTH_CHECK;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "healthCheckController")
public class HealthCheckController {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(HealthCheckController.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "HealthCheckController");

    @Autowired
    BuildProperties buildProperties;

    @GetMapping("/healthCheck")
    public Map<String, Object> healthCheck() {
        AUDITOR.recordInfo(EVENT_HEALTH_CHECK, AuditEventStatus.BEGIN, "Start - HealthCheckController.healthCheck() - Begin HealthCheck");
        Map<String, Object> statusProperties = new HashMap<>();
        statusProperties.put("status", "OK");
        statusProperties.put("build", getBuildPropertiesResource());
        AUDITOR.recordInfo(EVENT_HEALTH_CHECK, AuditEventStatus.END_SUCCESS, "End - HealthCheckController.healthCheck() - End HealthCheck");
        return statusProperties;
    }

    private Properties getBuildPropertiesResource() {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        Properties props = new Properties();
        props.setProperty("groupId", buildProperties.getGroup());
        props.setProperty("artifactId", buildProperties.getArtifact());
        props.setProperty("time", simpleDateFormat.format(buildProperties.getTime().getEpochSecond()));
        props.setProperty("version", buildProperties.getVersion());
        return props;
    }


}
