package com.efx.pet.service.registration.exception;


import com.efx.pet.service.registration.domain.SingleSignOnResponse.StatusCode;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CustomException class for SingleSignOnOAuth2Exception
 *
 * @author vxc64
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class SingleSignOnException extends Exception {

  /**
   *
   */
  @JsonInclude
  private static final long serialVersionUID = 1L;

  @JsonInclude
  private final StatusCode statusCode;

  @JsonInclude
  private final String message;

  public SingleSignOnException(StatusCode statusCode, String message) {
    super(message);
    this.statusCode = statusCode;
    this.message = message;
  }

  public SingleSignOnException(StatusCode statusCode, String message, Throwable t) {
    super(message, t);
    this.statusCode = statusCode;
    this.message = message;
  }
}
