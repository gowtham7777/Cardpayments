package com.efx.pet.registration.controller.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SessionUtil {

    private static Logger logger = LoggerFactory.getLogger(SessionUtil.class);

    public void invalidateSession(final HttpServletRequest httpServletRequest) {
        final HttpSession session = httpServletRequest.getSession(false);
        if (session != null) {

            logger.info("Invalidated the session, id: {}", session.getId());
            session.invalidate();
        }
    }

}
