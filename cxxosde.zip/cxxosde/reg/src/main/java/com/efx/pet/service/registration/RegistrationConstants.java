package com.efx.pet.service.registration;

public class RegistrationConstants {

    private RegistrationConstants() {
        
    }

    public static final String CONSUMER = "CONSUMER";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String ENROLLMENT_DATE = "enrollmentDate";
    public static final String PHONE_ELIGIBLE = "PHONE_ELIGIBLE";
    public static final String INDICATOR_YES = "Y";
    public static final String INDICATOR_NO = "N";
    public static final String EID_STATUS = "EID_STATUS";
    public static final String OTP_ELIGIBLE = "OTP_ELIGIBLE";
    public static final String LOCATION = "Location";
    public static final String TID_STATUS_SUCCESS = "SUCCESS";
    public static final String TID_STATUS_DUPLICATE_ENROLLMENT = "DUPLICATE_ENROLLMENT";
    public static final String TID_STATUS_FAILURE = "FAILURE";
    public static final String DOB_RETRY_COUNT = "DOB_RETRY_COUNT";
    public static final String ACTIVATION_URL = "ACTIVATION_URL";
    public static final String DISABLED = "DISABLED";
    public static final String TRANSACTION_CACHE_NAME = "TRANSACTION_CACHE";
    public static final String IOVATION_BLACKBOX = "blackBox";
    public static final String APPLICATION_JSON = "application/json; charset=utf-8";
	public static final String APPLICATION_XML = "application/xml; charset=utf-8";
	public static final String TEXT_PLAIN = "text/plain; charset=utf-8";
	public static final String EMPTY_JSON = "{}";
	public static final String EID_QUIZ_CREATED_TIME = "EID_QUIZ_CREATED_TIME";
}
