package com.efx.pet.service.registration.domain;

/**
 * Custom Exception for Flow Interceptor class
 * Use this class to define custom error and status codes, if any
 * @author vxc64
 *
 */
public class FlowInterceptorException extends Exception {


    /**
   *
   */
  private static final long serialVersionUID = -8698991951693098317L;

    public FlowInterceptorException(String string) {
        super(string);
    }

}
