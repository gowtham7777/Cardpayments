package com.efx.pet.service.registration;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OTPResponse {

	public enum StatusCode {
		ENROLL_OTP_RESEND_ALLOWED,
		ENROLL_OTP_RESEND_MAX,
		ENROLL_OTP_ERROR,
		ENROLL_OTP_ERROR_UNKNOWN,
		ENROLL_OTP_SYSTEM_ERROR, //http 500
		OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX,
		OTP_VALIDATE_ERROR,
		OTP_VALIDATE_ERROR_UNKNOWN,
		OTP_VALIDATE_SYSTEM_ERROR, //http 500
		VALIDATION_ERROR, //http 400
		ENROLL_OTP_RESEND_ALLOWED_INIT,
		OTP_VALIDATE_PIN_SUCCESS,
		KBA_FAILURE_ELIGIBILITY_FAIL,
	    PIN_TO_POST_PRIMARY,
	    PIN_TO_POST_SECONDARY,
	    KBA_QUIZ_ERROR,
	    PTP_ELIGIBILITY_FAIL
	}

	private String transactionId;
	private StatusCode statusCode;
	private String destinationUrl;
  private int remainingAttempts;

	public StatusCode getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	public void setDestinationUrl(String destinationUrl) {
		this.destinationUrl = destinationUrl;
	}

  public int getRemainingAttempts() {
    return remainingAttempts;
  }

  public void setRemainingAttempts(int remainingAttempts) {
    this.remainingAttempts = remainingAttempts;
  }

	public OTPResponse(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	// Default constructor for use with serialization
	public OTPResponse(){}
}
