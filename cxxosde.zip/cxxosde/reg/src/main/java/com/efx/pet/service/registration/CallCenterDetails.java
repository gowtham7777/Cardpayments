package com.efx.pet.service.registration;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CallCenterDetails {
	private String callCenterTimeMessage;
	private String callCenterPhoneNumber;
	private String ptpCallCenterMessage;

}
