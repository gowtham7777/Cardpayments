package com.efx.pet.service.registration.controller.processor;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;

import com.efx.pet.client.eligibility.EligibilityConfiguration;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.message.EmergencyBreakQueueMessage;
import com.efx.pet.service.registration.CreateAccountResponse;
import com.efx.pet.service.registration.CreateAccountResponse.StatusCode;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.utility.RegistrationPublisher;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

/**
 * This class contains the methods common between CreateAccountController and
 * EmergencyBreakProcessor
 *
 * @author vxc64
 *
 */
@Component
@ContextConfiguration(classes = EligibilityConfiguration.class)
public class CreateAccountProcessor {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(CreateAccountProcessor.class);
    public static final String HEADER_FORWARD = "HTTP_X_FORWARDED_FOR";
    public static final String HEADER_FORWARD_STANDARD = "X-Forwarded-For";

    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "createAccount");

    @Value("${aws.sqs.emergency.break.queue.name}")
    private String emergencyBreakQueueName;

    @Autowired
    private RegistrationPublisher registrationPublisher;

     public ResponseEntity<CreateAccountResponse> sendMessageToEmergencyBreakQueue(final EmergencyBreakQueueMessage queueMessage) {

            registrationPublisher.sendMessageToEmergencyBreakQueue(queueMessage, emergencyBreakQueueName);
            if(queueMessage.isOptedForPinToPost()) {
                return new ResponseEntity<>(
                        new CreateAccountResponse(StatusCode.EMERGENCY_BREAK_P2P_OPTED_IN), HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(
                        new CreateAccountResponse(StatusCode.EMERGENCY_BREAK_P2P_OPTED_OUT), HttpStatus.OK);
            }
        }

    public String getDeviceFingerPrint(final String content, ConsumerContext consumerContext) {
        final JSONObject jsonObject = new JSONObject(content);
        String deviceFingerPrint = null;
        try {
            deviceFingerPrint = jsonObject.has(RegistrationConstants.IOVATION_BLACKBOX) ? jsonObject.getString(RegistrationConstants.IOVATION_BLACKBOX) : null;
        } catch(JSONException jsonException) {
            String message = "BlackBox recieved null while parsing content : " + jsonException.getMessage();
             LOGGER.error(message);
             AUDITOR.recordError(AuditConstants.EVENT_CREATE_ACCOUNT, AuditEventStatus.END_FAIL, message, consumerContext);
        }
        return deviceFingerPrint;
    }

}
