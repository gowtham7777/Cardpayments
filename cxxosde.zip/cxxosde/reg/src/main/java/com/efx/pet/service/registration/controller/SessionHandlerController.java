package com.efx.pet.service.registration.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


/**
 * Created by rrk4 on 12/15/2017.
 */
@RestController
@RequestMapping("/rest/1.0")
@Tag(name ="SessionHandlerController", description="Session Handler Operations")
public class SessionHandlerController {
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(SessionHandlerController.class);
	private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "SessionHandler");

	/**
	 * Invalidates current session, provided it exists, and creates a new session with same attributes.
	 * This is to ensure user's session doesn't expire during long periods of inactivity
	 * @param httpServletRequest
	 * @return
	 */
	@Operation(summary = "Invalidates current session and creates a new session")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Returns with new session", content = {
			@Content(schema = @Schema(implementation = Object.class)) }) })
	@RequestMapping(value = "/keepalive", method = RequestMethod.GET)
	public ResponseEntity<?> keepAlive(HttpServletRequest httpServletRequest) {
		String message = "";
		final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false)
                        .getAttribute(CommonConstants.CONSUMER_CONTEXT);
		message = "Begin session keep alive";
		LOGGER.info(message);
		AUDITOR.recordInfo(AuditConstants.EVENT_SESSION_KEEPALIVE, AuditEventStatus.BEGIN, message, consumerContext);
		return new ResponseEntity<>(null, null, HttpStatus.OK);
	}

	/**
	 * Invalidates current session, provided it exists
	 * @param httpServletRequest
	 * @return
	 */
	@Operation(summary = "Invalidates current session")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns success after invalidation", content = {
					@Content(schema = @Schema(implementation = Object.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = Object.class)) }) })
	@RequestMapping(value = "/timeout", method = RequestMethod.GET)
	public ResponseEntity<?> timeOut(HttpServletRequest httpServletRequest) {
		String message = "";
		final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false)
                        .getAttribute(CommonConstants.CONSUMER_CONTEXT);
		message = "Begin explicit session invalidation";
		LOGGER.info(message);
		AUDITOR.recordInfo(AuditConstants.EVENT_SESSION_TIMEOUT, AuditEventStatus.BEGIN, message, consumerContext);
		//get the current session
		HttpSession currentSession = httpServletRequest.getSession(false);
		if (currentSession == null) {
			message = "Current session doesn't exist";
			LOGGER.error(message);
			AUDITOR.recordError(AuditConstants.EVENT_SESSION_TIMEOUT, AuditEventStatus.END_FAIL, message, consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return new ResponseEntity<>(null, null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		message = "Invalidating current session";
		LOGGER.info(message);
		AUDITOR.recordInfo(AuditConstants.EVENT_SESSION_TIMEOUT, AuditEventStatus.IN_PROGRESS, message, consumerContext);
		currentSession.invalidate();
		message = "Current session invalidated successfully";
		LOGGER.info(message);

    AUDITOR.recordInfo(AuditConstants.EVENT_SESSION_TIMEOUT, AuditEventStatus.END_SUCCESS, message, consumerContext, null,null,HttpStatus.OK.toString());
		return new ResponseEntity<>(null, null, HttpStatus.OK);
	}
}
