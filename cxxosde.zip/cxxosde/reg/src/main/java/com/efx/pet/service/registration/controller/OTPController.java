package com.efx.pet.service.registration.controller;

import java.text.MessageFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.OtpMethod;
import com.efx.pet.domain.tid.common.IDPData;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.registration.OTPResponse;
import com.efx.pet.service.registration.domain.EnrollOTPRequest;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.service.registration.domain.OTPConsumer;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Created by dxl84 on 9/8/2017.
 */
@RestController
@RequestMapping("/rest/2.0")
@Tag(name = "OTPController", description = "OTP Operations")
public class OTPController extends RestControllerBase {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(OTPController.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "Otp");
	private static final String ENROLL_OTP = AuditConstants.EVENT_OTP_ENROLL;
	private static final String VALIDATE_PIN = AuditConstants.EVENT_OTP_VALIDATE_PIN;
	private static final int OTP_RESEND_INITIAL_ATTEMPT_COUNT = 1;
	private HttpHeaders headers = new HttpHeaders();
	private ResponseEntity<OTPResponse> DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY;
	private static final ResponseEntity<OTPResponse> DEFAULT_VALIDATE_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
			new OTPResponse(OTPResponse.StatusCode.OTP_VALIDATE_SYSTEM_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
	private static final EnumMap<IdProofingResponse.StatusCode, ResponseEntity<OTPResponse>> ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP = new EnumMap<>(
			IdProofingResponse.StatusCode.class);
	private static final EnumMap<IdProofingResponse.StatusCode, ResponseEntity<OTPResponse>> VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP = new EnumMap<>(
			IdProofingResponse.StatusCode.class);

    private static Pattern pinPattern = Pattern.compile("^[0-9]{6}$");

    @Autowired
    EncryptUtility encryptUtility;

    @Autowired
    private SessionUtil sessionUtil;

    @Autowired
    private IdProofingService idProofingService;

    @Value("${com.efx.pet.service.registration.otp.resend.max.count:2}")
    private byte otpResendMaxCount;

    @Value("${com.efx.pet.service.registration.otp.retry.max.count:3}")
    private byte otpRetryMaxCount;

	@PostConstruct
	public void init() {
		// Response header implementation so IE doesn't store get request in cache.
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
				new OTPResponse(OTPResponse.StatusCode.ENROLL_OTP_SYSTEM_ERROR), headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
		/**
		 * Used HttpStatus.ACCEPTED (202) as against HttpStatus.OK (200) for some set of
		 * entries in map. Intent for those entries is to audit as error and invalidate
		 * session. This is non-impacting to front end App.
		 */
		// Map has all UNSUCCESSFUL entries for OTP enroll, except for Kba Quiz Success
		// since it involves ResponseEntity of kind 'KbaResponse'
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.ID_PROOFING_SYSTEM_ERROR,
				DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY);
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL), headers,
						HttpStatus.ACCEPTED));
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PIN_TO_POST_PRIMARY), headers,
						HttpStatus.OK));
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_SECONDARY,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PIN_TO_POST_SECONDARY), headers,
						HttpStatus.OK));
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.KBA_QUIZ_ERROR), headers,
						HttpStatus.ACCEPTED));
		ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PTP_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PTP_ELIGIBILITY_FAIL), headers,
						HttpStatus.ACCEPTED));
		// Map has all UNSUCCESSFUL entries for OTP validate, except for Kba Quiz Success
		// since it involves ResponseEntity of kind 'KbaResponse'
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.ID_PROOFING_SYSTEM_ERROR,
				DEFAULT_VALIDATE_ERROR_RESPONSE_ENTITY);
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL),
						HttpStatus.ACCEPTED));
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PIN_TO_POST_PRIMARY), HttpStatus.OK));
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_SECONDARY,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PIN_TO_POST_SECONDARY), HttpStatus.OK));
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.KBA_QUIZ_ERROR), HttpStatus.ACCEPTED));
		VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PTP_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.PTP_ELIGIBILITY_FAIL), HttpStatus.ACCEPTED));
	}

    /**
     * If consumer does opt-in, call Eid Service to Sms PIN to consumer. Based on:
     * -success of that call, show OTP verify page
     * -failure of that call, get Kba Quiz
     *
     * @param httpServletRequest
     * @return
     */
    @Operation(summary = "Returns the StatusCode")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns status when OTP initiation successful", content = {
					@Content(schema = @Schema(implementation = OTPResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = OTPResponse.class)) }) })
    @PostMapping(value = "/enrollOTP", produces = APPLICATION_JSON, consumes = APPLICATION_JSON)
    public ResponseEntity<?> enrollOTP(HttpServletRequest httpServletRequest, @RequestBody String content) {
        final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
        AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.BEGIN, "Start - OTPController.enrollOTP() - Begin One Time Pin enrollment.", consumerContext);
        long startTime = System.currentTimeMillis();
        //Retrieve from HttpSession and Decrypt consumer
        final String decryptedConsumer = encryptUtility.decrypt(httpServletRequest, CommonConstants.CONSUMER_DATA);
        final Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
        EnrollOTPRequest request = JsonUtils.fromSanitizedJson(content, EnrollOTPRequest.class);
    	String pinType = request.getPinType();
        if (consumer == null) {
          AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.END_FAIL, "Either HttpSession OR Consumer in HttpSession is null.", consumerContext, null, OTPResponse.StatusCode.ENROLL_OTP_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
          sessionUtil.invalidateSession(httpServletRequest);
          return DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY;
        }

        if(consumer.getOtpMethod() == null) {
        	AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.END_FAIL, "OtpMethod can not be null", consumerContext, consumer.getConsumerKey(), OTPResponse.StatusCode.ENROLL_OTP_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
        	sessionUtil.invalidateSession(httpServletRequest);
        	return DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY;
        }
        else  {
        	if (StringUtils.isBlank(pinType)) {
        		String message ="Missing Input pinType.";
        		if(consumer.getOtpMethod() == OtpMethod.TEXT_EMAIL) {
        			AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), OTPResponse.StatusCode.ENROLL_OTP_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            		sessionUtil.invalidateSession(httpServletRequest);
        			return DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY;
        		}
        		AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.IN_PROGRESS, message, consumerContext);
        	}
        	else
        		validateAndSetPinType(consumer, consumerContext, pinType);
        	  consumerContext.setOtpMethod(consumer.getOtpMethod().name());
        }

        try {
        	AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.IN_PROGRESS, "Calling idProofingService.enrollInOtp()...",
        			consumer.getConsumerKey(), consumerContext);
        	// Below line gets idpData object from session. which contains RAE endpoints information
        	IDPData idpData = (IDPData) httpServletRequest.getSession(false).getAttribute(CommonConstants.IDP_DATA);
        	IdProofingResponse idProofingResponse = idProofingService.enrollInOtp(consumer, consumerContext, idpData);
        	if (idProofingResponse != null) {
        		if (IdProofingResponse.StatusCode.OTP_ENROLL_SUCCESS == idProofingResponse.getStatusCode()) {
        			// Enroll positive scenario
        			return enrollOtpSuccessResponse(idProofingResponse, consumer, consumerContext, httpServletRequest,startTime);
        		}
        		if (idProofingResponse.getKbaPackage() != null) {
        			return kbaSuccessResponse(idProofingResponse, consumer, consumerContext, httpServletRequest,
        					ENROLL_OTP);
        		}
        	}
        	return unsuccessfulResponse(idProofingResponse, consumer, consumerContext, httpServletRequest,
        			ENROLL_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP, ENROLL_OTP);
        } catch (Exception e) {
        	String message = "Unknown Exception encountered when enrolling in OTP.";
        	LOGGER.checkBeforeError(message, e);
        	AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), OTPResponse.StatusCode.ENROLL_OTP_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
        	sessionUtil.invalidateSession(httpServletRequest);
        	return DEFAULT_ENROLL_ERROR_RESPONSE_ENTITY;
        }
    }

    private void validateAndSetPinType(Consumer consumer, ConsumerContext consumerContext, String pinType) {
    	LOGGER.checkBeforeDebug("Start- validateAndSetPinType");
    	if(consumer.getOtpMethod() == OtpMethod.TEXT_EMAIL)
    		consumer.setOtpMethod(OtpMethod.valueOf(pinType));
    	else {
    		if(!StringUtils.equals(consumer.getOtpMethod().toString(), pinType)) {
    			AUDITOR.recordError(ENROLL_OTP, AuditEventStatus.IN_PROGRESS, "PinType and OtpMethod are not matching.", consumerContext);
    		}
    	}
    }

	private ResponseEntity<OTPResponse> enrollOtpSuccessResponse(IdProofingResponse idProofingResponse,
			Consumer consumer, ConsumerContext consumerContext, HttpServletRequest httpServletRequest, long startTime) {
		LOGGER.checkBeforeDebug("Start- enrollOtpSuccessResponse");
		try {
			// Don't return unencrypted transaction key to UI
			consumer.setOtpTransactionKey(idProofingResponse.getTransactionKey());
			// Update OTP resend count
			byte otpResendCount = consumer.getOtpResendCount() != null ? consumer.getOtpResendCount() : 0;
			AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.IN_PROGRESS,
					MessageFormat.format("OTP session resent count = {0}", otpResendCount), consumer.getConsumerKey(),
					consumerContext);
			consumer.setOtpResendCount(++otpResendCount);
			encryptUtility.encrypt(httpServletRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
			if (otpResendCount == OTP_RESEND_INITIAL_ATTEMPT_COUNT) {
				AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.END_SUCCESS,
						MessageFormat.format(
								"OTP resend allowed init. OTP session resend count = {0}, OTP max resend count = {1}",
								otpResendCount, otpResendMaxCount),
						consumerContext, consumer.getConsumerKey(),
						OTPResponse.StatusCode.ENROLL_OTP_RESEND_ALLOWED_INIT.toString(), HttpStatus.OK.toString(), Long.toString(startTime));
				return new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.ENROLL_OTP_RESEND_ALLOWED_INIT),
						headers, HttpStatus.OK);
			} else if (otpResendCount > otpResendMaxCount) {
				AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.END_PARTIAL_SUCCESS,
						MessageFormat.format(
								"OTP resend maxed-out. OTP session resend count = {0}, OTP max resend count = {1}",
								otpResendCount, otpResendMaxCount),
						consumerContext, consumer.getConsumerKey(),
						OTPResponse.StatusCode.ENROLL_OTP_RESEND_MAX.toString(), HttpStatus.OK.toString());
				return new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.ENROLL_OTP_RESEND_MAX), headers,
						HttpStatus.OK);
			}
			// Success
			AUDITOR.recordInfo(ENROLL_OTP, AuditEventStatus.END_SUCCESS, "One Time Pin enrollment successful.",
					consumerContext, consumer.getConsumerKey(),
					OTPResponse.StatusCode.ENROLL_OTP_RESEND_ALLOWED.toString(), HttpStatus.OK.toString(),Long.toString(startTime));
			return new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.ENROLL_OTP_RESEND_ALLOWED), headers,
					HttpStatus.OK);
		} finally {
			LOGGER.checkBeforeDebug("End- enrollOtpSuccessResponse");
		}
	}

	private ResponseEntity<KbaResponse> kbaSuccessResponse(IdProofingResponse idProofingResponse, Consumer consumer,
			ConsumerContext consumerContext, HttpServletRequest httpServletRequest, String auditEventName) {
		LOGGER.checkBeforeDebug("Start- kbaSuccessResponse");
		Date sessionAccessedTime = new Date(httpServletRequest.getSession(false).getLastAccessedTime());
		LOGGER.checkBeforeDebugFormat("Session accessed time during quiz generation : {0}", sessionAccessedTime);
		consumer.setQuizLastAccessedTime(sessionAccessedTime);
		consumer.setKbaQuizTransactionKey(idProofingResponse.getKbaPackage().getTransactionKey());
		encryptUtility.encrypt(httpServletRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
		KbaResponse kbaResponse = new KbaResponse(
				KbaResponse.StatusCode.valueOf(idProofingResponse.getStatusCode().toString()));
		kbaResponse.setQuizIdentifier(idProofingResponse.getKbaPackage().getQuizIdentifier());
		kbaResponse.setQuestions(idProofingResponse.getKbaPackage().getKbaQuiz());
		AUDITOR.recordInfo(auditEventName, AuditEventStatus.END_PARTIAL_SUCCESS, "Kba quiz generation successful.",
				consumerContext, consumer.getConsumerKey(), kbaResponse.getStatusCode().toString(),
				HttpStatus.OK.toString());
		LOGGER.checkBeforeDebug("End- kbaSuccessResponse");
		return new ResponseEntity<>(kbaResponse, HttpStatus.OK);
	}

	private ResponseEntity<?> unsuccessfulResponse(IdProofingResponse idProofingResponse, Consumer consumer,
			ConsumerContext consumerContext, HttpServletRequest httpServletRequest,
			EnumMap<IdProofingResponse.StatusCode, ResponseEntity<OTPResponse>> map, String auditEventName)
			throws IdProofingServiceException {
		LOGGER.checkBeforeDebug("Start- unsuccessfulResponse");
		try {
			if (idProofingResponse != null) {
				ResponseEntity<OTPResponse> responseEntity = map.get(idProofingResponse.getStatusCode());
				if (responseEntity != null) {
					if (HttpStatus.OK == responseEntity.getStatusCode()) {
						AUDITOR.recordInfo(auditEventName, AuditEventStatus.END_PARTIAL_SUCCESS,
								"Next Id proofing initiated successfully.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
					} else {
						AUDITOR.recordError(auditEventName, AuditEventStatus.END_FAIL,
								"Next Id proofing initiation failed.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
						sessionUtil.invalidateSession(httpServletRequest);
					}
					return responseEntity;
				}
			}
			String message = "";
			if (ENROLL_OTP == auditEventName) {
				message = "Null or unhandled response from idProofingService.enrollInOtp().";
			} else {
				message = "Null or unhandled response from idProofingService.validateOtp().";
			}
			LOGGER.checkBeforeError(message);
			throw new IdProofingServiceException(message);
		} finally {
			LOGGER.checkBeforeDebug("End- unsuccessfulResponse");
		}
	}

    /**
     * If consumer enters the PIN, call Eid Service to validate the PIN keyed in by consumer.
     * For OTP PIN pass scenario, Call Save Consumer to TID API and redirect to TID if save consumer is successful,
     * or show error page if save consumer call fails.
     * If OTP PIN fails, get Kba Quiz
     *
     * @param httpServletRequest
     * @param content
     * @return
     */
    @Operation(summary = "Returns the StatusCode")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns status when Pin validation and TID successful OR Kba quiz generation successful", content = {
					@Content(schema = @Schema(implementation = OTPResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Missing required fields", content = {
					@Content(schema = @Schema(implementation = OTPResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = OTPResponse.class)) }) })
    @RequestMapping(value = "/validatePin", method = RequestMethod.POST, produces = APPLICATION_JSON, consumes = APPLICATION_JSON)
    public ResponseEntity<?> validatePin(HttpServletRequest httpServletRequest, @RequestBody String content) {
        final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
        AUDITOR.recordInfo(VALIDATE_PIN, AuditEventStatus.BEGIN, "Start - OTPController.validatePin() - Begin OTP pin validation.", consumerContext);
        long startTime = System.currentTimeMillis();
        // Fetch consumer from session, for either saving to TID on successful pin validation OR
        // alternate authentication - Kba quiz generation
        final String decryptedConsumer = encryptUtility.decrypt(httpServletRequest, CommonConstants.CONSUMER_DATA);
		Consumer consumer = null;
		try {
			consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
            OTPConsumer request;
            request = JsonUtils.fromSanitizedJson(content, OTPConsumer.class);
            String passCode = request.getPin();
            if (StringUtils.isBlank(passCode) || !pinPattern.matcher(passCode).matches()) {
                String message = "Missing or invalid pin.";
                LOGGER.checkBeforeError(message);
                AUDITOR.recordError(VALIDATE_PIN, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), OTPResponse.StatusCode.OTP_VALIDATE_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
                return new ResponseEntity<>(new OTPResponse(OTPResponse.StatusCode.OTP_VALIDATE_ERROR), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isBlank(consumer.getOtpTransactionKey())) {
                String message = "Either HttpSession OR Consumer/Transaction Key in HttpSession is null.";
                LOGGER.checkBeforeError(message);
                AUDITOR.recordError(VALIDATE_PIN, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), OTPResponse.StatusCode.OTP_VALIDATE_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
                sessionUtil.invalidateSession(httpServletRequest);
                return DEFAULT_VALIDATE_ERROR_RESPONSE_ENTITY;
            }
			AUDITOR.recordInfo(VALIDATE_PIN, AuditEventStatus.IN_PROGRESS, "Calling idProofingService.validateOtp()...",
					consumer.getConsumerKey(), consumerContext);
			// Below line gets idpData object from session. which contains RAE endpoints information
        	IDPData idpData = (IDPData) httpServletRequest.getSession(false).getAttribute(CommonConstants.IDP_DATA);
			IdProofingResponse idProofingResponse = idProofingService.validateOtp(passCode, consumer, consumerContext, idpData);
			if (idProofingResponse != null) {
				if (IdProofingResponse.StatusCode.OTP_VALIDATE_PIN_SUCCESS == idProofingResponse.getStatusCode()) {
					// Validate positive scenario
					final OTPResponse otpResponse = new OTPResponse(OTPResponse.StatusCode.OTP_VALIDATE_PIN_SUCCESS);
					if (StringUtils.isNotBlank(idProofingResponse.getActivationUrl())) {
						// Only applies to TID flow
						otpResponse.setDestinationUrl(idProofingResponse.getActivationUrl());
						sessionUtil.invalidateSession(httpServletRequest); // invalidate Session only for TID flow for Positive scenario
					}
					AUDITOR.recordInfo(VALIDATE_PIN, AuditEventStatus.END_SUCCESS, "OTP validate pin successful.",
							consumerContext, consumer.getConsumerKey(),
							OTPResponse.StatusCode.OTP_VALIDATE_PIN_SUCCESS.toString(), HttpStatus.OK.toString(),Long.toString(startTime));
					return new ResponseEntity<>(otpResponse, HttpStatus.OK);
				}
				if (IdProofingResponse.StatusCode.OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX == idProofingResponse
						.getStatusCode()) {
					byte otpRetryCount = (consumer.getOtpRetryCount() != null ? consumer.getOtpRetryCount()
							: otpRetryMaxCount);
					consumer.setOtpRetryCount(--otpRetryCount);
					encryptUtility.encrypt(httpServletRequest, JsonUtils.toJson(consumer),
							CommonConstants.CONSUMER_DATA);
					// Per current requirement, new PIN resend request is NOT allowed after first
					// pin submission attempt
					final OTPResponse otpResponse = new OTPResponse(
							OTPResponse.StatusCode.OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX);
					otpResponse.setRemainingAttempts(otpRetryCount);
					AUDITOR.recordInfo(VALIDATE_PIN, AuditEventStatus.END_PARTIAL_SUCCESS,
							MessageFormat.format(
									"OTP validate pin failed. Allowed resubmit. Remaining retry attempts count = {0}",
									otpRetryCount),
							consumerContext, consumer.getConsumerKey(),
							OTPResponse.StatusCode.OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX.toString(),
							HttpStatus.OK.toString());
					return new ResponseEntity<>(otpResponse, HttpStatus.OK);
				}
				if (idProofingResponse.getKbaPackage() != null) {
					return kbaSuccessResponse(idProofingResponse, consumer, consumerContext, httpServletRequest,
							VALIDATE_PIN);
				}
			}
			return unsuccessfulResponse(idProofingResponse, consumer, consumerContext, httpServletRequest,
					VALIDATE_OTP_UNSUCCESSFUL_RESPONSE_ENTITY_MAP, VALIDATE_PIN);
        } catch (Exception e) {
            String message = "Unknown Exception encountered while trying to validate Pin.";
            LOGGER.checkBeforeError(message, e);
            AUDITOR.recordError(VALIDATE_PIN, AuditEventStatus.END_FAIL, message, consumerContext, consumer != null ? consumer.getConsumerKey() : "Invalid consumer data", OTPResponse.StatusCode.OTP_VALIDATE_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            sessionUtil.invalidateSession(httpServletRequest);
            return DEFAULT_VALIDATE_ERROR_RESPONSE_ENTITY;
        }
    }
}
