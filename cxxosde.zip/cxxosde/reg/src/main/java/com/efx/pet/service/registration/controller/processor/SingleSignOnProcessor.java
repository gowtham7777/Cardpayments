package com.efx.pet.service.registration.controller.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import reactor.core.publisher.Mono;

import com.efx.domain.sso.SingleSignOnData;
import com.efx.domain.sso.SingleSignOnDetails;
import com.efx.domain.sso.TokenInfo;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.eligibility.operations.LogFraudEventRequest;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.service.registration.domain.SingleSignOnResponse.StatusCode;
import com.efx.pet.service.registration.exception.SingleSignOnException;
import com.efx.pet.utility.encryption.Encryptor;
import com.efx.pet.utility.fraudevents.logging.FraudEventLogger;
import com.efx.pet.utility.fraudevents.logging.FraudEventUtils;
import com.efx.pet.utility.utils.SanitizedJsonUtils;

/**
 * Single Sign On processor - provides abstraction for intermediate calls for SingleSignOnController
 * @author vxc64
 *
 */
@Component
public class SingleSignOnProcessor {

	@Autowired
	private EncryptUtility encryptUtility;

	@Autowired
	@Qualifier("memberCenterEncryptor")
	Encryptor encryptor;

	@Autowired
	FraudEventLogger fraudEventLogger;

	@Autowired
	WebClient webClient;

	private static final String USER_NAME = "username";
	private static final String GRAND = "password";
	private static final String GRAND_TYPE = "grant_type";
	private static final String ACCESS_TOKEN = "access_token";
	private static final String EXPIRES_IN = "expires_in";
	private static final String REFRESH_TOKEN = "refresh_token";

  /**
   * Get OAuth Token Info for specific customerKey
   * @param consumer
   * @param consumerContext
   * @throws TokenInfo
   */
	TokenInfo getOAuthorizedClient(Consumer consumer, ConsumerContext consumerContext) throws SingleSignOnException {
		TokenInfo result;
		try {
			Mono<TokenInfo> resultMono = webClient.post()
					.body(BodyInserters.fromFormData(GRAND_TYPE, GRAND).with(GRAND, consumer.getPassword())
							.with(USER_NAME, consumer.getConsumerKey()))
					.accept(MediaType.APPLICATION_JSON).retrieve()
					.onStatus(HttpStatus::is5xxServerError,
							response -> Mono.error(new SingleSignOnException(StatusCode.SSO_SYSTEM_ERROR,
									String.format("Exception getting OAuthToken from AG MS. Consumer Key: %s", consumer.getConsumerKey()))))
					.bodyToMono(Map.class)
					.flatMap(SingleSignOnProcessor::mapResponseToTokenInfo);
					result = resultMono.block();

			sendAuthSuccessfulFraudEvent(consumer, consumerContext);

		} catch (WebClientResponseException webEx) {
			throw new SingleSignOnException(StatusCode.SSO_VALIDATION_ERROR,
					String.format("Exception getting OAuthToken from AG MS, %s", webEx.getMessage()));
		} catch (Exception e) {
			throw new SingleSignOnException(StatusCode.SSO_SYSTEM_ERROR, e.getCause().getMessage());
		}
		return result;
	}

	static Mono<TokenInfo> mapResponseToTokenInfo(Map<String, Object> response) {
		String tokenValue = (String) response.get(ACCESS_TOKEN);
		Integer expiresIn = (Integer) response.get(EXPIRES_IN);
		String refreshToken = (String) response.get(REFRESH_TOKEN);
		TokenInfo result = TokenInfo.builder().accessToken(tokenValue).expiresIn(expiresIn).refreshToken(refreshToken)
					.build();
		return Mono.just(result);
	}

	/**
	 * Map Single Sign on Response
	 * @param consumer
	 * @param consumerContext
	 * @return
	 * @throws SingleSignOnException
	 */
	public SingleSignOnDetails mapResponse(Consumer consumer, ConsumerContext consumerContext) throws SingleSignOnException {
		TokenInfo tokenInfo = getOAuthorizedClient(consumer, consumerContext);
		SingleSignOnDetails singleSignOnDetails = new SingleSignOnDetails();
		singleSignOnDetails.setEncryptedData(mapMemberCenterEncryptedData(consumer, consumerContext));
		singleSignOnDetails.setTokenInfo(tokenInfo);
        if (consumerContext.getUpsellSkuId() != null) {
            singleSignOnDetails.setUpsellSkuId(consumerContext.getUpsellSkuId());
        }
		return singleSignOnDetails;
	}

  /**
   * Decrypt encrypted consumer retrieved from session
   * Map relevant fields from Consumer and ConsumerContext domain objects
   * @param consumer
   * @param consumerContext
   * @return
   */
	private String mapMemberCenterEncryptedData(Consumer consumer, ConsumerContext consumerContext) {
		SingleSignOnData singleSignOnData = new SingleSignOnData();
		singleSignOnData.setAgentId(consumerContext.getAgentId());
		singleSignOnData.setQueryParamsMap(consumerContext.getQueryParamsMap());
		singleSignOnData.setConversationId(consumerContext.getConversationId());
		singleSignOnData.setCustomerKey(consumer.getConsumerKey());
		singleSignOnData.setEmailAddress(consumer.getEmail());
		singleSignOnData.setIndirectEnrollmentId(consumer.getIndirectEnrollmentId());
		singleSignOnData.setPartnerId(consumerContext.getPartnerId());
		singleSignOnData.setTenantId(consumerContext.getTenantId());
		singleSignOnData.setConsumerIntent(consumerContext.getIntent());
		singleSignOnData.setSkuId(consumerContext.getSkuId());
		singleSignOnData.setUpsellSkuId(consumerContext.getUpsellSkuId());
		return encryptor.encrypt(SanitizedJsonUtils.toJson(singleSignOnData));
	}

  /**
	/**
	 * Decrypt consumer object from encrypted PII string
	 * @param encryptedConsumer
	 * @return
	 * @throws SingleSignOnException
	 */
	public Consumer getDecryptedConsumer(String encryptedConsumer) throws SingleSignOnException {

		if(StringUtils.isBlank(encryptedConsumer)) {
			throw new SingleSignOnException(StatusCode.SSO_SYSTEM_ERROR, "Either HttpSession OR Consumer in HttpSession is null.");
		}
		Consumer consumer = encryptUtility.decryptConsumer(encryptedConsumer);
		if (consumer == null) {
			throw new SingleSignOnException(StatusCode.SSO_SYSTEM_ERROR, "Decryption error : encryptedConsumer, check secret Key");
		}
		return consumer;
	}

  /**
   * sendAuthSuccessfulFraudEvent
   * @param consumer
   * @param consumerContext
   */
	private void sendAuthSuccessfulFraudEvent(Consumer consumer, ConsumerContext consumerContext) {
		LogFraudEventRequest event = FraudEventUtils.createBaseFraudEventRequest(consumerContext, consumer.getConsumerKey());
		Map<String, String> dataMap = event.getEventDataMap();
		// Conversation ID is used as transaction id in eligibility service
		dataMap.put(FraudEventUtils.FIELD_REFTRANSACTION_ID, consumerContext.getConversationId());
		// CID is called as customer identifier
		event.setProfileKey(consumer.getCustomerIdentifier());
		event.setId(FraudEventUtils.EVENT_ID_AUTHENTICATION_SUCCESSFUL);
		event.setEventDataMap(dataMap);
		fraudEventLogger.logMessage(event, consumerContext, AuditConstants.EVENT_SINGLE_SIGN_ON);
	}
}
