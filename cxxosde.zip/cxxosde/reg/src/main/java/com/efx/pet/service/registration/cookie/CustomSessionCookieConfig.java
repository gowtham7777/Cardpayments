package com.efx.pet.service.registration.cookie;

import javax.servlet.SessionCookieConfig;

/**
 * Interface defined to make the Session Encoding handling option.
 * We can pass session encoding flag true/false to define behavior.
 *
 * Spring application property
 * server.servlet.session.cookie.use-base64-encoding=true/false
 * */
public interface CustomSessionCookieConfig extends SessionCookieConfig {
  boolean isUseBase64Encoding();

  void setUseBase64Encoding(boolean useBase64Encoding);

  String getSameSite();

}
