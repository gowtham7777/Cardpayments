package com.efx.pet.service.registration;

public class TouResponse {

  private String termsOfUseUrl;
  private String termsOfUseVersion;
  private String privacyPolicyUrl;
  private String privacyPolicyVersion;

  public String getTermsOfUseUrl() {
    return termsOfUseUrl;
  }

  public void setTermsOfUseUrl(String termsOfUseUrl) {
    this.termsOfUseUrl = termsOfUseUrl;
  }

  public String getTermsOfUseVersion() {
    return termsOfUseVersion;
  }

  public void setTermsOfUseVersion(String termsOfUseVersion) {
    this.termsOfUseVersion = termsOfUseVersion;
  }

  public String getPrivacyPolicyUrl() {
    return privacyPolicyUrl;
  }

  public void setPrivacyPolicyUrl(String privacyPolicyUrl) {
    this.privacyPolicyUrl = privacyPolicyUrl;
  }

  public String getPrivacyPolicyVersion() {
    return privacyPolicyVersion;
  }

  public void setPrivacyPolicyVersion(String privacyPolicyVersion) {
    this.privacyPolicyVersion = privacyPolicyVersion;
  }

}
