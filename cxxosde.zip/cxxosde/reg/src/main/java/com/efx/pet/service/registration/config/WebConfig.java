package com.efx.pet.service.registration.config;


import com.efx.pet.service.registration.filter.DomainFilter;
import com.efx.pet.service.registration.filter.HTMLResponseFilter;
import com.efx.pet.service.registration.flow.FlowInterceptorFilter;
import com.efx.pet.utility.context.filter.PetCorsFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.Filter;

/**
 * Created by dxl84 on 9/7/2017.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

  @Autowired
  private HTMLResponseFilter htmlResponseFilter;

  @Autowired
  private DomainFilter domainFilter;

  @Bean
  public Filter corsFilter() {
    return new PetCorsFilter();
  }

  @Bean
  public FilterRegistrationBean registrationBean() {

    FilterRegistrationBean registrationBean = new FilterRegistrationBean();
    registrationBean.setFilter(htmlResponseFilter);

    //TODO : set url patterns in properties
    registrationBean.addUrlPatterns("/html/personal-info.html");
    registrationBean.setName("customFilter");
    registrationBean.setOrder(1);

    return registrationBean;
  }

  @Bean
  public FilterRegistrationBean<DomainFilter> domainFilterBean() {
    FilterRegistrationBean<DomainFilter> registrationBean = new FilterRegistrationBean<>();
    registrationBean.setFilter(domainFilter);
    registrationBean.addUrlPatterns("/rest/1.0/*");
    return registrationBean;
  }

  @Autowired
  private FlowInterceptorFilter flowInterceptorFilter;

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(flowInterceptorFilter).addPathPatterns("/rest/1.0/*", "/rest/2.0/*", "/rest/3.0/*");
  }
}
