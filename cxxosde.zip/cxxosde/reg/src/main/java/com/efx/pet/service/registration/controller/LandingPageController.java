package com.efx.pet.service.registration.controller;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.dataanalytics.DataLayer;
import com.efx.pet.domain.partnertenant.PartnerTenantData;
import com.efx.pet.order.mgmt.OrderMgmtService;
import com.efx.pet.order.mgmt.domain.OrderMgmtException;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse.StatusCode;
import com.efx.pet.registration.controller.util.DigitalDataLayerUtility;
import com.efx.pet.registration.controller.util.ParamsValidatorUtil;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.registration.AnalyticsConfigResponse;
import com.efx.pet.service.registration.AppConfigResponse;
import com.efx.pet.service.registration.CallCenterDetails;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.service.registration.util.DecryptionServiceUtil;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.QueryParamEnums;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logger.LoggingUtil;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.efx.pet.utility.service.AppUtilService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "LandingPageController API", description = "LandingPageController - API Contract")
public class LandingPageController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(LandingPageController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "AppConfig");
  private static final String UI_CUSTOMER_CARE_PAGE = "#/call-center-generic";

  @Autowired
  private SessionUtil sessionUtil;

  @Autowired
  PartnerTenantClient partnerTenantClient;

  @Autowired
  private DecryptionServiceUtil decryptionServiceUtil;

  private String frontEndBundleLocation;

  @Value("${ensighten.uri}")
  private String ensightenUri;

  @Value("${iOvation.uri}")
  private String iOvationUri;

  @Value("${success.mc.login.url}")
  private String successMCLoginUrl;

  @Value("${com.efx.pet.registration.timeout.page.url}")
  private String timeoutPageUrl;

  @Value("${com.efx.pet.registration.user.idle.duration:840}")
  private int idleDuration;

  @Value("${com.efx.pet.registration.user.idle.warning.duration:60}")
  private int idleWarningDuration;

  @Value("${lock.and.alerts.terms.url}")
  private String termsUrl;

  @Value("${lock.and.alerts.terms.version}")
  private String termsVersion;

  @Value("${spinner.millisecond.delay:2000}")
  private int spinnerMillisecondDelay;

  @Value("${orderFunnel.partnerAlias}")
  private String partnerAlias;

  @Value("${orderFunnel.hostName}")
  private String hostName;

  @Value("${efxdirect.min.registration.age:16}")
  private int efxDirectMinAgeToRegister;

  @Value("${com.efx.pet.product.terms.url}")
  private String productTermsUrl;

  @Value("${com.efx.pet.product.terms.version}")
  private String productTermsVersion;

  @Value("${com.efx.callcenter.time.message}")
  private String callCenterTimeMessage;

  @Value("${com.efx.callcenter.phonenumber}")
  private String callCenterPhoneNumber;

  @Value("${com.efx.ptp.callcenter.time.message}")
  private String ptpCallCenterMessage;

  @Autowired
  private OrderMgmtService orderManagementService;

  @Autowired
  private AppUtilService appUtilService;

  @PostConstruct
  public void setFrontEndBundleLocation() throws CoreServiceClientException {
    frontEndBundleLocation = partnerTenantClient.getFrontEndBundleLocation();
  }

  /**
   * Creates and returns AppConfig for Initial Configuration needed for FrontEnd
   *
   * @param httpServletRequest
   * @return
   */
  @Operation(summary = "Returns the Initial Configuration needed for FrontEnd")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Returns status when Kba quiz generation successful", content = {
      @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AppConfigResponse.class))}),
    @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
      @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AppConfigResponse.class))})})
  @GetMapping(value = "/appConfig", produces = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<AppConfigResponse> appConfig(HttpServletRequest httpServletRequest) {

    HttpSession httpSession = httpServletRequest.getSession(false);
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    String message = "Begin Creating the initial appConfig";
    LOGGER.info(message);
    AUDITOR.recordInfo(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.BEGIN, message, consumerContext);
    AppConfigResponse appConfigResponse;
    updateConsumerContextWithPartnerLookup(httpSession, consumerContext);
    appConfigResponse = checkIfUpSellSKUOrOfferCodeAvailable(consumerContext);
    if (Objects.isNull(appConfigResponse)) {
      appConfigResponse = new AppConfigResponse();
      sessionUtil.invalidateSession(httpServletRequest);
      return new ResponseEntity<>(appConfigResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    if (consumerContext.getSkuId() == null) {
      try {
        message = "Setting skuId fom partnerTenant config";
        consumerContext.setSkuId(getSkuIdFromConfig());
        AUDITOR.recordInfo(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.IN_PROGRESS, message, consumerContext);
      } catch (CoreServiceClientException e) {
        message = "SkuId is null";
        AUDITOR.recordError(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.END_FAIL, message, consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
        sessionUtil.invalidateSession(httpServletRequest);
        return new ResponseEntity<>(appConfigResponse, HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }

    try {
      appConfigResponse.setSuccessMCLoginUrl(successMCLoginUrl);
      appConfigResponse.setTimeoutPageUrl(timeoutPageUrl);
      appConfigResponse.setIdleDuration(idleDuration);
      appConfigResponse.setIdleWarningDuration(idleWarningDuration);
      appConfigResponse.setTermsUrl(termsUrl);
      appConfigResponse.setTermsVersion(termsVersion);
      appConfigResponse.setSpinnerMillisecondDelay(spinnerMillisecondDelay);
      appConfigResponse.setCallCenterDetails(buildCallCenterDetails());
      /*
       * frontEndBundleLocation has already been pattern matched prior
       * Hence, no additional checks being done here during split()
       */
      appConfigResponse.setTenantPartner(frontEndBundleLocation.split("/")[2]);
      appConfigResponse.setPartnerGuid(consumerContext.getPartnerGuid());
      appConfigResponse.setPartnerId(consumerContext.getPartnerId());
      appConfigResponse.setTenantId(consumerContext.getTenantId());
      appConfigResponse.setDefaultLocale(consumerContext.getDefaultLocale());
      appConfigResponse.setSupportedLocales(consumerContext.getSupportedLocales());
      // double check if the campaign code is presented in case of page refresh causes the value missing.
      if (!consumerContext.getQueryParamsMap().containsKey(QueryParamEnums.CAMPAIGNCODE.value())) {
        consumerContext.getQueryParamsMap().put(QueryParamEnums.CAMPAIGNCODE.value(), CommonConstants.DEFAULT_CAMPAIGNCODE);
      }
      appConfigResponse.setQueryParamsMap(consumerContext.getQueryParamsMap());
      // make sure intent is included in query params map of AppConfigResponse if present in ConsumerContext
      if (StringUtils.isNotBlank(consumerContext.getIntent())) {
        appConfigResponse.getQueryParamsMap().put(QueryParamEnums.INTENT.value(), consumerContext.getIntent());
      }
      if (CommonConstants.EFX_DIRECT_PARTNER_ID.equalsIgnoreCase(consumerContext.getPartnerId())) {
        appConfigResponse.setMinAgeToRegister(efxDirectMinAgeToRegister);
      } else {
        appConfigResponse.setMinAgeToRegister(CommonConstants.DEFAULT_MIN_AGE_TO_REGISTER);
      }

      AUDITOR.recordInfo(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.END_SUCCESS, "Initial appConfig creation success.", consumerContext, null, null, HttpStatus.OK.toString());
      return new ResponseEntity<>(appConfigResponse, HttpStatus.OK);
    } catch (Exception ex) {
      message = "Unknown Exception while trying to get app config";
      LOGGER.error(message, ex);
      AUDITOR.recordError(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.END_FAIL, message, consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpServletRequest);
    }
    return new ResponseEntity<>(appConfigResponse, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  private CallCenterDetails buildCallCenterDetails() {
	 CallCenterDetails callCenterDetails = new CallCenterDetails();
	 callCenterDetails.setCallCenterTimeMessage(callCenterTimeMessage);
	 callCenterDetails.setCallCenterPhoneNumber(callCenterPhoneNumber);
	 callCenterDetails.setPtpCallCenterMessage(ptpCallCenterMessage);
	 return callCenterDetails;
  }

/**
   * check if the consumer context contains up sell sku or offer code and add in to app config response
   *
   * @param consumerContext
   * @return
   */
  private AppConfigResponse checkIfUpSellSKUOrOfferCodeAvailable(ConsumerContext consumerContext) {
    String message = null;
    AppConfigResponse appConfigResponse = new AppConfigResponse();
    if (Objects.nonNull(consumerContext.getUpsellSkuId()) || Objects.nonNull(consumerContext.getQueryParamsMap().get(QueryParamEnums.OFFERCODE.value()))) {
      try {
        ProductOfferResponse productOfferResponse = Objects.nonNull(consumerContext.getUpsellSkuId()) ?
          orderManagementService.getProductBySkuId(consumerContext) : orderManagementService.getProductByOfferCode(consumerContext);

        if (productOfferResponse.getStatusCode() == StatusCode.SUCCESS && Objects.nonNull(productOfferResponse.getProductOfferDetails())) {
          AUDITOR.recordInfo(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.IN_PROGRESS,
            "recieved product info from OM service", consumerContext);
          appConfigResponse.setProductOfferDetails(productOfferResponse.getProductOfferDetails());
          //adding subscription product terms details
          appConfigResponse.setProductTermsUrl(productTermsUrl);
          appConfigResponse.setProductTermsVersion(productTermsVersion);
          // check if the tou on REG2 needs to be disabled or not
          boolean isTouDisabled = appUtilService.isTouDisabled(appConfigResponse.getProductOfferDetails().getProductCode());
          appConfigResponse.setTouDisabled(isTouDisabled);
          consumerContext.setTouDisabled(isTouDisabled);
          // getting ishtml property allowed from ordermgmt service impl
          appConfigResponse.setHtmlAllowed(true);
        } else {
          appConfigResponse = null;
        }
      } catch (OrderMgmtException exception) {
        message = String.format("Exception while fetching the product details : SkuId %s; offerCode: %s",
          consumerContext.getUpsellSkuId(), consumerContext.getQueryParamsMap().get(QueryParamEnums.OFFERCODE.value()));
        LOGGER.error(message, exception);
        AUDITOR.recordError(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.IN_PROGRESS, message,
          consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
        appConfigResponse = null;
      }
    } else {
      AUDITOR.recordInfo(AuditConstants.EVENT_APP_CONFIG, AuditEventStatus.IN_PROGRESS,
        "Empty upsell sku id or offer code in the consumer context object, proceeding without product info", consumerContext);
    }
    return appConfigResponse;
  }

  /**
   * Update ConsumerContext in the existing session with PartnerLookupDetails
   *
   * @param httpSession
   * @param consumerContext
   */
  private void updateConsumerContextWithPartnerLookup(HttpSession httpSession, ConsumerContext consumerContext) {

    PartnerTenantData partnerTenantData = partnerTenantClient.getPartnerTenantData();
    consumerContext.setPartnerId(partnerTenantData.getPartnerId());
    consumerContext.setTenantId(partnerTenantData.getTenantId());
    consumerContext.setPartnerGuid(partnerTenantData.getId());
    consumerContext.setDefaultLocale(partnerTenantData.getDefaultLocale());
    consumerContext.setSupportedLocales(partnerTenantData.getSupportedLocales());
    httpSession.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
    LOGGER.debug("updateConsumerContextWithPartnerLookup, partnerId : {}, tenantId : {}", consumerContext.getPartnerId(), consumerContext.getTenantId());
  }

  /**
   * Creates and returns Digital Layer Analytics for Initial Configuration needed for FrontEnd
   *
   * @param httpServletRequest
   * @return
   */
  @Operation(summary = "Returns the Digital Layer Analytics needed for FrontEnd")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Returns status when Kba quiz generation successful", content = {
      @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AnalyticsConfigResponse.class))}),
    @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
      @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AnalyticsConfigResponse.class))})})
  @GetMapping(value = "/analyticsConfig", produces = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<AnalyticsConfigResponse> analyticsConfig(HttpServletRequest httpServletRequest) {
    final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false)
      .getAttribute(CommonConstants.CONSUMER_CONTEXT);
    String message = "Begin Creating the initial analyticsConfig";
    LOGGER.info(message);
    AUDITOR.recordInfo(AuditConstants.EVENT_ANALYTICS_CONFIG, AuditEventStatus.BEGIN, message, consumerContext);
    AnalyticsConfigResponse analyticsConfigResponse = new AnalyticsConfigResponse();

    try {
      DigitalDataLayerUtility digitalDataLayerUtility = new DigitalDataLayerUtility();
      DataLayer dataLayer = digitalDataLayerUtility.populateDigitalDataLayerConfiguration(httpServletRequest);
      analyticsConfigResponse.setDataLayer(dataLayer);
      analyticsConfigResponse.setEnsightenUrl(ensightenUri);
      analyticsConfigResponse.setiOvationUrl(iOvationUri);
      AUDITOR.recordInfo(AuditConstants.EVENT_ANALYTICS_CONFIG, AuditEventStatus.END_SUCCESS, "Initial analyticsConfig creation success.", consumerContext, null, null, HttpStatus.OK.toString());
      return new ResponseEntity<>(analyticsConfigResponse, HttpStatus.OK);
    } catch (Exception ex) {
      message = "Unknown Exception while trying to get analytics config";
      LOGGER.error(message, ex);
      AUDITOR.recordError(AuditConstants.EVENT_ANALYTICS_CONFIG, AuditEventStatus.END_FAIL, message, consumerContext, null, HttpStatus.INTERNAL_SERVER_ERROR.toString());
    }
    return new ResponseEntity<>(analyticsConfigResponse, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Redirect Partner Tenant based on front end bundle location and optional query parameters
   * externalProductReference: is used to pass in a skuid from public pages.
   *
   * @param attributes
   * @param httpServletRequest
   * @param upsellSkuId
   * @param campaignCode
   * @param intent
   * @param invitationId
   * @param offerCode
   * @return
   */
  @Operation(hidden = true, summary = "Redirects user to correct webapp bundle based on tenant partner")
  @GetMapping(value = "/redirectPartnerTenant")
  public RedirectView redirectPartnerTenant(RedirectAttributes attributes, HttpServletRequest httpServletRequest,
                                            @RequestParam(name = "externalProductReference", required = false) Long upsellSkuId,
                                            @RequestParam(name = "campaignCode", required = false) String campaignCode,
                                            @RequestParam(name = "intent", required = false) String intent,
                                            @RequestParam(name = "invitationId", required = false) String invitationId,
                                            @RequestParam(name = "offerCode", required = false) String offerCode,
                                            @RequestParam(name = "liftId", required = false) String liftId) {
    HttpSession httpSession = httpServletRequest.getSession(false);
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.BEGIN,
      "Begin redirect to correct webapp bundle based on tenant partner.", consumerContext);
    if (!StringUtils.isBlank(campaignCode) && !ParamsValidatorUtil.isValidCampaignCode(campaignCode)) {
      AUDITOR.recordError(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.END_FAIL,
        LoggingUtil.sanitizeLoggedMessage(MessageFormat
          .format("Invalid campaignCode passing in from query param, redirect to customer care page: code {0}", campaignCode)));
      sessionUtil.invalidateSession(httpServletRequest);
      attributes.addFlashAttribute("flashAttribute", "redirectWithRedirectView");
      return new RedirectView(frontEndBundleLocation + UI_CUSTOMER_CARE_PAGE);
    }
    mapAdditionalAttributes(consumerContext, upsellSkuId, intent, campaignCode, invitationId, offerCode, liftId);

    httpSession.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.END_SUCCESS,
      "Now redirecting..", consumerContext, null, null, HttpStatus.FOUND.toString());
    attributes.addFlashAttribute("flashAttribute", "redirectWithRedirectView");
    return new RedirectView(frontEndBundleLocation);
  }


  @Operation(hidden = true, summary = "Redirects user to ptp-submit-pin component path")
  @GetMapping(value = "/pin")
  public RedirectView redirectPtpSubmit(RedirectAttributes attributes, HttpServletRequest httpServletRequest) {
    final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false)
      .getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PIN, AuditEventStatus.BEGIN, "Begin redirect to ptp-submit-pin path.", consumerContext);
    attributes.addFlashAttribute("flashAttribute", "redirectWithRedirectView");
    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.END_SUCCESS, "Now redirecting..", consumerContext, null, null, HttpStatus.FOUND.toString());
    return new RedirectView(frontEndBundleLocation + "#/ptp-submit-pin");
  }


  /**
   * Custom Exception handler for invalid session Attributes for SingleSignOnController
   *
   * @param ex
   * @param httpSession
   * @return
   */
  @ExceptionHandler(CoreServiceClientException.class)
  public ResponseEntity<HttpStatus> handleCustomException(CoreServiceClientException ex,
                                                          HttpSession httpSession) {
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    final String sanitizedLogMessage = LoggingUtil.sanitizeLoggedMessage(ex.getMessage());
    LOGGER.error(sanitizedLogMessage);
    AUDITOR.recordError(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.END_FAIL, ex.getMessage(),
      consumerContext, null, HttpStatus.INTERNAL_SERVER_ERROR.toString());
    httpSession.invalidate();
    return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * @param consumerContext
   * @param upsellSkuId
   * @param intent
   * @param campaignCode
   * @param invitationId
   * @param offerCode
   * @return
   */
  private ConsumerContext mapAdditionalAttributes(ConsumerContext consumerContext, Long upsellSkuId, String intent,
    String campaignCode, String invitationId, String offerCode, String liftId) {
    if (Objects.nonNull(upsellSkuId)) {
      consumerContext.setUpsellSkuId(upsellSkuId);
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "Capture skuId passing in from query param to ConsumerContext.", consumerContext);
    }
    if (Objects.nonNull(offerCode)) {
      consumerContext.getQueryParamsMap().put(QueryParamEnums.OFFERCODE.value(), decryptionServiceUtil.decryptOfferCode(offerCode, consumerContext));
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "Capture offerCode passing in from query param to ConsumerContext.", consumerContext);
    }
    if (!StringUtils.isBlank(campaignCode)) {
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "Capture campaignCode passing in from query param to ConsumerContext.", consumerContext);
    } else {
      campaignCode = CommonConstants.DEFAULT_CAMPAIGNCODE;
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "No campaignCode passed in from query param to ConsumerContext. Set the default value.", consumerContext);
    }
    consumerContext.getQueryParamsMap().put(QueryParamEnums.CAMPAIGNCODE.value(), campaignCode);
    if (Objects.nonNull(invitationId)) {
      consumerContext.getQueryParamsMap().put(QueryParamEnums.INVITATIONID.value(), invitationId);
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "Capture invitationId passing in from query param to ConsumerContext.", consumerContext);
    }
    if (StringUtils.isNotBlank(liftId)) {
      consumerContext.getQueryParamsMap().put(QueryParamEnums.LIFTID.value(), liftId);
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        "Capture liftId passing in from query param to ConsumerContext.", consumerContext);
    }
    // Map optional intent after comparison with partnerTenantClient settings.
    if (StringUtils.isNotBlank(intent) && compareIntentWithConfig(intent)) {
      consumerContext.setIntent(intent);
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        LoggingUtil.sanitizeLoggedMessage(
          MessageFormat.format("Intent matched that in Partner Tenant configuration: {0}", intent)));
    }
    return consumerContext;
  }

  /**
   * Get SkuId from Partner Tenant configuration settings map
   *
   * @return
   * @throws CoreServiceClientException
   */
  private Long getSkuIdFromConfig() throws CoreServiceClientException {

    if (partnerTenantClient.getSettings() == null || StringUtils.isBlank(partnerTenantClient.getSettings().getSkuId())) {
      throw new CoreServiceClientException("Sku ID not configured for the partner Alias, received null or empty");
    }
    String skuId = partnerTenantClient.getSettings().getSkuId();
    return Long.valueOf(skuId);
  }

  /**
   * Check if Intent is allowed and matches one in Partner Tenant configuration
   * settings map
   *
   * @param intent
   * @return
   */
  private boolean compareIntentWithConfig(String intent) {

    if (partnerTenantClient.getSettings() == null
      || CollectionUtils.isEmpty(partnerTenantClient.getSettings().getIntentList())) {
      AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
        LoggingUtil.sanitizeLoggedMessage(MessageFormat
          .format("Intent NOT allowed for this Partner Tenant configuration: {0}", intent)));
      return false;
    }
    List<String> intentList = partnerTenantClient.getSettings().getIntentList();
    for (String intentStr : intentList) {
      if (StringUtils.isNotBlank(intentStr) && intent.equals(intentStr)) {
        return true;
      }
    }
    AUDITOR.recordError(AuditConstants.EVENT_REDIRECT_PARTNER_TENANT, AuditEventStatus.IN_PROGRESS,
      LoggingUtil.sanitizeLoggedMessage(MessageFormat
        .format("Supplied Intent does not match any in Partner Tenant configuration: {0}", intent)));
    return false;
  }

}
