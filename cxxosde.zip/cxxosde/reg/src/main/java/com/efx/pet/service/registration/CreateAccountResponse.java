package com.efx.pet.service.registration;

public class CreateAccountResponse {

  public enum StatusCode {

    /**
     * duplicate enrollment
     */
    DUPLICATE_ENROLLMENT,
    /**
     * Validation error
     */
    VALIDATION_ERROR,
    /**
     * All system error scenarios
     */
    CREATE_ACCOUNT_SYSTEM_ERROR,
    /**
     * Id Proofing error - fraud check failure
     */
    CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR,
    /**
     * Id Proofing error - no hit
     */
    ELIGIBILITY_CHECK_NO_HIT,
    /**
     * Emergency break turned on in server
     */
    EMERGENCY_BREAK_ON,
    /**
     * Emergency break - p2pEligible - customer opted in to receive pin via p2p
     */
    EMERGENCY_BREAK_P2P_OPTED_IN,
    /**
     * Emergency break - p2pOpted out
     */
    EMERGENCY_BREAK_P2P_OPTED_OUT,
    /**
     * Pin to text and Email
     */
    GET_PIN_TO_TEXT_EMAIL,
    /**
     * Pin to text
     */
    GET_PIN_TO_TEXT,
    /**
     * Pin 2 email
     */
    GET_PIN_TO_EMAIL,
    KBA_FAILURE_ELIGIBILITY_FAIL,
    PIN_TO_POST_PRIMARY,
    PIN_TO_POST_SECONDARY,
    KBA_QUIZ_ERROR,
    PTP_ELIGIBILITY_FAIL
  }

  private StatusCode statusCode;
  
  public CreateAccountResponse(StatusCode statusCode) {
	this.statusCode = statusCode;
  }
  
  public CreateAccountResponse() {}

  public StatusCode getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(StatusCode statusCode) {
    this.statusCode = statusCode;
  }

}
