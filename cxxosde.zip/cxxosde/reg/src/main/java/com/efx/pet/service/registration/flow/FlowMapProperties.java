package com.efx.pet.service.registration.flow;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
@ConfigurationProperties("flow")
public class FlowMapProperties {

	// All URI configuration gets loaded in this Map
	private final Map<String, String> uri = new HashMap<>();

	public Map<String, String> getUri() {
		return uri;
	}

}
