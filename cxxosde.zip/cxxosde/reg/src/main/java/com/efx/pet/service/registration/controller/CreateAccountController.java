package com.efx.pet.service.registration.controller;

import java.text.MessageFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.CustomerPolicyDecision;
import com.efx.pet.domain.OtpMethod;
import com.efx.pet.domain.message.EmergencyBreakQueueMessage;
import com.efx.pet.domain.tid.common.IDPData;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.direct.registration.RegistrationResponse;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.eid.exception.ServiceException;
import com.efx.pet.service.idproofing.FraudEligibilityResponse;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.registration.CreateAccountResponse;
import com.efx.pet.service.registration.CreateAccountResponse.StatusCode;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.service.registration.controller.processor.CreateAccountProcessor;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.cache.redis.util.PiiToHashUtility;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.efx.pet.utility.utils.SanitizedJsonUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "CreateAccountController", description = "Create Account")
public class CreateAccountController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(CreateAccountController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "createAccount");
  
  public static final String HEADER_FORWARD = "HTTP_X_FORWARDED_FOR";
  public static final String HEADER_FORWARD_STANDARD = "X-Forwarded-For";
  private static final String CREATE_ACCOUNT = AuditConstants.EVENT_CREATE_ACCOUNT;
  private static final ResponseEntity<CreateAccountResponse> DEFAULT_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
			new CreateAccountResponse(StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
  private static final EnumMap<RegistrationResponse.StatusCode, ResponseEntity<CreateAccountResponse>> REGISTRATION_RESPONSE_ENTITY_MAP = new EnumMap<>(
			RegistrationResponse.StatusCode.class);
  private static final EnumMap<IdProofingResponse.StatusCode, ResponseEntity<CreateAccountResponse>> ID_PROOFING_RESPONSE_ENTITY_MAP = new EnumMap<>(
			IdProofingResponse.StatusCode.class);

  @Value("${com.efx.pet.feature.emergencyBreak.enabled}")
  private String isEmergencyBreakEnabled;

  @Value("${aws.sqs.emergency.break.queue.name}")
  private String emergencyBreakQueueName;

  @Autowired
  ObtainIpUtility obtainIpUtility;

  @Autowired
  EncryptUtility encryptUtility;

  @Autowired
  CreateAccountProcessor createAccountProcessor;

  @Autowired
  private SessionUtil sessionUtil;

  @Autowired
  private PiiToHashUtility piiToHashUtility;

  @Autowired
  private RegistrationService registrationService;

  @Autowired
  private IdProofingService idProofingService;
  
  private static final String USER_PATTERN = "^\\S+@\\S+\\.\\S+$";
  private static final String PASS_REGEX = "^(?!.*(.)\\1{2,})(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@$*+\\-])(?!.*\\s)(?!.*([0-9]){9,})[a-zA-Z0-9!@$*+\\-]{8,20}$";
  private static final String PROXY_PREFIX = "Agpr0xy@";
  private static final String TERMS_POLICY_DECISION = "termsPolicyDecision";

	@PostConstruct
	public void init() {
		// HttpStatus.CONTINUE denotes that orchestration continues, not one returned to
		// client/browser
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SUCCESS,
				new ResponseEntity<>(null, HttpStatus.CONTINUE));
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.EMAIL_IN_USE,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.DUPLICATE_ENROLLMENT), HttpStatus.OK));
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.CUSTOMER_CREDENTIALS_EXIST,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.DUPLICATE_ENROLLMENT), HttpStatus.OK));
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.CREATE_CREDENTIALS_SYSTEM_ERROR,
				DEFAULT_ERROR_RESPONSE_ENTITY);
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SAVE_TOU_SYSTEM_ERROR,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR), HttpStatus.OK));
		REGISTRATION_RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SAVE_POLICY_DECISION_ERROR,
				DEFAULT_ERROR_RESPONSE_ENTITY);

		/**
		 * Used HttpStatus.ACCEPTED (202) as against HttpStatus.OK (200) for some set of
		 * entries in map. Intent for those entries is to audit as error and invalidate
		 * session. This is non-impacting to front end App.
		 */
		// Map has all entries except for Kba Quiz Success since it involves ResponseEntity of kind 'KbaResponse'
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.ELIGIBILITY_CHECK_NO_HIT,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.ELIGIBILITY_CHECK_NO_HIT),
						HttpStatus.ACCEPTED));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.GET_PIN_TO_TEXT_EMAIL,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.GET_PIN_TO_TEXT_EMAIL), HttpStatus.OK));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.GET_PIN_TO_TEXT,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.GET_PIN_TO_TEXT), HttpStatus.OK));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.GET_PIN_TO_EMAIL,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.GET_PIN_TO_EMAIL), HttpStatus.OK));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL),
						HttpStatus.ACCEPTED));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.PIN_TO_POST_PRIMARY), HttpStatus.OK));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_SECONDARY,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.PIN_TO_POST_SECONDARY), HttpStatus.OK));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.KBA_QUIZ_ERROR), HttpStatus.ACCEPTED));
		ID_PROOFING_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PTP_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new CreateAccountResponse(StatusCode.PTP_ELIGIBILITY_FAIL), HttpStatus.ACCEPTED));
	}

  /**
   * This method is used to create the Account and save it in consumer
   * information using username/password It sends the PII information to EID.
   * Based on the eligibility, the user will be shown either an Otp enroll
   * page, Kba page or an error page
   *
   * @param content
   * @return
   * @throws Exception
   */
	@Operation(summary = "Returns the StatusCode")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns a success confirmation", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Required fields missing", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "System Error", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }) })
  @PostMapping(value = "/createAccount", produces = RegistrationConstants.APPLICATION_JSON, consumes = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<?> createAccount(HttpServletRequest httpRequest, @RequestBody String content) throws Exception {
    ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    long startTime = System.currentTimeMillis();
    AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.BEGIN, "Start - CreateAccountController.createAccount() - Begin account creation.", consumerContext);

    // Retrieve from HttpSession and Decrypt consumer
    String decryptedConsumer = encryptUtility.decrypt(httpRequest, CommonConstants.CONSUMER_DATA);
    Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
    if (consumer == null) {
      String message = "Either HttpSession OR Consumer in HttpSession is null.";
      LOGGER.error(message);
      AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_FAIL, message,
        consumerContext, StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpRequest);
      return DEFAULT_ERROR_RESPONSE_ENTITY;
    }

    JSONObject jsonObject = new JSONObject(content);
    String username;
    String password;
    JSONObject policyDecision;
    try {
      //Check username and password
      username = jsonObject.has("username") ? jsonObject.getString("username") : null;
      password = jsonObject.has("password") ? jsonObject.getString("password") : null;
      policyDecision = !jsonObject.isNull(TERMS_POLICY_DECISION) && jsonObject.has(TERMS_POLICY_DECISION) ? jsonObject.getJSONObject(TERMS_POLICY_DECISION) : null;
      if (StringUtils.isBlank(username) || StringUtils.isBlank(password)
        || StringUtils.equalsIgnoreCase(username, password) || !validate(password, username)) {
        String message = MessageFormat.format("Username and/or password failed field formatting checks. Encrypted username = {0}", encryptUtility.encryptString(username));
        LOGGER.error(message);
        AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_FAIL,
          message, consumerContext, consumer.getConsumerKey(), StatusCode.VALIDATION_ERROR.toString(),
          HttpStatus.BAD_REQUEST.toString());
        sessionUtil.invalidateSession(httpRequest);
        return new ResponseEntity<CreateAccountResponse>(new CreateAccountResponse(StatusCode.VALIDATION_ERROR),
          HttpStatus.BAD_REQUEST);
      }

      //Update consumerContext
      consumerContext = updateConsumerContextWithDeviceDetails(httpRequest, content);
      //Set consumer email, username, and password
      consumer.setEmail(username);
      consumer.setUsername(username);
      if (consumerContext != null && StringUtils.isNotBlank(consumerContext.getAgentId())) {
        // Overwrite with prefix to comply validation rules, appended with random alphanumeric string
        password = generatePassword(consumerContext);
      }
      consumer.setPassword(password);
      setPolicyDecisionDetails(consumer, policyDecision);
      AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
        MessageFormat.format("Consumer email, username, and password set. Encrypted username = {0}",
          piiToHashUtility.getHashWithoutSalt(username)), consumer.getConsumerKey(), consumerContext);

      if (Boolean.valueOf(isEmergencyBreakEnabled)) {
        encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
        AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
          "Emergency break is enabled.", consumerContext, consumer.getConsumerKey(), StatusCode.EMERGENCY_BREAK_ON.toString(),
          HttpStatus.OK.toString());
        return new ResponseEntity<CreateAccountResponse>(new CreateAccountResponse(StatusCode.EMERGENCY_BREAK_ON), HttpStatus.OK);
      } else {
		RegistrationResponse registrationResponse = registerAccount(consumer, consumerContext, httpRequest);
		if ((registrationResponse == null)
				|| (HttpStatus.INTERNAL_SERVER_ERROR == REGISTRATION_RESPONSE_ENTITY_MAP
						.get(registrationResponse.getStatusCode()).getStatusCode())) {
			String message = "Consumer and/or credentials registration returned null / unknown status code / unhandled exception.";
			LOGGER.checkBeforeError(message);
			AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_FAIL, message, consumerContext,
					consumer.getConsumerKey(),

					DEFAULT_ERROR_RESPONSE_ENTITY.getBody().getStatusCode().toString(),
					HttpStatus.INTERNAL_SERVER_ERROR.toString());
			sessionUtil.invalidateSession(httpRequest);
			return DEFAULT_ERROR_RESPONSE_ENTITY;
		}	
		if (HttpStatus.OK == REGISTRATION_RESPONSE_ENTITY_MAP.get(registrationResponse.getStatusCode())
				.getStatusCode()) {
			AUDITOR.recordInfo(
					CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS, "Consumer has duplicate enrollment.",
					consumerContext, consumer.getConsumerKey(), REGISTRATION_RESPONSE_ENTITY_MAP
							.get(registrationResponse.getStatusCode()).getStatusCode().toString(),
					HttpStatus.OK.toString());
			return REGISTRATION_RESPONSE_ENTITY_MAP.get(registrationResponse.getStatusCode());
		}

		IDPData idpData = processFraudEligibilityChecks(consumer, consumerContext, httpRequest);
		if (idpData == null) {
			sessionUtil.invalidateSession(httpRequest);
			return new ResponseEntity<>(new CreateAccountResponse(StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR),
		            HttpStatus.OK);
		}
        return initiateIdpOrchestration(idpData, consumer, consumerContext, httpRequest, startTime);
      }
    } catch (final Exception ex) {
      String message = "Unknown Exception while trying to go through createAccount/initiateIdProofing.";
      LOGGER.checkBeforeError(message, ex);
      AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpRequest);
      return DEFAULT_ERROR_RESPONSE_ENTITY;
    }
  }
	
	private void setPolicyDecisionDetails(Consumer consumer, JSONObject policyDecision ) { 
		if(policyDecision != null && !StringUtils.isEmpty(policyDecision.toString())) { 
			CustomerPolicyDecision decision = SanitizedJsonUtils.fromJson(policyDecision.toString(), CustomerPolicyDecision.class);
			consumer.setPolicyDecision(decision.getDecision());
			consumer.setPolicyVersionId(decision.getPolicyVersionId());
			consumer.setPolicyType(decision.getPolicyType());
    	}
	}

	private RegistrationResponse registerAccount(Consumer consumer, ConsumerContext consumerContext,
			HttpServletRequest httpRequest) {
		RegistrationResponse registrationResponse = null;
		try {
			AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Calling registrationService.createCredentials()...", consumer.getConsumerKey(), consumerContext);
			registrationResponse = registrationService.createCredentials(consumer, consumerContext);
			/**
			 * PET orchestration returns RegistrationResponse.StatusCode.SUCCESS but no
			 * customerKey. Hence no additional check below for
			 * registrationResponse.getStatusCode() ==
			 * RegistrationResponse.StatusCode.SUCCESS
			 */
			if (registrationResponse != null && StringUtils.isNotBlank(registrationResponse.getCustomerKey())) {
				consumer.setConsumerKey(registrationResponse.getCustomerKey());
				AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS, "Customer Key returned.",
						consumer.getConsumerKey(), consumerContext);
			}
			encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
			AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Consumer credentials, along with any new customerKey, successfully saved to session.",
					consumer.getConsumerKey(), consumerContext);
		} catch (Exception e) {
			String message = "Unhandled exception during save consumer and/or credentials to session/system. Internal server error.";
			LOGGER.checkBeforeError(message, e);
			AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS, message, consumerContext,
					consumer.getConsumerKey(), StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR.toString(), null);
			registrationResponse = null;
		}
		return registrationResponse;
	}

	private IDPData processFraudEligibilityChecks(Consumer consumer, ConsumerContext consumerContext,
			HttpServletRequest httpRequest) throws IdProofingServiceException {
		LOGGER.checkBeforeDebug("Start- processFraudEligibilityChecks");
		try {
			AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Calling idProofingService.checkFraudEligibility()...", consumer.getConsumerKey(), consumerContext);
			FraudEligibilityResponse fraudEligibilityResponse = idProofingService.checkFraudEligibility(consumer,
					consumerContext);
			IDPData idpData = null;
			if (fraudEligibilityResponse != null
					&& FraudEligibilityResponse.StatusCode.SUCCESS == fraudEligibilityResponse.getStatusCode()
					&& fraudEligibilityResponse.getIdpData() != null) {
				idpData = fraudEligibilityResponse.getIdpData();
				consumer.setKbaStatus(idpData.getKbaVerifcationResponse() != null ? idpData.getKbaVerifcationResponse().getAuthStatus() : null);
				if (idpData.getPinToPostResponse() != null) {
					consumer.setEidStatus(idpData.getPinToPostResponse().getStatus());
					if (idpData.getStandardCurrentAddress() != null) {
						consumer.setStandardizedAddress(idpData.getStandardCurrentAddress());
						// Clear out sensitive ADDRESS from idpData before pushing it (without
						// encryption) to session
						idpData.setStandardCurrentAddress(null);
					}
				}
				// Below line saves idpData object in session
				httpRequest.getSession(false).setAttribute(CommonConstants.IDP_DATA, idpData);
				// Below line saves consumer object in session
				encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
				return idpData;
			} else {
				String message = "Null or unsuccessful response from idProofingService.checkFraudEligibility().";
				LOGGER.checkBeforeError(message);
				AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS, message, consumerContext,
						consumer.getConsumerKey(), StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR.toString(),
						HttpStatus.OK.toString());
				return null;
			}
		} catch (IdProofingServiceException idpEx) {
			String message = "Exception thrown during idProofingService.checkFraudEligibility() OR saving outcome to session. Internal server error.";
			LOGGER.checkBeforeError(message, idpEx);
			AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS, message, consumerContext,
					consumer.getConsumerKey(), StatusCode.CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR.toString(),
					HttpStatus.OK.toString());
			return null;
		} finally {
			LOGGER.checkBeforeDebug("End- processFraudEligibilityChecks");
		}
	}

	private ResponseEntity<?> initiateIdpOrchestration(IDPData idpData, Consumer consumer,
		ConsumerContext consumerContext, HttpServletRequest httpRequest, long startTime) throws IdProofingServiceException {
		LOGGER.checkBeforeDebug("Start- initiateIdpOrchestration");
		try {
			AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Calling idProofingService.initiateIdProofing()...", consumer.getConsumerKey(), consumerContext);
			IdProofingResponse idProofingResponse = idProofingService.initiateIdProofing(consumer, consumerContext,
					idpData);
			if (idProofingResponse != null) {
				if (idProofingResponse.getKbaPackage() != null) {
					return kbaSuccessResponse(idProofingResponse, consumer, consumerContext, httpRequest,startTime);
				}
				ResponseEntity<CreateAccountResponse> responseEntity = ID_PROOFING_RESPONSE_ENTITY_MAP
						.get(idProofingResponse.getStatusCode());
				if (responseEntity != null) {
					//update consumer object before putting in to session
					consumer.setFraudActor(idProofingResponse.isFraudActor());
					setConsumerOtpEligibility(responseEntity, consumer);
					//updating the rae transaction id in to consumer object for future uses
					if (StringUtils.isNotBlank(idpData.getRaeResponseTransactionId())) {
						consumer.setRaeResponseTransactionId(idpData.getRaeResponseTransactionId());
					}
					encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
					if (HttpStatus.OK == responseEntity.getStatusCode()) {
						AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.END_SUCCESS,
								"Id proofing initiated successfully.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString(), Long.toString(startTime));
					} else {
						AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.END_FAIL, "Id proofing initiation failed.",
								consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
						sessionUtil.invalidateSession(httpRequest);
					}
					return responseEntity;
				}
			}
			String message = "Null or unhandled response from idProofingService.initiateIdProofing().";
			LOGGER.checkBeforeError(message);
			throw new IdProofingServiceException(message);
		} finally {
			LOGGER.checkBeforeDebug("End- initiateIdpOrchestration");
		}
	}

	private void setConsumerOtpEligibility(ResponseEntity<CreateAccountResponse> responseEntity, Consumer consumer) {
		if (StatusCode.GET_PIN_TO_TEXT == responseEntity.getBody().getStatusCode()) {
			consumer.setOtpMethod(OtpMethod.TEXT);
		}
		if (StatusCode.GET_PIN_TO_EMAIL == responseEntity.getBody().getStatusCode()) {
			consumer.setOtpMethod(OtpMethod.EMAIL);
		}
		if (StatusCode.GET_PIN_TO_TEXT_EMAIL == responseEntity.getBody().getStatusCode()) {
			consumer.setOtpMethod(OtpMethod.TEXT_EMAIL);
			consumer.setOtpTextEmailEligible(true);
		}
	}

	private ResponseEntity<KbaResponse> kbaSuccessResponse(IdProofingResponse idProofingResponse, Consumer consumer,
			ConsumerContext consumerContext, HttpServletRequest httpRequest, long startTime) {
		consumer.setFraudActor(idProofingResponse.isFraudActor());
		Date sessionAccessedTime = new Date(httpRequest.getSession(false).getLastAccessedTime());
		LOGGER.checkBeforeDebugFormat("Session accessed time during quiz generation : {0}", sessionAccessedTime);
		consumer.setQuizLastAccessedTime(sessionAccessedTime);
		consumer.setKbaQuizTransactionKey(idProofingResponse.getKbaPackage().getTransactionKey());
		encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
		KbaResponse kbaResponse = new KbaResponse(KbaResponse.StatusCode.KBA_QUIZ_SUCCESS);
		kbaResponse.setQuizIdentifier(idProofingResponse.getKbaPackage().getQuizIdentifier());
		kbaResponse.setQuestions(idProofingResponse.getKbaPackage().getKbaQuiz());
		AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.END_SUCCESS, "Kba quiz generation successful.",
				consumerContext, consumer.getConsumerKey(), kbaResponse.getStatusCode().toString(),
				HttpStatus.OK.toString(), Long.toString(startTime));
		return new ResponseEntity<>(kbaResponse, HttpStatus.OK);
	}

  /**
   * This method is used to send emergency break message with user chosen
   * option for pin to post
   *
   * @param content
   * @return
   * @throws Exception
   */
	@Operation(summary = "Returns the Emergency Break Submission Success")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns a success confirmation", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Required fields missing", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "System Error", content = {
					@Content(schema = @Schema(implementation = CreateAccountResponse.class)) }) })
  @RequestMapping(value = "/initiateEmergencyBreak", method = RequestMethod.POST, produces = RegistrationConstants.APPLICATION_JSON, consumes = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<?> initiateEmergencyBreak(HttpServletRequest httpRequest, @RequestBody String content) throws Exception {
	 long startTime = System.currentTimeMillis();
	final String EVENT_CREATE_ACCOUNT_INITIATE_EBREAK = AuditConstants.EVENT_CREATE_ACCOUNT_INITIATE_EBREAK;
    final ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(EVENT_CREATE_ACCOUNT_INITIATE_EBREAK, AuditEventStatus.BEGIN, "Start - CreateAccountController.initiateEmergencyBreak() - Begin emergency break submission", consumerContext);

    // Retrieve from HttpSession and Decrypt consumer
    String decryptedConsumer = encryptUtility.decrypt(httpRequest, CommonConstants.CONSUMER_DATA);
    Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
    if (consumer == null) {
      String message = "Either HttpSession OR Consumer in HttpSession is null";
      AUDITOR.recordError(EVENT_CREATE_ACCOUNT_INITIATE_EBREAK, AuditEventStatus.END_FAIL, message, consumerContext, StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpRequest);
      return DEFAULT_ERROR_RESPONSE_ENTITY;
    }

    JSONObject jsonObject = new JSONObject(content);
    boolean isOptedForPinToPost = jsonObject.has("optedForPinToPost") ? jsonObject.getBoolean("optedForPinToPost") : false;
    try {
      EmergencyBreakQueueMessage queueMessage = new EmergencyBreakQueueMessage();
      queueMessage.setOptedForPinToPost(isOptedForPinToPost);
      queueMessage.setConsumer(consumer);
      queueMessage.setConsumerContext(consumerContext);
      AUDITOR.recordInfo(EVENT_CREATE_ACCOUNT_INITIATE_EBREAK, AuditEventStatus.IN_PROGRESS, MessageFormat.format("Sending to emergency break queue... Consumer has opted for Pin to Post = {0}", isOptedForPinToPost), consumer.getConsumerKey(), consumerContext);
      ResponseEntity<CreateAccountResponse> responseEntity = createAccountProcessor.sendMessageToEmergencyBreakQueue(queueMessage);
      AUDITOR.recordInfo(EVENT_CREATE_ACCOUNT_INITIATE_EBREAK, AuditEventStatus.END_SUCCESS, "Message sent to emergency break queue.", consumerContext, consumer.getConsumerKey(), responseEntity.getBody().getStatusCode().toString(), responseEntity.getStatusCode().toString(),Long.toString(startTime));
      return responseEntity;
    } catch (final Exception ex) {
      String message = "Unknown Exception while sending message to emergency break queue.";
      LOGGER.error(message, ex);
      AUDITOR.recordError(EVENT_CREATE_ACCOUNT_INITIATE_EBREAK, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), StatusCode.CREATE_ACCOUNT_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
      return DEFAULT_ERROR_RESPONSE_ENTITY;
    }
  }

  private ConsumerContext updateConsumerContextWithDeviceDetails(HttpServletRequest httpRequest, String content) {

    ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession()
      .getAttribute(CommonConstants.CONSUMER_CONTEXT);

    consumerContext.setIpAddress(obtainIpUtility.obtainIpAddress(httpRequest));
    // update IP address version (e.g: IPv4 or IPv6)
    try {
    	String ipAddressVersion = obtainIpUtility.obtainIpAddressVersion(consumerContext.getIpAddress());
    	consumerContext.setIpAddressVersion(ipAddressVersion);
	} catch (ServiceException e) {
		String message = "Not able to find the ip address version from the identified ip address";
		LOGGER.error(message, e);
		AUDITOR.recordError(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS, message);
	}

    String deviceFingerPrint = createAccountProcessor.getDeviceFingerPrint(content, consumerContext);
    if (StringUtils.isNotBlank(deviceFingerPrint)) {
      consumerContext.setDeviceFingerPrint(deviceFingerPrint);
    }
    // set it to session to be reused in ebrake
    httpRequest.getSession().setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    return consumerContext;

  }

  public boolean validate(final String password, final String username) {
      if(username == null || password == null){
        return false;
      }

      Pattern pattern = Pattern.compile(USER_PATTERN);
      Matcher matcher = pattern.matcher(username);
      //Validate username
      if (!matcher.matches()) {
        return false;
      }
      //Validate password
      else {
        pattern = Pattern.compile(PASS_REGEX);
        matcher = pattern.matcher(password);
        if (matcher.matches()) {
          return !passwordContainsUsername(username, password);
        }
        else return false;
      }
    }

    private boolean passwordContainsUsername(String username, String password) {
      String lowercaseUsername = username.toLowerCase();
      String lowercasePassword = password.toLowerCase();
      String[] splitUsername = lowercaseUsername.split("@");
      if (splitUsername.length > 0) {
        lowercaseUsername = splitUsername[0];
        if (lowercasePassword.contains(lowercaseUsername)) {
          return true;
        }
      }
      return false;
    }

    private String generatePassword(ConsumerContext consumerContext){
        AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS, "Agent Flow - Generating password", consumerContext);

        for (int i=1; i<6; i++) {
            String pwd = PROXY_PREFIX + UUID.randomUUID().toString().substring(0, 4);
            Pattern pattern = Pattern.compile(PASS_REGEX);
            Matcher matcher = pattern.matcher(pwd);
            if (matcher.matches()) {
                AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
                        MessageFormat.format("Agent Flow - Generated password passed regex validation. Attempt: {0}", i), consumerContext);
                return pwd;
            } else {
                AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
                        MessageFormat.format("Agent Flow - Generated password failed regex validation. Attempt: {0}", i), consumerContext);
            }
        }
        AUDITOR.recordInfo(CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS, "Agent Flow - Exhausted attempts with falling back to default.", consumerContext);
        return PROXY_PREFIX+"1a2b";
    }

}
