package com.efx.pet.service.registration.config;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

/**
 * Created by lxg90 on 6/26/2018.
 */
@Configuration
@EnableFeignClients(basePackages = "com.efx.pet")
public class FeignClientConfiguration {
}
