package com.efx.pet.service.registration.controller.processor;

import java.text.MessageFormat;

import javax.jms.JMSException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.EidStatus;
import com.efx.pet.domain.idp.EidCompareResponse;
import com.efx.pet.domain.message.EmailQueueMessage;
import com.efx.pet.domain.message.EmergencyBreakQueueMessage;
import com.efx.pet.domain.tid.common.IDPData;
import com.efx.pet.service.idproofing.FraudEligibilityResponse;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.idproofing.util.AuthStatusUtil;
import com.efx.pet.registration.controller.util.JobStatusUtils;
import com.efx.pet.service.direct.registration.RegistrationResponse;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.direct.registration.RegistrationServiceException;
import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.domain.EmergencyBreakException;
import com.efx.pet.utility.AsyncJobStatus;
import com.efx.pet.utility.RegistrationPublisher;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.encryption.Encryptor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

/**
 * This class is instantiated from EmergencyBreakConfig to ensure Async settings
 * are set.
 *
 * @author vxc64
 *
 */
@Component
public class EmergencyBreakProcessor {

	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(EmergencyBreakProcessor.class);
	private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "emergencyBreak");
	@Autowired
	private JobStatusUtils jobStatusUtils;

	@Value("${aws.sqs.emergency.break.queue.name}")
	private String emergencyBreakQueueName;

	@Value("${aws.sqs.emergency.break.email.success.queue.name}")
	private String successEmailQueueName;

	@Value("${aws.sqs.emergency.break.email.failed.queue.name}")
	private String failureEmailQueueName;

	@Value("${aws.sqs.emergency.break.ptp.optout.email.queue.name}")
	private String ptpOptOutEmailQueueName;

	@Autowired
	@Qualifier("jmsEncryptor")
	Encryptor encryptor;

	@Autowired
	private RegistrationPublisher registrationPublisher;
	
	@Autowired
	private RegistrationService registrationService;
	
	@Autowired
	private IdProofingService idProofingService;
	
	@Autowired
	private PartnerTenantClient partnerTenantClient;

	/**
	 * Asynchronous method to process N numberOfMessage per invocation
	 * Update job status to Redis periodically
	 * @param numberOfMessagesToProcess
	 * @param jobStatus
	 * @throws Exception
	 */
	@Async
	public void process(int numberOfMessagesToProcess, AsyncJobStatus jobStatus) throws EmergencyBreakException {
		jobStatusUtils.markAsInProgress(jobStatus);
		try {
			for (int i = 1; i <= numberOfMessagesToProcess; i++) {
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				if (i % 100 == 0) {
					// update status in cache for every 100 recrods
					// cache write for every record is more I/O time
					jobStatusUtils.update(jobStatus);
				}
				//if one message ends in exception, skip message and continue
				try {
					EmergencyBreakQueueMessage emergencyBreakQueueMessage = registrationPublisher.readMessageFromEmergencyBreakQueue(emergencyBreakQueueName);
					if (emergencyBreakQueueMessage != null) {
						LOGGER.checkBeforeInfoFormat("BEGIN processing message {0} of {1}" + i, numberOfMessagesToProcess);
						processEmergencyBreakMessage(emergencyBreakQueueMessage);
						jobStatus.incrementRecordCount();
					}
				} catch (JMSException e) {
					String message = "Cannot send message to queue";
					LOGGER.checkBeforeErrorFormat("Cannot send message to queue : {0}", emergencyBreakQueueName);
					jobStatus.incrementErrorCount();
					jobStatus.setErrorMessage(e.getMessage());
					LOGGER.checkBeforeError(e.getMessage());
					throw new EmergencyBreakException(message);
				}
				stopWatch.stop();
				LOGGER.checkBeforeInfoFormat("END processing message {0} of {1} , duration: {2} ms", i, numberOfMessagesToProcess, stopWatch.getTotalTimeMillis());
			}
		} finally {
			jobStatusUtils.markAsCompleted(jobStatus);
		}
	}

	private void processEmergencyBreakMessage(EmergencyBreakQueueMessage emergencyBreakQueueMessage)
			throws JMSException {

		try {
			Consumer consumer = emergencyBreakQueueMessage.getConsumer();
			ConsumerContext consumerContext = emergencyBreakQueueMessage.getConsumerContext();
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.BEGIN,
					"Start processing message.", consumer.getConsumerKey(), consumerContext);

			saveConsumer(consumer, consumerContext);
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Begin consumer validation", consumer.getConsumerKey(), consumerContext);

			// execute Fraud, Eligibility checks and send check results to TID
			IDPData idpData = validateFraudEligibilityCheck(consumer, consumerContext);


			if (idpData.getPinToPostResponse() != null) {
				consumer.setEidStatus(idpData.getPinToPostResponse().getStatus());
				consumer.setStandardizedAddress(idpData.getStandardCurrentAddress());
			}

			validateNoHit(idpData, consumerContext, consumer.getConsumerKey());
			//consumer should have eidStatus PIN_TO_POST_ELIGIBLE and standardizedAddress should not be null
			verifyPtpEligibility(consumer, consumerContext);

			if (emergencyBreakQueueMessage.isOptedForPinToPost()) {
				AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
						"Calling idProofingService.enrollInPtp()...", consumer.getConsumerKey(), consumerContext);
				IdProofingResponse idProofingResponse = idProofingService.enrollInPtp(consumer, consumerContext,
						getPrintTemplateId(), true); // isEmergencyBrakeEnabled true
				if (idProofingResponse != null
						&& IdProofingResponse.StatusCode.PTP_ENROLL_SUCCESS == idProofingResponse.getStatusCode()) {
					LOGGER.checkBeforeDebug("Pin to Post enrollment successful.");
					AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_SUCCESS,
							"Pin to Post enrollment successful.", consumer.getConsumerKey(), consumerContext);
				} else {
					String message = "Pin to Post enrollment unsuccessful.";
					LOGGER.checkBeforeError(message);
					AUDITOR.recordError(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_FAIL,
							message, consumerContext, consumer.getConsumerKey(), null,
							null);
					throw new JMSException(message);
				}
			} else {
				String message = "Consumer did not opt for Ptp, sending message to pin to post opt out email queue";
				LOGGER.checkBeforeDebug(message);
				registrationPublisher.writeToEmailQ(mapEmailQueueMessage(emergencyBreakQueueMessage), ptpOptOutEmailQueueName);
			}
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_SUCCESS,
					"Message processed and written to relevant queue successfully.", consumer.getConsumerKey(),
					consumerContext);

		} catch (EmergencyBreakException ex) {
			LOGGER.checkBeforeWarnFormat("Message failed processing due to TID / EID exception, emailNotificationSent {0}",
					emergencyBreakQueueMessage.getConsumer().getConsumerKey());
			registrationPublisher.writeToEmailQ(mapEmailQueueMessage(emergencyBreakQueueMessage), failureEmailQueueName);
		} catch (IdProofingServiceException ex) {
			LOGGER.checkBeforeError("Unknown Exception encountered during Pin to Post enrollment.", ex);
			throw new JMSException("Unknown Exception encountered during Pin to Post enrollment.");
		}
	}

	/**
	 * Step - Run Fraud and Eligibility checks
	 * @param consumer
	 * @param consumerContext
	 * @return
	 * @throws EmergencyBreakException
	 */
	private IDPData validateFraudEligibilityCheck(Consumer consumer, ConsumerContext consumerContext)
			throws EmergencyBreakException {
		IDPData idpData = null;
		try {

			LOGGER.checkBeforeDebug("Begin execute Fraud Check");
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Begin executeFraudCheck and executeIdProofingCheck", consumer.getConsumerKey(), consumerContext);

			FraudEligibilityResponse fraudEligibilityResponse = idProofingService.checkFraudEligibility(consumer, consumerContext);

			if(fraudEligibilityResponse  == null || fraudEligibilityResponse.getIdpData() == null) {
				throw new EmergencyBreakException("FraudEligibilityResponse or IDPData returned null");
			}

			idpData = fraudEligibilityResponse.getIdpData();
			boolean isFraudCheckFailed = AuthStatusUtil.isEligibilityFraudCheckFailed(idpData);

			if(isFraudCheckFailed) {
				String message = "eligibilityFraudCheckFailed, sending message to failure email queue";
				LOGGER.checkBeforeDebug(message);
				AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
						message, consumerContext);
				throw new EmergencyBreakException(message);
			}

		} catch (Exception e) {
			String message = MessageFormat.format("FraudEligibilityChecksFailed  : {0}", consumer.getConsumerKey());
			LOGGER.checkBeforeWarn(message, e);
			throw new EmergencyBreakException(message);
		}
		return idpData;
	}

	/**
	 * Step - Save consumer, stop processing message on exception.
	 *
	 * @param consumer
	 * @param consumerContext
	 * @throws EmergencyBreakException
	 */
	private void saveConsumer(Consumer consumer, ConsumerContext consumerContext)
			throws EmergencyBreakException {

		RegistrationResponse registrationResponse = null;
		try {
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Calling registrationService.createCredentials()...", consumer.getConsumerKey(), consumerContext);
			registrationResponse = registrationService.createCredentials(consumer, consumerContext);
		} catch (RegistrationServiceException e) {
			String message = "Unhandled exception during save consumer with credentials to system. Internal server error.";
			LOGGER.checkBeforeError(message, e);
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
					message, consumerContext);
		}
		RegistrationResponse.StatusCode statusCode = (registrationResponse == null) ? null : registrationResponse.getStatusCode();
		if (RegistrationResponse.StatusCode.SUCCESS != statusCode) {
			String message = MessageFormat
					.format("Save consumer with credentials not successful, received statusCode {0}", statusCode);
			throw new EmergencyBreakException(message);
		}
		if (registrationResponse != null && StringUtils.isNotBlank(registrationResponse.getCustomerKey())) {
			consumer.setConsumerKey(registrationResponse.getCustomerKey());
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.IN_PROGRESS,
					"Customer Key returned.", consumer.getConsumerKey(), consumerContext);
		}
	}

	/**
	 * Step - Validate no Hit status, if status present, skip consecutive
	 * steps.
	 *
	 * @param idpData
	 * @param consumerContext
	 * @param consumerKey
	 * @throws EmergencyBreakException
	 */
    private void validateNoHit(IDPData idpData,
                    final ConsumerContext consumerContext, String consumerKey) throws EmergencyBreakException {

		if(idpData.getEidCompareResponse() == null ) {
			String message = "EidCompareResponse is null, sending message to failure email queue";
			LOGGER.checkBeforeDebug(message);
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
					message, consumerKey, consumerContext);
			throw new EmergencyBreakException(message);
		}

		EidCompareResponse.Metadata authMetadata = (EidCompareResponse.Metadata) idpData
				.getEidCompareResponse().getMetadata();


		if (authMetadata != null && authMetadata.isEligibilityNoHit()) {
			String message = "EidCompareResponse has noHit status";
			LOGGER.checkBeforeDebug(message);
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
					message, consumerKey, consumerContext);
			throw new EmergencyBreakException(message);
		}
	}

	/**
	 * Return PTP eligibility for emergency break
	 *
	 * @param consumer
	 * @param consumerContext
	 * @return
	 * @throws EmergencyBreakException
	 */
    public boolean verifyPtpEligibility(final Consumer consumer,
                    final ConsumerContext consumerContext) throws EmergencyBreakException {

		if (consumer.getEidStatus() == EidStatus.PIN_TO_POST_ELIGIBLE && consumer.getStandardizedAddress() != null) {
			return true;
		} else {
			String message = "Address check on ACRO failed, ptp not eligible";
			LOGGER.checkBeforeDebug(message);
			AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_CREATE_ACCOUNT, AuditEventStatus.END_PARTIAL_SUCCESS,
					message, consumer.getConsumerKey(), consumerContext);
			throw new EmergencyBreakException(message);
		}
	}
	
	private String getPrintTemplateId() {
		if (partnerTenantClient == null) {
			return null;
		}
		if (partnerTenantClient.getSettings() == null) {
			return null;
		} else {
			return partnerTenantClient.getSettings().getPrintTemplateId();
		}
	}

	/**
	 * Map Consumer details from emergency break message to email message.
	 * @param emergencyBreakQueueMessage
	 * @return
	 */
	private EmailQueueMessage mapEmailQueueMessage(final EmergencyBreakQueueMessage emergencyBreakQueueMessage) {
		EmailQueueMessage emailQueueMessage = new EmailQueueMessage();
		emailQueueMessage.setConversationId(emergencyBreakQueueMessage.getConsumerContext().getConversationId());
		emailQueueMessage.setConsumerKey(emergencyBreakQueueMessage.getConsumer().getConsumerKey());
		emailQueueMessage.setEmail(emergencyBreakQueueMessage.getConsumer().getEmail());
		emailQueueMessage.setFirstName(emergencyBreakQueueMessage.getConsumer().getFirstName());
		emailQueueMessage.setLastName(emergencyBreakQueueMessage.getConsumer().getLastName());
		return emailQueueMessage;
	}

}
