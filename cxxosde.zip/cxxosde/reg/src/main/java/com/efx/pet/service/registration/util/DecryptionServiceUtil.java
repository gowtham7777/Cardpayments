package com.efx.pet.service.registration.util;


import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.service.encryption.DecryptionService;
import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DecryptionServiceUtil {

  @Autowired
  private DecryptionService decryptionService;

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(DecryptionServiceUtil.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "DecryptionServiceUtil");


  public String decryptOfferCode(String encValue, ConsumerContext consumerContext) {
    String decryptedLine = null;
    try {
      decryptedLine = decryptionService.decryptLine(encValue);
    } catch (IllegalArgumentException e) {
      LOGGER.error(e.getMessage());
      AUDITOR.recordError(AuditConstants.EVENT_DECRYPTION_LINE, AuditEventStatus.END_FAIL, e.getMessage(), consumerContext);
    }
    return decryptedLine;
  }


}
