package com.efx.pet.service.registration.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

  //**
  // Here we provide the rules on CSP. The sha- hash tag was added to allow Swagger UI makes a forward to other page.
  // It is a hash code of script that execute forwarding. It can be found only on a browser.
  // */
  @Value("${com.efx.pet.service.registration.contentSecurityPolicy: default-src 'self' *.equifax.com 'sha256-uGJV1INRCzRQ65HtahUNomtGV0G2E/dzVWsvQpazKHw='}")
  private String contentSecurityPolicy;

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http
      .authorizeRequests()
      .antMatchers("/**")
      .permitAll()
      .and()
      .headers()
      .contentSecurityPolicy(contentSecurityPolicy);
  }

  @Override
  public void configure(WebSecurity web) {
    web.ignoring().antMatchers("/rest/**");
  }
}
