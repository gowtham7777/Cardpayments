package com.efx.pet.service.registration.domain;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerTenantResponse {

  private String id;
  private String partnerName;
  private String tenantName;
  private String partnerId;
  private String tenantId;
  private Map<String, String> coreServices = new HashMap<>();
  private String partnerAlias;
  private String defaultLocale;
  private String supportedLocale;
  private String createdUser;
  private String createdDate;
  private String modifiedUser;
  private String modifiedDate;

  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public String getPartnerName() {
    return partnerName;
  }
  public void setPartnerName(String partnerName) {
    this.partnerName = partnerName;
  }
  public String getTenantName() {
    return tenantName;
  }
  public void setTenantName(String tenantName) {
    this.tenantName = tenantName;
  }
  public String getPartnerId() {
    return partnerId;
  }
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }
  public String getTenantId() {
    return tenantId;
  }
  public void setTenantId(String tenantId) {
    this.tenantId = tenantId;
  }
  public Map<String, String> getCoreServices() {
    return coreServices;
  }
  public void setCoreServices(Map<String, String> coreServices) {
    this.coreServices = coreServices;
  }
  public String getPartnerAlias() {
    return partnerAlias;
  }
  public void setPartnerAlias(String partnerAlias) {
    this.partnerAlias = partnerAlias;
  }
  public String getDefaultLocale() {
    return defaultLocale;
  }
  public void setDefaultLocale(String defaultLocale) {
    this.defaultLocale = defaultLocale;
  }
  public String getSupportedLocale() {
    return supportedLocale;
  }
  public void setSupportedLocale(String supportedLocale) {
    this.supportedLocale = supportedLocale;
  }
  public String getCreatedUser() {
    return createdUser;
  }
  public void setCreatedUser(String createdUser) {
    this.createdUser = createdUser;
  }
  public String getCreatedDate() {
    return createdDate;
  }
  public void setCreatedDate(String createdDate) {
    this.createdDate = createdDate;
  }
  public String getModifiedUser() {
    return modifiedUser;
  }
  public void setModifiedUser(String modifiedUser) {
    this.modifiedUser = modifiedUser;
  }
  public String getModifiedDate() {
    return modifiedDate;
  }
  public void setModifiedDate(String modifiedDate) {
    this.modifiedDate = modifiedDate;
  }


}
