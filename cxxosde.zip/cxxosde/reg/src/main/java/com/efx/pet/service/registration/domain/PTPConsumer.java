package com.efx.pet.service.registration.domain;

import java.io.Serializable;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by lxg90 on 05/21/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PTPConsumer implements Serializable {

  private static final long serialVersionUID = 1L;
  private String email;
  private String pin;
  private String reCaptchaResponse;

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPin() {
    return pin;
  }

  public void setPin(String pin) {
    this.pin = StringUtils.trimToNull(pin);
  }

  public String getReCaptchaResponse() {
    return reCaptchaResponse;
  }

  public void setReCaptchaResponse(String reCaptchaResponse) {
    this.reCaptchaResponse = reCaptchaResponse;
  }
}
