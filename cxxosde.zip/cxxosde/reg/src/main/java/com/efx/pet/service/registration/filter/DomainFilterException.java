package com.efx.pet.service.registration.filter;

public class DomainFilterException extends RuntimeException{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  public DomainFilterException(String message) {
    super(message);
}

}
