package com.efx.pet.registration.controller.util;

import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Pattern;

public class ParamsValidatorUtil {
  private static Pattern campaignCodePattern = Pattern.compile("^[a-zA-Z0-9]*$");
  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(ParamsValidatorUtil.class);

  public static boolean isValidCampaignCode(String campaignCode) {
    if (StringUtils.isBlank(campaignCode)) {
      return false;
    }
    if (!campaignCodePattern.matcher(campaignCode).matches()) {
      //Ensures that the input provided by the user is never used directly in a log entry.
      //OWASP Top 10: A1.Log Forging
      LOGGER.error("CampaignCode is invalid. Please provide code in a valid format");
      return false;
    }
    return true;
  }
}
