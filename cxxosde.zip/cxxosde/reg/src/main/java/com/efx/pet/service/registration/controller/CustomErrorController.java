package com.efx.pet.service.registration.controller;

import com.efx.pet.registration.controller.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

/**
 * Created by dxl84 on 8/30/2017.
 */
@Controller
public class CustomErrorController implements ErrorController {
    @Autowired
    private SessionUtil sessionUtil;

    @RequestMapping("/error")
    public ModelAndView renderErrorPage(HttpServletRequest httpRequest) {

        String errorPageName = "/error/generic.html";
        Optional<Object> httpErrorCode = getErrorCode(httpRequest);

        if (httpErrorCode.isPresent() && HttpStatus.valueOf((Integer) httpErrorCode.get()).is4xxClientError()) {
          errorPageName = "html/error/4xx.html";

        } else if (httpErrorCode.isPresent() && HttpStatus.valueOf((Integer) httpErrorCode.get()).is5xxServerError()) {
          errorPageName = "html/system-error.html";

        }
        sessionUtil.invalidateSession(httpRequest);

        return new ModelAndView(errorPageName);
    }

    private Optional<Object> getErrorCode(HttpServletRequest httpRequest) {
        return  Optional.ofNullable(httpRequest
                .getAttribute("javax.servlet.error.status_code"));
    }

    @Override
    public String getErrorPath() {
        return "/error";
    }
}
