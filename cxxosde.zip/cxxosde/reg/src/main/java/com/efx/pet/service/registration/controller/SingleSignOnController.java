package com.efx.pet.service.registration.controller;

import static com.efx.pet.service.registration.controller.RestControllerBase.APPLICATION_JSON;

import javax.servlet.http.HttpSession;

import com.efx.pet.utility.logger.LoggingUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.efx.domain.sso.SingleSignOnDetails;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.service.registration.controller.processor.SingleSignOnProcessor;
import com.efx.pet.service.registration.domain.SingleSignOnResponse;
import com.efx.pet.service.registration.domain.SingleSignOnResponse.StatusCode;
import com.efx.pet.service.registration.exception.SingleSignOnException;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * This controller handles the token generation from Authentication Gateway MS
 * OAuth Provider Once Token is generated context details are encrypted and sent
 * along with the generated tokens
 *
 * @author vxc64
 */
@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "SingleSignOnController API", description = "SingleSignOnController - API Contract")
public class SingleSignOnController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(SingleSignOnController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "singleSignOn");

  private SingleSignOnProcessor singleSignOnProcessor;

  @Autowired
  public SingleSignOnController (SingleSignOnProcessor singleSignOnProcessor){
    this.singleSignOnProcessor = singleSignOnProcessor;
  }

  @Operation(summary = "Returns the sso oAuth Tokens")
  @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Returns Single Sign on Details", content = {
      @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = SingleSignOnResponse.class)) }),
      @ApiResponse(responseCode = "400", description = "Validation error", content = {
          @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = SingleSignOnResponse.class)) }),
      @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
          @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = SingleSignOnResponse.class)) }) })
  @GetMapping(value = "/ssoDetails", produces = APPLICATION_JSON)
  public ResponseEntity<SingleSignOnResponse> getSingleSignOnDetails(HttpSession httpSession)
    throws SingleSignOnException {
	long startTime = System.currentTimeMillis();
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(AuditConstants.EVENT_SINGLE_SIGN_ON, AuditEventStatus.BEGIN,
      "Start - Begin getSingleSignOnDetails", consumerContext);
    String encryptedConsumer = (String) httpSession.getAttribute(CommonConstants.CONSUMER_DATA);
    Consumer consumer = singleSignOnProcessor.getDecryptedConsumer(encryptedConsumer);
    SingleSignOnDetails singleSignOnDetails = singleSignOnProcessor.mapResponse(consumer, consumerContext);
    SingleSignOnResponse signOnResponse = new SingleSignOnResponse(StatusCode.SSO_TOKEN_GENERATION_SUCCESS,
      singleSignOnDetails);
    AUDITOR.recordInfo(AuditConstants.EVENT_SINGLE_SIGN_ON, AuditEventStatus.END_SUCCESS,
      "End - getSingleSignOnDetails", consumerContext, consumer == null? null : consumer.getConsumerKey(), null, HttpStatus.OK.toString(),Long.toString(startTime));
    LOGGER.checkBeforeDebugFormat("End - ssoDetails - getSingleSignOnDetails : status - {0}",
      signOnResponse.getStatusCode());
    httpSession.invalidate();
    return new ResponseEntity<>(signOnResponse, signOnResponse.getStatusCode().getHttpStatus());
  }

  /**
   * Custom Exception handler for invalid Attributes for
   * SingleSignOnController
   *
   * @param ex
   * @param httpSession
   * @return
   */
  @ExceptionHandler(SingleSignOnException.class)
  public ResponseEntity<SingleSignOnResponse> handleCustomException(SingleSignOnException ex,
                                                                    HttpSession httpSession) {
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    final String sanitizedLogMessage = LoggingUtil.sanitizeLoggedMessage(ex.getMessage());
    LOGGER.error(sanitizedLogMessage);
    AUDITOR.recordError(AuditConstants.EVENT_SINGLE_SIGN_ON, AuditEventStatus.END_FAIL, ex.getMessage(),
      consumerContext, ex.getStatusCode().toString(), ex.getStatusCode().getHttpStatus().toString());
    httpSession.invalidate();
    return new ResponseEntity<>(new SingleSignOnResponse(ex.getStatusCode()), ex.getStatusCode().getHttpStatus());
  }

}
