package com.efx.pet.service.registration.controller;

import static com.efx.pet.service.registration.controller.RestControllerBase.APPLICATION_JSON;

import java.text.MessageFormat;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.efx.pet.domain.customer.entity.CustomerEnums;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.client.eligibility.EligibilityConfiguration;
import com.efx.pet.client.eligibility.EligibilityServiceClient;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.customer.entity.CustomerEnums.IdpStatus;
import com.efx.pet.domain.eligibility.operations.IdpResponseDataRequest;
import com.efx.pet.domain.eligibility.operations.IdpResponseDataResponse;
import com.efx.pet.domain.eligibility.operations.ServiceResponse;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.service.idproofing.util.PtpMessageUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.eid.util.IdpResponseDataBuilder;
import com.efx.pet.service.eligibility.util.EligibilityActionType;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.idproofing.helper.PtpIdProofingHelper;
import com.efx.pet.service.idproofing.processor.IdpProcessor;
import com.efx.pet.service.registration.PtpResponse;
import com.efx.pet.service.registration.PtpResponse.StatusCode;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.ReCaptchaService;
import com.efx.pet.service.registration.domain.PTPConsumer;
import com.efx.pet.service.registration.domain.PtpIdProofingResult;
import com.efx.pet.utility.AccountSetupMessageUtility;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.ConsumerValidator;
import com.efx.pet.utility.cache.redis.util.PiiToHashUtility;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Created by sxm472 on 11/9/2017.
 */
@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "PtpController", description = "Ptp Operations")
@ContextConfiguration(classes = EligibilityConfiguration.class)
public class PtpController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(PtpController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "Ptp");
  private static final String VALIDATE_PTP = AuditConstants.EVENT_PTP_VALIDATE;

  @Autowired
  private IdProofingService idProofingService;

  @Autowired
  private EncryptUtility encryptUtility;

  @Autowired
  private PtpMessageUtility ptpMessageUtility;

  @Autowired
  private SessionUtil sessionUtil;

  @Autowired
  private ReCaptchaService reCaptchaService;

  @Autowired
  private ObtainIpUtility obtainIpUtility;

  @Value("${com.efx.pet.service.registration.ptp.retry.max.count:3}")
  private Byte ptpRetryMaxCount;

  @Autowired
  private ConsumerService consumerService;

  @Autowired
  private PiiToHashUtility piiToHashUtility;

  @Autowired
  private EligibilityServiceClient eligibilityServiceClient;

  @Autowired
  private ConsumerValidator consumerValidator;

  @Autowired
  private IdpProcessor idpProcessor;

  @Autowired
  private AccountSetupMessageUtility accountSetupMessageUtility;

  @Autowired
  private PtpIdProofingHelper ptpIdProofingHelper;

  @Autowired
  private PartnerTenantClient partnerTenantClient;

  @Operation(summary = "Returns the StatusCode")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Returns status when Pin to Post initiation successful", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }),
      @ApiResponse(responseCode = "400", description = "Missing required fields", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }),
      @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }) })
  @RequestMapping(value = "/initiatePtp", method = RequestMethod.GET, produces = APPLICATION_JSON)
  public ResponseEntity<PtpResponse> initiatePtp(HttpServletRequest httpRequest) {
    final String PTP_INITIATE = AuditConstants.EVENT_PTP_INITIATE;
    ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession(false)
        .getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(PTP_INITIATE, AuditEventStatus.BEGIN,
        "Start - PtpController.initiatePtp() - Begin Pin to Post initiation.", consumerContext);

    // get decrypted consumer from httpRequest
    String decryptedConsumer = encryptUtility.decrypt(httpRequest, CommonConstants.CONSUMER_DATA);
    Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
    if (consumer == null) {
      String message = "Either HttpSession OR Consumer in HttpSession is null.";
      LOGGER.error(message, new Exception(message));
      AUDITOR.recordError(PTP_INITIATE, AuditEventStatus.END_FAIL, message, consumerContext,
          StatusCode.INITIATE_PTP_SYSTEM_ERROR.toString(),
          HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpRequest);
      return new ResponseEntity<>(new PtpResponse(StatusCode.INITIATE_PTP_SYSTEM_ERROR),
          HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // check if consumer has necessary fields
    if (!consumerHasNecessaryFields(consumer, consumerContext)) {
      String message = "Consumer validation failed.";
      LOGGER.error(message, new Exception(message));
      AUDITOR.recordError(PTP_INITIATE, AuditEventStatus.END_FAIL, message, consumerContext,
          consumer.getConsumerKey(), StatusCode.VALIDATE_PTP_ERROR.toString(),
          HttpStatus.BAD_REQUEST.toString());
      sessionUtil.invalidateSession(httpRequest);
      return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_ERROR),
          HttpStatus.BAD_REQUEST);
    }

	try {
		LOGGER.checkBeforeDebug("Calling idProofingService.enrollInPtp()...");
		AUDITOR.recordInfo(PTP_INITIATE, AuditEventStatus.IN_PROGRESS, "Calling idProofingService.enrollInPtp()...",
				consumer.getConsumerKey(), consumerContext);
		IdProofingResponse idProofingResponse = idProofingService.enrollInPtp(consumer, consumerContext,
				getPrintTemplateId(), false); // isEmergencyBrakeEnabled false
		if (idProofingResponse != null
				&& IdProofingResponse.StatusCode.PTP_ENROLL_SUCCESS == idProofingResponse.getStatusCode()) {
			LOGGER.checkBeforeDebug("Pin to Post initiated successfully.");
			AUDITOR.recordInfo(PTP_INITIATE, AuditEventStatus.END_SUCCESS, "Pin to Post initiated successfully.",
					consumerContext, consumer.getConsumerKey(), StatusCode.INITIATE_PTP_SUCCESS.toString(),
					HttpStatus.OK.toString());
			sessionUtil.invalidateSession(httpRequest);
			return new ResponseEntity<>(new PtpResponse(StatusCode.INITIATE_PTP_SUCCESS), HttpStatus.OK);
		} else {
			LOGGER.checkBeforeError("Pin to Post initiation unsuccessful.");
			AUDITOR.recordError(PTP_INITIATE, AuditEventStatus.END_FAIL, "Pin to Post initiation unsuccessful.",
					consumerContext, consumer.getConsumerKey(), StatusCode.INITIATE_PTP_SYSTEM_ERROR.toString(),
					HttpStatus.INTERNAL_SERVER_ERROR.toString());
		}
	} catch (IdProofingServiceException ex) {
		LOGGER.checkBeforeError("Unknown Exception encountered during Pin to Post initiation.", ex);
		AUDITOR.recordError(PTP_INITIATE, AuditEventStatus.END_FAIL,
				"Unknown Exception encountered during Pin to Post initiation.", consumerContext,
				consumer.getConsumerKey(), StatusCode.INITIATE_PTP_SYSTEM_ERROR.toString(),
				HttpStatus.INTERNAL_SERVER_ERROR.toString());
	}
	sessionUtil.invalidateSession(httpRequest);
	return new ResponseEntity<>(new PtpResponse(StatusCode.INITIATE_PTP_SYSTEM_ERROR),
			HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @Operation(summary = "Returns the StatusCode")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Returns status when Pin to Post validation successful", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }),
      @ApiResponse(responseCode = "400", description = "Invalid required fields", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }),
      @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
          @Content(schema = @Schema(implementation = PtpResponse.class)) }) })
  @RequestMapping(value = "/submitPtp", method = RequestMethod.POST, produces = APPLICATION_JSON,
      consumes = APPLICATION_JSON)
  public ResponseEntity<PtpResponse> submitPtp(HttpServletRequest httpRequest,
      @RequestBody String content) {

    final ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession(false)
        .getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(VALIDATE_PTP, AuditEventStatus.BEGIN,
        "Start - PTPController.submitPtp() - Begin PTP pin validation.", consumerContext);

    // Get PTPConsumer
    PTPConsumer ptpConsumer = null;
    try {
      ptpConsumer = JsonUtils.fromSanitizedJson(content, PTPConsumer.class);
    } catch (Exception e) {
      String message =
          "Unhandled exception during Pin to Post validation. Not able to convert request body Json content to PTPConsumer.";
      LOGGER.error(message, e);
      AUDITOR.recordError(VALIDATE_PTP, AuditEventStatus.END_FAIL, message, consumerContext, null,
          StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
      sessionUtil.invalidateSession(httpRequest);
      return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_ERROR),
          HttpStatus.BAD_REQUEST);
    }

    //validate Ptp input
    boolean isValidInput = validatePtpConsumer(ptpConsumer, consumerContext);
    if(!isValidInput) {
      sessionUtil.invalidateSession(httpRequest);
      return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_ERROR),
          HttpStatus.BAD_REQUEST);
    }

    // Validate reCaptcha
    boolean isValidRecaptcha = validateRecaptcha(httpRequest, ptpConsumer, consumerContext);
    if(!isValidRecaptcha) {
      return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_RECAPTCHA_ERROR),
          HttpStatus.OK);
    }

    //search customer by email
    LOGGER.debug("Search CustomerKey for customerEmail (hashed): {}, partnerId:{}, tenantId: {}", piiToHashUtility.getHash(ptpConsumer.getEmail()), consumerContext.getPartnerId(), consumerContext.getTenantId());
    Consumer consumerDetail = consumerService.findConsumerByEmail(ptpConsumer.getEmail(), consumerContext);
    String customerKey = null;
    boolean isValidConsumerInfo = isValidConsumerDetailsPresent(consumerDetail);
    if (isValidConsumerInfo) {
    	customerKey = consumerDetail.getConsumerKey();
    	ResponseEntity<PtpResponse> responseEntity = priorIdProofingResponse(httpRequest, customerKey, consumerContext);
    	//exit if user was authenticated in a previous session
    	if(responseEntity != null) {
    		return responseEntity;
    	}
    }

    // Validate pin
    Map<String, String> ptpData = ptpMessageUtility.readPtpDataFromCache(customerKey);

    return processCacheSearchResults(httpRequest, consumerContext, consumerDetail, ptpConsumer, ptpData);

  }

  private ResponseEntity<PtpResponse> processCacheSearchResults(HttpServletRequest httpRequest, ConsumerContext consumerContext, Consumer consumerDetail, PTPConsumer ptpConsumer, Map<String, String> ptpData) {
	    if(ptpData !=null && isValidConsumerDetailsPresent(consumerDetail)) {

	        AUDITOR.recordInfo(VALIDATE_PTP, AuditEventStatus.IN_PROGRESS,
	            "Customer entered PIN received via enrollment in PIN2POST feature. Checking pin expiry", consumerDetail.getConsumerKey(), consumerContext);

	        boolean isExpired = ptpMessageUtility.checkPinExpiry(ptpData.get(PtpMessageUtility.PIN_EXPIRATION_DATE));

	        if(isExpired) {
	      	  return executeStepsForExpiredPinAndExit(httpRequest, consumerContext, consumerDetail.getConsumerKey());
	        } else {
	        	AUDITOR.recordInfo(VALIDATE_PTP, AuditEventStatus.IN_PROGRESS,
	      	            "Pin Not expired, proceeding compare", consumerDetail.getConsumerKey(), consumerContext);
	        }

	        // If pin validation passed
        CustomerEnums.Status pinCompare = pinCompare(ptpConsumer.getPin(), ptpData, consumerDetail.getConsumerKey(), consumerContext);

        if (pinCompare.equals(CustomerEnums.Status.SUCCESS)) {
	      	  if(isIdProofingSuccessResultSaved(httpRequest, consumerDetail, consumerContext, ptpConsumer.getEmail())) {
	  	    	  return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_SUCCESS), HttpStatus.OK);
	  	      } else {
	  	    	  return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
	  	      }
	        }
        else if (pinCompare.equals(CustomerEnums.Status.FAILURE)) {
          if(isIdProofingFailureResultSaved(httpRequest, consumerDetail.getConsumerKey(), consumerContext)) {
            //resubmission check or nothing is done here as we are doing at the end
          } else
            return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
          }

	      } else {
	        String message = "Ptp data returned null, check retry attempts";
	        LOGGER.warn(message);
	      }

	      // when pin validation failed, check if resubmission is allowed
	      String customerKey = consumerDetail == null? null : consumerDetail.getConsumerKey();
	      return getRetryResponse(httpRequest, customerKey, ptpData, consumerContext);
  }

  private ResponseEntity<PtpResponse> executeStepsForExpiredPinAndExit(HttpServletRequest httpRequest, ConsumerContext consumerContext, String customerKey) {
	  ptpMessageUtility.deletePinFromCache(customerKey);
      String failureReason = "PIN entered via enrollment in PIN2POST feature failed validation. The pin has expired and so deleted from cache now.";
      IdpResponseDataRequest iRequest =IdpResponseDataBuilder.buildIdpResponseDataRequest(customerKey, EligibilityActionType.PTP_SUBMIT_PIN,
      		JsonUtils.toJson(new PtpIdProofingResult(PtpIdProofingResult.IdProofingStatus.FAIL, failureReason)), consumerContext);
      eligibilityServiceClient.saveIdpResponseData(iRequest);
      boolean idProofingResponse = isIdProofingFailureResultSaved(httpRequest, customerKey, consumerContext);
      PtpResponse ptpResponse = new PtpResponse(StatusCode.VALIDATE_PTP_EXPIRE);
      ptpResponse.setRemainingAttempts((byte)0);
      AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
          failureReason, consumerContext, customerKey,
          ptpResponse.getStatusCode().toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
      if(idProofingResponse)
        sessionUtil.invalidateSession(httpRequest);
      return new ResponseEntity<>(ptpResponse, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  private boolean isValidConsumerDetailsPresent(Consumer consumerDetail) {
	  return (consumerDetail!=null && StringUtils.isNotBlank(consumerDetail.getConsumerKey()));
  }

  private ResponseEntity<PtpResponse> priorIdProofingResponse(final HttpServletRequest httpRequest, final String customerKey, final ConsumerContext consumerContext) {
	  try {
		  LOGGER.debug("Search Eligibility Service for previous P2P Id Proofing response, if any, using customerKey: {}", customerKey);
		  IdpResponseDataResponse idpResponse = eligibilityServiceClient.getIdpResponseDataDocumentsByCustomerKeyAndOractionType(customerKey, EligibilityActionType.PTP_SUBMIT_PIN.toString());
		  if(idpResponse != null && idpResponse.getOperationStatus() == ServiceResponse.Status.SUCCESS
				  && !CollectionUtils.isEmpty(idpResponse.getIdpResponseData()) && idpResponse.getIdpResponseData().get(0) != null) {
			  LOGGER.debug("A previous PTP Id Proofing response found for customerKey: {}", customerKey);
			  PtpIdProofingResult ptpIdProofingResult = JsonUtils.fromSanitizedJson(idpResponse.getIdpResponseData().get(0).getRawData(), PtpIdProofingResult.class);
			  if (ptpIdProofingResult != null && ptpIdProofingResult.getIdProofingStatus() == PtpIdProofingResult.IdProofingStatus.PASS) {
				  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_PARTIAL_SUCCESS,
	        	            "PTP pin validation was successful in prior session.", consumerContext, customerKey,
	        	            StatusCode.VALIDATE_PTP_SUCCESS.toString(), HttpStatus.OK.toString());
				  sessionUtil.invalidateSession(httpRequest);
				  return new ResponseEntity<>(new PtpResponse(StatusCode.VALIDATE_PTP_SUCCESS), HttpStatus.OK);
			  } else {
				  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
	    				  "PTP pin validation failed in prior session", consumerContext, customerKey,
	    				StatusCode.VALIDATE_PTP_EXPIRE.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
				  sessionUtil.invalidateSession(httpRequest);
				  PtpResponse ptpResponse = new PtpResponse(StatusCode.VALIDATE_PTP_EXPIRE);
				  ptpResponse.setRemainingAttempts(new Byte("0"));
				  return new ResponseEntity<>(ptpResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			  }
		  }
	  } catch (Exception e) {
		  LOGGER.error("Unhandled exception during priorIdProofingResponse evaluation.", e);
	  }
	  return null;
  }

  private boolean isIdProofingFailureResultSaved(HttpServletRequest httpRequest, String customerKey, ConsumerContext consumerContext){

    try{
      idpProcessor.updateIdProofingStatus(IdpStatus.FAIL, customerKey, consumerContext);
      AUDITOR.recordError(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.IN_PROGRESS,
        "PIN entered via enrollment in PIN2POST feature failed validation.", consumerContext, customerKey, HttpStatus.OK.toString());
      return true;
    }
    catch(Exception e){
      String errMsg = "PIN entered via enrollment in PIN2POST feature failed validation. Unhandled exception during steps within isIdProofingFailureResultSaved().";
      LOGGER.error(errMsg, e);
      AUDITOR.recordError(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
        errMsg, consumerContext, customerKey, HttpStatus.INTERNAL_SERVER_ERROR.toString(),StatusCode.VALIDATE_PTP_ERROR.toString());
      sessionUtil.invalidateSession(httpRequest);
      return false;
    }
  }

  private boolean isIdProofingSuccessResultSaved(final HttpServletRequest httpRequest, final Consumer consumerDetail, final ConsumerContext consumerContext, final String email) {
	  try {
		  LOGGER.debug("Save P2P Id Proofing result to Eligibility Service using customerKey: {}", consumerDetail.getConsumerKey());
		  IdpResponseDataRequest iRequest =IdpResponseDataBuilder.buildIdpResponseDataRequest(consumerDetail.getConsumerKey(), EligibilityActionType.PTP_SUBMIT_PIN, JsonUtils.toJson(new PtpIdProofingResult(PtpIdProofingResult.IdProofingStatus.PASS, null)), consumerContext);
	      IdpResponseDataResponse iResponse = eligibilityServiceClient.saveIdpResponseData(iRequest);
	      if(iResponse != null && iResponse.getOperationStatus() == ServiceResponse.Status.SUCCESS) {
	    	  // Update Customer Service - 'PASS' idpStatus
		      idpProcessor.updateIdProofingStatus(IdpStatus.PASS, consumerDetail.getConsumerKey(), consumerContext);
	    	  consumerDetail.setEmail(email);
      		  accountSetupMessageUtility.writeToEmailQ(consumerDetail, consumerContext);
	    	  ptpMessageUtility.deletePinFromCache(consumerDetail.getConsumerKey());
	    	  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_SUCCESS,
	  	            "PIN entered via enrollment in PIN2POST feature passed validation. Id proofing successful.", consumerContext, consumerDetail.getConsumerKey(),
	  	            StatusCode.VALIDATE_PTP_SUCCESS.toString(), HttpStatus.OK.toString());
	    	  sessionUtil.invalidateSession(httpRequest);
	    	  return true;
	      } else {
	    	  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
	  	            "PIN entered via enrollment in PIN2POST feature failed validation. Eligibility Service update failed.", consumerContext, consumerDetail.getConsumerKey(),
	  	            StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
	    	  sessionUtil.invalidateSession(httpRequest);
	    	  return false;
	      }
	  } catch (Exception e) {
		  String errMsg = "PIN entered via enrollment in PIN2POST feature failed validation. Unhandled exception during steps within isIdProofingSuccessResultSaved().";
		  LOGGER.error(errMsg, e);
		  AUDITOR.recordError(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
				  errMsg, consumerContext, consumerDetail.getConsumerKey(),
	  	            StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
	    	  sessionUtil.invalidateSession(httpRequest);
		  return false;
	  }
  }

  private boolean validatePtpConsumer(PTPConsumer ptpConsumer, ConsumerContext consumerContext) {

    // Validate PTPConsumer request
    if (ptpConsumer == null) {
      String message = "Request body is null or empty, Bad Request.";
      LOGGER.error(message, new Exception(message));
      AUDITOR.recordError(VALIDATE_PTP, AuditEventStatus.END_FAIL, message, consumerContext, null,
          StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
      return false;
    }

    // Validate input pin
    String requestPin = ptpConsumer.getPin();
    if (StringUtils.isBlank(requestPin)
        || !ptpMessageUtility.getPtpPinPattern().matcher(requestPin).matches()) {
      String message = "Missing or invalid pin.";
      LOGGER.error(message, new Exception(message));
      AUDITOR.recordError(VALIDATE_PTP, AuditEventStatus.END_FAIL, message, consumerContext, null,
          StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
      return false;
    }

    // Validate input email
    String email = ptpConsumer.getEmail();
    if (StringUtils.isBlank(email) || !Pattern.compile(ConsumerValidator.EMAIL_PATTERN).matcher(email).matches()) {
      String message = "Missing or invalid email.";
      LOGGER.error(message, new Exception(message));
      AUDITOR.recordError(VALIDATE_PTP, AuditEventStatus.END_FAIL, message, consumerContext, null,
          StatusCode.VALIDATE_PTP_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
      return false;
    }
    return true;
  }

  private boolean validateRecaptcha(HttpServletRequest httpRequest, PTPConsumer ptpConsumer, ConsumerContext consumerContext) {
    AUDITOR.recordInfo(VALIDATE_PTP, AuditEventStatus.IN_PROGRESS,
        MessageFormat.format("Validating reCaptcha response... reCaptchaResponse = {0}",
            ptpConsumer.getReCaptchaResponse()),
        null, consumerContext);
    boolean reCaptchaValid = reCaptchaService.isResponseValid(
        obtainIpUtility.obtainIpAddress(httpRequest), ptpConsumer.getReCaptchaResponse());
    if (!reCaptchaValid) {
      String message =
          MessageFormat.format("reCaptcha response failed validation. reCaptchResponse = {0}",
              ptpConsumer.getReCaptchaResponse());
      LOGGER.debug(message);
      AUDITOR.recordError(VALIDATE_PTP, AuditEventStatus.END_FAIL, message, consumerContext, null,
          StatusCode.VALIDATE_PTP_RECAPTCHA_ERROR.toString(), HttpStatus.OK.toString());
      return false;
    }
    AUDITOR.recordInfo(VALIDATE_PTP, AuditEventStatus.IN_PROGRESS, "reCaptcha validation successful.", null, consumerContext);
    return true;
  }

  private ResponseEntity<PtpResponse> getRetryResponse(final HttpServletRequest httpRequest, final String customerKey, final Map<String, String> ptpData, final ConsumerContext consumerContext) {

	// Retrieve prior PTP remaining attempts from httpSession, if any
	HttpSession httpSession = httpRequest.getSession(false);
	Byte ptpRemainingAttempts = (httpSession == null || httpSession.getAttribute(CommonConstants.PTP_REMAINING_ATTEMPTS) == null)
			? ptpRetryMaxCount : (Byte) httpSession.getAttribute(CommonConstants.PTP_REMAINING_ATTEMPTS);
    PtpResponse ptpResponse = new PtpResponse(StatusCode.VALIDATE_PTP_ERROR_RESUBMIT_ALLOWED);
    ResponseEntity<PtpResponse> responseEntity = null;

    --ptpRemainingAttempts; //Since validation attempt has already failed at this time, decrement first
    // Store PTP remaining attempts into httpSession
    httpRequest.getSession().setAttribute(CommonConstants.PTP_REMAINING_ATTEMPTS, ptpRemainingAttempts);
    ptpResponse.setRemainingAttempts(ptpRemainingAttempts);

    if (ptpRemainingAttempts <= 0) { // Check for less than 0 as a safety net
      ptpResponse.setStatusCode(StatusCode.VALIDATE_PTP_EXPIRE);
      if (StringUtils.isNotBlank(customerKey)) {
    	  String failureReason;
    	  if (ptpData !=null) {
    		  // Should we delete Pin entry from cache ??
    		  failureReason = "PIN entered via enrollment in PIN2POST feature failed validation. Maxed out attempts.";
    		  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
    				  failureReason, consumerContext, customerKey,
    		          ptpResponse.getStatusCode().toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
    		  IdpResponseDataRequest iRequest =IdpResponseDataBuilder.buildIdpResponseDataRequest(customerKey, EligibilityActionType.PTP_SUBMIT_PIN,
    				  JsonUtils.toJson(new PtpIdProofingResult(PtpIdProofingResult.IdProofingStatus.FAIL, failureReason)), consumerContext);
        	  eligibilityServiceClient.saveIdpResponseData(iRequest);
    	  } else {
    		  failureReason = "No pin entry found for customerkey: '" + customerKey + "' in cache. Maxed out attempts.";
    		  AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_FAIL,
    				  failureReason, consumerContext, customerKey,
    		          ptpResponse.getStatusCode().toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
    		  IdpResponseDataRequest iRequest =IdpResponseDataBuilder.buildIdpResponseDataRequest(customerKey, EligibilityActionType.PTP_SUBMIT_PIN,
    				  JsonUtils.toJson(new PtpIdProofingResult(PtpIdProofingResult.IdProofingStatus.FAIL, failureReason)), consumerContext);
        	  eligibilityServiceClient.saveIdpResponseData(iRequest);
    	  }
      }
      responseEntity = new ResponseEntity<>(ptpResponse, HttpStatus.INTERNAL_SERVER_ERROR);
      sessionUtil.invalidateSession(httpRequest);
    } else {
      AUDITOR.recordInfo(AuditConstants.EVENT_PTP_VALIDATE, AuditEventStatus.END_PARTIAL_SUCCESS,
          MessageFormat.format(
              "PIN entered via enrollment in PIN2POST feature is incorrect and needs resubmission. Remaining retry attempts count = {0}",
              ptpRemainingAttempts),
          consumerContext, customerKey, ptpResponse.getStatusCode().toString(), HttpStatus.OK.toString());
      responseEntity = new ResponseEntity<>(ptpResponse, HttpStatus.OK);
    }

    return responseEntity;
  }


  private CustomerEnums.Status pinCompare(String inputPin, Map<String, String> ptpData, String customerKey, ConsumerContext consumerContext) {
    final String PTP_VALIDATE = AuditConstants.EVENT_PTP_VALIDATE;
    String validPin = (ptpData !=null ? ptpData.get(PtpMessageUtility.PIN) : null);
    if (StringUtils.isNotBlank(validPin) && inputPin.equals(validPin)) {
      AUDITOR.recordInfo(PTP_VALIDATE, AuditEventStatus.IN_PROGRESS, "PTP pin compare successful",
          customerKey, consumerContext);
      return CustomerEnums.Status.SUCCESS;
    }
    else if (StringUtils.isNotBlank(validPin) && !inputPin.equals(validPin)) {
      AUDITOR.recordInfo(PTP_VALIDATE, AuditEventStatus.IN_PROGRESS, "PTP pin compare failed",
        customerKey, consumerContext);
      return CustomerEnums.Status.FAILURE;
    }
    else {
      AUDITOR.recordInfo(PTP_VALIDATE, AuditEventStatus.IN_PROGRESS, "PTP validate failed", customerKey,
    		  consumerContext);
      return CustomerEnums.Status.ERROR;
    }
  }

  private Boolean consumerHasNecessaryFields(final Consumer consumer,
      final ConsumerContext consumerContext) {
    if (StringUtils.isBlank(consumer.getConsumerKey())
        || !consumerValidator.isValidFirstName(consumer.getFirstName())
        || !consumerValidator.isValidLastName(consumer.getLastName())
        || StringUtils.isBlank(consumer.getEmail())) {
      return false;
    }
    return ptpIdProofingHelper.isValidAddress(consumer, consumerContext);
  }

  private String getPrintTemplateId() {
		if (partnerTenantClient == null) {
			return null;
		}
		if (partnerTenantClient.getSettings() == null) {
			return null;
		} else {
			return partnerTenantClient.getSettings().getPrintTemplateId();
		}
	}

}
