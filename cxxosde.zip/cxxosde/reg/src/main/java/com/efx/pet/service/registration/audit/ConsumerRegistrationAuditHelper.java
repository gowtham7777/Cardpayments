package com.efx.pet.service.registration.audit;

import com.efx.pet.utility.configuration.audit.LockAlertAuditHelper;

@Deprecated
public class ConsumerRegistrationAuditHelper extends LockAlertAuditHelper{}
