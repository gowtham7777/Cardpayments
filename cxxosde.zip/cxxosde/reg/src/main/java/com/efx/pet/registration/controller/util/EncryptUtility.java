package com.efx.pet.registration.controller.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.efx.pet.domain.Consumer;
import com.efx.pet.service.registration.domain.KbaResponseException;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.encryption.Encryptor;

/**
 * Created by sxs10 on 11/10/2017.
 */

@Component
public class EncryptUtility {


  @Autowired
  @Qualifier("jmsEncryptor")
  Encryptor encryptor;


	/**
	 * Encrypts the  consumer object
   *  @param httpRequest
	 * @return
	 * @throws KbaResponseException
	 */
	public void encrypt(HttpServletRequest httpRequest,String consumer, String commonConstants) {
    if (StringUtils.isNotBlank(consumer)){
      String encryptedConsumer = encryptor.encrypt(consumer);
      httpRequest.getSession().setAttribute(commonConstants, encryptedConsumer);
  }

  }

  public String decrypt(HttpServletRequest httpRequest,String commonConstants) {
    String encryptedObject = (httpRequest.getSession(false) != null) ? (String) httpRequest.getSession(false).getAttribute(commonConstants) : null;
    if(StringUtils.isNotBlank(encryptedObject)) {
      return encryptor.decrypt(encryptedObject);
    }
    return null;
   }

	/**
	 * Utility method to decrypt consumer string
	 * @param encryptedConsumer
	 * @return
	 */
	public Consumer decryptConsumer(String encryptedConsumer) {
		String decryptedConsumer = encryptor.decrypt(encryptedConsumer);
		return JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
	}

	/**
	 * Used for encrypting any of the approved PII String values that can be
	 * logged or audited
	 *
	 * @param piiKey
	 */
	public String encryptString(String piiKey) {
		return encryptor.encrypt(piiKey);
	}

  public String decryptString(String input) { return encryptor.decrypt(input); }
}
