package com.efx.pet.registration.controller.util;

import static org.jsoup.parser.Parser.unescapeEntities;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.safety.Whitelist;
import org.owasp.esapi.ESAPI;
import org.owasp.html.AttributePolicy;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;

public class CleanseUtility {

  public static final PolicyFactory POLICY_FACTORY =
      new HtmlPolicyBuilder().allowCommonBlockElements().allowCommonInlineFormattingElements()
          .allowUrlProtocols("https", "http").allowAttributes("class").onElements("p")
          .allowStyling().allowUrlsInStyles(AttributePolicy.IDENTITY_ATTRIBUTE_POLICY).toFactory();

  /**
   * Add private constructor to prevent autowiring remove in future if we decide to expose
   * non-static methods
   */
  private CleanseUtility() {

  }

  public static String stripXSSVulnerabilities(String content) {
    if (content != null) {
      content = ESAPI.encoder().canonicalize(content);
      content = content.replaceAll("\0", "");

      Document.OutputSettings outputSettings = new Document.OutputSettings();
      outputSettings.escapeMode(Entities.EscapeMode.xhtml);
      outputSettings.prettyPrint(false);
      content = Jsoup.clean(content, "",
          Whitelist.basic().addProtocols("a", "href", "http", "https", "#"), outputSettings);
      return unescapeEntities(POLICY_FACTORY.sanitize(content), true);
    }
    return content;
  }

}
