package com.efx.pet.service.registration.controller;

import static com.efx.pet.service.registration.controller.RestControllerBase.APPLICATION_JSON;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.order.mgmt.OrderMgmtService;
import com.efx.pet.order.mgmt.domain.OrderMgmtException;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse;
import com.efx.pet.order.mgmt.domain.ProductOfferResponse.StatusCode;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author vxc64
 */
@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "ShoppingCartController API", description = "ShoppingCartController - API Contract")
public class ShoppingCartController {

  private static final PetLogger LOGGER =
    PetLoggerFactory.getLogger(ShoppingCartController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "ShoppingCart");

  @Autowired
  private OrderMgmtService orderManagementService;

  @Autowired
  private SessionUtil sessionUtil;

  // TODO in future we need a map of all products with associated product pages. For now just redirecting to main products page
  @Value("${product.page:https://www.equifax.com/personal/products/}")
  private String productPage;

  @Operation(summary = "Returns the StatusCode")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Returns ProductDetails when SKU ID is matched with an existing product configuration", content = {
          @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ProductOfferResponse.class)) }),
      @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
          @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ProductOfferResponse.class)) }) })
  @Deprecated
  @GetMapping(path = "/offer/product", produces = APPLICATION_JSON)
  public ResponseEntity<ProductOfferResponse> getProduct(HttpServletRequest httpServletRequest) {
    final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(AuditConstants.EVENT_SHOPPING_CART_INITIATE, AuditEventStatus.BEGIN,
      "Start - Begin Shopping cart - getProduct", consumerContext);
    ProductOfferResponse offerResponse = null;
    try {
      offerResponse = orderManagementService.getProductBySkuId(consumerContext);
      AUDITOR.recordInfo(AuditConstants.EVENT_SHOPPING_CART_INITIATE, AuditEventStatus.END_SUCCESS, "End - ShoppingCartController - getProduct", consumerContext, null, null, HttpStatus.OK.toString());
      LOGGER.checkBeforeDebugFormat("End - ShoppingCartController - getProduct : {0}", consumerContext.getSkuId());
      return new ResponseEntity<>(offerResponse, offerResponse.getStatusCode().getHttpStatus());
    } catch (OrderMgmtException ex) {
      final String message = "OrderManangementException fetching product details :" + ex.getMessage();
      return logExceptionAndExit(ex, httpServletRequest, consumerContext, message, ex.getStatusCode());
    } catch (Exception ex) {
      final String message = "Unknown exception fetching product details - OrderMgmt.getProduct";
      return logExceptionAndExit(ex, httpServletRequest, consumerContext, message, StatusCode.SYSTEM_ERROR);
    }

  }

  @Operation(summary = "Redirects user to appropriate product information public page")
  @RequestMapping(value = "/redirectToProductPage", method = RequestMethod.GET)
  public RedirectView redirectToProductPage(HttpServletRequest httpServletRequest) {
    final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_TO_PRODUCT_PAGE, AuditEventStatus.BEGIN,
      "Begin redirect to appropriate product information public page.", consumerContext);
    // TODO Logic to relate skuId from consumerContext to a product public page
    AUDITOR.recordInfo(AuditConstants.EVENT_REDIRECT_TO_PRODUCT_PAGE, AuditEventStatus.END_SUCCESS,
      "Now redirecting..", consumerContext, null, null, HttpStatus.FOUND.toString());
    sessionUtil.invalidateSession(httpServletRequest);
    return new RedirectView(productPage);
  }


  private ResponseEntity<ProductOfferResponse> logExceptionAndExit(Exception ex, HttpServletRequest httpServletRequest, ConsumerContext consumerContext, String failureMessage, StatusCode statusCode) {
    ResponseEntity<ProductOfferResponse> responseEntity = new ResponseEntity<>(new ProductOfferResponse(statusCode), statusCode.getHttpStatus());
    LOGGER.error(failureMessage, ex);
    AUDITOR.recordError(AuditConstants.EVENT_SHOPPING_CART_INITIATE, AuditEventStatus.END_FAIL, failureMessage, consumerContext, statusCode.toString(), responseEntity.getStatusCode().toString());
    sessionUtil.invalidateSession(httpServletRequest);
    return responseEntity;
  }
}
