package com.efx.pet.service.registration.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class OAuthConfig {

	@Value("${com.efx.pet.authentication.gateway.credentials.uri.base}")
	private String credentialsUriBase;

	@Value("${com.efx.pet.authentication.oauth.client.id}")
	private String clientId;

	@Value("${com.efx.pet.authentication.oauth.client.secret}")
	private String clientSecret;

	private static final String OAUTH_TOKEN_ENDPOINT = "/pet-authentication-gateway/oauth/token";

	@Bean
	public WebClient webClient() {
		return WebClient.builder().baseUrl(credentialsUriBase + OAUTH_TOKEN_ENDPOINT)
				.defaultHeaders(header -> header.setBasicAuth(clientId, clientSecret))
				.defaultHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded").build();
	}
}
