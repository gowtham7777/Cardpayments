package com.efx.pet.service.registration;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PtpResponse {

    public enum StatusCode {
        INITIATE_PTP_SUCCESS,
        INITIATE_PTP_SYSTEM_ERROR, //http 500
        VALIDATE_PTP_ERROR, //http 400
        VALIDATE_PTP_RECAPTCHA_ERROR,
        VALIDATE_PTP_SUCCESS,
        VALIDATE_PTP_ERROR_RESUBMIT_ALLOWED,
        VALIDATE_PTP_EXPIRE
    }

    private StatusCode statusCode;
    private String transactionId;
    private Byte remainingAttempts;

    public StatusCode getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(StatusCode statusCode) {
        this.statusCode = statusCode;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public PtpResponse(StatusCode statusCode) {
        this.setStatusCode(statusCode);
    }


    public Byte getRemainingAttempts() {
      return remainingAttempts;
    }

    public void setRemainingAttempts(Byte remainingAttempts) {
      this.remainingAttempts = remainingAttempts;
    }

    public PtpResponse(){}


}
