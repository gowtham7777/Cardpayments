package com.efx.pet.service.registration.controller;

import java.util.Calendar;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.RequestMapping;

import com.efx.pet.utility.utils.JsonMapBuilder;

public class RestControllerBase {

	public static final String APPLICATION_JSON= "application/json; charset=utf-8";
	public static final String APPLICATION_XML= "application/xml; charset=utf-8";
	public static final String TEXT_PLAIN= "text/plain; charset=utf-8";
	Calendar calendar = Calendar.getInstance();

    @Operation(hidden = true)
    @RequestMapping("/getStatus/**")
    public String getStatus() throws Exception {
		return new JsonMapBuilder("response").put("status", "ACTIVE").toJson();
	} 
}
