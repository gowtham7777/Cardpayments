package com.efx.pet.service.registration.domain;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by dxl84 on 9/10/2017.
 */
public class OTPConsumer {
	
    private String pin;
    
    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = StringUtils.trimToNull(pin);
    }
}
