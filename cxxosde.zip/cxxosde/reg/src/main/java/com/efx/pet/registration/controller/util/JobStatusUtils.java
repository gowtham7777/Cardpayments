package com.efx.pet.registration.controller.util;

import com.efx.pet.service.registration.EmergencyBreakConstants;
import com.efx.pet.utility.AsyncJobStatus;
import com.efx.pet.utility.AsyncStatus;
import com.efx.pet.utility.cache.Cache;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

@Component
public class JobStatusUtils {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(JobStatusUtils.class);

  @Value("#{cacheProvider.getCache()}")
  Cache cache;

  public AsyncJobStatus createAndAddToCache(String name, Class<?> cls, Properties parameters) {
    AsyncJobStatus jobStatus = new AsyncJobStatus(name, cls.getName());
    jobStatus.setJobParameters(parameters);
    try {
      jobStatus.setMachineName(InetAddress.getLocalHost().getHostName());
    } catch (UnknownHostException e) {
      LOGGER.info("cannot find the computername", e);
    }
    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
    cache.putAsString(EmergencyBreakConstants.JOB_THREAD, jobStatus.getId(), Thread.currentThread().getName());
    return jobStatus;
  }

  public void markAsCompleted(AsyncJobStatus jobStatus) {
    jobStatus.setEndTime(Calendar.getInstance(TimeZone.getTimeZone(EmergencyBreakConstants.TIMEZONE_UTC)));
    jobStatus.setStatus(AsyncStatus.COMPLETED);
    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
    cache.delete(EmergencyBreakConstants.JOB_THREAD, jobStatus.getId());
  }

  public void markAsAborted(AsyncJobStatus jobStatus) {
    jobStatus.setEndTime(Calendar.getInstance(TimeZone.getTimeZone(EmergencyBreakConstants.TIMEZONE_UTC)));
    jobStatus.setStatus(AsyncStatus.ABORTED);
    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
    cache.delete(EmergencyBreakConstants.JOB_THREAD, jobStatus.getId());
  }

  public void markAsInProgress(AsyncJobStatus jobStatus) {
    jobStatus.setStartTime(Calendar.getInstance(TimeZone.getTimeZone(EmergencyBreakConstants.TIMEZONE_UTC)));
    jobStatus.setStatus(AsyncStatus.PROCESSING);
    cache.putAsString(EmergencyBreakConstants.JOB_THREAD, jobStatus.getId(), Thread.currentThread().getName());
    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
  }

  public void update(AsyncJobStatus jobStatus) {
    cache.put(EmergencyBreakConstants.JOB_STATUS, jobStatus.getId(), jobStatus);
  }

  public Map<String, Object> getActiveJobThreads() {
    return cache.entries(EmergencyBreakConstants.JOB_THREAD);
  }

  @PostConstruct
  public void attachShutDownHook() {

    Runtime.getRuntime().addShutdownHook(new Thread() {

      @Override
      public void run() {

        LOGGER.info("executing shutdown!!!!");
        // logic to clean the cache
        if (cache != null) {
          Map<String, Object> activeJobThreads = cache.entries(EmergencyBreakConstants.JOB_THREAD);
          if (activeJobThreads != null && activeJobThreads.size() > 0) {
            markJobsAsAborted(activeJobThreads);
          }
        }
      }
    });
    LOGGER.info("Shut Down Hook Attached");
  }

  private void markJobsAsAborted(Map<String, Object> activeJobThreads) {
    String computerName = null;
    try {
      computerName = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      LOGGER.info("cannot find the computername", e);
    }

    for (Map.Entry<String, Object> entry : activeJobThreads.entrySet()) {
      String jobId = entry.getKey();
      LOGGER.debug("jobId-->> {}", jobId);
      AsyncJobStatus jobStatus = cache.get(EmergencyBreakConstants.JOB_STATUS, jobId, AsyncJobStatus.class);
      if (StringUtils.equals(jobStatus.getMachineName(), computerName)) {
        markAsAborted(jobStatus);
        LOGGER.info("marking job as aborted and deleting from job thread cache :: job Id ::{}", jobId);
      }
    }
  }

}
