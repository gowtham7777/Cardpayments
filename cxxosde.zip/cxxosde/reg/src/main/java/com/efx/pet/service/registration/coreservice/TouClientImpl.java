package com.efx.pet.service.registration.coreservice;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.efx.pet.service.registration.TouResponse;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
@Component
public class TouClientImpl {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(TouClientImpl.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "TouClientImpl", "Service");

    @Autowired
    RestTemplate restTemplate;

    @Value("${termsOfUse.gateway.url}")
    private String serviceURL;
    
    @Value("${termsOfUse.api.key}")
    private String apiKey;

    public TouResponse getTouDetails(String partnerId, String tenantId) {
        if (StringUtils.isBlank(partnerId) || StringUtils.isBlank(tenantId)) {
            LOGGER.error("partnerId or tenantId is null");
            AUDITOR.recordInfo("getTouDetails", AuditEventStatus.BEGIN,
                    "Start - TouClientImpl().getTouDetails() - Retrieving TOU details.");
        }
        try {
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.setContentType(MediaType.APPLICATION_JSON);
            requestHeaders.set("x-api-key", apiKey);

            JSONObject requestBody = new JSONObject();
            requestBody.put("partnerId", partnerId);
            requestBody.put("tenantId", tenantId);

            HttpEntity<String> requestEntity = new HttpEntity<String>(requestBody.toString(), requestHeaders);
            ResponseEntity<TouResponse> responseEntity = restTemplate.exchange(serviceURL, HttpMethod.POST,
                    requestEntity, TouResponse.class);
            if (responseEntity != null) {
                return responseEntity.getBody();
            }

        } catch (final Exception ex) {
            final String message = "Exception in getting TOU details";
            LOGGER.error(message, ex);
            AUDITOR.recordError("getTouDetails", AuditEventStatus.END_FAIL, message);
        }
        return null;
    }
}
