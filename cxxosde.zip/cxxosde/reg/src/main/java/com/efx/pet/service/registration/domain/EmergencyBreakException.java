package com.efx.pet.service.registration.domain;

/**
 * Created by rrk4 on 10/26/2017.
 */
public class EmergencyBreakException extends Exception {
	
	private static final long serialVersionUID = 166889669992250078L;
	
	public EmergencyBreakException(String string) {
		super(string);
	}
}
