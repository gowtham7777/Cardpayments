package com.efx.pet.service.registration.coreservice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.amazonaws.util.StringUtils;
import com.efx.pet.domain.partnertenant.PartnerTenantData;
import com.efx.pet.domain.partnertenant.Settings;
import com.efx.pet.service.client.partnertenant.PartnerTenantLookupServiceClient;
import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.partnertenant.entity.PartnerTenant;
import com.efx.pet.service.partnertenant.operations.PartnerTenantResponse;
import com.efx.pet.service.partnertenant.operations.ServiceResponse;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

@Component
public class PartnerTenantClient {
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(PartnerTenantClient.class);
	private static final String FRONT_END_BUNDLE_LOCATION = "UIBundleLocation";
	private static final String PRINT_TEMPLATE_ID = "printTemplateId";
	private static final String SKU_ID = "skuId";
	private static final String INTENT_LIST = "intentList";
	private static final String INTENT_SPLIT = "\\s*,\\s*";
	protected static final String FRONT_END_BUNDLE_LOCATION_PATTERN = "^..\\/..\\/[A-Z-]{4,10}\\/index.html$";
	private static final String REGISTRATION_SERVICE_KEY = "RegistrationService";
	private static final String CONSUMER_SERVICE_KEY = "ConsumerService";
	private static final String ID_PROOFING_SERVICE_KEY = "IdProofingService";

	@Autowired
	private ApplicationContext applicationContext;

	@Value("${orderFunnel.hostName}")
	private String hostName;

	@Value("${orderFunnel.partnerAlias}")
	private String partnerAlias;

	@Value("${orderFunnel.partnerTenantUrl}")
	private String partnerTenantUrl;

	@Autowired
	private PartnerTenantLookupServiceClient partnerTenantLookupServiceClient;

	private PartnerTenantData partnerTenantData;

	protected String getPartnerAlias() {
		return partnerAlias;
	}

	protected void setPartnerAlias(String partnerAlias) {
		this.partnerAlias = partnerAlias;
	}

	/**
	 * Fetch and saves configuration needed for Registration Spring Boot App from
	 * PartnerTenantLookupServiceClient
	 *
	 * @throws CoreServiceClientException
	 */
	@PostConstruct
	public void init() throws CoreServiceClientException {
		LOGGER.checkBeforeDebugFormat("Start Partner tenant lookup for hostName: {0}, partnerAlias: {1}, partnerTenantUrl:{2}", hostName,
				partnerAlias, partnerTenantUrl);

		try {
			// Call the PartnerTenant Service to get the partner tenant configuration
			partnerTenantLookupServiceClient.setUrl(partnerTenantUrl);
			getPartnerConfig();
		} catch (Exception e) {
			LOGGER.checkBeforeError("Unknown Exception", e);
		}
	}

	/**
	 * Return ConsumerService instance from available eager loaded implementation
	 *
	 * @return
	 * @throws CoreServiceClientException
	 */
	public ConsumerService getConsumerServiceInstance() throws CoreServiceClientException {

		if (isValidCoreServiceMap(partnerTenantData)) {
			LOGGER.checkBeforeDebug("getConsumerServiceInstance: coreServiceBeanMap is null.");
			getPartnerConfig();
		}
		String beanName = partnerTenantData.getCoreServiceMap().get(CONSUMER_SERVICE_KEY);
		if (StringUtils.isNullOrEmpty(beanName)) {
			LOGGER.checkBeforeDebugFormat(
					"No bean name associated to {0} provided within core service bean map configuration.",
					CONSUMER_SERVICE_KEY);
			return null;
		}
		LOGGER.checkBeforeInfoFormat("Loading implementation {0}", applicationContext.getBean(beanName).getClass().getName());
		return (ConsumerService) applicationContext.getBean(beanName);
	}

	/**
	 * Invoke Partner Tenant Client by partnerAlias or hostname
	 *
	 * @throws Exception
	 */
	private void getPartnerConfig() throws CoreServiceClientException {
		PartnerTenantResponse partnerTenantResponse = null;

		try {
			// Search by partnerAlias or hostname
			if (!StringUtils.isNullOrEmpty(partnerAlias)) {
				LOGGER.checkBeforeDebugFormat("Find partner tenant information by partnerAlias: {0}", partnerAlias);
				partnerTenantResponse = partnerTenantLookupServiceClient.findByPartnerAlias(partnerAlias);
			} else if (!StringUtils.isNullOrEmpty(hostName)) {
				LOGGER.checkBeforeDebugFormat("Find partner tenant information by hostName : {0}", hostName);
				partnerTenantResponse = partnerTenantLookupServiceClient.findByHostname(hostName);
			}
		} catch (Exception e) {
			String msg = "Exception thrown in PartnerTenantLookupServiceClient.findByPartnerAlias";
			LOGGER.checkBeforeError(msg, e);
			throw new CoreServiceClientException(msg);
		}

		if (partnerTenantResponse != null
				&& partnerTenantResponse.getServiceStatus() == ServiceResponse.Status.SUCCESS) {
			mapPartnerTenantResponse(partnerTenantResponse);
		} else {
			String message = "Invalid or null response from PartnerTenantLookupServiceClient.";
			LOGGER.checkBeforeError(message);
			throw new CoreServiceClientException(message);
		}
	}

	private void mapPartnerTenantResponse(PartnerTenantResponse partnerTenantResponse) throws CoreServiceClientException {
		LOGGER.checkBeforeDebugFormat("Search result : {0}", JsonUtils.toJson(partnerTenantResponse));
		List<PartnerTenant> partnerTenants = partnerTenantResponse.getPartnerTenants();
		// Get core service Map, one unique entry expected per partnerAlias || hostName
		if (partnerTenants != null && !partnerTenants.isEmpty()) {
			PartnerTenant partnerTenant = partnerTenants.get(0);
			mapPartnerTenantData(partnerTenant);
		}
	}

	private void mapPartnerTenantData(PartnerTenant partnerTenant) throws CoreServiceClientException {
		if (partnerTenant == null) {
			LOGGER.checkBeforeErrorFormat("Unable to map response attributes, received null in response, {0}",
					partnerTenant);
			return;
		}
		partnerTenantData = new PartnerTenantData();
		partnerTenantData.setCoreServiceMap(partnerTenant.getCoreServices());
		partnerTenantData.setPartnerId(partnerTenant.getPartnerId());
		partnerTenantData.setTenantId(partnerTenant.getTenantId());
		partnerTenantData.setId(partnerTenant.getId());
		partnerTenantData.setDefaultLocale(partnerTenant.getDefaultLocale());
		partnerTenantData.setSupportedLocales(partnerTenant.getSupportedLocales());
		partnerTenantData.setSettings(mapSettingData(partnerTenant.getSettings()));
	}

	private Settings mapSettingData(Map<String, String> settingMap) throws CoreServiceClientException {

		if(settingMap == null || settingMap.isEmpty()) {
			throw new CoreServiceClientException("Invalid entry, received null/empty settingsMap, UIBundleLocation is a mandatory attribute");
		}
		Settings settings = new Settings();
		settings.setPrintTemplateId(settingMap.get(PRINT_TEMPLATE_ID));
		settings.setUiBundleLocation(settingMap.get(FRONT_END_BUNDLE_LOCATION));
		if(settingMap.containsKey(SKU_ID) && !StringUtils.isNullOrEmpty(settingMap.get(SKU_ID))) {
			settings.setSkuId(settingMap.get(SKU_ID));
		}
		if(settingMap.containsKey(INTENT_LIST) && !StringUtils.isNullOrEmpty(settingMap.get(INTENT_LIST))) {
			String[] commaSeparatedArr = settingMap.get(INTENT_LIST).split(INTENT_SPLIT);
			settings.setIntentList(Arrays.stream(commaSeparatedArr).collect(Collectors.toList()));
		}
		return settings;
	}

	public PartnerTenantData getPartnerTenantData() {
		return partnerTenantData;
	}

	public Settings getSettings() {
		return partnerTenantData.getSettings();
	}

	public String getFrontEndBundleLocation() throws CoreServiceClientException {
		if (isSettingsNull(partnerTenantData)) {
			LOGGER.checkBeforeDebug("getFrontEndBundleLocation: settingsMap is null.");
			getPartnerConfig();
		}
		String frontEndBundleLocationConfig = partnerTenantData.getSettings().getUiBundleLocation();
		if (StringUtils.isNullOrEmpty(frontEndBundleLocationConfig)
				|| !isValidBundleLocation(FRONT_END_BUNDLE_LOCATION_PATTERN, frontEndBundleLocationConfig)) {
			throw new CoreServiceClientException(
					FRONT_END_BUNDLE_LOCATION + " is not defined or invalid pattern in PartnerTenantLookup.");
		} else {
			return frontEndBundleLocationConfig;
		}
	}

	protected boolean isValidBundleLocation(String frontEndBundleLocationPattern, String frontEndBundleLocation) {
		Pattern pattern = Pattern.compile(frontEndBundleLocationPattern);
		Matcher matcher = pattern.matcher(frontEndBundleLocation);
		if (matcher.matches()) {
			LOGGER.checkBeforeDebug("Front End Bundle Location from Partner Tenant Lookup is a valid pattern.");
			return true;
		} else {
			LOGGER.checkBeforeError("Front End Bundle Location from Partner Tenant Lookup is not a valid pattern.");
			return false;
		}
	}

	/**
	 * Return RegistrationService instance from available eager loaded
	 * implementation
	 *
	 * @return
	 * @throws CoreServiceClientException
	 */
	public RegistrationService getRegistrationServiceInstance() throws CoreServiceClientException {

		if (isValidCoreServiceMap(partnerTenantData)) {
			LOGGER.checkBeforeDebug("getRegistrationServiceInstance: coreServiceBeanMap is null.");
			getPartnerConfig();
		}
		String beanName = partnerTenantData.getCoreServiceMap().get(REGISTRATION_SERVICE_KEY);
		if (StringUtils.isNullOrEmpty(beanName)) {
			LOGGER.checkBeforeDebugFormat(
					"No bean name associated to {0} provided within core service bean map configuration.",
					REGISTRATION_SERVICE_KEY);
			return null;
		}
		LOGGER.checkBeforeInfoFormat("Loading {0}", applicationContext.getBean(beanName).getClass().getName());
		return (RegistrationService) applicationContext.getBean(beanName);
	}

	/**
	 * Return IdProofingService instance from available eager loaded implementation
	 *
	 * @return
	 * @throws CoreServiceClientException
	 */
	public IdProofingService getIdProofingServiceInstance() throws CoreServiceClientException {

		if (isValidCoreServiceMap(partnerTenantData)) {
			LOGGER.checkBeforeDebug("getIdProofingServiceInstance: coreServiceBeanMap is null.");
			getPartnerConfig();
		}
		String beanName = partnerTenantData.getCoreServiceMap().get(ID_PROOFING_SERVICE_KEY);
		if (StringUtils.isNullOrEmpty(beanName)) {
			LOGGER.checkBeforeDebugFormat(
					"No bean name associated to {0} provided within core service bean map configuration.",
					ID_PROOFING_SERVICE_KEY);
			return null;
		}
		LOGGER.checkBeforeInfoFormat("Loading {0}", applicationContext.getBean(beanName).getClass().getName());
		return (IdProofingService) applicationContext.getBean(beanName);
	}

	private boolean isSettingsNull(PartnerTenantData partnerTenantData) {
		return partnerTenantData == null || partnerTenantData.getSettings() == null;
	}

	private boolean isValidCoreServiceMap(PartnerTenantData partnerTenantData) {
		return partnerTenantData == null || partnerTenantData.getCoreServiceMap() == null || partnerTenantData.getCoreServiceMap().isEmpty();
	}
}
