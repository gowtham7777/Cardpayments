package com.efx.pet.service.registration.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.PoliciesResponse;
import com.efx.pet.domain.ServiceResponse;
import com.efx.pet.service.policies.PoliciesService;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "PolicyController", description = "Policy Operations")
public class PolicyController {
	
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(PolicyController.class);
	private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "termsOfUsePolicies");	
    
    @Autowired
    PoliciesService policiesService;

	/**
	 * End point to Fetch Latest Policies
	 * @param httpRequest
	 * @return
	 */
    @Operation(summary = "Returns the Get Latest Policies ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns status when Get Policies successful", content = {
					@Content(schema = @Schema(implementation = PoliciesResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = PoliciesResponse.class)) }) })
	@GetMapping(value="/policies", produces = RegistrationConstants.APPLICATION_JSON)
	public ResponseEntity<PoliciesResponse> getLatestPolicies(HttpServletRequest httpRequest) { 
    	long startTime = System.currentTimeMillis();
		
    	ConsumerContext consumerContext = null;
		PoliciesResponse response = null;
	    try {
	    	consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
		    AUDITOR.recordInfo(AuditConstants.EVENT_GET_LATEST_POLICY, AuditEventStatus.BEGIN, "Start - Policy Controller - get Policy Details", consumerContext);
			response = policiesService.getLatestPolicies(consumerContext.getConversationId());
			AUDITOR.recordInfo(AuditConstants.EVENT_GET_LATEST_POLICY, response.getHttpStatus().is2xxSuccessful() ? AuditEventStatus.END_SUCCESS : AuditEventStatus.END_FAIL, 
					"End - Policy Controller - get Policy Details", consumerContext, null, response.getServiceStatus().toString(), response.getHttpStatus().toString(), Long.toString(startTime));
			response.setHtmlAllowed(true);
			return new ResponseEntity<>(response, response.getHttpStatus());			
	    } catch(Exception ex) {
	    	String message = "unable to fetch policy details";
	    	LOGGER.error(message, ex);
	    	response = new PoliciesResponse();
	    	response.setOperationStatus(ServiceResponse.Status.ERROR);
	    	response.setOperationMessage(message); 
	    	AUDITOR.recordInfo(AuditConstants.EVENT_GET_LATEST_POLICY, AuditEventStatus.END_FAIL, 
	    			"End - Policy Controller - get Policy Details", consumerContext, null,
					ServiceResponse.Status.ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString(), Long.toString(startTime));
	    	return new ResponseEntity<>(response , HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
		
}

