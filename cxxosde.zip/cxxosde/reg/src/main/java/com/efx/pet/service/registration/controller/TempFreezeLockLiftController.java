package com.efx.pet.service.registration.controller;

import javax.servlet.http.HttpServletRequest;

import com.efx.pet.domain.LiftMaskedConsumer;
import com.efx.pet.domain.LiftMaskedResponse;
import com.efx.pet.domain.LiftResponse;
import com.efx.pet.domain.LiftInfoResponse;
import com.efx.pet.service.lift.LiftService;
import com.efx.pet.utility.QueryParamEnums;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.ServiceResponse;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "TempFreezeLockLiftController", description = "Temporary Lift of Credit File Lock or Freeze")
public class TempFreezeLockLiftController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(TempFreezeLockLiftController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "tempFreezeLockLift");

  @Autowired
  LiftService liftService;

  /**
   * End point to Fetch Masked Consumer Details from the Lift Service
   * @param httpRequest - simple request object
   * @return a ResponseEntity with a LiftResponse in it - holds the Consumer object with masked data
   */
  @Operation(summary = "Returns the Masked Consumer Details")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Returns Consumer when Get Masked Consumer successful", content = {
      @Content(schema = @Schema(implementation = LiftResponse.class)) }),
    @ApiResponse(responseCode = "204", description = "Response from Lift service was empty", content = {
      @Content(schema = @Schema(implementation = LiftResponse.class)) }),
    @ApiResponse(responseCode = "404", description = "Lift Consumer not found", content = {
      @Content(schema = @Schema(implementation = LiftResponse.class)) }),
    @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
      @Content(schema = @Schema(implementation = LiftResponse.class)) }) })
  @GetMapping(value="/lift-consumer-masked", produces = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<LiftMaskedResponse> getMaskedConsumer(HttpServletRequest httpRequest) {
    long startTime = System.currentTimeMillis();

    ConsumerContext consumerContext = null;
    LiftMaskedResponse response;
    try {
      consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
      AUDITOR.recordInfo(AuditConstants.EVENT_GET_MASKED_CONSUMER, AuditEventStatus.BEGIN, "Start - Lift Controller - get Masked Consumer Details", consumerContext);
      response = liftService.getMaskedConsumer(consumerContext.getQueryParamsMap().get(QueryParamEnums.LIFTID.value()));
      AUDITOR.recordInfo(AuditConstants.EVENT_GET_MASKED_CONSUMER, response.getHttpStatus().is2xxSuccessful() ? AuditEventStatus.END_SUCCESS : AuditEventStatus.END_FAIL,
        "End - Lift Controller - get Masked Consumer Details", consumerContext,null, response.getServiceStatus().toString(), response.getHttpStatus().toString(), Long.toString(startTime));
      return new ResponseEntity<>(response, response.getHttpStatus());
    } catch(Exception ex) {
      String message = "unable to fetch Masked Consumer details";
      LOGGER.error(message, ex);
      response = new LiftMaskedResponse();
      response.setConsumer(new LiftMaskedConsumer());
      response.getConsumer().setSsn(null);
      response.setOperationStatus(ServiceResponse.Status.ERROR);
      response.setOperationMessage(message);
      AUDITOR.recordError(AuditConstants.EVENT_GET_MASKED_CONSUMER, AuditEventStatus.END_FAIL,
        "End - Lift Controller - get Masked Consumer Details", consumerContext, null,
        ServiceResponse.Status.ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString(), Long.toString(startTime));
      return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * End point to Fetch non-Consumer Lift Details from the Lift Service
   * @param httpRequest - simple request object
   * @return a ResponseEntity with a LiftInfoResponse in it - holds the Consumer object
   */
  @Operation(summary = "Returns the Consumer Details")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Returns Lift details when Get Lift Info successful", content = {
      @Content(schema = @Schema(implementation = LiftInfoResponse.class)) }),
    @ApiResponse(responseCode = "204", description = "Response from Lift service was empty", content = {
      @Content(schema = @Schema(implementation = LiftInfoResponse.class)) }),
    @ApiResponse(responseCode = "404", description = "Lift record not found", content = {
      @Content(schema = @Schema(implementation = LiftInfoResponse.class)) }),
    @ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
      @Content(schema = @Schema(implementation = LiftInfoResponse.class)) }) })
  @GetMapping(value="/lift-info", produces = RegistrationConstants.APPLICATION_JSON)
  public ResponseEntity<LiftInfoResponse> getLiftInfo(HttpServletRequest httpRequest) {
    long startTime = System.currentTimeMillis();

    ConsumerContext consumerContext = null;
    LiftInfoResponse response;
    try {
      consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
      AUDITOR.recordInfo(AuditConstants.EVENT_GET_LIFT_INFO, AuditEventStatus.BEGIN, "Start - Lift Controller - get Lift record details", consumerContext);
      response = liftService.getLiftInfo(consumerContext.getQueryParamsMap().get(QueryParamEnums.LIFTID.value()));
      AUDITOR.recordInfo(AuditConstants.EVENT_GET_LIFT_INFO, response.getHttpStatus().is2xxSuccessful() ? AuditEventStatus.END_SUCCESS : AuditEventStatus.END_FAIL,
        "End - Lift Controller - get Lift record details", consumerContext,null, response.getServiceStatus().toString(), response.getHttpStatus().toString(), Long.toString(startTime));
      return new ResponseEntity<>(response, response.getHttpStatus());
    } catch(Exception ex) {
      String message = "unable to fetch Consumer details";
      LOGGER.error(message, ex);
      response = new LiftInfoResponse();
      response.setOperationStatus(ServiceResponse.Status.ERROR);
      response.setOperationMessage(message);
      AUDITOR.recordError(AuditConstants.EVENT_GET_LIFT_INFO, AuditEventStatus.END_FAIL,
        "End - Lift Controller - get Lift record Details", consumerContext, null,
        ServiceResponse.Status.ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString(), Long.toString(startTime));
      return new ResponseEntity<>(response , HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
