package com.efx.pet.service.registration.domain;

import java.util.List;
import java.util.regex.Pattern;

import com.efx.pet.domain.KbaQuizAnswer;

/**
 * Created by rrk4 on 11/14/2017.
 */
public class KbaRequest {
	
	private String quizIdentifier;
	private List<KbaQuizAnswer> answers;
	
	public String getQuizIdentifier() {
		return quizIdentifier;
	}
	
	public void setQuizIdentifier(String quizIdentifier) throws Exception {
		if(Pattern.compile("^[0-9]$").matcher(quizIdentifier).matches()) {
			this.quizIdentifier = quizIdentifier;
		} else {
			throw new Exception("Invalid quizIdentifier: " + quizIdentifier);
		}
	}

	public List<KbaQuizAnswer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<KbaQuizAnswer> answers) {
		this.answers = answers;
	}
}
