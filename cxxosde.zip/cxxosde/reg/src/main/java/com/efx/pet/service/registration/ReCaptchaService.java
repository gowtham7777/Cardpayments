package com.efx.pet.service.registration;


import java.text.MessageFormat;
import java.util.Collection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by dxl84 on 9/5/2017.
 *
 * Edited by sxp362 on 11/21/2017.
 */
@Service
public class ReCaptchaService {

    private static final String SECRET_PARAM = "secret";
    private static final String RESPONSE_PARAM = "response";
    private static final String REMOTE_IP = "remoteip";

    private static class ReCaptchaResponse {

        @JsonProperty("success")
        private boolean success;

        @JsonProperty("error-codes")
        private Collection<String> errorCodes;

        @Override
        public String toString() {
            return "ReCaptchaResponse{" +
                    "success=" + success +
                    ", errorCodes=" + errorCodes +
                    '}';
        }
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(ReCaptchaService.class);

    private final RestTemplate restTemplate;

    @Value("${recaptcha.url}")
    private String recaptchaUrl;

    @Value("${recaptcha.secret-key}")
    private String recaptchaSecretKey;

    @Autowired
    public ReCaptchaService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    	LOGGER.info("Recaptcha Url: {}", recaptchaUrl);
    }

    public boolean isResponseValid(String remoteIp, String response) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Validating captcha response for remoteIp={}, response={}", remoteIp, response);
        }

        // TODO what if response is null?
        boolean captchaResponseValidationResult = false;

        ReCaptchaResponse recaptchaResponse = null;

        try {

            recaptchaResponse = restTemplate.postForEntity(
                    recaptchaUrl, createBody(recaptchaSecretKey, remoteIp, response), ReCaptchaResponse.class)
                    .getBody();
        } catch (RestClientException e) {
            LOGGER.error("Recaptcha API not available exception: {}",e.getMessage());
        }

        if (LOGGER.isDebugEnabled()) {
            final String logMessage = MessageFormat.format("recaptchaResponse={0}", recaptchaResponse);
            LOGGER.debug(logMessage);
        }

        if (recaptchaResponse != null && recaptchaResponse.success) {
            captchaResponseValidationResult = true;
        }
        LOGGER.debug("Captcha response validation result: {}", captchaResponseValidationResult);
        return captchaResponseValidationResult;
    }

    private MultiValueMap<String, String> createBody(String secret, String remoteIp, String response) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add(SECRET_PARAM, secret);
        form.add(REMOTE_IP, remoteIp);
        form.add(RESPONSE_PARAM, response);
        return form;
    }

}
