package com.efx.pet.service.registration.domain;

import java.util.EnumMap;
import java.util.Map;

import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import com.efx.domain.sso.SingleSignOnDetails;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Response Entity for Single Sign On Details Response
 * @author vxc64
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SingleSignOnResponse {

	private StatusCode statusCode;

	private SingleSignOnDetails singleSignOnDetails;

	public SingleSignOnResponse(@JsonProperty("statusCode") final StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Http Status contract for request response (one-to-one mapping)
	 * @author vxc64
	 *
	 */
	public enum StatusCode {
		SSO_TOKEN_GENERATION_SUCCESS(HttpStatus.OK),
		SSO_VALIDATION_ERROR(HttpStatus.BAD_REQUEST),
		SSO_SYSTEM_ERROR(HttpStatus.INTERNAL_SERVER_ERROR);

		private HttpStatus httpStatus;
		private static final Map<HttpStatus, StatusCode> SSO_STATUS_MAP = new EnumMap<>(HttpStatus.class);

		static {
			for (StatusCode statusCode : values()) {
				SSO_STATUS_MAP.put(statusCode.getHttpStatus(), statusCode);
			}
		}

		StatusCode(HttpStatus httpStatus) {
			this.httpStatus = httpStatus;
		}

		public HttpStatus getHttpStatus() {
			return httpStatus;
		}

		public static StatusCode getStatusCodeByValue(HttpStatus httpStatus) {
			return SSO_STATUS_MAP.get(httpStatus);
		}
	}
}
