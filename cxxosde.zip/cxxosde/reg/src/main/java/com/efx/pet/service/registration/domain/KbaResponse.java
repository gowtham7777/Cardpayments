package com.efx.pet.service.registration.domain;

import java.util.List;

import com.efx.pet.domain.KbaQuiz;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by rrk4 on 10/26/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KbaResponse {

	public enum StatusCode {
		KBA_QUIZ_SUCCESS,
		KBA_QUIZ_ERROR,
        VALIDATION_ERROR,
		KBA_SUBMIT_ANSWERS_SUCCESS,
		KBA_SUBMIT_ANSWERS_ERROR,
		KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT,
		KBA_SUBMIT_ANSWERS_SYSTEM_ERROR,
		PIN_TO_POST_ELIGIBLE,
		PIN_TO_POST_PRIMARY,
		PIN_TO_POST_SECONDARY,
		KBA_SUCCESS_ELIGIBILITY_FAIL,
		KBA_GET_QUIZ_SUCCESS_OTP_PIN_RETRY_MAX,
        KBA_GET_QUIZ_SUCCESS_OTP_PIN_INITIATION_FAIL,
        KBA_GET_QUIZ_SUCCESS_OTP_PIN_VALIDATION_FAIL_UNKNOWN,
        KBA_FAILURE_ELIGIBILITY_FAIL,
        PTP_ELIGIBILITY_FAIL
        
	}

	private StatusCode statusCode;
	private String quizIdentifier;
	private List<KbaQuiz> questions;
	private String destinationUrl;

	public StatusCode getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	public String getQuizIdentifier() {
		return quizIdentifier;
	}

	public void setQuizIdentifier(String quizIdentifier) {
		this.quizIdentifier = quizIdentifier;
	}

	public List<KbaQuiz> getQuestions() {
		return questions;
	}

	public void setQuestions(List<KbaQuiz> questions) {
		this.questions = questions;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	public void setDestinationUrl(String destinationUrl) {
		this.destinationUrl = destinationUrl;
	}

	// Default constructor for use with serialization
	public KbaResponse(){}

	public KbaResponse(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

    @Override
    public String toString() {
	    //TODO legally allowed to append questions?
        return new StringBuilder()
            .append("Status Code :").append(getStatusCode())
            .append(", Quiz Identifier :").append(getQuizIdentifier())
            .append(", Destination URL :").append(getDestinationUrl())
            .toString();
    }
}
