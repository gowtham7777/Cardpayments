package com.efx.pet.service.registration.domain;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by pxp250 on 8/21/2019.
 */
public class EnrollOTPRequest {
	
    private String pinType;
    
    public String getPinType() {
        return pinType;
    }

    public void setPinType(String pinType) {
        this.pinType = StringUtils.trimToNull(pinType);
    }
}
