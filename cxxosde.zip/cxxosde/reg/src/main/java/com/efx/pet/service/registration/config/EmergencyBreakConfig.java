package com.efx.pet.service.registration.config;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;


@Configuration
@EnableAsync
public class EmergencyBreakConfig extends AsyncConfigurerSupport{

	private final String ASYNC_THREAD_PREFIX = "LockAlerts-Thread-";

	@Value("${com.efx.pet.feature.emergencyBreak.core.pool.size}")
	private int emergencyBreakCorePoolSize;

	@Value("${com.efx.pet.feature.emergencyBreak.max.pool.size}")
	private int emergencyBreakMaxPoolSize;

	@Value("${com.efx.pet.feature.emergencyBreak.queue.capacity}")
	private int emergencyBreakQueueCapacity;


	@Override
	@Bean(name = "threadPoolExecutor")
    public Executor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	    executor.setCorePoolSize(emergencyBreakCorePoolSize);
	    executor.setMaxPoolSize(emergencyBreakMaxPoolSize);
	    executor.setQueueCapacity(emergencyBreakQueueCapacity);
	    executor.setThreadNamePrefix(ASYNC_THREAD_PREFIX);
	    executor.initialize();
	    return executor;
	}

}
