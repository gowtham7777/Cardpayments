package com.efx.pet.service.registration.config;

import java.util.Collections;

import com.efx.pet.service.registration.cookie.CustomSessionCookieConfig;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.FlushMode;
import org.springframework.session.SaveMode;
import org.springframework.session.data.redis.RedisIndexedSessionRepository;
import org.springframework.session.data.redis.config.annotation.SpringSessionRedisConnectionFactory;
import org.springframework.session.data.redis.config.annotation.web.http.RedisHttpSessionConfiguration;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

import javax.servlet.ServletContext;

/**
 * Class was designed to address an issue
 * https://github.com/spring-projects/spring-session/issues/124
 * ERR unknown command 'CONFIG' when using Secured Redis
 *
 * We have to customize the default RedisHttpSessionConfiguration implementation
 * and use @Import this class to the SpringBootApplication
 * */
@Configuration
public class CustomRedisHttpSessionConfiguration extends RedisHttpSessionConfiguration {

  private RedisConnectionFactory redisConnectionFactory;

  private FlushMode flushMode = FlushMode.ON_SAVE;

	private SaveMode saveMode = SaveMode.ON_SET_ATTRIBUTE;

  private RedisSerializer<Object> defaultRedisSerializer;

  @Value("${session.expiration:900}")
  private Integer maxInactiveIntervalInSeconds;

  @Autowired
  @Override
  public void setRedisConnectionFactory(
          @SpringSessionRedisConnectionFactory ObjectProvider<RedisConnectionFactory> springSessionRedisConnectionFactory,
          ObjectProvider<RedisConnectionFactory> redisConnectionFactory) {
    RedisConnectionFactory redisConnectionFactoryToUse = springSessionRedisConnectionFactory.getIfAvailable();
    if (redisConnectionFactoryToUse == null) {
        redisConnectionFactoryToUse = redisConnectionFactory.getObject();
    }
    this.redisConnectionFactory = redisConnectionFactoryToUse;
  }

  @Autowired(required = false)
  @Qualifier("springSessionDefaultRedisSerializer")
  @Override
  public void setDefaultRedisSerializer(RedisSerializer<Object> defaultRedisSerializer) {
    this.defaultRedisSerializer = defaultRedisSerializer;
  }

  @Override
  public InitializingBean enableRedisKeyspaceNotificationsInitializer() {
      return null;
  }

  @Override
  public void setImportMetadata(AnnotationMetadata importMetadata) {
    //we do not want to set anything in a current implementation
  }

  @Bean
  @Override
  public RedisIndexedSessionRepository sessionRepository() {
    RedisTemplate<Object, Object> redisTemplate = createCustomRedisTemplate();
    RedisIndexedSessionRepository sessionRepository = new RedisIndexedSessionRepository(redisTemplate);
    sessionRepository.setDefaultMaxInactiveInterval(this.maxInactiveIntervalInSeconds);
    sessionRepository.setFlushMode(this.flushMode);
    sessionRepository.setSaveMode(this.saveMode);
    return sessionRepository;
  }

  @Bean
  @Override
  public RedisMessageListenerContainer springSessionRedisMessageListenerContainer(
          RedisIndexedSessionRepository sessionRepository) {
    RedisMessageListenerContainer container = new RedisMessageListenerContainer();
    container.setConnectionFactory(this.redisConnectionFactory);
    container.addMessageListener(sessionRepository,
            Collections.singletonList(new PatternTopic(sessionRepository.getSessionCreatedChannelPrefix() + "*")));
    return container;
  }

  private RedisTemplate<Object, Object> createCustomRedisTemplate() {
    RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setHashKeySerializer(new StringRedisSerializer());
    if (this.defaultRedisSerializer != null) {
      redisTemplate.setDefaultSerializer(this.defaultRedisSerializer);
    }
    redisTemplate.setConnectionFactory(this.redisConnectionFactory);
    redisTemplate.afterPropertiesSet();
    return redisTemplate;
  }

  @Bean
  public CookieSerializer cookieSerializer(ServletContext servletContext, CustomSessionCookieConfig sessionCookieConfig) {
    DefaultCookieSerializer cookieSerializer = new DefaultCookieSerializer();
    if (servletContext != null && sessionCookieConfig != null) {
      if (sessionCookieConfig.getName() != null)
        cookieSerializer.setCookieName(sessionCookieConfig.getName());
      if (sessionCookieConfig.getDomain() != null)
        cookieSerializer.setDomainName(sessionCookieConfig.getDomain());
      if (sessionCookieConfig.getPath() != null)
        cookieSerializer.setCookiePath(sessionCookieConfig.getPath());
      if (sessionCookieConfig.getMaxAge() != -1)
        cookieSerializer.setCookieMaxAge(sessionCookieConfig.getMaxAge());

      cookieSerializer.setUseSecureCookie(sessionCookieConfig.isSecure());
      cookieSerializer.setUseBase64Encoding(sessionCookieConfig.isUseBase64Encoding());
      cookieSerializer.setUseHttpOnlyCookie(sessionCookieConfig.isHttpOnly());
      cookieSerializer.setSameSite(sessionCookieConfig.getSameSite());
    }
    return cookieSerializer;
  }
}
