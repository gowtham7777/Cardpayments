package com.efx.pet.service.registration;

public class EmergencyBreakConstants {

	public static final String JOB_STATUS = "JOB_STATUS";
	public static final String JOB_THREAD = "JOB_THREAD";
	public static final String TIMEZONE_UTC = "UTC";
	public static final String CACHE_KEY_EMERGENCY_BRAKE = "emergencyBreak";
	public static final String CACHE_PARAM_NUMBER_OF_MESSAGES = "numberOfMessages";
}
