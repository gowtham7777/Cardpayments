package com.efx.pet.service.registration.config;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.efx.pet.client.customer.CustomerServiceClient;
import com.efx.pet.client.eligibility.EligibilityServiceClient;
import com.efx.pet.service.client.indirectenrollment.IndirectEnrollmentServiceClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

/**
 * Central configuration for all (micro) service clients, where necessary
 *
 * @author rrk4
 *
 */
@Configuration
public class ServiceClientsConfig {
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(ServiceClientsConfig.class);

	@Value("${com.efx.pet.indirect.enrollment.service.url}")
	private String indirectServiceClientUrl;

	@Value("${com.efx.pet.customer.service.url}")
	private String customerServiceClientUrl;

	@Value("${orderFunnel.eligibilityService.url}")
	private String eligibilityServiceClientUrl;

	@Autowired
	private IndirectEnrollmentServiceClient indirectEnrollmentServiceClient;

	@Autowired
	private CustomerServiceClient customerServiceClient;

	@Autowired
	private EligibilityServiceClient eligibilityServiceClient;

	@PostConstruct
	private void init() throws CoreServiceClientException {
		if (StringUtils.isBlank(indirectServiceClientUrl)) {
			throw new CoreServiceClientException("Indirect Enrollment Service Client url is missing.");
		}
		LOGGER.checkBeforeDebugFormat("indirectServiceClientUrl: {0}", indirectServiceClientUrl);
		indirectEnrollmentServiceClient.setUrl(indirectServiceClientUrl);
		if (StringUtils.isBlank(customerServiceClientUrl)) {
			throw new CoreServiceClientException("Customer Service Client url is missing.");
		}
		LOGGER.checkBeforeDebugFormat("customerServiceClientUrl: {0}", customerServiceClientUrl);
		customerServiceClient.setUrl(customerServiceClientUrl);
		if (StringUtils.isBlank(eligibilityServiceClientUrl)) {
			throw new CoreServiceClientException("Eligibility Service Client url is missing.");
		}
		LOGGER.checkBeforeDebugFormat("eligibilityServiceClientUrl: {0}", eligibilityServiceClientUrl);
		eligibilityServiceClient.setUrl(eligibilityServiceClientUrl);
	}
}
