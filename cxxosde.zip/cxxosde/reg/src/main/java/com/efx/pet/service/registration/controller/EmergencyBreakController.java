package com.efx.pet.service.registration.controller;

import com.efx.pet.registration.controller.util.JobStatusUtils;
import com.efx.pet.service.registration.CreateAccountResponse;
import com.efx.pet.service.registration.EmergencyBreakConstants;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.service.registration.controller.processor.EmergencyBreakProcessor;
import com.efx.pet.utility.AsyncJobStatus;
import com.efx.pet.utility.cache.Cache;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logger.LoggingUtil;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.efx.pet.utility.utils.JsonUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.web.bind.annotation.*;

import java.text.MessageFormat;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "EmergencyBreakController", description = "emergency break process")
public class EmergencyBreakController {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(EmergencyBreakController.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "EmergencyBreak");

	@Value("#{cacheProvider.getCache()}")
	Cache cache;

	JobStatusUtils jobStatusUtils;

	EmergencyBreakProcessor emergencyBreakProcessor;

	@Autowired
	public EmergencyBreakController (JobStatusUtils jobStatusUtils, EmergencyBreakProcessor emergencyBreakProcessor){
		this.jobStatusUtils = jobStatusUtils;
		this.emergencyBreakProcessor = emergencyBreakProcessor;
	}

	/**
	 * This method is used to send create account data message to emergency
	 * break queue
	 * @param numberOfMessagesToProcess
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Trigger emergency break job with certain number of messages")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns a success confirmation", content = {@Content(schema = @Schema(implementation = CreateAccountResponse.class))}),
			@ApiResponse(responseCode = "400", description = "Required fields missing", content = {@Content(schema = @Schema(implementation = CreateAccountResponse.class))}),
			@ApiResponse(responseCode = "500", description = "System Error", content = {@Content(schema = @Schema(implementation = CreateAccountResponse.class))})})
	@RequestMapping(value = "/processEmergencyBreakQueue", method = RequestMethod.GET, produces = RegistrationConstants.APPLICATION_JSON, consumes = RegistrationConstants.APPLICATION_JSON)
	@ResponseBody
	public Future<String> processMessages(@RequestParam int numberOfMessagesToProcess)
			throws Exception {
    AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_PROCESS_MESSAGES, AuditEventStatus.BEGIN, "Begin processing Emergency Break Queue messages.");

    Properties parameters = new Properties();
		parameters.setProperty(EmergencyBreakConstants.CACHE_PARAM_NUMBER_OF_MESSAGES, String.valueOf(numberOfMessagesToProcess));
		AsyncJobStatus jobStatus = jobStatusUtils.createAndAddToCache(EmergencyBreakConstants.CACHE_KEY_EMERGENCY_BRAKE, EmergencyBreakController.class,
				parameters);
		String message = MessageFormat.format("Begin processing messages. Number of messages to process: {0}, Job status: {1}.", numberOfMessagesToProcess, jobStatus.toString());
    AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_PROCESS_MESSAGES, AuditEventStatus.IN_PROGRESS, message);
    emergencyBreakProcessor.process(numberOfMessagesToProcess, jobStatus);
    AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_PROCESS_MESSAGES, AuditEventStatus.END_SUCCESS, "Finished processing Emergency Break Queue messages.");
    return new AsyncResult<String>(JsonUtils.toJson(jobStatus));
	}

	@RequestMapping(value = "/getJobStatus", method = RequestMethod.GET, produces = RegistrationConstants.APPLICATION_JSON)
	@ResponseBody
	public Future<String> getAsyncJobStatus(@RequestParam String jobId) throws Exception {
	  String message = MessageFormat.format("Begin getting Emergency Break job status. Job ID: {0}.", jobId);
    AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_GET_JOB_STATUS, AuditEventStatus.BEGIN, message);
    AsyncJobStatus jobStatus = cache.get(EmergencyBreakConstants.JOB_STATUS, jobId, AsyncJobStatus.class);
		if (jobStatus == null) {
		  message = MessageFormat.format("Invalid jobId: {0}. Job status is null.", jobId);
		  Exception exception = new Exception(message);
		  LOGGER.error(LoggingUtil.sanitizeLoggedMessage(message), exception);
      AUDITOR.recordError(AuditConstants.EVENT_EBREAK_GET_JOB_STATUS, AuditEventStatus.END_FAIL, message);
      throw new Exception("Invalid jobId");
		}
    message = MessageFormat.format("Successfully got Emergency Break job status. Job ID: {0}, Job status: {1}", jobId, jobStatus);
    AUDITOR.recordInfo(AuditConstants.EVENT_EBREAK_GET_JOB_STATUS, AuditEventStatus.END_SUCCESS, message);
    return new AsyncResult<String>(JsonUtils.toJson(jobStatus));
	}

	@RequestMapping(value = "/getActiveJobThreads", method = RequestMethod.GET, produces = RegistrationConstants.APPLICATION_JSON)
	@ResponseBody
	public Future<String> getActiveJobThreads() {
		Map<String, Object> map = jobStatusUtils.getActiveJobThreads();
		return new AsyncResult<String>(JsonUtils.toJson(map));
	}

}
