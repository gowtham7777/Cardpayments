package com.efx.pet.service.registration.flow;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

@Component
public class FlowValidator {

    @Autowired
    private FlowMapProperties flowMapProps;
    final Map<String, String> formattedURIMap = new HashMap<>();
    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(FlowValidator.class);
    
    @PostConstruct
    public void init() {
        if (flowMapProps != null) {
            LOGGER.info("Flow Map properties: {}", flowMapProps.getUri());

            if (flowMapProps.getUri() != null) {
                flowMapProps.getUri().forEach((key, value) -> {
                    formattedURIMap.put(key.replaceAll("_", "/"), value);
                });
            }
            LOGGER.info("Formatted flow.uri properties: {}", formattedURIMap);
        }
    }

    public boolean isThisRequestAllowed(final String requestedURI, final String lastRequestURI) {
        if (formattedURIMap.isEmpty()
                        || StringUtils.isBlank(formattedURIMap.get(requestedURI))) {
            // No restriction
            return true;
        }
        if (StringUtils.isNotBlank(formattedURIMap.get(requestedURI))
                        && StringUtils.isBlank(lastRequestURI)) {
            // This means requested URI is in the flow but there is no info about
            // user last accessed URI
            return false;
        }
        return formattedURIMap.get(requestedURI).contains(lastRequestURI);
    }
}
