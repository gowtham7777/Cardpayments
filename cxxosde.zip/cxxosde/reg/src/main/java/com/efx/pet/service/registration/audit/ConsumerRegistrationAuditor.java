package com.efx.pet.service.registration.audit;

import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logging.PetLogger;

@Deprecated
public class ConsumerRegistrationAuditor extends LockAlertAuditor{
	public ConsumerRegistrationAuditor(PetLogger logger, String markerDomain) {
		super(logger, markerDomain);
	}
}
