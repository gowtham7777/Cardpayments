package com.efx.pet.service.registration;

import java.util.List;
import java.util.Map;

import com.efx.pet.order.mgmt.domain.ProductOfferDetails;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AppConfigResponse {

  private String timeoutPageUrl;
  private int idleDuration;
  private int idleWarningDuration;
  private int spinnerMillisecondDelay;
  private String termsUrl;
  private String termsVersion;
  private String privacyPolicyUrl;
  private String privacyPolicyVersion;

  private String successMCLoginUrl; // Renamed from tidMCLoginUrl
  private String tenantPartner;

  private String partnerGuid;
  private String partnerId;
  private String tenantId;
  private String defaultLocale;
  private Map<String, String> queryParamsMap;
  private List<String> supportedLocales;
  private int minAgeToRegister;
  private ProductOfferDetails productOfferDetails;
  private String productTermsUrl;
  private String productTermsVersion;
  private boolean htmlAllowed;
  private boolean isTouDisabled;
  private CallCenterDetails callCenterDetails;
}
