package com.efx.pet.service.registration.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by lxg90 on 5/15/2018.
 */
public class CoreServiceClientException extends Exception {

  @JsonInclude
  private static final long serialVersionUID = 166889669992250078L;

  public CoreServiceClientException(String string) {
    super(string);
  }
}
