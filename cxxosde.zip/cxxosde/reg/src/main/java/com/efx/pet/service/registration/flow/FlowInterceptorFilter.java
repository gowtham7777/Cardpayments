package com.efx.pet.service.registration.flow;

import java.text.MessageFormat;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efx.pet.utility.EntryControllerURIEnums;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import com.amazonaws.util.ImmutableMapParameter;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.service.registration.domain.FlowInterceptorException;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logger.LoggingUtil;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import net.sf.uadetector.ReadableDeviceCategory;
import net.sf.uadetector.ReadableUserAgent;
import net.sf.uadetector.UserAgentStringParser;
import net.sf.uadetector.service.UADetectorServiceFactory;

@Component
public class FlowInterceptorFilter extends HandlerInterceptorAdapter {

    private static PetLogger logger = PetLoggerFactory.getLogger(FlowInterceptorFilter.class);
    private static UserAgentStringParser parser = UADetectorServiceFactory
                    .getResourceModuleParser();
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(logger, "Registration");

    private static final String USER_AGENT = "User-Agent";
    private static final String MOBILE_APP_HEADER = "Mobile-App";
    private static final String SESSION_ID = "session_id";


	static final Map<ReadableDeviceCategory.Category, ConsumerContext.ChannelEnum> CHANNEL_MAP = new ImmutableMapParameter.Builder<ReadableDeviceCategory.Category, ConsumerContext.ChannelEnum>()
			.put(ReadableDeviceCategory.Category.GAME_CONSOLE, ConsumerContext.ChannelEnum.DESKTOP)
			.put(ReadableDeviceCategory.Category.PDA, ConsumerContext.ChannelEnum.MOBILE_DEVICE)
			.put(ReadableDeviceCategory.Category.PERSONAL_COMPUTER, ConsumerContext.ChannelEnum.DESKTOP)
			.put(ReadableDeviceCategory.Category.SMART_TV, ConsumerContext.ChannelEnum.DESKTOP)
			.put(ReadableDeviceCategory.Category.SMARTPHONE, ConsumerContext.ChannelEnum.MOBILE_DEVICE)
			.put(ReadableDeviceCategory.Category.TABLET, ConsumerContext.ChannelEnum.MOBILE_DEVICE)
			.put(ReadableDeviceCategory.Category.WEARABLE_COMPUTER, ConsumerContext.ChannelEnum.MOBILE_DEVICE)
			.put(ReadableDeviceCategory.Category.OTHER, ConsumerContext.ChannelEnum.DESKTOP)
			.put(ReadableDeviceCategory.Category.UNKNOWN, ConsumerContext.ChannelEnum.DESKTOP).build();


    @Autowired
    private FlowValidator flowValidator;

    @Value("${web.flow.enable:false}")
    private boolean webFlowEnabled;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                    Object object) throws Exception {
        createLogMessageContext(request);
        final HttpSession httpSession = request.getSession();
        if (webFlowEnabled) {
            final String lastRequestURI = (String) httpSession
                            .getAttribute(CommonConstants.LAST_REQUEST_URI);

            final String requestURI = request.getRequestURI();
            final boolean proceed = flowValidator.isThisRequestAllowed(requestURI, lastRequestURI);
            final String logMessage = MessageFormat.format("RequestURI: {0}, lastRequestURI {1} proceed: {2} ", requestURI,
                            lastRequestURI, proceed);
            logger.debug(logMessage);

            if (!proceed) {
                final String sanitizedLogMessage = LoggingUtil.sanitizeLoggedMessage(MessageFormat.format("Requested resource not allowed. RequestURI: {0}, Last accessed URI: {1} ", requestURI, lastRequestURI));
                logger.debug(sanitizedLogMessage);
                AUDITOR.recordError(AuditConstants.EVENT_FLOW_INTERCEPTOR, AuditEventStatus.END_FAIL, sanitizedLogMessage);
                throw new FlowInterceptorException("Requested resource not allowed.");
            }
            httpSession.setAttribute(CommonConstants.LAST_REQUEST_URI, requestURI);
        }
        AUDITOR.recordInfo(AuditConstants.EVENT_FLOW_INTERCEPTOR, AuditEventStatus.END_SUCCESS, "Request passed through WebFlow successfully.", httpSession!=null?(ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT):null);
        return true;
    }


    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object object,
                    ModelAndView model) throws Exception {

      /* This operation is not implemented because we are not supporting it
       * Adding the nested comment to explain why it is empty, so SONAR is happy.
       */
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                    Object object, Exception arg3) throws Exception {
        // Clear the MDC
        MDC.clear();
    }

    /**
     * Create UUID and put it in MDC so that all log statements writes conversation id in logs. For
     * subsequent requests conversation id is retrieved from session and writes the same to track
     * the user trace.
     */
    private void createLogMessageContext(HttpServletRequest httpServletRequest) {
        //reset the entire http session if the request is the entry request.
        HttpSession httpSession;
        String requestURI = httpServletRequest.getRequestURI();
        if(EntryControllerURIEnums.isEntryURI(requestURI)){
          httpSession = httpServletRequest.getSession(false);
          if(httpSession != null){
            AUDITOR.recordInfo(AuditConstants.EVENT_FLOW_INTERCEPTOR, AuditEventStatus.IN_PROGRESS,"Invalid previous session for the entry request: "+ requestURI, (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT));
            httpSession.invalidate();
          }
          AUDITOR.recordInfo(AuditConstants.EVENT_FLOW_INTERCEPTOR, AuditEventStatus.IN_PROGRESS,"Starting a new session for the entry request: "+ requestURI);
        }
        httpSession = httpServletRequest.getSession();
        ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
        if (consumerContext == null || StringUtils.isBlank(consumerContext.getConversationId())) {
            consumerContext = new ConsumerContext(httpSession.getId(), UUID.randomUUID().toString());
            final String userAgent = httpServletRequest.getHeader(USER_AGENT);
            if (StringUtils.isNotBlank(userAgent)) {
                consumerContext.setUserAgent(userAgent);

                // set Channel
                final ReadableUserAgent readableUserAgent = parser.parse(userAgent);
                final ReadableDeviceCategory deviceCategory = readableUserAgent.getDeviceCategory();
                consumerContext.setChannel(CHANNEL_MAP.getOrDefault(deviceCategory.getCategory(), ConsumerContext.ChannelEnum.DESKTOP));

                consumerContext.setIpAddress(httpServletRequest.getRemoteAddr());
                final String host = httpServletRequest.getServerName();
                if (StringUtils.isNotBlank(host)) {
                    consumerContext.setHost(host);
                }
            }
            // override Channel with Mobile App if applicable
            final String mobileApp = httpServletRequest.getHeader(MOBILE_APP_HEADER);
            if ("true".equalsIgnoreCase(mobileApp)){
              consumerContext.setChannel(ConsumerContext.ChannelEnum.MOBILE_APP);
            }
            httpSession.setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);
        }
        MDC.put(CommonConstants.CONVERSATION_ID, consumerContext.getConversationId());
        MDC.put(SESSION_ID, consumerContext.getSessionId());
    }
}
