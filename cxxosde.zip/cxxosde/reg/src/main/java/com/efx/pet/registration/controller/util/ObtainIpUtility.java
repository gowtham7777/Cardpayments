package com.efx.pet.registration.controller.util;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.efx.pet.service.eid.exception.ServiceException;

@Service

public class ObtainIpUtility {
	
	public static final String HEADER_FORWARD = "HTTP_X_FORWARDED_FOR";
    public static final String HEADER_FORWARD_STANDARD = "X-Forwarded-For";
    public static final String IPV4 = "IPv4";
    public static final String IPV6 = "IPv6";
    
	public String obtainIpAddress(final HttpServletRequest request) {
        if (request == null) {
            return null;
        }

        String ipAddress = request.getHeader(HEADER_FORWARD_STANDARD);
        if (ipAddress == null) {
            ipAddress = request.getHeader(HEADER_FORWARD);
        }

        if (ipAddress == null) {
            ipAddress = request.getRemoteAddr();
        }
        // check whether multiple IPs are getting passed back from the frontend
        // servers
        if (ipAddress != null) {
            final String[] tokenizedIPs = StringUtils.split(ipAddress, ",");
            if (tokenizedIPs.length > 1) {
                ipAddress = tokenizedIPs[0];
            }
        }

        return ipAddress;
    }
	
	public String obtainIpAddressVersion(final String ipAddress) throws ServiceException {
		
		String ipAddressVersion = null;
		
		if(StringUtils.isBlank(ipAddress)) {
			return null;	
		}
		
		try {

		    InetAddress address = InetAddress.getByName(ipAddress);

		    if (address instanceof Inet4Address) {
		        ipAddressVersion  = IPV4;
		    } else if (address instanceof Inet6Address) {
		        ipAddressVersion =  IPV6;
		    }

		} catch(UnknownHostException e) {

		    String message = "Ip address version couldn't be found";
		    throw new ServiceException(message, e);

		}
		
		return ipAddressVersion;
		
	}
}
