package com.efx.pet.registration.controller.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import com.efx.pet.utility.QueryParamEnums;
import org.springframework.stereotype.Component;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.dataanalytics.Attributes;
import com.efx.pet.domain.dataanalytics.Category;
import com.efx.pet.domain.dataanalytics.DataLayer;
import com.efx.pet.domain.dataanalytics.Event;
import com.efx.pet.domain.dataanalytics.Page;
import com.efx.pet.domain.dataanalytics.PageInfo;
import com.efx.pet.utility.CommonConstants;

import net.sf.uadetector.ReadableDeviceCategory;
import net.sf.uadetector.ReadableUserAgent;
import net.sf.uadetector.UserAgentStringParser;
import net.sf.uadetector.VersionNumber;
import net.sf.uadetector.service.UADetectorServiceFactory;

/**
 * Created by sxs10 on 12/7/2017.
 */

@Component
public class DigitalDataLayerUtility {

  private static final UserAgentStringParser parser = UADetectorServiceFactory.getResourceModuleParser();

  public DataLayer populateDigitalDataLayerConfiguration(HttpServletRequest httpServletRequest) {
     ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession().getAttribute(CommonConstants.CONSUMER_CONTEXT);

    PageInfo pageInfo = new PageInfo();
    pageInfo.setPageID("");
    pageInfo.setDestinationURL("tobefilledinbyui");

    String referrer = httpServletRequest.getHeader("referer");
    pageInfo.setReferringURL(referrer);

    String userAgent = httpServletRequest.getHeader("User-Agent");

    if (userAgent != null ) {
      ReadableUserAgent readableUserAgent = parser.parse(userAgent);
      if(readableUserAgent!=null) {
        String browserName = readableUserAgent.getName();
        pageInfo.setVariant(browserName);

        //VersionNumber, DeviceCategory are @NotNull fields in ReadableUserAgent interface
        VersionNumber browserVersion = readableUserAgent.getVersionNumber();
        pageInfo.setVersion(browserVersion.toVersionString());


        ReadableDeviceCategory deviceCategory = readableUserAgent.getDeviceCategory();
        pageInfo.setSysEnv(deviceCategory.getName());
      }

    }
    pageInfo.setAuthor("Equifax");

    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

    pageInfo.setIssueDate(timestamp.getTime());
    pageInfo.setExpiryDate(timestamp.getTime());
    Locale locale = httpServletRequest.getLocale();

    pageInfo.setLanguage(locale.toString());
    pageInfo.setGeoRegion(locale.getCountry());
    pageInfo.setIndustryCodes("SIC-7320");
    pageInfo.setPublisher("Equifax");

    Page page = new Page();
    page.setPageInfo(pageInfo);

    Category category = new Category();
    page.setCategory(category);

    Attributes attributes = new Attributes();
    if (consumerContext != null && consumerContext.getSessionId() != null) {
    	attributes.setEfxSessionID(consumerContext.getSessionId());
    } else {
    	attributes.setEfxSessionID(null);
    }

    if (consumerContext != null && consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()) != null) {
      attributes.setCampaignSourceCode(consumerContext.getQueryParamsMap().get(QueryParamEnums.CAMPAIGNCODE.value()));
    } else {
      attributes.setCampaignSourceCode(CommonConstants.DEFAULT_CAMPAIGNCODE);
    }

    //As per the Keystone meeting, removing this. We might add converstaionId later
    //consumerContext.getConversationId()!=null ? consumerContext.getConversationId() : null);

    attributes.setEfxExperienceID("");
    attributes.setContextProduct("");

    attributes.setServer(httpServletRequest.getServerName() != null ? httpServletRequest.getServerName() : null);
    page.setAttributes(attributes);

    List<Event> eventList = new ArrayList<>();
    Event[] event = new Event[10];
    event[0] = new Event();
    eventList.add(event[0]);

    DataLayer dataLayer = new DataLayer();
    dataLayer.setPageInstanceID("");
    dataLayer.setPage(page);
    dataLayer.setProduct("");
    dataLayer.setCart("");
    dataLayer.setTransaction("");
    dataLayer.setEvent(eventList);
    dataLayer.setComponent("");
    dataLayer.setPrivacy("");
    dataLayer.setVersion("1.0.0");
    return dataLayer;
  }

}
