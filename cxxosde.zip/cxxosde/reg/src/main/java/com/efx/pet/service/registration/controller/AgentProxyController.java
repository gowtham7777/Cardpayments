package com.efx.pet.service.registration.controller;

import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.registration.controller.util.ParamsValidatorUtil;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.service.registration.util.DecryptionServiceUtil;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.QueryParamEnums;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logger.LoggingUtil;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;
import com.equifax.sast.inputvalidators.validate.GenericValidator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.MessageFormat;
import java.util.Objects;


/**
 * Created by rrk4 on 12/08/2017.
 */
@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "AgentProxyController", description = "Agent Proxy Operations")
public class AgentProxyController {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(AgentProxyController.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "AgentProxy");

  private static final String LOG_AGENT_BEGIN_SESSION = "Begin Proxy session";
  private static final String LOG_PROXY_NOT_SET = "proxy request param is either missing or its value isn't set.";
  private static final String LOG_CONSUMER_CONTEXT_NULL = "ConsumerContext is null.";
  private static final String LOG_SET_AGENT_PROXY_IN_SESSION = "Setting AgentProxy in session";
  private static final String LOG_REDIRECT_BEGIN = "Begin Proxy session successful. Now redirecting.";
  private static final String LOG_PROXY_NOT_CLEARED = "{0} is the AgentProxy value from previous registration is not cleared out in ConsumerContext";


  private static final String PROXY_QUERY_STRING_PARAM = "proxy";
  private static final String UI_SYSTEM_ERROR_FRAGMENT = "#system-error";

  private static final String FLASH_ATTRIBUTE = "flashAttribute";
  private static final String REDIRECT_WITH_REDIRECTVIEW = "redirectWithRedirectView";

  private DecryptionServiceUtil decryptionServiceUtil;

  @Autowired
  private SessionUtil sessionUtil;

  @Autowired
  private PartnerTenantClient partnerTenantClient;

  private String frontEndBundleLocation;

  @Autowired
  public AgentProxyController(SessionUtil sessionUtil, PartnerTenantClient partnerTenantClient, DecryptionServiceUtil decryptionServiceUtil)
    throws CoreServiceClientException {
    this.sessionUtil = sessionUtil;
    this.partnerTenantClient = partnerTenantClient;
    this.frontEndBundleLocation = this.partnerTenantClient.getFrontEndBundleLocation();
    this.decryptionServiceUtil = decryptionServiceUtil;
  }

  /**
   * Sets agent proxy info in session and redirects to root partner tenant application end point
   *
   * @param httpServletRequest
   * @param attributes
   * @param upsellSkuId
   * @param campaignCode
   * @param offerCode          encrypted promo code from consumer
   * @return {@link RedirectView} if all params are correct and were successfully added to {@link ConsumerContext}
   */
  @Operation(summary = "Redirects to appropriate Url")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "302",
      description = "Redirect Url for Registration App", content = {@Content(schema = @Schema(implementation = Object.class))}),
    @ApiResponse(responseCode = "500",
      description = "Unhandled System Error", content = {@Content(schema = @Schema(implementation = Object.class))})})
  @GetMapping(value = "/beginProxy")
  public RedirectView beginProxy(HttpServletRequest httpServletRequest, RedirectAttributes attributes,
                                 @RequestParam(name = PROXY_QUERY_STRING_PARAM, required = true) String agentProxy,
                                 @RequestParam(name = "externalProductReference", required = false) Long upsellSkuId,
                                 @RequestParam(name = "campaignCode", required = false) String campaignCode,
                                 @RequestParam(name = "offerCode", required = false) String offerCode) {
    final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false)
      .getAttribute(CommonConstants.CONSUMER_CONTEXT);

    LOGGER.debug(LOG_AGENT_BEGIN_SESSION);
    AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.BEGIN, LOG_AGENT_BEGIN_SESSION, consumerContext);

      if (StringUtils.isBlank(agentProxy)
              || consumerContext == null
              || !GenericValidator.isValidAlphaNumeric(agentProxy)) {
      final String message = StringUtils.isBlank(agentProxy) ? LOG_PROXY_NOT_SET : LOG_CONSUMER_CONTEXT_NULL;
      LOGGER.error(message);
      AUDITOR.recordError(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.END_FAIL, message, consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
      sessionUtil.invalidateSession(httpServletRequest);
      attributes.addFlashAttribute(FLASH_ATTRIBUTE, REDIRECT_WITH_REDIRECTVIEW);
      return new RedirectView(frontEndBundleLocation + UI_SYSTEM_ERROR_FRAGMENT);
    }
    agentProxy = agentProxy.trim();
    if (!StringUtils.isBlank(campaignCode) && !ParamsValidatorUtil.isValidCampaignCode(campaignCode)) {
      AUDITOR.recordError(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.END_FAIL,
        LoggingUtil.sanitizeLoggedMessage(MessageFormat
          .format("Invalid campaignCode passing in from query param, redirect to customer care page: code {0}", campaignCode)));
      sessionUtil.invalidateSession(httpServletRequest);
      attributes.addFlashAttribute(FLASH_ATTRIBUTE, REDIRECT_WITH_REDIRECTVIEW);
      return new RedirectView(frontEndBundleLocation + UI_SYSTEM_ERROR_FRAGMENT);
    }
    // This check is to troubleshoot in case of any issues with prior session invalidation
    if (StringUtils.isNotBlank(consumerContext.getAgentId())) {
      final String message = MessageFormat.format(LOG_PROXY_NOT_CLEARED, consumerContext.getAgentId());
      final String sanitizedMessage = LoggingUtil.sanitizeLoggedMessage(message);
      LOGGER.debug(sanitizedMessage);
      AUDITOR.recordError(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.END_FAIL, sanitizedMessage, consumerContext);
    }
    LOGGER.info(LOG_SET_AGENT_PROXY_IN_SESSION);
    AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.IN_PROGRESS, LOG_SET_AGENT_PROXY_IN_SESSION, consumerContext);
    consumerContext.setAgentId(agentProxy);
    mapAdditionalAttributes(consumerContext, upsellSkuId, campaignCode, offerCode);
    httpServletRequest.getSession(false).setAttribute(CommonConstants.CONSUMER_CONTEXT, consumerContext);

    LOGGER.info(LOG_REDIRECT_BEGIN);
    AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.END_SUCCESS, LOG_REDIRECT_BEGIN, consumerContext, null, null, HttpStatus.FOUND.toString());

    attributes.addFlashAttribute(FLASH_ATTRIBUTE, REDIRECT_WITH_REDIRECTVIEW);
    return new RedirectView(frontEndBundleLocation);
  }

  /**
   * Custom Exception handler for invalid session Attributes for SingleSignOnController
   *
   * @param httpSession
   * @return
   */
  @ExceptionHandler(CoreServiceClientException.class)
  public RedirectView handleCustomException(CoreServiceClientException ex,
                                            HttpSession httpSession, RedirectAttributes attributes) {
    ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
    final String sanitizedLogMessage = LoggingUtil.sanitizeLoggedMessage(ex.getMessage());
    LOGGER.error(sanitizedLogMessage);
    AUDITOR.recordError(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.END_FAIL, ex.getMessage(),
      consumerContext, HttpStatus.INTERNAL_SERVER_ERROR.toString());
    httpSession.invalidate();
    attributes.addFlashAttribute(FLASH_ATTRIBUTE, REDIRECT_WITH_REDIRECTVIEW);
    return new RedirectView(frontEndBundleLocation + UI_SYSTEM_ERROR_FRAGMENT);
  }

  /**
   * @param consumerContext
   * @param upsellSkuId
   * @param campaignCode
   * @param offerCode
   * @return
   * @throws CoreServiceClientException
   */
  private ConsumerContext mapAdditionalAttributes(ConsumerContext consumerContext, Long upsellSkuId, String campaignCode, String offerCode) {
    if (Objects.nonNull(upsellSkuId)) {
      String message = "Setting skuId from query param to consumerContext";
      consumerContext.setUpsellSkuId(upsellSkuId);
      AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.IN_PROGRESS, message, consumerContext);
    }
    if (!StringUtils.isBlank(campaignCode)) {
      AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.IN_PROGRESS,
        "Capture campaignCode passing in from query param to ConsumerContext.", consumerContext);
    } else {
      campaignCode = CommonConstants.DEFAULT_CAMPAIGNCODE;
      AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.IN_PROGRESS,
        "No campaignCode passed in from query param to ConsumerContext. Set the default value.", consumerContext);
    }
    consumerContext.getQueryParamsMap().put(QueryParamEnums.CAMPAIGNCODE.value(), campaignCode);
    if (Objects.nonNull(offerCode)) {
      String message = "Setting offerCode to consumerContext in QueryParams";
      consumerContext.getQueryParamsMap().put(QueryParamEnums.OFFERCODE.value(), decryptionServiceUtil.decryptOfferCode(offerCode, consumerContext));
      AUDITOR.recordInfo(AuditConstants.EVENT_BEGIN_PROXY, AuditEventStatus.IN_PROGRESS, message, consumerContext);
    }
    return consumerContext;
  }
}
