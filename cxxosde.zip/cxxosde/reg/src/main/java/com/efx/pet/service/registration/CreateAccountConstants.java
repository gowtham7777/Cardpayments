package com.efx.pet.service.registration;

public class CreateAccountConstants {

	public static final String DEVICE_CHECK_RESULT = "result";


	public static final String IDP_CHECK_PASS = "PASS";
	public static final String IDP_CHECK_FAIL = "FAIL";
	public static final String IDP_CHECK_ALLOW = "ALLOW";
	public static final String IDP_CHECK_DENY = "DENY";

}
