package com.efx.pet.service.registration.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.efx.pet.service.consumer.ConsumerService;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.registration.coreservice.PartnerTenantClient;
import com.efx.pet.service.registration.exception.CoreServiceClientException;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

/**
 * Configuration for PartnerTenantLookup
 * Inject order funnel service implementations based on look up
 * @author vxc64
 */
@Configuration
public class PartnerTenantConfig {
	private static final PetLogger LOGGER = PetLoggerFactory.getLogger(PartnerTenantConfig.class);

  @Autowired
  private PartnerTenantClient partnerLookupUtil;

  /**
   * Construct instance of ConsumerService based on PartnerTenantLookup
   * throws Spring BeanNotFound exception at build time if bean is not found in the map
   * @return ConsumerService interface type
   * @throws CoreServiceClientException
   */
  @Bean
  @Primary
  public ConsumerService consumerService() throws CoreServiceClientException {
	LOGGER.checkBeforeDebug("Start to resolve implementation class for ConsumerService.");
    return partnerLookupUtil.getConsumerServiceInstance();
  }
  
	/**
	 * Construct instance of RegistrationService based on PartnerTenantLookup throws
	 * Spring BeanNotFound exception at build time if bean is not found in the map
	 * 
	 * @return RegistrationService interface type
	 * @throws CoreServiceClientException
	 */
	@Bean
	@Primary
	public RegistrationService registrationService() throws CoreServiceClientException {
		LOGGER.checkBeforeDebug("Start to resolve implementation class for RegistrationService.");
		return partnerLookupUtil.getRegistrationServiceInstance();
	}
	
	/**
	 * Construct instance of IdProofingService based on PartnerTenantLookup throws
	 * Spring BeanNotFound exception at build time if bean is not found in the map
	 * 
	 * @return IdProofingService interface type
	 * @throws CoreServiceClientException
	 */
	@Bean
	@Primary
	public IdProofingService idProofingService() throws CoreServiceClientException {
		LOGGER.checkBeforeDebug("Start to resolve implementation class for IdProofingService.");
		return partnerLookupUtil.getIdProofingServiceInstance();
	}  
}
