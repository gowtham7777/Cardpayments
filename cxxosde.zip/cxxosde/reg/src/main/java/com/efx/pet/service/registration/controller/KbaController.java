package com.efx.pet.service.registration.controller;

import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumMap;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.domain.KbaPackage;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.idproofing.IdProofingResponse;
import com.efx.pet.service.idproofing.IdProofingService;
import com.efx.pet.service.idproofing.IdProofingServiceException;
import com.efx.pet.service.registration.RegistrationConstants;
import com.efx.pet.service.registration.domain.KbaRequest;
import com.efx.pet.service.registration.domain.KbaResponse;
import com.efx.pet.service.registration.domain.KbaResponseException;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;


/**
 * Created by rrk4 on 10/23/2017.
 */
@RestController
@RequestMapping("/rest/3.0")
@Tag(name="KbaController", description="Kba Operations")
public class KbaController extends RestControllerBase {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(KbaController.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "Kba");
    private static final String KBA_GET_QUIZ = AuditConstants.EVENT_KBA_GET_QUIZ;
    private static final String KBA_SUBMIT_ANSWERS = AuditConstants.EVENT_KBA_SUBMIT_ANSWERS;
    public static final String OVERALL_CONSUMER_IDP_STATUS_PASS = "PASS";
	private static final ResponseEntity<KbaResponse> DEFAULT_START_KBA_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
			new KbaResponse(KbaResponse.StatusCode.KBA_QUIZ_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
	private static final ResponseEntity<KbaResponse> DEFAULT_VALIDATE_KBA_ANSWERS_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
			new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_SYSTEM_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
	private static final EnumMap<IdProofingResponse.StatusCode, ResponseEntity<KbaResponse>> START_KBA_FAILURE_RESPONSE_ENTITY_MAP = new EnumMap<>(
			IdProofingResponse.StatusCode.class);
	private static final EnumMap<IdProofingResponse.StatusCode, ResponseEntity<KbaResponse>> VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP = new EnumMap<>(
			IdProofingResponse.StatusCode.class);

    @Autowired
    private IdProofingService idProofingService;

    @Autowired
    private SessionUtil sessionUtil;

    @Autowired
    private EncryptUtility encryptUtility;

    @PostConstruct
	public void init() {
		// Map has all FAILURE entries for start KBA questionnaire
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.ID_PROOFING_SYSTEM_ERROR,
				DEFAULT_START_KBA_ERROR_RESPONSE_ENTITY);
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL),
						HttpStatus.ACCEPTED));
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PIN_TO_POST_PRIMARY), HttpStatus.OK));
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_SECONDARY,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PIN_TO_POST_SECONDARY), HttpStatus.OK));
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_QUIZ_ERROR,
				DEFAULT_START_KBA_ERROR_RESPONSE_ENTITY);
		START_KBA_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PTP_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PTP_ELIGIBILITY_FAIL), HttpStatus.ACCEPTED));
		// Map has all FAILURE entries for validate KBA questionnaire answers
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.ID_PROOFING_SYSTEM_ERROR,
				DEFAULT_VALIDATE_KBA_ANSWERS_ERROR_RESPONSE_ENTITY);
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_SYSTEM_ERROR,
				DEFAULT_VALIDATE_KBA_ANSWERS_ERROR_RESPONSE_ENTITY);
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_SUCCESS_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_SUCCESS_ELIGIBILITY_FAIL),
						HttpStatus.ACCEPTED));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(
				IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT),
						HttpStatus.ACCEPTED));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR),
						HttpStatus.ACCEPTED));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_FAILURE_ELIGIBILITY_FAIL),
						HttpStatus.ACCEPTED));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_PRIMARY,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PIN_TO_POST_PRIMARY), HttpStatus.OK));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PIN_TO_POST_SECONDARY,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PIN_TO_POST_SECONDARY), HttpStatus.OK));
		VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP.put(IdProofingResponse.StatusCode.PTP_ELIGIBILITY_FAIL,
				new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.PTP_ELIGIBILITY_FAIL), HttpStatus.ACCEPTED));
    }

  /**
     * Fetches and returns Kba Quiz for consumer in http session
   *
     * @param httpServletRequest
     * @return
     */
    @Operation(summary = "Returns the StatusCode")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Returns status when Kba quiz generation successful", content = {
					@Content(schema = @Schema(implementation = KbaResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = KbaResponse.class)) }) })
    @RequestMapping(value = "/getQuiz", method = RequestMethod.GET, produces = RegistrationConstants.APPLICATION_JSON)
    public ResponseEntity<?> getQuiz(HttpServletRequest httpServletRequest) {
        final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
        AUDITOR.recordInfo(KBA_GET_QUIZ, AuditEventStatus.BEGIN, "Start - KbaController.getQuiz() - Begin KBA quiz generation.", consumerContext);
        long startTime = System.currentTimeMillis();
        //get decrypted consumer from httpRequest
        final String decryptedConsumer = encryptUtility.decrypt(httpServletRequest, CommonConstants.CONSUMER_DATA);
        final Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
        if (consumer == null) {
            String message = "Either HttpSession OR Consumer in HttpSession is null.";
            Exception e = new Exception(message);
            LOGGER.error(message, e);
            AUDITOR.recordError(KBA_GET_QUIZ, AuditEventStatus.END_FAIL, message, consumerContext, KbaResponse.StatusCode.KBA_QUIZ_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            sessionUtil.invalidateSession(httpServletRequest);
            return DEFAULT_START_KBA_ERROR_RESPONSE_ENTITY;
        }

		try {
			AUDITOR.recordInfo(KBA_GET_QUIZ, AuditEventStatus.IN_PROGRESS, "Calling idProofingService.startKba()...",
					consumer.getConsumerKey(), consumerContext);
			IdProofingResponse idProofingResponse = idProofingService.startKba(consumer, consumerContext);
			if (idProofingResponse != null && idProofingResponse.getKbaPackage() != null) {
				return generateQuizSuccessResponse(idProofingResponse, consumer, consumerContext, httpServletRequest, startTime);
			}
			return generateQuizFailureResponse(idProofingResponse, consumer, consumerContext, httpServletRequest);
		} catch (IdProofingServiceException ex) {
			String message = "Unknown Exception encountered when starting KBA questionnaire.";
			LOGGER.checkBeforeError(message, ex);
			AUDITOR.recordError(KBA_GET_QUIZ, AuditEventStatus.END_FAIL, message, consumerContext,
					consumer.getConsumerKey(), KbaResponse.StatusCode.KBA_QUIZ_ERROR.toString(),
					HttpStatus.INTERNAL_SERVER_ERROR.toString());
			sessionUtil.invalidateSession(httpServletRequest);
			return DEFAULT_START_KBA_ERROR_RESPONSE_ENTITY;
		}
    }

	private ResponseEntity<KbaResponse> generateQuizSuccessResponse(IdProofingResponse idProofingResponse,
			Consumer consumer, ConsumerContext consumerContext, HttpServletRequest httpServletRequest, long startTime) {
		LOGGER.checkBeforeDebug("Start- generateQuizSuccessResponse");
		Date sessionAccessedTime = new Date(httpServletRequest.getSession(false).getLastAccessedTime());
		LOGGER.checkBeforeDebugFormat("Session accessed time during quiz generation : {0}", sessionAccessedTime);
		consumer.setQuizLastAccessedTime(sessionAccessedTime);
		consumer.setKbaQuizTransactionKey(idProofingResponse.getKbaPackage().getTransactionKey());
		encryptUtility.encrypt(httpServletRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
		KbaResponse kbaResponse = new KbaResponse(
				KbaResponse.StatusCode.valueOf(idProofingResponse.getStatusCode().toString()));
		kbaResponse.setQuizIdentifier(idProofingResponse.getKbaPackage().getQuizIdentifier());
		kbaResponse.setQuestions(idProofingResponse.getKbaPackage().getKbaQuiz());
		AUDITOR.recordInfo(KBA_GET_QUIZ, AuditEventStatus.END_SUCCESS, "Kba quiz generation successful.",
				consumerContext, consumer.getConsumerKey(), kbaResponse.getStatusCode().toString(),
				HttpStatus.OK.toString(), Long.toString(startTime));
		LOGGER.checkBeforeDebug("End- generateQuizSuccessResponse");
		return new ResponseEntity<>(kbaResponse, HttpStatus.OK);
	}

	private ResponseEntity<KbaResponse> generateQuizFailureResponse(IdProofingResponse idProofingResponse, Consumer consumer,
			ConsumerContext consumerContext, HttpServletRequest httpServletRequest) throws IdProofingServiceException {
		LOGGER.checkBeforeDebug("Start- generateQuizFailureResponse");
		try {
			if (idProofingResponse != null) {
				ResponseEntity<KbaResponse> responseEntity = START_KBA_FAILURE_RESPONSE_ENTITY_MAP
						.get(idProofingResponse.getStatusCode());
				if (responseEntity != null) {
					if (HttpStatus.OK == responseEntity.getStatusCode()) {
						AUDITOR.recordInfo(KBA_GET_QUIZ, AuditEventStatus.END_PARTIAL_SUCCESS,
								"Next Id proofing initiated successfully.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
					} else {
						AUDITOR.recordError(KBA_GET_QUIZ, AuditEventStatus.END_FAIL,
								"Next Id proofing initiation failed.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
						sessionUtil.invalidateSession(httpServletRequest);
					}
					return responseEntity;
				}
			}
			String message = "Null or unhandled response from idProofingService.startKba().";
			LOGGER.checkBeforeError(message);
			throw new IdProofingServiceException(message);
		} finally {
			LOGGER.checkBeforeDebug("End- generateQuizFailureResponse");
		}
	}


    /**
     * When consumer submits answers to Kba quiz, call Eid Service to authenticate.
     * If authentication successful, call TID API and redirect to TID if successful.
     * If authentication fails or call to TID API fails, then return relevant error status code.
     *
     * @param httpServletRequest
     * @param content
     * @return
     */
    @Operation(summary = "Returns the StatusCode")
    @ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Quiz answers submitted and validated successfully", content = {
					@Content(schema = @Schema(implementation = KbaResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request/input", content = {
					@Content(schema = @Schema(implementation = KbaResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Unhandled System Error", content = {
					@Content(schema = @Schema(implementation = KbaResponse.class)) }) })
    @RequestMapping(value = "/submitAnswers", method = RequestMethod.POST, produces = RegistrationConstants.APPLICATION_JSON, consumes = RegistrationConstants.APPLICATION_JSON)
    public ResponseEntity<?> submitAnswers(HttpServletRequest httpServletRequest,  @RequestBody String content) throws KbaResponseException {
        final ConsumerContext consumerContext = (ConsumerContext) httpServletRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
        AUDITOR.recordInfo(KBA_SUBMIT_ANSWERS, AuditEventStatus.BEGIN, "Start - KbaController.submitAnswers() - Begin KBA quiz answer submission and validation.", consumerContext);
        long startTime = System.currentTimeMillis();
        //get decrypted consumer from httpRequest
        final String decryptedConsumer = encryptUtility.decrypt(httpServletRequest, CommonConstants.CONSUMER_DATA);
        final Consumer consumer = JsonUtils.fromSanitizedJson(decryptedConsumer, Consumer.class);
        if (consumer == null) {
            String message = "Either HttpSession OR Consumer in HttpSession is null.";
            LOGGER.error(message, new Exception(message));
            AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, message, consumerContext, null, KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            sessionUtil.invalidateSession(httpServletRequest);
            return new ResponseEntity<KbaResponse>(new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        try {
            KbaRequest kbaRequest;
            try {
                kbaRequest = JsonUtils.fromSanitizedJson(content, KbaRequest.class);
            } catch (Exception e) {
                String message = "Cannot parse request body, Bad Request.";
                LOGGER.error(message, e);
                AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), KbaResponse.StatusCode.VALIDATION_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
                return new ResponseEntity<KbaResponse>(new KbaResponse(KbaResponse.StatusCode.VALIDATION_ERROR), HttpStatus.BAD_REQUEST);
            }

            AUDITOR.recordInfo(KBA_SUBMIT_ANSWERS, AuditEventStatus.IN_PROGRESS, "Validating KBA request.", consumer.getConsumerKey(), consumerContext);
            if (!isValidKbaRequest(kbaRequest)) {
                AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, MessageFormat.format("KBA request is missing required fields. quiz identifier = {0}", kbaRequest.getQuizIdentifier()), consumerContext, consumer.getConsumerKey(), KbaResponse.StatusCode.VALIDATION_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
                return new ResponseEntity<KbaResponse>(new KbaResponse(KbaResponse.StatusCode.VALIDATION_ERROR), HttpStatus.BAD_REQUEST);
            }

            String transactionKey = consumer.getKbaQuizTransactionKey();
            if (StringUtils.isBlank(transactionKey)) {
                AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, "Either HttpSession OR KbaQuizTransactionKey in HttpSession is null.", consumerContext, consumer.getConsumerKey(), KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
                return new ResponseEntity<KbaResponse>(new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            // getQuizLastAccessedTime stands for when quiz was generated and presented to user.
            // It is necessary to evaluate whether past KBA Timeout limit.
            Date lastAccessedTime = consumer.getQuizLastAccessedTime();
            if(lastAccessedTime == null) {
            	AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, "Either HttpSession OR QuizLastAccessedTime in HttpSession is null.", consumerContext, consumer.getConsumerKey(), KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
                return new ResponseEntity<>(new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            KbaPackage kbaPackage = new KbaPackage();
            kbaPackage.setQuizIdentifier(kbaRequest.getQuizIdentifier());
            kbaPackage.setKbaAnswers(kbaRequest.getAnswers());
            kbaPackage.setTransactionKey(transactionKey);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(lastAccessedTime);
            kbaPackage.setCreateTimestamp(calendar);

			AUDITOR.recordInfo(KBA_SUBMIT_ANSWERS, AuditEventStatus.IN_PROGRESS,
					"Calling idProofingService.validateKbaAnswers()...", consumer.getConsumerKey(), consumerContext);
			IdProofingResponse idProofingResponse = idProofingService.validateKbaAnswers(consumer, consumerContext,
					kbaPackage);
			if (idProofingResponse != null
					&& IdProofingResponse.StatusCode.KBA_SUBMIT_ANSWERS_SUCCESS == idProofingResponse.getStatusCode()) {
				// Validate positive scenario
				final KbaResponse kbaResponse = new KbaResponse(KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_SUCCESS);
				if (StringUtils.isNotBlank(idProofingResponse.getActivationUrl())) {
					// Only applies to TID flow
					kbaResponse.setDestinationUrl(idProofingResponse.getActivationUrl());
					sessionUtil.invalidateSession(httpServletRequest); // invalidate session only for TID flow
				}
				AUDITOR.recordInfo(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_SUCCESS,
						"KBA quiz answers submitted and validated successfully.", consumerContext,
						consumer.getConsumerKey(), kbaResponse.getStatusCode().toString(), HttpStatus.OK.toString(), Long.toString(startTime));
				return new ResponseEntity<>(kbaResponse, HttpStatus.OK);
			}
			return submitAnswersFailureResponse(idProofingResponse, consumer, consumerContext, httpServletRequest);
        } catch (Exception e) {
            String message = "Unknown Exception while trying to validate submitted KBA quiz answers.";
            LOGGER.checkBeforeError(message, e);
            AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), KbaResponse.StatusCode.KBA_SUBMIT_ANSWERS_SYSTEM_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            return DEFAULT_VALIDATE_KBA_ANSWERS_ERROR_RESPONSE_ENTITY;
        }
    }

    private boolean isValidKbaRequest(KbaRequest kbaRequest) {
        return !(kbaRequest == null || CollectionUtils.isEmpty(kbaRequest.getAnswers()) || StringUtils.isBlank(kbaRequest.getQuizIdentifier()));
    }

	private ResponseEntity<KbaResponse> submitAnswersFailureResponse(IdProofingResponse idProofingResponse,
			Consumer consumer, ConsumerContext consumerContext, HttpServletRequest httpServletRequest)
			throws IdProofingServiceException {
		LOGGER.checkBeforeDebug("Start- submitAnswersFailureResponse");
		try {
			if (idProofingResponse != null) {
				ResponseEntity<KbaResponse> responseEntity = VALIDATE_KBA_ANSWERS_FAILURE_RESPONSE_ENTITY_MAP
						.get(idProofingResponse.getStatusCode());
				if (responseEntity != null) {
					if (HttpStatus.OK == responseEntity.getStatusCode()) {
						AUDITOR.recordInfo(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_PARTIAL_SUCCESS,
								"Next Id proofing initiated successfully.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
					} else {
						AUDITOR.recordError(KBA_SUBMIT_ANSWERS, AuditEventStatus.END_FAIL,
								"Next Id proofing initiation failed.", consumerContext, consumer.getConsumerKey(),
								responseEntity.getBody().getStatusCode().toString(),
								responseEntity.getStatusCode().toString());
						sessionUtil.invalidateSession(httpServletRequest);
					}
					return responseEntity;
				}
			}
			String message = "Null or unhandled response from idProofingService.validateKbaAnswers().";
			LOGGER.checkBeforeError(message);
			throw new IdProofingServiceException(message);
		} finally {
			LOGGER.checkBeforeDebug("End- submitAnswersFailureResponse");
		}
	}
}
