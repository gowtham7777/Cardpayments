package com.efx.pet.service.registration;

import com.efx.pet.domain.dataanalytics.DataLayer;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnalyticsConfigResponse {

  private String ensightenUrl;

  private String iOvationUrl;

	private DataLayer dataLayer;

	public String getEnsightenUrl() {
		return ensightenUrl;
	}

	public void setEnsightenUrl(String ensightenUrl) {
		this.ensightenUrl = ensightenUrl;
	}

	public String getiOvationUrl() {
		return iOvationUrl;
	}

	public void setiOvationUrl(String iOvationUrl) {
		this.iOvationUrl = iOvationUrl;
	}

	public DataLayer getDataLayer() {
		return dataLayer;
	}

	public void setDataLayer(DataLayer dataLayer) {
		this.dataLayer = dataLayer;
	}

	public AnalyticsConfigResponse(){}
}
