package com.efx.pet.service.registration;

public class SaveConsumerResponse {

	public enum StatusCode {
        VALIDATION_ERROR, //http 412
		SAVE_CONSUMER_SYSTEM_ERROR, //http 500
		SAVE_CONSUMER_SUCCESS,
		CONFIRMATION,
		RECAPTCHA_ERROR,
    SAVE_CONSUMER_EXIST,
    CID_UNAVAILABLE,
    INDIRECT_ENROLLMENT_SYSTEM_ERROR

  }

	private StatusCode statusCode;
	private String statusMessage;
	private String customerId;


	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public StatusCode getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {
		return "SaveConsumerResponse [statusCode=" + statusCode + ", statusMessage="
				+ statusMessage + ", customerId=" + customerId + "]";
	}

	public SaveConsumerResponse(StatusCode statusCode) {
	  setStatusCode(statusCode);
  }

	public SaveConsumerResponse(){}
}
