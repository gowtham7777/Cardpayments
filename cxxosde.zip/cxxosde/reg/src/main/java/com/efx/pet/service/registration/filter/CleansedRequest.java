package com.efx.pet.service.registration.filter;

import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.stream.Collectors;

import static com.efx.pet.registration.controller.util.CleanseUtility.stripXSSVulnerabilities;
import static com.efx.pet.utility.logger.LoggingUtil.sanitizeLoggedMessage;

public class CleansedRequest extends HttpServletRequestWrapper {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(CleansedRequest.class);

  private String body;


  /**
   * Constructs a request object wrapping the given request.
   *
   * @param request The request to wrap
   * @throws IllegalArgumentException if the request is null
   */
  public CleansedRequest(HttpServletRequest request) throws IOException {
    super(request);
    body = "";
    try {
      body = request.getReader().lines().collect(Collectors.joining());
      String xssSanitized = stripXSSVulnerabilities(body);
      if (!body.equals(xssSanitized)) {
        String msg = "Raw and Cleansed request are not equal. Attack or malformed request. Raw request content: %s. Cleansed request content: %s.";
        LOGGER.error(sanitizeLoggedMessage(String.format(msg, body, xssSanitized)));
        throw new RuntimeException();
      }
    } catch (IOException e) {
      LOGGER.error(e.getMessage());
      throw e;
    }
  }

  @Override
  public ServletInputStream getInputStream() throws IOException {
    final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(body.getBytes());
    return new ServletInputStream() {
      public int read() throws IOException {
        return byteArrayInputStream.read();
      }

      @Override
      public boolean isFinished() {
        return byteArrayInputStream.available() == 0;
      }

      @Override
      public boolean isReady() {
        return true;
      }

      @Override
      public void setReadListener(ReadListener readListener) {
      }
    };
  }

  @Override
  public String getHeader(String name) {
    String value = super.getHeader(name);
    return stripXSSVulnerabilities(value);
  }

  @Override
  public String getParameter(String name) {
    String value = super.getParameter(name);

    return stripXSSVulnerabilities(value);
  }

  @Override
  public String[] getParameterValues(String name) {
    String[] values = super.getParameterValues(name);

    if (values == null) {
      return null;
    }

    int count = values.length;
    String[] encodedValues = new String[count];
    for (int i = 0; i < count; i++) {
      encodedValues[i] = stripXSSVulnerabilities(values[i]);
    }

    return encodedValues;
  }

}
