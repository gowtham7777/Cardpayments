package com.efx.pet.service.registration.controller;

import java.text.MessageFormat;
import java.util.EnumMap;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.Pattern;


import com.efx.pet.domain.eligibility.operations.LogFraudEventRequest;
import com.efx.pet.service.lift.LiftService;
import com.efx.pet.utility.fraudevents.logging.FraudEventLogger;
import com.efx.pet.utility.fraudevents.logging.FraudEventUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.efx.pet.domain.Consumer;
import com.efx.pet.domain.ConsumerContext;
import com.efx.pet.registration.controller.util.EncryptUtility;
import com.efx.pet.registration.controller.util.ObtainIpUtility;
import com.efx.pet.registration.controller.util.SessionUtil;
import com.efx.pet.service.direct.registration.RegistrationResponse;
import com.efx.pet.service.direct.registration.RegistrationService;
import com.efx.pet.service.registration.ReCaptchaService;
import com.efx.pet.service.registration.SaveConsumerResponse;
import com.efx.pet.service.registration.SaveConsumerResponse.StatusCode;
import com.efx.pet.utility.CommonConstants;
import com.efx.pet.utility.ConsumerValidator;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.configuration.utils.JsonUtils;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/rest/1.0")
@Tag(name = "RegistrationController", description = "Registration Operations")
public class RegistrationController extends RestControllerBase {

    private static final PetLogger LOGGER = PetLoggerFactory.getLogger(RegistrationController.class);
    private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, "Registration");

    public static final String HEADER_FORWARD = "HTTP_X_FORWARDED_FOR";
    public static final String HEADER_FORWARD_STANDARD = "X-Forwarded-For";
    public static final String TEMP_FREEZE_LOCK_LIFT_INTENT = "TEMP_FREEZE_LOCK_LIFT";
    private static final String SAVE_CONSUMER = AuditConstants.EVENT_SAVE_CONSUMER;
	private static final ResponseEntity<SaveConsumerResponse> DEFAULT_ERROR_RESPONSE_ENTITY = new ResponseEntity<>(
			new SaveConsumerResponse(StatusCode.SAVE_CONSUMER_SYSTEM_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
	private static final EnumMap<RegistrationResponse.StatusCode, ResponseEntity<SaveConsumerResponse>> RESPONSE_ENTITY_MAP = new EnumMap<>(
			RegistrationResponse.StatusCode.class);

    private ReCaptchaService reCaptchaService;
    private EncryptUtility encryptUtility;
    private ObtainIpUtility obtainIpUtility;
    private SessionUtil sessionUtil;
    private ConsumerValidator consumerValidator;
    private RegistrationService registrationService;
    private FraudEventLogger fraudEventLogger;
    private LiftService liftService;

    @Value("${recaptcha.site-key}")
    private String recaptchaSiteKey;

    private String recaptchaSiteKeyName = "siteKey";

    @Autowired
    public RegistrationController(
      ReCaptchaService reCaptchaService,
      EncryptUtility encryptUtility,
      ObtainIpUtility obtainIpUtility,
      SessionUtil sessionUtil,
      ConsumerValidator consumerValidator,
      RegistrationService registrationService,
      FraudEventLogger fraudEventLogger,
      LiftService liftService
    ) {
      this.reCaptchaService = reCaptchaService;
      this.encryptUtility = encryptUtility;
      this.obtainIpUtility = obtainIpUtility;
      this.sessionUtil = sessionUtil;
      this.consumerValidator = consumerValidator;
      this.registrationService = registrationService;
      this.fraudEventLogger = fraudEventLogger;
      this.liftService = liftService;
    }

	@PostConstruct
	public void init() {
		RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SUCCESS,
				new ResponseEntity<>(new SaveConsumerResponse(StatusCode.CONFIRMATION), HttpStatus.OK));
		RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_CID_UNAVAILABLE,
				new ResponseEntity<>(new SaveConsumerResponse(StatusCode.CID_UNAVAILABLE), HttpStatus.OK));
		RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR,
				new ResponseEntity<>(new SaveConsumerResponse(StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR),
						HttpStatus.INTERNAL_SERVER_ERROR));
		RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SAVE_CONSUMER_EXIST,
				new ResponseEntity<>(new SaveConsumerResponse(StatusCode.SAVE_CONSUMER_EXIST), HttpStatus.OK));
		RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.SAVE_CONSUMER_SYSTEM_ERROR,
				DEFAULT_ERROR_RESPONSE_ENTITY);
    RESPONSE_ENTITY_MAP.put(RegistrationResponse.StatusCode.INDIRECT_ENROLLMENT_REQUIRED_FIELD_MISSING,
      new ResponseEntity<>(new SaveConsumerResponse(StatusCode.INDIRECT_ENROLLMENT_SYSTEM_ERROR),
        HttpStatus.INTERNAL_SERVER_ERROR));
	}

  /**
     * @param httpRequest
     * @param content
     * @return
     * @throws Exception
     */
    @Operation(summary = "Returns the StatusCode")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Returns a success confirmation", content = {
                    @Content(schema = @Schema(implementation = SaveConsumerResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Required fields missing", content = {
                    @Content(schema = @Schema(implementation = SaveConsumerResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "System Error", content = {
                    @Content(schema = @Schema(implementation = SaveConsumerResponse.class)) }) })
    @PostMapping(value = "/saveConsumer", produces = APPLICATION_JSON, consumes = APPLICATION_JSON)
    public ResponseEntity<SaveConsumerResponse> saveConsumer(HttpServletRequest httpRequest, @RequestBody String content) {
    	long startTime = System.currentTimeMillis();
        ConsumerContext consumerContext = (ConsumerContext) httpRequest.getSession(false).getAttribute(CommonConstants.CONSUMER_CONTEXT);
        String message = "Start - RegistrationController.saveConsumer() - Begin saving consumer to session.";
    //code starts
        AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.BEGIN, message, consumerContext);

        //Get consumer
        Consumer consumer;
        try {
            AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Beginning consumer validation.", consumerContext);
            if (TEMP_FREEZE_LOCK_LIFT_INTENT.equals(consumerContext.getIntent())) {
              AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Lift flow - retrieve Consumer details.", consumerContext);
              consumer = liftService.getConsumer(consumerContext);
            } else {
              AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Registration flow - deserialize Consumer details.", consumerContext);
              consumer = JsonUtils.fromSanitizedJson(content, Consumer.class);
            }
        } catch (Exception ex) {
            message = "Unhandled exception during save consumer. Not able to convert request body Json content to consumer.";
            LOGGER.error(message, ex);
            AUDITOR.recordError(SAVE_CONSUMER, AuditEventStatus.END_FAIL, message, consumerContext, StatusCode.VALIDATION_ERROR.toString(), HttpStatus.INTERNAL_SERVER_ERROR.toString());
            sessionUtil.invalidateSession(httpRequest);
            return new ResponseEntity<>(new SaveConsumerResponse(StatusCode.VALIDATION_ERROR), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        //Validate consumer
        AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Validating consumer...", consumer.getConsumerKey(), consumerContext);
        if (!consumerValidator.isValidConsumer(consumer, consumerContext)) { //format/regex checks - except for middleName, addressLine2, previousAddressLine2, email
            message = "Consumer failed field formatting checks.";
            LOGGER.debug(message);
            AUDITOR.recordError(SAVE_CONSUMER, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), StatusCode.VALIDATION_ERROR.toString(), HttpStatus.BAD_REQUEST.toString());
            sessionUtil.invalidateSession(httpRequest);
            return new ResponseEntity<>(new SaveConsumerResponse(StatusCode.VALIDATION_ERROR), HttpStatus.BAD_REQUEST);
        }

        //reCaptcha validation
        AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, MessageFormat.format("Validating captcha response... captchaResponse = {0}", consumer.getCaptchaResponse()), consumer.getConsumerKey(), consumerContext);
        boolean captchaResponse = reCaptchaService.isResponseValid(obtainIpUtility.obtainIpAddress(httpRequest), consumer.getCaptchaResponse());
        if (!captchaResponse) {
            message = MessageFormat.format("Captcha response failed validation. captchResponse = {0}", consumer.getCaptchaResponse());
            LOGGER.debug(message);
            AUDITOR.recordError(SAVE_CONSUMER, AuditEventStatus.END_FAIL, message, consumerContext, consumer.getConsumerKey(), StatusCode.RECAPTCHA_ERROR.toString(), HttpStatus.OK.toString());
            return new ResponseEntity<>(new SaveConsumerResponse(StatusCode.RECAPTCHA_ERROR), HttpStatus.OK);
        } else {
            AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Captcha successful validation.", consumer.getConsumerKey(), consumerContext);
           }

		RegistrationResponse registrationResponse = null;
		try {
			registrationResponse = registrationService.createConsumer(consumer, consumerContext);
			/**
			 * TID orchestration always returns RegistrationResponse.StatusCode.SUCCESS but
			 * no customerKey or no indirectEnrollmentId nor cid. Hence no additional check below
			 * for registrationResponse.getStatusCode() ==
			 * RegistrationResponse.StatusCode.SUCCESS
			 */
			if (registrationResponse != null && StringUtils.isNotBlank(registrationResponse.getCustomerKey())
					&& StringUtils.isNotBlank(registrationResponse.getIndirectEnrollmentId()) && StringUtils.isNotBlank(registrationResponse.getCustomerIdentifier())) {
				consumer.setConsumerKey(registrationResponse.getCustomerKey());
				consumer.setIndirectEnrollmentId(registrationResponse.getIndirectEnrollmentId());
				consumer.setCustomerIdentifier(registrationResponse.getCustomerIdentifier());
				AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS,
						"Customer Key and Indirect Enrollment Id returned.", consumer.getConsumerKey(),
						consumerContext);
			}
			encryptUtility.encrypt(httpRequest, JsonUtils.toJson(consumer), CommonConstants.CONSUMER_DATA);
			AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, "Consumer successfully saved to session.",
					consumer.getConsumerKey(), consumerContext);
		} catch (Exception e) {
			message = "Unhandled exception during save consumer to session/system. Internal server error.";
			LOGGER.checkBeforeError(message, e);
			AUDITOR.recordError(SAVE_CONSUMER, AuditEventStatus.IN_PROGRESS, message, consumerContext,
					consumer.getConsumerKey());
			registrationResponse = null;
		}
		return mapRegistrationResponse(registrationResponse, httpRequest, consumer.getConsumerKey(), consumerContext, startTime);
    }

    @Operation(summary = "Returns the Captcha Site Key Rest Endpoint and fires fraud event if personal info page.")
    @GetMapping(value = "/captchaSiteKey", produces = "application/json")
    public String getRecaptchaSiteKeyRestEndpoint(
          HttpServletRequest httpServletRequest,
          @RequestParam(name = CommonConstants.PAGE_NAME, required = false) @Pattern(regexp = "[A-Za-z]*") String pageName) {

      if(CommonConstants.PERSONAL_INFO.equals(pageName)) {
        HttpSession httpSession = httpServletRequest.getSession(false);
        ConsumerContext consumerContext = (ConsumerContext) httpSession.getAttribute(CommonConstants.CONSUMER_CONTEXT);
        LogFraudEventRequest event = FraudEventUtils.createBaseFraudEventRequest(consumerContext, null);
        event.setId(FraudEventUtils.EVENT_ID_PII_PAGE_DISPLAYED);
        AUDITOR.recordInfo(AuditConstants.EVENT_RECAPTCHA_SITE_KEY, AuditEventStatus.BEGIN, "Call to fraud event request started", consumerContext);
        fraudEventLogger.logMessage(event, consumerContext, AuditConstants.EVENT_RECAPTCHA_SITE_KEY);
        AUDITOR.recordInfo(AuditConstants.EVENT_RECAPTCHA_SITE_KEY, AuditEventStatus.END_SUCCESS, "Call to fraud event request completed.", consumerContext);
      }

      JSONObject json = new JSONObject();
      json.put(recaptchaSiteKeyName, recaptchaSiteKey);
      return json.toString();
    }

	private ResponseEntity<SaveConsumerResponse> mapRegistrationResponse(RegistrationResponse registrationResponse,
			HttpServletRequest httpRequest, String customerKey, ConsumerContext consumerContext, long startTime) {

		ResponseEntity<SaveConsumerResponse> responseEntity = DEFAULT_ERROR_RESPONSE_ENTITY;
		if (registrationResponse != null) {
			responseEntity = RESPONSE_ENTITY_MAP.get(registrationResponse.getStatusCode());
		}
		if (responseEntity.getStatusCode() != HttpStatus.OK) {
			AUDITOR.recordError(SAVE_CONSUMER, AuditEventStatus.END_FAIL, "Consumer not saved to system.",
					consumerContext, customerKey, responseEntity.getBody().getStatusCode().toString(),
					responseEntity.getStatusCode().toString());
			sessionUtil.invalidateSession(httpRequest);
		} else {
			AUDITOR.recordInfo(SAVE_CONSUMER, AuditEventStatus.END_SUCCESS, "Consumer successfully saved to system",
					consumerContext, customerKey, responseEntity.getBody().getStatusCode().toString(),
					responseEntity.getStatusCode().toString(), Long.toString(startTime));
		}
		return responseEntity;
	}
}
