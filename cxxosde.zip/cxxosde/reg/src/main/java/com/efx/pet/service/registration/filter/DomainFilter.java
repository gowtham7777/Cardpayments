package com.efx.pet.service.registration.filter;

import static com.efx.pet.registration.controller.util.CleanseUtility.stripXSSVulnerabilities;

import java.io.IOException;
import java.text.MessageFormat;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.efx.pet.service.registration.controller.AuditConstants;
import com.efx.pet.utility.configuration.audit.LockAlertAuditor;
import com.efx.pet.utility.logger.LoggingUtil;
import com.efx.pet.utility.logging.AuditEventStatus;
import com.efx.pet.utility.logging.PetLogger;
import com.efx.pet.utility.logging.PetLoggerFactory;

@Component
public class DomainFilter implements Filter {

  private static final PetLogger LOGGER = PetLoggerFactory.getLogger(DomainFilter.class);
  private static final LockAlertAuditor AUDITOR = new LockAlertAuditor(LOGGER, DomainFilter.class.getSimpleName());
  private static final String HTML_ALLOWED = "htmlAllowed";

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    /*
     * Intentionally not implemented
     *
     * */
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    if (response.getCharacterEncoding() == null) {
      response.setCharacterEncoding("UTF-8");
    }

    final HttpServletResponseCopier responseCopier = new HttpServletResponseCopier((HttpServletResponse) response);

    chain.doFilter(new CleansedRequest((HttpServletRequest) request),responseCopier);

    final byte[] copy = responseCopier.getContentAsByteArray();
    final String responseContent = new String(copy, response.getCharacterEncoding());
    final String sanitizedContent = stripXSSVulnerabilities(responseContent);
    if (!responseContent.equals(sanitizedContent) && !responseContent.contains(HTML_ALLOWED)) {
      String msg = "Raw and Cleansed response are not equal. Attack or malformed response. Raw response content: {0}. Cleansed response content: {1}.";
      final String sanitizedLogMessage = LoggingUtil.sanitizeLoggedMessage(MessageFormat.format(msg, responseContent, sanitizedContent));
      LOGGER.error(sanitizedLogMessage);
	  AUDITOR.recordError(AuditConstants.EVENT_DOMAIN_FILTER, AuditEventStatus.END_FAIL, sanitizedLogMessage);
      throw new DomainFilterException("Exception thrown in Domain filter during content sanitization, compare content with whitelist to find root cause");
    }
    responseCopier.copyBodyToResponse();
    responseCopier.flushBuffer();
  }

  /* (non-Javadoc)
   * @see javax.servlet.Filter#destroy()
   */
  @Override
  public void destroy() {
    /*
     * Intentionally not implemented
     *
     * */
  }

}
