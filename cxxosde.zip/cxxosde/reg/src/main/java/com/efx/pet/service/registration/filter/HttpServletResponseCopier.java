package com.efx.pet.service.registration.filter;

import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class HttpServletResponseCopier extends ContentCachingResponseWrapper {

  public HttpServletResponseCopier(HttpServletResponse response) throws IOException {
    super(response);
  }

}
