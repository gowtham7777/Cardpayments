# Pet Channel Web Consumer Registration UI

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.

## Getting started

To work inside the EFX proxy, common issues are proxy settings for [node](https://confluence.equifax.com/display/~sxt214/Current+.npmrc) and [git](https://confluence.equifax.com/display/~bxw58/current+.gitconfig). As of this writing we are using node `v10+` and npm version `6+`.

## .npmrc

`registry=https://nexus.us.equifax.com/repository/gcs-npm-group-v2/ email=youremail@equifax.com`

## Development server

Run `npm run start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files. By default the partner/tenant is defined in the angular.json file under `defaultProject` currently `LA-US`. To run different partners (for example `UCSC`) run `ng serve UCSC --proxy-config proxy.conf.json` or the `npm run startUCSC` shortcut as defined in the package.json scripts. When in doubt, refer to the package.json "scripts" section to see if what you need is there.

Default Tenant UCSC `npm run start`

LA-US 
```npm run startLA-US```

USCS 
```npm run startUCSC```

MY-EFX-US 
```npm run startMY-EFX-US```

## Proxy REST Development Environment

In order to simulate a mock REST API proxy we need to take 3 steps:

1. Run `npm run server` in a single terminal session from the project root. This will use tenants/LA-US/server/server.js to start a node webserver hosting our tenants/LA-US/server/db.json file as `localhost:3000` in your local browser. You will see debugging logged out into this terminal window going forward. To run different partners like `UCSC` run the command `npm run serverUCSC`. Same way this will use `tenants/UCSC/server/server.js` and `tenants/UCSC/server/db.json`.

Default Tenant UCSC `npm run server`

LA-US 
```npm run serverLA-US```

USCS 
```npm run serverUCSC```

MY-EFX-US 
```npm run serverMY-EFX-US```

2. With that server running open a second terminal window and run `npm start` (again defaulting to `LA-US` as our default project as defined in the angular.json file) from the project root. This will start our proxy webserver hosting the angular application using webpack as well as proxy communication to the `localhost:4200/rest` path into our `localhost:3000` server started in step #1.

3. Open your browser to `localhost:4200` and use the web application as normal. AJAX calls should now call our proxy and return mock data using http protocols! You can use this mock server for CRUD operations and see updates using an in-memory data state.

## Component Documentation

 LA-US 
```npm run compodocLA-US```

 USCS 
```npm run compodocUCSC```

 MY-EFX-US 
```npm run compodocMY-EFX-US```


 LA-US Documentation Path
```/documentation/LA-US/index.html```

 USCS Documentation Path
```/documentation/UCSC/index.html```

 MY-EFX-US Documentation Path
```/documentation/MY-EFX-US/index.html```


## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm run build` to build the project. Under the hood this will run a gulp build that will build each tenant/partner in turn. The build artifacts will be stored in the `dist/` directory per subdirectory as named by the tenant/partner. Use the `-prod` flag for a production build. Use the `-aot` flag for ahead of time compilation (recommended). Please refer to the script property in package.json file for commands to build any/all tenants.

## Running unit tests

Run `npm test` to execute the unit tests via [Karma](https://karma-runner.github.io).
Run `npm run coverage` to execute unit tests with [Istanbul](https://www.npmjs.com/package/karma-coverage-istanbul-reporter) and view results in ~\pet-channel-web-consumer-registration\coverage\index.html.

 LA-US 
```npm run coverageLA-US```

 USCS 
```npm run coverageUCSC```

 MY-EFX-US 
```npm run coverageMY-EFX-US```

## Web Driver Manager - Automation Sever

### Update WebDriver
```
webdriver-manager update --versions.chrome 2.44 --proxy=http://username:password@172.22.240.68:18717 --versions.standalone=3.141.59
```
### Start WebDriver 
```
webdriver-manager start --versions.chrome 2.44 --proxy=http://username:password@172.22.240.68:18717 --versions.standalone=3.141.59
```
## UCSC Live Automation - Load Enviroment

### Install dependencies

```
$cd webapp/UCSC/QA-Automation/integration
$npm install
```


### Start Local Smoke

```
npm run local-smoke
```


### Start Local Smoke - Personal Info

```
npm run local-personalInfo-smoke
```


### Start Local Smoke - Account Create

```
npm run local-accountCreate-smoke
```

### Start Live Smoke

```
npm run live-smoke
```

### Start Live Smoke KBA

```
npm run live-smoke-kba
```

### Start Live Smoke Email

```
npm run live-smoke-email
```


### Start Live Smoke Text

```
npm run live-smoke-text
```


### Start happy path KBA Free Extral Product 4 steps

```
npm run live-happyPathKBA-free-product
```

### Start happy path KBA Paid External Product 4 steps

```
npm run live-happyPathKBA-paid-product
```

### Start Product sign in with Campaign Code

```
npm run live-product-campaign-sign-in
```

### Start Product sign in default

```
npm run live-product-sign-in
```

## Unit tests through BrowserStack

Since our Jenkins servers cannot run angular unit tests through Chrome, we needed a separate karma config for BrowserStack specific execution. If you have BrowserStack Local set up on your local machine, you can run unit tests with this configuration with the command, `npm run coverageJenkins` for all unit tests on each tenant. For individual tenants, you can use the specific scripts listed in package.json, such as `npm run coverageUCSCJenkins`

## Running behavior driven tests with Cucumber/Protractor

https://confluence.equifax.com/pages/viewpage.action?pageId=410694731

## Running end-to-end tests (not currently in-use)

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/). Protractor tests are NOT actively in development for this project.

## Problems installing

If you have problems running `npm install` after an git update: delete the `node_modules` folder and `package-lock.json` then do a fresh `npm install`. Sometimes `package-lock.json` will have https addresses that get blocked or intercepted by the proxy differently in certain locations (eg. such as Dublin vs JVW/OAC). Also I have seen incomplete `npm install` operation leave corrupted files in `node_modules` which needs a clean reinstall to work (hence the `delete the node_modules` step).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
