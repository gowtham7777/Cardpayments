module.exports = {
    singleQuote: true,
};
