// ================================================================================================
// Constants
// ================================================================================================
const execSync = require('child_process').execSync;
const fs = require('fs');
const gulp = (require('gulp'));
const options = require('gulp-options');

// Read configuration from angular.json
const NG_CONFIG = JSON.parse(fs.readFileSync('./angular.json'));

// ================================================================================================
// Tasks
// ================================================================================================

gulp.task('build', async function() {
    buildTargetApps(); 
    getBuildTargetAppsOptions();
});
gulp.task('test', async function() {
    testTargetApps()
});


// ================================================================================================
// Helper Methods
// ================================================================================================

// For a clear log message
function logBannerMessage(str) {
    console.log(
        `\n\n==============================\n${str}\n==============================\n\n`
    );
}

// Builds a string with format: --key=value --key2=value2
function paramStringFromJsonObj(obj) {
    let paramString = '';
    Object.keys(obj).forEach(key => {
        paramString += obj[key] ? `--${key} ${obj[key]} ` : '';
    });
    return paramString;
}

// Runs the provided command with logging
function verboseExecSync(cmd) {
    console.log(`> ${cmd}`);
    execSync(cmd, { stdio: [0, 1, 2] });
}

// Execute the ng build command for the target appNames using the given build args
function ngBuildFor(appNames, buildConfigObj) {
    for (let name of appNames) {
        logBannerMessage(`Building app with name: ${name}`);

        let updatedConfig = JSON.parse(JSON.stringify(buildConfigObj)); // hardcopy
        // Tack on a subdirectory structure before the results of the build
        if (options.has('subDir')) {
            updatedConfig['output-path'] += `${options.get('subDir')}/`;
        }

        updatedConfig['output-path'] += `${name}/`; // force subdirectory for tenant in output path
        updatedConfig['base-href'] += `${name}/`; // use tenant routes in single war
        updatedConfig['deploy-url'] += `${name}/`; // use tenant routes in single war

        // Build the cmd to run after updating the config
        const args = paramStringFromJsonObj(updatedConfig);
        verboseExecSync(`ng build ${args} --project ${name}`);
        
    }
}

// Returns an array of the apps to build as provided in the user options.
// Defaults to the angular.json "defaultProject"
function getTargetApps() {
    let targetApps = [];

    if (NG_CONFIG && NG_CONFIG.projects) {
        // Either build the default app listed in angular.json or from passed in arg
        targetApps = [NG_CONFIG.defaultProject];
        if (options.get('projects')) {
            targetApps = options
                .get('projects')
                .split(',')
                .map(x => x.trim());
        }
    }

    if (targetApps.length === 0) {
        console.error('No apps specified in angular.json. Exiting...');
        process.exit(0);
    }

    return targetApps;
}

// ================================================================================================
// Task Methods & Options
// ================================================================================================

// Build the specified apps
function buildTargetApps() {
    let targetApps = getTargetApps();

    if (targetApps) {
        // Retrieve the specified build config file, if provided
        const buildConfigFile = options.has('config')
            ? options.get('config')
            : 'build-prod.conf.json';
        const buildParams = JSON.parse(fs.readFileSync(buildConfigFile));
        buildParams['output-path'] = options.has('outputPath')
            ? options.get('outputPath')
            : buildParams['output-path'];

        ngBuildFor(targetApps, buildParams);
    }
}
function getBuildTargetAppsOptions() {
    return {
        options: {
            'config=path_to_config':
                'Uses the build configuration file specified. Defaults to build-prod.conf.json',
            'projects=App1,App2,...':
                'Comma separated list of projects to build. (Default project will build if nothing provided)',
            'outputPath=directory':
                'Explicitly set the output directory (relative to this gulpfile). Overrides `output-path` in the config.',
            'subDir=directory':
                'Place the output in the following sub directory. Used for <outputPath>/AppName/<subDir>'
        }
    };
}

// Test the specified apps
function testTargetApps() {
    let targetApps = getTargetApps();
    if (targetApps) {
        for (let name of targetApps) {
            logBannerMessage(`Testing app with name: ${name}`);
            verboseExecSync(
                `ng test ${name} --code-coverage`
            );
        }
    }
}
function getTestTargetAppsOptions() {
    return {
        options: {
            'karma-config=path_to_config':
                'Uses the karma configuration file name specified within the webapp/tenants/TENANT/ folder',
            'projects=App1,App2,...':
                'Comma separated list of projects to test. (Default project will build if nothing provided)'
        }
    };
}
