import { Component, OnInit } from '@angular/core';
import { BrowserCheckService } from '@services/browser-check.service';

// This component is loaded into app.component.html to provide users with a global, dismissible
// warning if their browser is unsupported
@Component({
  selector: 'unsupported-browser',
  templateUrl: './unsupported-browser.component.html',
  styleUrls: ['./unsupported-browser.component.scss'],
})
export class UnsupportedBrowserComponent implements OnInit {
  unknownBrowser = false;
  showMessage = false;
  minimumVersion: number;
  browserVersion: string;

  constructor(private browserCheck: BrowserCheckService) {}

  ngOnInit() {
    this.browserCheck.detectBrowserVersion();
    this.minimumVersion = this.browserCheck.getMinimumVersion();
    this.browserVersion = this.browserCheck.getBrowserVersion();
    this.showMessage = this.browserCheck.isBrowserMessageVisible();
    this.unknownBrowser = this.browserCheck.isUnknownBrowser();
  }

  close() {
    this.showMessage = false;
    this.browserCheck.hideBrowserMessage();
  }
}
