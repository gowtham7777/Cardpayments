import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { BrowserCheckService } from '@services/browser-check.service';
import { HttpClient } from '@angular/common/http';

import { UnsupportedBrowserComponent } from './unsupported-browser.component';

describe('UnsupportedBrowserComponent', () => {
  let component: UnsupportedBrowserComponent;
  let fixture: ComponentFixture<UnsupportedBrowserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ TestBedModule ],
      providers: [ BrowserCheckService, HttpClient ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnsupportedBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
