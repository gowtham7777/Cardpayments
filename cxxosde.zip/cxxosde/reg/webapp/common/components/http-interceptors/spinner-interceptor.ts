// Angular
import {
  HttpInterceptor,
  HttpHandler,
  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';

// Rxjs
import { finalize } from 'rxjs/operators';


// Custom
import { AppConfig } from '@app/app.config';
import { GlobalSpinnerComponent } from './global-spinner/global-spinner.component';
import { AppConfiguration } from '@common/models/app-configuration.model';

@Injectable()
export class SpinnerInterceptor implements HttpInterceptor {
  // These variables persist across all instances of the SpinnerInterceptor
  private static spinnerDelay = 2000; // default to be overwritten by call to AppConfigService
  private static dialogTracker = 0;

  private dialogTimer;
  private spinner: MatDialogRef<GlobalSpinnerComponent>;

  constructor(
    private config: AppConfig,
    private dialog: MatDialog,
  ) { }

  setConfiguration(configurationData: AppConfiguration) {
    SpinnerInterceptor.spinnerDelay = configurationData.spinnerMillisecondDelay;
  }

  // Intercept HTTP requests and load a spinner
  // If you do not want to show the spinner on a particular request,
  // just add a header with the key, noSpinnerHeader, found in the AppConfig
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const noSpinner = req.headers.has(this.config.noSpinnerHeader);

    // Strip excess header if we did not want a spinner
    if (noSpinner) {
      const cleanHeaders = req.headers.delete(this.config.noSpinnerHeader);
      const cleanReq = req.clone({headers: cleanHeaders});
      return next.handle(cleanReq);

      // Start the spinner logic!
    } else {
      this.startSpinnerTimer(SpinnerInterceptor.spinnerDelay);

      // Attempt to stop the spinner after a response comes back
      return next.handle(req)
        .pipe(
          finalize(() => {
            this.endSpinnerTimer();
          })
        );
    }
  }

  // Create a timeout object to start spinner after x milliseconds
  startSpinnerTimer(targetMilli) {
    if (!this.dialogTimer) {
      this.dialogTimer = setTimeout(this.startSpinner.bind(this), targetMilli);
    }
  }

  // Open the spinner dialog and keep track of the # of requests
  startSpinner() {
    if (SpinnerInterceptor.dialogTracker === 0 && this.spinner === undefined) {
      window.scrollTo(0, 0); // scroll to top before dialog appears
      this.spinner = this.dialog.open(GlobalSpinnerComponent, {disableClose: true});
    }

    // Not a critical region because JavaScript is single threaded
    SpinnerInterceptor.dialogTracker += 1;
  }

  // Hide the spinner and disable the timeout object
  endSpinnerTimer() {
    if (this.dialogTimer !== undefined) {
      this.stopSpinner();
      clearTimeout(this.dialogTimer);
      this.dialogTimer = undefined;
    }
  }

  // Close the spinner dialog if there was only one request left to finish
  stopSpinner() {
    if (SpinnerInterceptor.dialogTracker === 1 && this.spinner !== undefined) {
      this.spinner.close(GlobalSpinnerComponent);
      this.spinner = undefined;
    }

    if (SpinnerInterceptor.dialogTracker > 0) { SpinnerInterceptor.dialogTracker -= 1; }
  }
}
