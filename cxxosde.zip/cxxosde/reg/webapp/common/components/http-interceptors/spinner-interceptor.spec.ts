// Angular
import { async, TestBed } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { HttpRequest, HttpHeaders, HttpXhrBackend } from '@angular/common/http';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Routes } from '@angular/router';

// Modules
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';

// Misc
import { AppConfig } from '@app/app.config';
import { SpinnerInterceptor } from './spinner-interceptor';
import { GlobalSpinnerComponent } from '@common/components/http-interceptors/global-spinner/global-spinner.component';


describe('Spinner Interceptor', () => {
  let config: AppConfig;
  let interceptor: SpinnerInterceptor;
  const mockHandler = new HttpXhrBackend(null);
  const limitedRoutes: Routes = BaseRoutesWith([]);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        GlobalSpinnerComponent
      ],
      imports: [
        MatDialogModule,
        TestBedModule,
        RouterTestingModule.withRoutes(limitedRoutes)
      ],
      providers: [
        { provide: MatDialogRef, useValue: {} },
        AppConfig,
        SpinnerInterceptor
      ]
    });

    // Allow global spinner to be recognized by interceptor
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [GlobalSpinnerComponent]
      }
    });
  }));

  beforeEach(() => {
    config = TestBed.get(AppConfig);
    interceptor = TestBed.get(SpinnerInterceptor);
  });

  it('should attempt to open the spinner on an http request', () => {
    const mockHeaders = new HttpHeaders();
    const mockReq = new HttpRequest('GET', '', {headers: mockHeaders});

    spyOn(interceptor, 'startSpinnerTimer');
    interceptor.intercept(mockReq, mockHandler);
    expect(interceptor.startSpinnerTimer).toHaveBeenCalled();
  });

  it('should not attempt to open the spinner if the request has the no spinner header', () => {
    const mockHeaders = new HttpHeaders().set(config.noSpinnerHeader, 'true');
    const mockReq = new HttpRequest('GET', '', {headers: mockHeaders});

    spyOn(mockReq.headers, 'delete');
    interceptor.intercept(mockReq, mockHandler);
    expect(mockReq.headers.delete).toHaveBeenCalledWith(config.noSpinnerHeader);
  });

  it('should open the dialog window if there is not one currently open', () => {
    spyOn(interceptor['dialog'], 'open').and.stub();

    interceptor.startSpinner();
    expect(interceptor['dialog'].open).toHaveBeenCalled();
  });

  it('should keep track of multiple attempts to open the dialog window, but only open once', () => {
    spyOn(interceptor['dialog'], 'open').and.stub();

    // Even if we call the spinner 3 times, it should only open the dialog once
    const attempts = 3;
    SpinnerInterceptor['dialogTracker'] = 0;
    for (let i = 0; i < attempts; ++i ) {
      interceptor.startSpinner();
    }

    expect(interceptor['dialog'].open).toHaveBeenCalledTimes(1);
    expect(SpinnerInterceptor['dialogTracker']).toBe(attempts);
  });

  it('should close the dialog window if there is only one request left', () => {
    SpinnerInterceptor['dialogTracker'] = 0;
    interceptor.startSpinner();
    expect(interceptor['spinner']).toBeTruthy();

    interceptor.stopSpinner();
    expect(interceptor['spinner']).toBeFalsy();
  });

  it('should clear the dialog trigger timer', () => {
    interceptor.startSpinnerTimer(2000);
    expect(interceptor['dialogTimer']).toBeTruthy();

    interceptor.endSpinnerTimer();
    expect(interceptor['dialogTimer']).toBeFalsy();
  });
});
