import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { CartContentResponse } from '@common/models/cart-content.model';
import { environment } from '@common/environments/environment';
import { CartContentService } from '@common/services/cart-content.service';

@Component({
  selector: 'cart-content',
  templateUrl: './cart-content.component.html',
  styleUrls: ['./cart-content.component.scss']
})
export class CartContentComponent implements OnInit {

  private MONTHLY = 'MONTHLY';
  private ANNUALLY = 'ANNUALLY';
  private MONTH = "mo";
  private YEAR = "yr";
  private USD = "USD"
  public isCartDropdownVisible = false;

  visible: boolean = true;
  @Output() openDropdown: EventEmitter<any> = new EventEmitter();

  cartContent: CartContentResponse;

  constructor(
    private router: Router,
    private httpClient: HttpClient,
    private cartService: CartContentService
  ) {  }

  ngOnInit() {
    this.cartService.shouldShowCart().subscribe((showCart: any) => {
      if (showCart && !this.cartContent) {
        this.getProductOffer();
      }
    });
  }

  private getProductOffer = () => {
    this.httpClient
      .get<any>(environment.cartContentUrl).subscribe(
        (data:any) => {
          if (data) {
            this.cartContent = data;
          }
        },
        err => {
          this.router.navigateByUrl('system-error');
        }
      );
  }

  getTerm = () => {
    if (!this.cartContent || !this.cartContent.productOfferDetails || !this.cartContent.productOfferDetails.term) {
      throw new Error('Product Term Unknown');
    }
    const term = this.cartContent.productOfferDetails.term;
    if (term === this.MONTHLY) {
      return this.MONTH;
    } else if (term === this.ANNUALLY) {
      return this.YEAR;
    } else {
      throw new Error('Unrecognized Product Term');
    }
  }

  getCartContent = () => {
    return JSON.stringify(this.cartContent);
  }

  removeProduct = () => {
    window.location.href = environment.redirectToProductPageUrl;
  }

  showCartDropdown() {
    this.visible = !this.visible;
    this.openDropdown.emit(this.visible);
  }

  getCurrencySymbol = () => {
    if (!this.cartContent || !this.cartContent.productOfferDetails
      || !this.cartContent.productOfferDetails.retailPrice || !this.cartContent.productOfferDetails.retailPrice.currency) {
        throw new Error('Currency Type Unknown');
    }

    if (this.cartContent.productOfferDetails.retailPrice.currency.toUpperCase() === this.USD) {
      return '$';
    } else {
      throw new Error("Unrecognized Currency Type: " + this.cartContent.productOfferDetails.retailPrice.currency);
    }
  }

}
