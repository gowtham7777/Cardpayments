import { HttpClient } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TestBedModule } from '@app/shared/test-bed.module';
import { CartContentService } from '@common/services/cart-content.service';
import { SvgIconStub } from '@common/test/stubs/svg-icon-stub';
import { of } from 'rxjs';
import { CartContentComponent } from './cart-content.component';

const mockedResponse = {
  "statusCode": "SUCCESS",
  "productOfferDetails": {
    "skuId": 123,
    "productName": "Equifax Complete Premier Plan",
    "productCode": "APLAN",
    "deliveryChannel": "ONLINE",
    "shortDescription": "<p> This product includes your 3-Bureau Credit scores </p> <p> These credit scores are Vantage 3.0 based on Equifax data. Third parties may use a different type of credit score to assess your creditworthiness </p> <p> Cancel at any time; sorry, no partial month refunds </p>",
    "longDescription": "<div> <li> Get Alerted of key changes to your Equifax Credit Report </li> <li> Daily access to your credit score </li> <li> Dedicated ID restoration specialists to help you recover from ID Theft </li> </div>",
    "retailPrice": {
      "amount": 19.95,
      "currency": "USD"
    },
    "salePrice": {
      "amount": 19.95,
      "currency": "USD"
    },
    "term": "MONTHLY"
  }
}
export class RouterStub {
  navigateByUrl = (url: string) => {
    // do nothing
  }
}

export class HttpClientStub {

  response;

  constructor(response) {
    this.response = response;
  }

  get = (url: string) => {
    return of(this.response);
  }
}

export class CartServiceStub {
  shouldShowCart = () => {
    return of(true);
  }
}

describe('CartContentComponent', () => {
  let fixture: ComponentFixture<CartContentComponent>;
  let component: CartContentComponent;
  let priceFormat = '${} / {}';


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CartContentComponent, SvgIconStub],
      providers: [
        { provide: HttpClient, useValue: {} },
        CartContentComponent,
        { provide: CartContentService, useClass: CartServiceStub }
      ],
      imports: [
        TestBedModule
      ]
    });
  }));

  it('should retrieve cart content from mocked service', () => {
    TestBed.overrideProvider(HttpClient, { useValue: new HttpClientStub(mockedResponse) });
    TestBed.compileComponents();
    fixture = TestBed.createComponent(CartContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    expect(component.getCartContent()).toEqual(JSON.stringify(mockedResponse));
    expect(component.getTerm()).toEqual('mo');
    expect(component.getCurrencySymbol()).toEqual("$");
    let cartContent = JSON.parse(component.getCartContent());
    expect(cartContent.productOfferDetails.retailPrice.amount).toEqual(mockedResponse.productOfferDetails.retailPrice.amount);
  });

  it('should throw error if currency type is not recognized', () => {
    let response = JSON.parse(JSON.stringify(mockedResponse)); 
    response.productOfferDetails.retailPrice.currency = 'NOT_RECOGNIZED';
    TestBed.overrideProvider(HttpClient, { useValue: new HttpClientStub(response) });
    TestBed.compileComponents();
    fixture = TestBed.createComponent(CartContentComponent);
    component = fixture.componentInstance;

    let errorWasThrown = false;
    try {
      fixture.detectChanges();
    } catch (e) {
      errorWasThrown = true;
    }
    expect(errorWasThrown).toBe(true);
  });

  it('should display same price as mockedResponse', () => {
    TestBed.overrideProvider(HttpClient, { useValue: new HttpClientStub(mockedResponse) });
    TestBed.compileComponents();
    fixture = TestBed.createComponent(CartContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const priceElement = fixture.debugElement.query(By.css('.efx-type--bold.efx-l-pad-xsmall--vertical.efx-type-copy'));
    const price = priceElement.nativeElement.innerHTML;
    const correctPriceToDisplay = priceFormat
      .replace('{}', JSON.stringify(mockedResponse.productOfferDetails.retailPrice.amount))
      .replace('{}', 'mo');
    expect(price).toEqual(correctPriceToDisplay);
  });

  it('should display 0.00 as 0.00', () => {
    let response = JSON.parse(JSON.stringify(mockedResponse))
    response.productOfferDetails.retailPrice.amount = 0.00;
    TestBed.overrideProvider(HttpClient, { useValue: new HttpClientStub(response) });
    TestBed.compileComponents();
    fixture = TestBed.createComponent(CartContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const priceElement = fixture.debugElement.query(By.css('.efx-type--bold.efx-l-pad-xsmall--vertical.efx-type-copy'));
    const price = priceElement.nativeElement.innerHTML;
    const correctPriceToDisplay = priceFormat
      .replace('{}', '0.00')
      .replace('{}', 'mo');
    expect(price).toEqual(correctPriceToDisplay);
  });

  it('should throw error when currency is not recognized', () => {
    let response = JSON.parse(JSON.stringify(mockedResponse))
    response.productOfferDetails.retailPrice.currency = "BTC";
    TestBed.overrideProvider(HttpClient, { useValue: new HttpClientStub(response) });
    TestBed.compileComponents();
    fixture = TestBed.createComponent(CartContentComponent);
    component = fixture.componentInstance;

    let errorWasThrown = false;
    try {
      fixture.detectChanges();
    } catch (e) {
      errorWasThrown = true;
    }
    expect(errorWasThrown).toBe(true);
  });

});

