import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { TermsOfUse } from '@common/models/termsOfUse.model';
import { environment } from '../../tenants/UCSC/environments/environment';

/**
 * Service to handle Terms of Use of leadgen
 */
@Injectable()
export class LeadgenTermsOfUseService {
     termsPackagePolicy: BehaviorSubject<any> = new BehaviorSubject<any>(null);

    constructor(private httpClient: HttpClient) {}

    //method to get the policies.
    getLatestTermsByPolicyType() {
        return this.httpClient.get<TermsOfUse>(
            environment.getLatestPolicyByPolicyType
        );
    }    

    updateTOUPolicy(policy: any){
        this. termsPackagePolicy.next(policy);
    }
}
