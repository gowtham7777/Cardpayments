import { TestBed, inject } from '@angular/core/testing';
import { SingleSignOnService } from './single-sign-on.service';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { TestBedModule } from '@app/shared/test-bed.module';
import { Router } from '@angular/router';
import { RouteNames } from '@app/app.route-names';

export class RouterStub {
    navigate = (url: string) => {
        // do nothing
    }
}

const successResponse = {
    'statusCode': 'SSO_TOKEN_GENERATION_SUCCESS',
    'singleSignOnDetails': {
      // tslint:disable-next-line:max-line-length
        'encryptedData': 'AZWYLxjGlAA+IEGyNc5gkOZAJoskG9YFqXoZzWe6GnlbDVoHgCh1bgRXfn+cSazhb+bIQo1CPsmISc+O1F4erqpR8CqKq2LekXWIM1c6WqQwF9M6SiTUOiy8rTSl0N+RLfGH2u9HEX9llAd/FoU8wdzE8y/knglM/fUfTYUoSTKDkSbbH5coqJX7Kcz6jsEivzr+/g4/jF0trnWrrZSntI1B7UCVQRx4guYkRuRlV5oqx4rahOQl/lV4g9cWM2wMjI1LymyTsEvIf4ds0ezvhUxGIQSNqDFsG5Y2Up1xWYiCL8wCysF9TtGV+WEnhT+fwEnwePHxJ0P95CY3twfHe6yUPuhmeoYvY9NP57yuqDzzJWhimoqlvXy0xa5OXjtv01aXSZYLklKzofxf6aTcF+YXZH8VuaGMpvD9kbC1Bw5fuK5KoZlVG4YeSYhdgCUc',
        'tokenInfo': {
            'accessToken': 'a765cbe6-40d1-46e8-be08-e34df4c67cfb',
            'refreshToken': '9bcced90-895f-4120-bec0-4200e1e38251',
            'expiresIn': 339
        }
    }
};

const successResponseWithUpsellSkuId = {
    'statusCode': 'SSO_TOKEN_GENERATION_SUCCESS',
    'singleSignOnDetails': {
        // tslint:disable-next-line:max-line-length
        'encryptedData': 'AZWYLxjGlAA+IEGyNc5gkOZAJoskG9YFqXoZzWe6GnlbDVoHgCh1bgRXfn+cSazhb+bIQo1CPsmISc+O1F4erqpR8CqKq2LekXWIM1c6WqQwF9M6SiTUOiy8rTSl0N+RLfGH2u9HEX9llAd/FoU8wdzE8y/knglM/fUfTYUoSTKDkSbbH5coqJX7Kcz6jsEivzr+/g4/jF0trnWrrZSntI1B7UCVQRx4guYkRuRlV5oqx4rahOQl/lV4g9cWM2wMjI1LymyTsEvIf4ds0ezvhUxGIQSNqDFsG5Y2Up1xWYiCL8wCysF9TtGV+WEnhT+fwEnwePHxJ0P95CY3twfHe6yUPuhmeoYvY9NP57yuqDzzJWhimoqlvXy0xa5OXjtv01aXSZYLklKzofxf6aTcF+YXZH8VuaGMpvD9kbC1Bw5fuK5KoZlVG4YeSYhdgCUc',
        'tokenInfo': {
            'accessToken': 'a765cbe6-40d1-46e8-be08-e34df4c67cfb',
            'refreshToken': '9bcced90-895f-4120-bec0-4200e1e38251',
            'expiresIn': 339
        },
        'upsellSkuId': 10990
    },
};

const failResponse = {
    'statusCode': 'SSO_TOKEN_VALIDATION_ERROR'
};

const authResponse = {
    'expires_in': 339,
    'authorities': [
      {
        'roleId': 'ROLE_ALLOW'
      }
    ]
};

describe('SingleSignOnService', () => {

    let httpClient: HttpClient;
    let router: Router;
    let routeNames: RouteNames;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                SingleSignOnService,
                { provide: Router, useClass: RouterStub }
            ],
            imports: [TestBedModule]
        });
    });

    beforeEach(() => {
        httpClient = TestBed.get(HttpClient);
        router = TestBed.get(Router);
        routeNames = TestBed.get(RouteNames);
    });

    it('should be created', inject([SingleSignOnService], (service: SingleSignOnService) => {
        expect(service).toBeTruthy();
    }));

  // tslint:disable-next-line:max-line-length
    it('should redirect to memberceneter account-is-setup when success ssoDetail response returned', inject([SingleSignOnService], (service: SingleSignOnService) => {
        spyOn(httpClient, 'get').and.returnValue(of(successResponse));
        const clientSpy = spyOn(httpClient, 'post').and.returnValue(of(authResponse));
        const sessionSpy = spyOn(window.sessionStorage, 'setItem');

        service.beginSingleSignOn();

        // can not assert on window.location.href change so needed to assert on post call that is made before window change
        expect(clientSpy).toHaveBeenCalled();
        expect(sessionSpy).toHaveBeenCalledTimes(3);
    }));

    // tslint:disable-next-line:max-line-length
    it('should redirect to memberceneter checkout when success ssoDetail response returned with upsellSkuId', inject([SingleSignOnService], (service: SingleSignOnService) => {
        spyOn(httpClient, 'get').and.returnValue(of(successResponseWithUpsellSkuId));
        const clientSpy = spyOn(httpClient, 'post').and.returnValue(of(authResponse));
        const sessionSpy = spyOn(window.sessionStorage, 'setItem');

        service.beginSingleSignOn();

        // can not assert on window.location.href change so needed to assert on post call that is made before window change
        expect(clientSpy).toHaveBeenCalled();
        expect(sessionSpy).toHaveBeenCalledTimes(4);
    }));

    it('should navigate to error page when failure response is returned', inject([SingleSignOnService], (service: SingleSignOnService) => {
        spyOn(httpClient, 'get').and.returnValue(of(failResponse));
        const routerSpy = spyOn(router, 'navigate');
        service.beginSingleSignOn();
        expect(routerSpy).toHaveBeenCalledWith([routeNames.callCenter]);
    }));

});
