import { TestBed } from '@angular/core/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';
import { MatDialogModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';

import { AppConfigService } from './app-config.service';
import { LanguageService } from '@common/services/language.service';

import { Subscriber, Observable } from 'rxjs';

let mockData = {
    'captchaSiteKey': '6LeyhS8UAAAAAOKY7IX5dgdkkStjzZChXtbV7Cj6',
    'idleDuration': 840,
    'idleWarningDuration': 60,
    'resourceBundle': '/dist/lockandalert/',
    'minAgeToRegister': 18,
    'spinnerMillisecondDelay': 2000,
    'successMCLoginUrl': 'https://my.equifax.com/membercenter/#/login',
    'tenantLocale': 'en-us',
    'defaultLocale': 'EN',
    'tenantPartner': 'ucsc',
    'termsUrl': 'https://www.equifax.com/myEquifaxterms',
    'timeoutPageUrl': 'https://www.equifax.com',
    'callCenterDetails' : {
    'callCenterTimeMessage': 'Customer Care is available 9:00 AM and 9:00 PM ET, Mon-Fri; 9:00 AM and 6:00 PM ET, Sat-Sun.',
    'callCenterPhoneNumber': '1-888-EQUIFAX (1-888-378-4329)',
    'ptpCallCenterMessage':'between 9:00 AM and 9:00 PM ET, Mon-Fri; 9:00 AM and 6:00 PM ET, Sat-Sun.'
    }
}

describe('AppConfigService', () => {
  let service: AppConfigService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule, MatDialogModule, RouterTestingModule.withRoutes(BaseRoutesWith([]))],
      providers: [
        AppConfigService,
        LanguageService
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AppConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getLoginURL', () => {
    const result = 'https://tid-uat9.trustedid.com';
    const url = 'https://tid-uat9.trustedid.com';
    expect(service.updateUrlForMobileParam(url)).toBe(result);
  });

  it('should fetch configurations from endpoint and try to assign values', () => {
    const mockConfig = new Observable<any>( (subscriber: Subscriber<any>) => (subscriber.next({ test: 'test' })) );
    spyOn(service['http'], 'get').and.returnValue(mockConfig);
    spyOn(service['timeoutService'], 'setConfiguration').and.stub();
    spyOn(service['spinnerInterceptor'], 'setConfiguration').and.stub();
    spyOn(service['languageService'], 'setConfiguration').and.stub();

    service.getAppConfiguration();
    expect(service['http'].get).toHaveBeenCalled();
    expect(service['timeoutService'].setConfiguration).toHaveBeenCalled();
    expect(service['spinnerInterceptor'].setConfiguration).toHaveBeenCalled();
    expect(service['languageService'].setConfiguration).toHaveBeenCalled();
  });

  it('should get configuration from endpoint and try to get customer message and other customer care details', () => {
    const mockConfig = new Observable<any>( (subscriber: Subscriber<any>) => (subscriber.next(mockData)) );
    spyOn(service['http'], 'get').and.returnValue(mockConfig);
    service.getAppConfiguration();
    expect(service['http'].get).toHaveBeenCalled();
    expect(service.configurationData.callCenterDetails.callCenterTimeMessage).not.toBe('');
    expect(service.configurationData.callCenterDetails.callCenterPhoneNumber).not.toBe('');
    expect(service.configurationData.callCenterDetails.ptpCallCenterMessage).not.toBe('');

  })

});
