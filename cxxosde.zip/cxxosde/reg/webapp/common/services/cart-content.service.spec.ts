import { inject, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { CartContentService } from './cart-content.service';

describe('CartContentService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CartContentService],
            imports: [TestBedModule]
        });
    });

    it('should be created', inject([CartContentService], (service: CartContentService) => {
        expect(service).toBeTruthy();
    }));

    it('should default showCart to false', inject([CartContentService], (service: CartContentService) => {
        service.shouldShowCart().subscribe(val => expect(val).toEqual(false));
    }));

    it('updateShowCart to false should update showCart to false', inject([CartContentService], (service: CartContentService) => {
        service.updateShowCart(false);
        service.shouldShowCart().subscribe(val => expect(val).toEqual(false));
    }));


});