import { AnalyticsService } from '@common/services/analytics.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfig } from '@app/app.config';
import { AppConfiguration } from '@common/models/app-configuration.model';
import { TimeoutService } from '@app/timeout/timeout.service';
import { LanguageService } from '@common/services/language.service';
import { SpinnerInterceptor } from '@common/components/http-interceptors/spinner-interceptor';
import { environment } from '@app/../environments/environment';
import { ReplaySubject, BehaviorSubject } from 'rxjs';


@Injectable()
export class AppConfigService {
  headers: HttpHeaders;
  isMobileApp = false;
  public mobileQueryParamValue = null;
  configurationData: AppConfiguration;
  private configurationData$ = new ReplaySubject<AppConfiguration>();
  isDataCached: false;
  private productOffer$ = new ReplaySubject<any>();
  callCenterPhoneNumber$ = new BehaviorSubject('');
  callCenterTimeMessage$ = new BehaviorSubject('');
  ptpCallCenterMessage$ = new BehaviorSubject('');

  constructor(
    private http: HttpClient,
    private timeoutService: TimeoutService,
    private languageService: LanguageService,
    private spinnerInterceptor: SpinnerInterceptor,
    private config: AppConfig,
    public analyticsService: AnalyticsService,
    private router: Router) {
      this.headers = new HttpHeaders()
      .set('Accept', 'application/json')
      .set('Content-Type', 'application/json')
      .set('Cache-Control', 'no-cache, no-store, must-revalidate');

      this.getAppConfiguration();

      this.isMobileApp = (window['isFromMobileApp']) ? true : false;
      this.mobileQueryParamValue = this.isMobileApp ? window['mobileQueryParamValue'] : null;
  }

  changeProductOffer(data: any) {
    if (data.skuId) {
      this.productOffer$.next(data);
    }
  }

  getConfigurationData$() {
    return this.configurationData$.asObservable();
  }

  getProductOffer$() {
    return this.productOffer$.asObservable();
  }

  getAppConfiguration() {
    const time = Date.now();
    const extra = '?timestamp=' + time;
    this.http
      .get<AppConfiguration>(environment.appConfigUrl + extra, {
        headers: this.headers
      })
      .subscribe(
        // Successful responses call the first callback.
        (data:any) => {
          if (data) {
            this.configurationData = data;
            this.configurationData$.next(data);
            // Updating product details
            if(data.productOfferDetails){
              this.changeProductOffer(data.productOfferDetails);
            }

            
            if(data.callCenterDetails){
            this.callCenterTimeMessage$.next(data.callCenterDetails.callCenterTimeMessage);
            this.ptpCallCenterMessage$.next(data.callCenterDetails.ptpCallCenterMessage);
            this.callCenterPhoneNumber$.next(data.callCenterDetails.callCenterPhoneNumber);
            }
            
            this.timeoutService.setConfiguration(this.configurationData);
            this.spinnerInterceptor.setConfiguration(this.configurationData);
            this.languageService.setConfiguration(data);

            /**
             * Ensure loaded Frontend tenant bundle name matches that of backend tenant-partner configuration.
             * When it doesn't, redirect to system error route for loaded bundle.
             */
            const pathname = window.location.pathname;
            // Use this log statement to reason system error route load, right when first/default route is loading
            window.console.log('url pathname: ' + pathname);
            const pathArray = pathname.split('/');
            if ((pathArray.length > 2) && (pathArray[2] !== data.tenantPartner)) {
                // uncomment this when appconfig is updated to return correct tenant bundle
                // window.console.log('ERROR!! Frontend bundle does not match that of backend configuration.');
                // this.router.navigateByUrl('system-error');
            }
          } else {
            this.analyticsService.errorKeyAnalytics(this.config.errorKeys.noObject);
          }
        },
        // Errors will call this callback instead:
        err => {
          this.router.navigateByUrl('system-error');
        }
      );
  }

  updateUrlForMobileParam(destinationUrl: string) {
    const fromMobileApp = this.isMobileApp && !!this.mobileQueryParamValue;
    const queryDelimiter = (destinationUrl.indexOf('?') > -1)  ? '&' : '?';
    const mobileQueryParam = `${queryDelimiter}${this.config.mobileQueryParam}=${this.mobileQueryParamValue}`;
    const queryParam = fromMobileApp ? mobileQueryParam : '';
    return destinationUrl + queryParam;
  }
}
