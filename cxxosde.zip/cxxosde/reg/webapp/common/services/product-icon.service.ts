import { Injectable } from '@angular/core';
import { ProductConstants } from '@common/constants/product-constants';

/**
 * A service to manage product icons for a customer
 */

@Injectable({
  providedIn: 'root'
})
export class ProductIconService {

  /**
   * Get the product icon
   */
  getProductIcon(productCode) {
    const product = ProductConstants.products.filter(res => res.productCode === productCode);
    if (product.length === 1) {
      return 'assets/product-icons/' + product[0].icon + '.svg';
    } else {
      return '';
    }
  }
}
