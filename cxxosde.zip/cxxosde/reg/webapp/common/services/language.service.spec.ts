import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BaseRoutesWith, TestBedModule } from '@app/shared/test-bed.module';
import { AppConfiguration } from '@common/models/app-configuration.model';
import { LanguageService } from './language.service';


const mockDefault = 'testDefault';
const mockPartner = 'testPartner';

describe('LanguageService', () => {
  let service: LanguageService;
  const mockConfig: AppConfiguration = new AppConfiguration;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ],
      providers: [LanguageService]
    });

    mockConfig.defaultLocale = mockDefault;
    mockConfig.tenantPartner = mockPartner;
    service = TestBed.get(LanguageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set the target language(s) after receiving configurations', () => {
    spyOn(service, 'setLanguage').and.callThrough();
    spyOn(service['translate'], 'setDefaultLang');
    spyOn(service['translate'], 'use');
    service.setConfiguration(mockConfig);

    const primaryLang = service.generateLangString(service.defaultLocale, service.partner);
    expect(service.setLanguage).toHaveBeenCalled();
    expect(service['translate'].use).toHaveBeenCalledWith(primaryLang);
    expect(service['translate'].setDefaultLang).toHaveBeenCalledWith(service.defaultLocale);
  });

});
