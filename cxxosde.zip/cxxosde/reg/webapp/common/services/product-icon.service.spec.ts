import { ProductIconService } from './product-icon.service';

describe('Products Service', () => {
  let productBundleService: ProductIconService;

  beforeEach(() => {
    productBundleService = new ProductIconService();
  });

  it('should get an icon for a product', () => {
    expect(productBundleService.getProductIcon('')).toBe('');
    expect(productBundleService.getProductIcon('ECC')).toBe('assets/product-icons/efx-icon--core-credit.svg');
    expect(productBundleService.getProductIcon('ECM')).toBe('assets/product-icons/efx-icon--credit-monitor.svg');
    expect(productBundleService.getProductIcon('EC')).toBe('assets/product-icons/efx-icon--complete.svg');
    expect(productBundleService.getProductIcon('no_match')).toBe('');
  });

});
