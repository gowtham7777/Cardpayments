import { TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { AnalyticsService } from '@common/services/analytics.service';


describe('AnalyticsService', () => {
  let service: AnalyticsService;
  const windowBefore: any = {};
  const mockEventId = 'MockEventId';
  const mockEventName = 'MockEvent';
  const mockErrorKey = 'MockErroCode';
  const mockPageName = 'MockPage';
  const mockPageType = 'MockPageType';
  const mockUpFrontcost = '0.00';
  const mockRecurringCost = '4.99';
  const mockProductCode = 'ECM';
  const mockProductName = 'ECM';
  const mockProductDescription = 'ECM';
  const mockEventIds = [mockEventId];
  const mockEvent = {
    eventData: {
      eventName: mockEventName,
      errorKey: mockErrorKey,
      pageName: mockPageName
    },
    eventIds: mockEventIds
  };
  const mockDigitalData = {
    event: [],
    page: {
      pageInfo: {
        pageName: 'placeholder'
      },
      category: {
        pageType: 'placeholder'
      }
    }
  };
  const mockEventWithContextProduct = {
    eventData: {
      eventName: mockEventName,
      errorKey: mockErrorKey,
      pageName: mockPageName
    },
    eventIds: mockEventIds,
    productDetails: {
      productInfo: {
        productID: mockProductCode,
        productName: mockProductName,
        description: mockProductDescription,
        productCode: mockProductCode,
        upFrontCost: mockUpFrontcost,
        recurringCost: mockRecurringCost
      }
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ TestBedModule ],
      providers: [
        AnalyticsService
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.get(AnalyticsService);
    windowBefore['Analytics'] = window['Analytics'];
    windowBefore['digitalData'] = window['digitalData'];
    windowBefore['isAnalyticsConfigured'] = window['isAnalyticsConfigured'];

    // Mock digital data values
    window['Analytics'] = new Object();
    window['Analytics'].trackEvent = () => {};
    window['digitalData'] = mockDigitalData;
    window['isAnalyticsConfigured'] = true;
  });

  // Maintain the state of window before the test was ran
  // Makes sure the global 'window' variable won't be impacted from test to test
  afterEach(() => {
    window['Analytics'] = windowBefore['Analytics'];
    window['digitalData'] = windowBefore['digitalData'];
    window['isAnalyticsConfigured'] = windowBefore['isAnalyticsConfigured'];
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create digital data events', () => {
    expect(service.createDigitalDataEvent(mockEvent)).toBeTruthy();
  });

  it('should update page names in the digital data object', () => {
    service.updatePageName(mockPageName);
    expect(window['digitalData'].page.pageInfo.pageName).toBe(mockPageName);
  });

  it('should create a digital data event before tracking', () => {
    spyOn(service, 'createDigitalDataEvent').and.callThrough();
    spyOn(service, 'updatePageName').and.stub();
    spyOn(service, 'fireEventTracking').and.stub();

    service.appendEvent(mockEvent);
    expect(service.createDigitalDataEvent).toHaveBeenCalled();
    expect(service.updatePageName).toHaveBeenCalled();
    expect(service.fireEventTracking).toHaveBeenCalled();
  });

  it('should send event attributes to analytics if they exist', () => {
    spyOn(window['Analytics'], 'trackEvent').and.stub();
    const mockEventDetail = service.createDigitalDataEvent(mockEvent);
    mockEventDetail['eventId'] = mockEventId;
    mockEventDetail['attributes'] = {};

    service.fireEventTracking(mockEventDetail);
    expect(window['Analytics'].trackEvent).toHaveBeenCalledWith(
      mockEventDetail['eventId'],
      mockEventDetail['attributes']
    );
  });

  it('should only send event id to analytics if attributes are missing', () => {
    spyOn(window['Analytics'], 'trackEvent').and.stub();
    const mockEventDetail = service.createDigitalDataEvent(mockEvent);
    mockEventDetail['eventId'] = mockEventId;

    service.fireEventTracking(mockEventDetail);
    expect(window['Analytics'].trackEvent).toHaveBeenCalledWith(
      mockEventDetail['eventId']
    );
  });

  it('should send context product details', () => {
    spyOn(service, 'createDigitalDataEvent').and.callThrough();
    spyOn(service, 'updatePageName').and.stub();
    spyOn(service, 'fireEventTracking').and.stub();
    spyOn(service, 'updateContextProductInfo').and.stub();
    
    service.appendEvent(mockEventWithContextProduct);
    expect(service.createDigitalDataEvent).toHaveBeenCalled();
    expect(service.updatePageName).toHaveBeenCalled();
    expect(service.updateContextProductInfo).toHaveBeenCalled();
  });

  it('should update the pageType for each registration Page', () => {
    service.updateCategoryPageName(mockPageType);
    expect(window['digitalData'].page.category.pageType).toBe(mockPageType);
  });

});
