import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AppConfiguration } from '@common/models/app-configuration.model';

// This service is used to synchronize the language set on the
// TranslateService, LocalizeRouterService, and RoutingService
@Injectable()
export class LanguageService {
  public defaultLocale;
  public partner;

  constructor(
    private translate: TranslateService
  ) {
    this.translate.setDefaultLang('en');
  }

  // Generates the primary language string
  generateLangString(locale, partner) {
    return (partner) ? `${locale}-${partner}` : locale;
  }

  // Determine which language json file to use based on supported locales and the partner
  setConfiguration(appConfig: AppConfiguration) {
    this.defaultLocale = appConfig['defaultLocale'].toLowerCase() || 'en';
    this.partner = appConfig['tenantPartner'].toLowerCase();

    // Form the target translation reference to fit the pattern: locale-partner
    // ex) en-ucsc
    const targetJson = this.generateLangString(this.defaultLocale, this.partner);
    this.setLanguage(targetJson, this.defaultLocale);
  }

  setLanguage(primary, secondary) {
    this.translate.setDefaultLang(secondary);
    this.translate.use(primary);
  }

}
