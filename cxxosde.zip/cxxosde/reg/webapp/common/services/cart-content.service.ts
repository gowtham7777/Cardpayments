import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable()
export class CartContentService {

    private showCart$ = new BehaviorSubject(false);

    shouldShowCart(): Observable<boolean> {
        return this.showCart$;
    }

    updateShowCart(shouldShowCart: boolean) {
        this.showCart$.next(shouldShowCart);
    }

}
