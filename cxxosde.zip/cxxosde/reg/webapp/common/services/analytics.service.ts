import { Injectable } from '@angular/core';
import { AppConfig } from '@app/app.config';
@Injectable()
export class AnalyticsService {
    constructor(public appConfig: AppConfig) {}

    appendEvent(eventSet) {
        // first check we've configured our analytics datalayer
        if (window['isAnalyticsConfigured'] && window['Analytics']) {
            // manually fire events directly to Ensighten as recieved...
            if (eventSet.eventIds.length > 0) {
                // Works only for UCSC tenant on ajaxPageLoad events.
                if (this.appConfig.tenantName === 'UCSC') {
                    // For different products
                    // In future replace dynamic product information.
                    if (eventSet.eventIds.includes('ajaxPageLoad')) {
                        this.updateCategoryPageName(eventSet.pageType);
                        this.updateProductInfo(eventSet.productDetails);
                        this.updateContextProductInfo(eventSet.productDetails);
                        this.updateCartInfo(eventSet.productDetails);
                    }
                }

                for (const eventId of eventSet['eventIds']) {
                    const event = this.createDigitalDataEvent(
                        eventSet['eventData']
                    );
                    event['eventId'] = eventId; // append this item of the eventIds set
                    this.updatePageName(eventSet['eventData']['pageName']);
                    this.fireEventTracking(event);
                }
            }
        } else {
            // analytics is not yet configured, set timeout and wait for callback
            setTimeout(() => {
                this.appendEvent(eventSet);
            }, 1000);
        }
    }

    // Creates an object in the Digital Data Event format, pre-populated with information from the 'eventData' parameter.
    createDigitalDataEvent(eventData) {
        if (eventData) {
            return {
                eventInfo: {
                    eventName: eventData.eventName || null,
                    pageName: eventData.pageName || null,
                    eventAction: eventData.eventAction || null,
                    eventPoints: eventData.eventPoints || 0,
                    type: eventData.type || '',
                    timeStamp: eventData.timeStamp || new Date().getTime(),
                    effect: eventData.effect || null,
                    errorKey: eventData.errorKey || null
                },
                category: {
                    primaryCategory: eventData.primaryCategory || null,
                    secondaryCategory: eventData.secondaryCategory || null,
                    tertiaryCategory: eventData.tertiaryCategory || null
                },
                attributes: eventData.attributes || null
            };
        }
    }

    updatePageName(pageName: string) {
        // a safe way of updating the digitalData pageName if included
        if (
            pageName &&
            window['digitalData'] &&
            window['digitalData'].page &&
            window['digitalData'].page.pageInfo &&
            window['digitalData'].page.pageInfo.pageName
        ) {
            window['digitalData'].page.pageInfo.pageName = pageName;
        }
    }

    fireEventTracking(eventDetail: object) {
        if (
            window['digitalData'] &&
            window['digitalData'].event &&
            window['Analytics']
        ) {
            window['digitalData'].event.push(eventDetail);
            if (eventDetail['eventId']) {
                if (eventDetail['attributes'] && eventDetail['attributes'] != null) {
                    window['Analytics'].trackEvent(
                        eventDetail['eventId'],
                        eventDetail['attributes']
                    );
                }  else if (eventDetail['eventInfo'] && eventDetail['eventInfo']['errorKey'] &&
                            eventDetail['eventInfo']['errorKey'] != null) {
                        window['Analytics'].trackEvent(
                        eventDetail['eventId'],
                        {'errorKey': eventDetail['eventInfo']['errorKey']}
                    );
                }   else {
                    window['Analytics'].trackEvent(eventDetail['eventId']);
                }
            }
        }
        return eventDetail;
    }

    callcenterBeacon() {
        this.appendEvent({
            eventData: {
                eventName: this.appConfig.analytics.callCenter.callCustomerCare
                    .eventName
            },
            eventIds: this.appConfig.analytics.callCenter.callCustomerCare.eventIds
        });
    }

    // Adding PageType as authentication for ID Proofing pages
    updateCategoryPageName(newPageType: string) {
        if (
            newPageType &&
            window['digitalData'] &&
            window['digitalData'].page &&
            window['digitalData'].page.category &&
            window['digitalData'].page.category.pageType
        ) {
            window['digitalData'].page.category.pageType = newPageType;
        }
    }

    updateProductInfo(productDetails) {
        if (productDetails && productDetails.productInfo && productDetails.productInfo.productID) {
            if (
                window['digitalData'] &&
                window['digitalData']['product']
            ) {
                window['digitalData']['product'].push({
                    'productInfo': productDetails.productInfo,
                    'category': productDetails.category
                });
            }
        }
    }

    updateCartInfo(productDetail) {
        if (productDetail && productDetail.productInfo && productDetail.productInfo.upFrontCost && productDetail.productInfo.recurringCost  ) {
            if (
                window['digitalData']
            ) {
                window['digitalData']['cart'].price.cartTotal =  productDetail.productInfo.upFrontCost;
                window['digitalData']['cart'].price.basePrice =  productDetail.productInfo.recurringCost;
            }
        }
    }

    updateContextProductInfo(productDetail) {
        if (productDetail && productDetail.productInfo &&
            productDetail.productInfo.productID &&
            productDetail.productInfo.upFrontCost &&
            productDetail.productInfo.recurringCost) {
            if (
                window['digitalData']
            ) {
                window['digitalData']['page']['attributes']['contextProduct'].productCode = productDetail.productInfo.productID;
                window['digitalData']['page']['attributes']['contextProduct'].upFrontCost = productDetail.productInfo.upFrontCost;
                window['digitalData']['page']['attributes']['contextProduct'].recurringCost = productDetail.productInfo.recurringCost;
                }
            }
        }

    errorKeyAnalytics(errorKeyValue) {
        this.appendEvent({
          eventData: {
            errorKey: errorKeyValue
          },
          eventIds: [this.appConfig.errorDisplay]
        });
      }
}
