import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BaseRoutesWith, TestBedModule } from '@app/shared/test-bed.module';
import { LeadgenTermsOfUseService } from './leadgen-terms-of-use.service';


describe('LeadgenTermsOfUseService', () => {
  let service: LeadgenTermsOfUseService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ],
      providers: [LeadgenTermsOfUseService]
    });

    service = TestBed.get(LeadgenTermsOfUseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('updateTOUPolicy to tou policy and subscribed value match', inject([LeadgenTermsOfUseService], (service: LeadgenTermsOfUseService) => {
    service.updateTOUPolicy("tou policy");
    service.termsPackagePolicy.subscribe(val => expect(val).toEqual("tou policy"));
}));

});
