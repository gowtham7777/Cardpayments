import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '@app/../environments/environment';
import { RouteNames } from '@app/app.route-names';
import { QueryParamsMapConstants } from '@common/constants/query-params-map.constants';
import { SsoDetails } from '@common/models/sso-details.model';
import { AppConfigService } from '@common/services/app-config.service';
import { AuthenticationRequest } from '../models/authentication-request.model';
import { AuthenticationResponse } from '../models/authentication-response.model';
import { QueryParamsMap } from './../models/query-params-map.model';


@Injectable()
export class SingleSignOnService {

  private storageName = 'efx-app';
  private accessTokenBegin = 'access_token_begin';
  private authoritires = 'authorities';
  private expiresIn = 'expires_in';
  private ssoDetailsSuccessResponse = 'SSO_TOKEN_GENERATION_SUCCESS';
  private upsellSkuId = 'upsellskuid';
  private headers: HttpHeaders;
  private memberCenterUrl: string;
  private queryParamsMap: QueryParamsMap;

  constructor(
    private configService: AppConfigService,
    private httpClient: HttpClient,
    private router: Router,
    private routes: RouteNames
  ) {
    this.headers = new HttpHeaders().set('Content-Type', 'text/plain');
    this.configService.getConfigurationData$().subscribe(config => {
      this.memberCenterUrl = config.successMCLoginUrl;
      this.queryParamsMap = config.queryParamsMap;
    });
  }

  beginSingleSignOn = () => {
    this.getSsoDetails().subscribe(
      (data: any) => {
        const ssoDetails: SsoDetails = this.parseSsoDetailsResponse(data);
        this.validateSsoDetails(ssoDetails);
        this.redirectToMemberCenter(ssoDetails);
      },
      err => {
        this.router.navigate([this.routes.callCenter]);
      }
    );
  }

  private getSsoDetails = () => {
    return this.httpClient.get<any>(environment.ssoDetailsUrl);
  }

  private parseSsoDetailsResponse = (data: any): SsoDetails => {
    if (data) {
      const ssoDetails: SsoDetails = data;
      return ssoDetails;
    } else {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  private validateSsoDetails = (ssoDetails: SsoDetails) => {
    if (ssoDetails.statusCode !== this.ssoDetailsSuccessResponse) {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  private validateAuthResponse = (authResponse: AuthenticationResponse) => {
    if (!authResponse || !authResponse.expires_in || !authResponse.authorities || authResponse.authorities.length<1) {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  private setSessionStorage = (authResponse: AuthenticationResponse, upsellSkuIdValue: number) => {
    sessionStorage.setItem(this.formatKey(this.accessTokenBegin), this.encodeValue(this.getCurrentTime()));
    sessionStorage.setItem(this.formatKey(this.authoritires), this.encodeValue(authResponse.authorities));
    sessionStorage.setItem(this.formatKey(this.expiresIn), this.encodeValue((Number(authResponse.expires_in)*1000)));
    if (upsellSkuIdValue) {
      sessionStorage.setItem(this.formatKey(this.upsellSkuId), this.encodeValue(upsellSkuIdValue));
    }
  }

  private redirectToMemberCenter = (ssoDetails: SsoDetails) => {
    const authRequest: AuthenticationRequest = new AuthenticationRequest();
    const tokenInfo: any = {};
    tokenInfo.accessToken = ssoDetails.singleSignOnDetails.tokenInfo.accessToken;
    tokenInfo.expiresIn = ssoDetails.singleSignOnDetails.tokenInfo.expiresIn;
    tokenInfo.refreshToken = ssoDetails.singleSignOnDetails.tokenInfo.refreshToken;
    authRequest.encryptedData = ssoDetails.singleSignOnDetails.encryptedData;
    authRequest.tokenInfo = tokenInfo;
    const upsellSkuIdValue = ssoDetails.singleSignOnDetails.upsellSkuId;

    this.httpClient.post<any>(this.memberCenterUrl + environment.memberCenterAuthPath, JSON.stringify(authRequest), {
      headers: this.headers,
      withCredentials: true
    }).subscribe(
      value => {
        if (value) {
          const authResponse: AuthenticationResponse = value;
          this.validateAuthResponse(authResponse);
          this.setSessionStorage(authResponse, upsellSkuIdValue);
          if (upsellSkuIdValue) {
            this.memberCenterUrl += environment.memberCenterCheckoutRoute;
          } else {
            this.memberCenterUrl += environment.memberCenterAccountIsSetupRoute;
          }

          if (this.queryParamsMap) {
            const queryParamsList: string[] = Object.keys(this.queryParamsMap);

            const queryParamsString = queryParamsList.reduce((queryString: string, param: string): string => {
              return queryString + `&${QueryParamsMapConstants[param]}=${this.queryParamsMap[param]}`;
            }, '').slice(1);

            this.memberCenterUrl += '?' + queryParamsString;
          }

          window.location.href = this.memberCenterUrl;
        } else {
          this.router.navigate([this.routes.callCenter]);
        }
      },
      err => {
        this.router.navigate([this.routes.callCenter]);
      });
  }

  private getCurrentTime = () => {
    return new Date().getTime();
  }

  private encodeValue = (value): any => {
    return btoa(JSON.stringify(value));
  }

  private formatKey(key): string {
    return this.storageName + '-' + key;
  }

}
