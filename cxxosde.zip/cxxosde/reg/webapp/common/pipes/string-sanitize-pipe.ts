import { Pipe, PipeTransform } from "@angular/core";

@Pipe({name: 'stringSanitize'})
export class StringSanitizePipe implements PipeTransform {
  transform(value: string, regex: string): any {
    if (!value) return value;

    return value.trim().replace(new RegExp(regex, 'g'), "");
  }
}
