import {StringSanitizePipe} from './string-sanitize-pipe';

describe('String Sanitize Pipe', () => {
    let stringSanitPipe: StringSanitizePipe;
    const regPattern = '\\W';

    beforeAll(() => {
        stringSanitPipe = new StringSanitizePipe();
    });

    it('should strip the given string of the characters that match a certain regex ', () => {
        const inputString = ' \\this\\is\\one\\bad\\string ';
        expect(stringSanitPipe.transform(inputString, regPattern))
            .toBe('thisisonebadstring');
    });

    it('should return the given input string when tested for falsy value (empty, null, undefined, etc)', () => {
        let inputString = '';
        expect(stringSanitPipe.transform(inputString, regPattern))
            .toBe(inputString);
        inputString = null;
        expect(stringSanitPipe.transform(inputString, regPattern))
            .toBe(inputString);
        inputString = undefined;
        expect(stringSanitPipe.transform(inputString, regPattern))
            .toBe(inputString);
    });
});
