export class SsoDetails  {
    'statusCode': string;
    'singleSignOnDetails': {
        'encryptedData': string;
        'tokenInfo': {
            'accessToken': string;
            'refreshToken': string;
            'expiresIn': string;
        };
        'upsellSkuId': number;
    };
}
