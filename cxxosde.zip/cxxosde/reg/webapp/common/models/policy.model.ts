export class Policy {
  policyVersionId: number;
  policyVersionNumber: number;
  policyType: string;
  policyContent: string;
}
