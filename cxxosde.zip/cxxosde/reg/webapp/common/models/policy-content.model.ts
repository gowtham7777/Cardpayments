export class PolicyContent {
    text: string;
}
