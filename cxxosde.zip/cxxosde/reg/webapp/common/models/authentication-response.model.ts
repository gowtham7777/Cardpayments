export class AuthenticationResponse {
    'expires_in': string;
    'authorities': [{
        'roleId': string;
    }]
}
