export class CallCenterDetails {

    callCenterTimeMessage: string;
    callCenterPhoneNumber: string;
    ptpCallCenterMessage: string;

}
