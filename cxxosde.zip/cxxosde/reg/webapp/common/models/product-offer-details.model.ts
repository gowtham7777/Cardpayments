export class ProductOfferDetails {
    skuId: number;
    productName: string;
    productCode: string;
    deliveryChannel: string;
    shortDescription: string;
    longDescription: string;
    term: string;
    retailPrice: Money;
    salePrice?: Money;
    productFeatureNameForDisplay: string;
    trialOffer?: TrialOffer;
    numberOfPeriods?: number;
}

export class Money {
    amount: number;
    currency: string;
}

export class TrialOffer {
    amount: number;
    currency: string;
    trialOfferPeriod: number;
    trialOfferTerm: string;
}

