import { Policy } from './policy.model';

export class TermsOfUse {
    policies: Policy[];
    operationMessage: string;
    operationStatus: string;
    serviceStatus: string;
    httpStatus: string;
    htmlAllowed: boolean;
}
