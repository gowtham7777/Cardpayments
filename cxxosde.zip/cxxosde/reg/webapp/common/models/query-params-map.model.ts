export class QueryParamsMap {
    CAMPAIGNCODE?: string;
    INVITATIONID?: string;
    OFFERCODE?: string;
    INTENT?: string;
    LIFTID?:string;
}
