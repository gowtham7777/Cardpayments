export class AuthenticationRequest {
    'encryptedData': string;
    'tokenInfo': {
        'accessToken': string;
        'refreshToken': string;
        'expiresIn': string;
    }
}
