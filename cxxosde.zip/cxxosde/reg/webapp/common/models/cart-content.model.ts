export class CartContentResponse  {    
    'statusCode': string;
    'productOfferDetails': {
        'skuId': number;
        'productName': string;
        'productCode': string;
        'deliveryChannel': string;
        'shortDescription': string;
        'longDescription': string;
        'retailPrice': {
            'amount': number;
            'currency': string;
        };
        'salePrice': {
            'amount': number;
            'currency': string;
        };
        'term': string;
    }
}