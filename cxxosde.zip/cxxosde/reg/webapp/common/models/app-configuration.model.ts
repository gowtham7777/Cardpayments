import { QueryParamsMap } from './query-params-map.model';
import { ProductOfferDetails } from './product-offer-details.model';
import { CallCenterDetails } from './call-center-details.model';

export class AppConfiguration {
  'idleDuration': number;
  'idleWarningDuration': number;
  'minAgeToRegister': number;
  'resourceBundle': string;
  'spinnerMillisecondDelay': number;
  'successMCLoginUrl': string;
  'tenantPartner': string;
  'termsUrl': string;
  'productTermsUrl': string;
  'timeoutPageUrl': string;
  'defaultLocale': string;
  'productOfferDetails': ProductOfferDetails;
  'productTermsVersion': string;
  'queryParamsMap': QueryParamsMap;
  'touDisabled': boolean;
  'callCenterDetails': CallCenterDetails;
}
