import { Component } from '@angular/core';

@Component({
  selector: 'app-svg-icon',
  template: ''
})
export class SvgIconStub {

}