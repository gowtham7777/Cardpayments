import { Directive, OnInit } from '@angular/core';

@Directive({
  selector: '[appIovation]'
})
export class IovationDirective implements OnInit {
  fpBlackboxValue: any;
  tpBlackboxValue: any;

  constructor() { }

  ngOnInit() {
    this.loadFirstPartyBlackbox();
    this.loadThirdPartyBlackbox();
  }

  loadFirstPartyBlackbox() {
    let fpIntervalId;
    const useFirstPartyBlackbox = (intervalCount) => {
      if (typeof (<any>window).fpGetBlackbox !== 'function') { return; }

      const firstPartyData = (<any>window).fpGetBlackbox();
      if (firstPartyData.blackbox) {
        clearInterval(fpIntervalId);
        this.fpBlackboxValue = firstPartyData.blackbox;
      }
    };
    fpIntervalId = setInterval(useFirstPartyBlackbox, 500);
  }

  loadThirdPartyBlackbox() {
    let tpIntervalId;
    const useThirdPartyBlackbox = (intervalCount) => {
      // ioGetBlackbox: returns an object that can be queried to determine if black box string is available/value of that string
      if (typeof (<any>window).ioGetBlackbox !== 'function') { return; }

      const thirdPartyData = (<any>window).ioGetBlackbox();
      if (thirdPartyData.blackbox) {
        clearInterval(tpIntervalId);
        this.tpBlackboxValue = thirdPartyData.blackbox;
      }
    };
    tpIntervalId = setInterval(useThirdPartyBlackbox, 500);
  }

  combineBlackboxes() {
    let combineBlackboxesValues = this.fpBlackboxValue ? this.fpBlackboxValue : '';
    combineBlackboxesValues = this.tpBlackboxValue
                              ? (combineBlackboxesValues ? `${combineBlackboxesValues};${this.tpBlackboxValue}` : this.tpBlackboxValue)
                              : combineBlackboxesValues;
    return combineBlackboxesValues;
  }
}
