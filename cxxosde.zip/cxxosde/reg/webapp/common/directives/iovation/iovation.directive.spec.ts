import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { IovationDirective } from './iovation.directive';

/**
 * Test wrapper component:
 * To test a directive we typically create a dummy test component
 * so we can interact with the directive and test it
 */
@Component({
  template: ''
})
class TestIovationComponent {
}

describe('App with Iovation Directive', () => {
  let fixture: ComponentFixture<TestIovationComponent>;
  let directiveEl: DebugElement;
  let directiveInstance: any;
  let tempFpGetBlackbox, tempIoGetBlackbox ;

  beforeEach(fakeAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestIovationComponent,
        IovationDirective
       ] // Declare both the directive we want to test and the dummy test component
    });
    // Add the template (that contains the directive) to the component
    // It can be handled dynamically by overwriting the template
    TestBed.overrideComponent(TestIovationComponent, {
      set: {
        template: '<div appIovation></div>'
      }
    });
    // Compile the component, and query it using By.directive
    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(TestIovationComponent);
      directiveEl = fixture.debugElement.query(By.directive(IovationDirective));
      directiveInstance = directiveEl.injector.get(IovationDirective);

      // The directive depends on these window functions to be defined
      tempFpGetBlackbox = window['fpGetBlackbox'];
      tempIoGetBlackbox = window['ioGetBlackbox'];
      window['fpGetBlackbox'] = () => ({'blackbox': 'mockFP'});
      window['ioGetBlackbox'] = () => ({'blackbox': 'mockTP'});
    });
  }));

  // Make sure we didn't overwrite the actual methods by returning it to its previous value
  afterEach(() => {
    window['fpGetBlackbox'] = tempFpGetBlackbox;
    window['ioGetBlackbox'] = tempIoGetBlackbox;
  });

  it('should create', () => {
    expect(directiveEl).toBeTruthy();
    expect(directiveInstance).toBeTruthy();
  });

  it('should load first party black box', fakeAsync(() => {
    spyOn(directiveInstance, 'loadFirstPartyBlackbox').and.stub();
    directiveInstance.loadFirstPartyBlackbox();
    expect(directiveInstance.loadFirstPartyBlackbox).toHaveBeenCalled();
  }));

  it('should load third party black box', fakeAsync(() => {
    spyOn(directiveInstance, 'loadThirdPartyBlackbox').and.stub();
    directiveInstance.loadThirdPartyBlackbox();
    expect(directiveInstance.loadThirdPartyBlackbox).toHaveBeenCalled();
  }));

  it('should init', () => {
    spyOn(directiveInstance, 'loadFirstPartyBlackbox').and.stub();
    spyOn(directiveInstance, 'loadThirdPartyBlackbox').and.stub();
    directiveInstance.ngOnInit();
    expect(directiveInstance.loadFirstPartyBlackbox).toHaveBeenCalled();
    expect(directiveInstance.loadThirdPartyBlackbox).toHaveBeenCalled();
  });

  it('should combine and return both blackbox values', () => {
    expect(directiveInstance.fpBlackboxValue).toBe(undefined);
    expect(directiveInstance.tpBlackboxValue).toBe(undefined);
    directiveInstance.fpBlackboxValue = '0400FP';
    directiveInstance.tpBlackboxValue = '0400TP';
    expect(directiveInstance.combineBlackboxes()).toBe('0400FP;0400TP');
  });

  it('should return first party blackbox value', () => {
    expect(directiveInstance.fpBlackboxValue).toBe(undefined);
    expect(directiveInstance.tpBlackboxValue).toBe(undefined);
    directiveInstance.fpBlackboxValue = '0400FP';
    expect(directiveInstance.combineBlackboxes()).toBe('0400FP');
  });

  it('should return third party blackbox value', () => {
    expect(directiveInstance.fpBlackboxValue).toBe(undefined);
    expect(directiveInstance.tpBlackboxValue).toBe(undefined);
    directiveInstance.tpBlackboxValue = '0400TP';
    expect(directiveInstance.combineBlackboxes()).toBe('0400TP');
  });

  it('should return empty blackbox value', () => {
    expect(directiveInstance.fpBlackboxValue).toBe(undefined);
    expect(directiveInstance.tpBlackboxValue).toBe(undefined);
    expect(directiveInstance.combineBlackboxes()).toBe('');
  });

  it('should return undefined if calling non set functions', () => {
    expect(directiveInstance.loadFirstPartyBlackbox()).toBe(undefined);
    expect(directiveInstance.loadThirdPartyBlackbox()).toBe(undefined);
  });

  it('should return defined when triggering setInterval in loadFirstPartyBlackbox Method', (done: DoneFn) => {
    expect(directiveInstance.fpBlackboxValue).toBeUndefined();
    directiveInstance.loadFirstPartyBlackbox();

    // Wait 500 ms before checking the value of the first party black box
    setTimeout(() => {
      expect(directiveInstance.fpBlackboxValue).toBeDefined();
      done();
    }, 501);
  });

  it('should return defined when triggering setInterval in loadThirdPartyBlackbox Method', (done: DoneFn) => {
    expect(directiveInstance.tpBlackboxValue).toBeUndefined();
    directiveInstance.loadThirdPartyBlackbox();

    // Wait 500 ms before checking the value of the first party black box
    setTimeout(() => {
      expect(directiveInstance.tpBlackboxValue).toBeDefined();
      done();
    }, 501);
  });
});
