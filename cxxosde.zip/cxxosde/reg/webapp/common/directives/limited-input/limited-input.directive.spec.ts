import { LimitedInputDirective } from './limited-input.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
    template: '<input [appLimitedInput]="regexTest">'
})
class TestLimitedInputComponent {
    public regexTest = '^[0-9]{1,5}$';
}

describe('LimitedInputDirective', () => {
  let fixture: ComponentFixture<TestLimitedInputComponent>;
  let directiveEl: DebugElement;
  let directive: LimitedInputDirective;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestLimitedInputComponent,
        LimitedInputDirective
      ]
    });

    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(TestLimitedInputComponent);
      directiveEl = fixture.debugElement.query(By.directive(LimitedInputDirective));
      directive = directiveEl.injector.get(LimitedInputDirective);
      fixture.detectChanges();
    });
  }));

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  // Keypress event

  it('should call the keyDownHandler method on keypress', () => {
    const keypressSpy = spyOn(directive, 'keyDownHandler');
    directiveEl.triggerEventHandler('keypress', {'key': 'A'});
    expect(keypressSpy).toHaveBeenCalled();
  });

  it('should reject invalid characters on keypress', () => {
    const invalidKeyEvent = new KeyboardEvent('keypress', {
      key: 'A',
      cancelable: true
    });
    const isRegexCompliant = directive.keyDownHandler(invalidKeyEvent);
    expect(isRegexCompliant).toBeFalsy();
  });

  it('should accept valid characters on keypress', () => {
    const validKeyEvent = new KeyboardEvent('keypress', {
      key: '0',
      cancelable: true
    });
    const isRegexCompliant = directive.keyDownHandler(validKeyEvent);
    expect(isRegexCompliant).toBeTruthy();
  });

  // Paste Event

  it('should strip invalid characters on paste event', () => {
    const validData = '0123';
    const event = new ClipboardEvent('paste');

    // Emulate the pasted content since we can't fake event.clipboardData
    spyOn(directive, 'getClipboardData').and.returnValue(`test${validData}test`);
    spyOn(directive, 'limitedPaste').and.callThrough();

    directiveEl.triggerEventHandler('paste', event);
    expect(directive.limitedPaste).toHaveBeenCalled();
    expect(directive['el'].nativeElement.value).toBe(validData);
  });

});
