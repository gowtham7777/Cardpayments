import { Directive, Input, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appLimitedInput]'
})
export class LimitedInputDirective {
  /* tslint:disable:no-input-rename */
  @Input('appLimitedInput') regexAllowedStr: string;
  @Input() maxlength: number;
  /* tslint:enable:no-input-rename */

  constructor(
    private el: ElementRef
  ) { }

  // Extracts clipboard data from event object
  public getClipboardData(event, dataType) {
    // IE doesn't use event.clipboard data, so the fallback is in window object
    const clipboardData = event.clipboardData || window['clipboardData'];
    return clipboardData.getData(dataType);
  }

  // Prevent invalid characters from being registered
  @HostListener('keypress', ['$event']) keyDownHandler(event) {
    const regex = new RegExp(this.regexAllowedStr);
    return regex.test(this.el.nativeElement.value + event.key);
  }

  // Scrub the paste input of characters that do not match the provided regex
  @HostListener('paste', ['$event']) limitedPaste(event) {
    const regex = new RegExp(this.regexAllowedStr);
    const cleanVal = this.getClipboardData(event, 'text/plain')
      .split('')
      .filter((curr) => regex.test(curr))
      .join('');

    // Paste the cleaned value
    const finalVal = (this.el.nativeElement.value + cleanVal);
    this.maxlength = this.maxlength || finalVal.length;
    this.el.nativeElement.value = finalVal.substr(0, this.maxlength);
    this.el.nativeElement.dispatchEvent(new Event('input'));
    event.preventDefault();
  }
}
