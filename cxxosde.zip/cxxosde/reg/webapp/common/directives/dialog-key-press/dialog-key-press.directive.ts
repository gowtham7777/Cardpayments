import { Directive, Input, HostListener } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Directive({
    selector: '[appDialogKeyPress]'
})
export class DialogKeyPressDirective {
    @Input() targetDialog: MatDialogRef<any>;
    private KEY_ESC = 27;

    constructor() { }

    @HostListener('keyup', ['$event']) keyPressHandler(event: KeyboardEvent) {
        switch (event.keyCode) {
            // Close the referenced dialog if the user pressed the escape key
            case this.KEY_ESC:
                this.targetDialog.close();
                break;
        }

    }
}
