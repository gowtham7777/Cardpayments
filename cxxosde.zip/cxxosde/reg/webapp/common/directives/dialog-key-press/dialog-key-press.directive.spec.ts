import { By } from '@angular/platform-browser';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { Component, DebugElement } from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';

import { DialogKeyPressDirective } from './dialog-key-press.directive';


const mockMatDialogRef = {
  open: function(a, b) {},
  close: function(a, b) {},
  closeAll: function(a, b) {}
};

@Component({
  template: '<div appDialogKeyPress [targetDialog]="dialogRef"></div>'
})
class TestDialogKeyPressComponent {
    constructor (
        public dialogRef: MatDialogRef<any>
    ) {}
}

describe('DialogKeyPressDirective', () => {
  let fixture: ComponentFixture<TestDialogKeyPressComponent>;
  let directiveEl: DebugElement;
  let directive: DialogKeyPressDirective;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        declarations: [
            TestDialogKeyPressComponent,
            DialogKeyPressDirective
        ],
        imports: [
            MatDialogModule
        ],
        providers: [
            { provide: MatDialogRef, useValue: mockMatDialogRef }
        ]
    });

    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(TestDialogKeyPressComponent);
      directiveEl = fixture.debugElement.query(By.directive(DialogKeyPressDirective));
      directive = directiveEl.injector.get(DialogKeyPressDirective);
      fixture.detectChanges();
    });
  }));

  it('should create an instance', () => {
    expect(directiveEl).toBeTruthy();
    expect(directive).toBeTruthy();
  });

  it('should try to close the dialog window if the ESC key is pressed', () => {
    spyOn(directive, 'keyPressHandler').and.callThrough();
    spyOn(directive['targetDialog'], 'close').and.stub();
    directiveEl.triggerEventHandler('keyup', {'key': 'Escape', 'keyCode': 27});

    expect(directive.keyPressHandler).toHaveBeenCalled();
    expect(directive['targetDialog'].close).toHaveBeenCalled();
  });
});
