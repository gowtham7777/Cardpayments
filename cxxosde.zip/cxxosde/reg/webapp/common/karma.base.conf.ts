declare var require: any;
declare var process: any;

export function KarmaBaseConfigFor(prefix, config) {
    return {
        basePath: '',
        frameworks: ['jasmine', '@angular-devkit/build-angular'],
        plugins: [
            require('karma-jasmine'),
            require('karma-chrome-launcher'),
            require('karma-junit-reporter'),
            require('karma-jasmine-html-reporter'),
            require('karma-spec-reporter'),
            require('karma-coverage-istanbul-reporter'),
            require('karma-browserstack-launcher'),
            require('@angular-devkit/build-angular/plugins/karma')
        ],
        client: {
            clearContext: false, // leave Jasmine Spec Runner output visible in browser
            captureConsole: false // ignore warning logs
        },
        coverageIstanbulReporter: {
            reports: ['html', 'lcovonly', 'text-summary'],
            'report-config': { text: { file: 'code-coverage.txt' } },
            fixWebpackSourcePaths: true,
            dir: `coverage/${prefix}/`
        },
        angularCli: {
            environment: 'dev'
        },
        reporters: ['spec'], // ['progress', 'kjhtml']
        specReporter: {
            suppressSkipped: true, // do not print information about skipped tests 
        },
        port: 9876,
        colors: true,

        autoWatch: false,
        logLevel: config.LOG_DEBUG,
        customLaunchers: { },
        browsers: ['ChromeHeadless'],
        singleRun: true,
        captureTimeout: 210000,
        browserDisconnectTolerance: 3,
        browserDisconnectTimeout: 210000,
        browserNoActivityTimeout: 210000,
        failOnEmptyTestSuite: false
    };
}

export function KarmaJenkinsConfigFor(prefix, config) {
    const baseConfig = KarmaBaseConfigFor(prefix, config);

    // Prepare coverage reports for Jenkins
    baseConfig.coverageIstanbulReporter.reports = [
        'html',
        'lcovonly',
        'cobertura',
        'text'
    ];
    baseConfig.coverageIstanbulReporter['report-config']['cobertura'] = {
        file: 'cobertura.xml'
    };

    // Include browserstack
    baseConfig.plugins.push(require('karma-browserstack-launcher'));
    baseConfig['browserStack'] = {
        startTunnel: false,
        username: process.env.BROWSERSTACK_USER.split('-')[0],
        accessKey: process.env.BROWSERSTACK_ACCESSKEY,
        proxyHost: '172.18.100.15',
        proxyPort: '18717',
        tunnelIdentifier: process.env.BROWSERSTACK_LOCAL_IDENTIFIER,
        video: false
    };
    baseConfig['customLaunchers'] = {
        bs_chrome_win: {
            base: 'BrowserStack',
            browser: 'chrome',
            browser_version: '64.0',
            os: 'Windows',
            os_version: '10'
        }
    };
    baseConfig.browsers = ['bs_chrome_win'];

    return baseConfig;
}
