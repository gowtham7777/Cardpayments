/**
 * Constants for product icons.
 */
export const ProductConstants = {
    products: [
      {
        productCode: 'ECC',
        icon: 'efx-icon--core-credit',
        name: 'Equifax Core Credit™'
      },
      {
        productCode: 'EIDB',
        icon: 'efx-icon--identity-basic',
        name: 'Equifax Identity Basic™'
      },
      {
        productCode: 'EIDP',
        icon: 'efx-icon--identity-plus',
        name: 'Equifax Identity Plus™'
      },
      {
        productCode: 'ECM',
        icon: 'efx-icon--credit-monitor',
        name: 'Equifax Credit Monitor™'
      },
      {
        productCode: 'ECP',
        icon: 'efx-icon--credit-plus',
        name: 'Equifax Credit Plus™'
      },
      {
        productCode: 'ECWG',
        icon: 'efx-icon--credit-watch-gold',
        name: 'Equifax Credit Watch™ Gold'
      },
      {
        productCode: 'PRECWG',
        icon: 'efx-icon--credit-watch-gold',
        name: 'Equifax Credit Watch™ Gold by Mail'
      },
      {
        productCode: 'EIDW',
        icon: 'efx-icon--identity-watch',
        name: 'Equifax Identity Watch™'
      },
      {
        productCode: 'EC',
        icon: 'efx-icon--complete',
        name: 'Equifax Complete™'
      },
      {
        productCode: 'ECPPB',
        icon: 'efx-icon--complete-premier',
        name: 'Equifax Complete™ Premier'
      },
      {
        productCode: 'ECPP',
        icon: 'efx-icon--complete-premier',
        name: 'Equifax Complete™ Premier Plan'
      },
      {
        productCode: 'PRECPP',
        icon: 'efx-icon--complete-premier',
        name: 'Equifax Complete™ Premier Plan by mail'
      },
      {
        productCode: 'ECFP',
        icon: 'efx-icon--family--yellow',
        name: 'Equifax Complete™ Family Plan'
      },
      {
        productCode: 'ECAAP',
        icon: 'efx-icon--family--yellow',
        name: 'Equifax Complete™ Family Plan Additional Adult'
      },
      {
        productCode: 'BEIDP',
        icon: 'efx-icon--id-patrol',
        name: 'Equifax ID Patrol™'
      },
      {
        productCode: 'ESW',
        icon: 'efx-icon--score-watch',
        name: 'Equifax Score Watch®'
      },
      {
        productCode: 'NECPP',
        icon: 'efx-icon--complete-premier',
        name: 'Equifax Complete™ Premier for Partners'
      },
      {
        productCode: 'NECFP',
        icon: 'efx-icon--family--yellow',
        name: 'Equifax Complete™ Family Plan for Partners'
      },
      {
        productCode: 'NECAAP',
        icon: 'efx-icon--family--yellow',
        name: 'Equifax Complete™ Family Plan Additional Adult for Partners'
      },
      {
        productCode: 'SP',
        icon: 'efx-icon--score-power',
        name: 'Equifax Score Power®'
      },
      {
        productCode: 'ELA',
        icon: 'efx-icon--lock-alert',
        name: 'Lock & Alert™'
      },
      {
        productCode: 'EPS',
        icon: 'efx-icon--platinum-shield',
        name: 'Equifax Platinum Shield™'
      },
      {
        productCode: 'EPSF',
        icon: 'efx-icon--platinum-shield-family',
        name: 'Equifax Platinum Shield™ Family'
      },
      {
        productCode: 'E3CP',
        icon: 'efx-icon--3-in-1',
        name: 'Equifax 3-in-1 Credit Report'
      },
      {
        productCode: 'ECIM',
        icon: 'efx-icon--child-identity-monitoring',
        name: 'Equifax Child Identity Monitoring'
      },
      {
        productCode: 'ECHMP',
        icon: 'efx-icon--child-identity-monitoring',
        name: 'Equifax Child Monitoring Package'
      },
      {
        productCode: 'ELW',
        icon: 'efx-icon--lock-watch',
        name: 'Equifax Lock & Watch'
      },
      {
        productCode: 'ECWGADM',
        icon: 'efx-icon--credit-watch-gold--active-duty',
        name: 'Equifax Credit Watch™ Gold for Active Duty Military'
      }
    ]
  };