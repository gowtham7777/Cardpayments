import { QueryParamsMap } from '../models/query-params-map.model';

export const QueryParamsMapConstants: QueryParamsMap = {
    CAMPAIGNCODE: 'campaignCode',
    INVITATIONID: 'invitationId',
    OFFERCODE: 'offerCode',
    INTENT: 'intent',
    LIFTID:'liftId'
};
