export const environment = {
  cartContentUrl: '../rest/1.0/getProduct',
  redirectToProductPageUrl: '../rest/1.0/redirectToProductPage',
  ssoDetailsUrl: '../rest/1.0/ssoDetails',
  memberCenterAuthPath: 'validateToken'
};
