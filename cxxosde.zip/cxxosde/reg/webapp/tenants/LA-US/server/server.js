// Using json-server for mock local REST
// see documentation: https://github.com/typicode/json-server
const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('webapp/tenants/LA-US/server/rest/db.json');
const middlewares = jsonServer.defaults();

server.use(middlewares);
/**
 * When App does POST to an end point,
 * intercept and override to GET
 * so that MOCK response from db.json is returned
 * Here's an example below of how to..
 */
server.post('/rest/1.0/createAccount', function(req, res, next) {
    req.method = 'GET'
    next()
});
/**
 * As this is already a GET end point, merely a placeholder now.
 * Intercept and override behavior when necessary
 */
server.get('/rest/3.0/getQuiz', function(req, res, next) {
    next()
});
/**
 * Here's an example of how to intercept
 * and simulate error http responses 400/500,
 * with appropriate MOCK response from db.json
 */
server.post('/rest/3.0/submitAnswers', function(req, res, next) {
    req.method = 'GET'
    //res.statusCode = 400
    next()
});
server.get('/rest/2.0/enrollOTP', function(req, res, next) {
    next()
});
server.get('/rest/1.0/initiatePtp', function(req, res, next) {
    next()
});
server.post('/rest/1.0/submitPtp', function(req, res, next) {
    req.method = 'GET'
    next()
});
server.post('/rest/2.0/validatePin', function(req, res, next) {
    req.method = 'GET'
    next()
});
server.post('/rest/1.0/saveConsumer', function(req, res, next) {
    req.method = 'GET'
    next()
});
server.get('rest/1.0/captchaSiteKey', function(req, res, next){
    next()
});
server.post('rest/1.0/initiateEmergencyBreak', function(req, res, next){
    req.method = 'GET'
    next()
});
server.use(router);
server.listen(3000, () => {
    console.log('JSON Server is running')
});
