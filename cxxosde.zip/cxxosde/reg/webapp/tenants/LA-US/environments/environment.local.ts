// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  appConfigUrl : 'http://localhost:8310/consumer-registration/rest/1.0/appConfig',
  analyticsConfigUrl : 'http://localhost:8310/consumer-registration/rest/1.0/analyticsConfig',
  registrationUrl : 'http://localhost:8310/consumer-registration/rest/1.0/saveConsumer',
  accountCreationUrl : 'http://localhost:8310/consumer-registration/rest/1.0/createAccount',
  submitAnswersUrl : 'http://localhost:8310/consumer-registration/rest/3.0/submitAnswers',
  enrollOTPUrl : 'http://localhost:8310/consumer-registration/rest/2.0/enrollOTP',
  enrollPTPUrl : 'http://localhost:8310/consumer-registration/rest/1.0/initiatePtp',
  submitPTPPinUrl: 'http://localhost:8310/consumer-registration/rest/1.0/submitPtp', // TODO update with correct endpoint
  getQuizUrl : 'http://localhost:8310/consumer-registration/rest/3.0/getQuiz',
  validatePinUrl: 'http://localhost:8310/consumer-registration/rest/2.0/validatePin',
  getCaptchaUrl: 'http://localhost:8310/consumer-registration/rest/1.0/captchaSiteKey',
  emergencyBrakeUrl: 'http://localhost:8310/consumer-registration/rest/1.0/initiateEmergencyBreak',
  keepAliveUrl: 'http://localhost:8310/consumer-registration/rest/1.0/keepalive',
  timeoutUrl: 'http://localhost:8310/consumer-registration/rest/1.0/timeout',
  isRouteGuardEnabled: true,
  isPtpPinSubmissionEnabled: true
};
