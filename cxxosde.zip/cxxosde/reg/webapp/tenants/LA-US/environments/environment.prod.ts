export const environment = {
  production: true,
  appConfigUrl : '../rest/1.0/appConfig',
  registrationUrl : '../rest/1.0/saveConsumer',
  accountCreationUrl : '../rest/1.0/createAccount',
  submitAnswersUrl : '../rest/3.0/submitAnswers',
  enrollOTPUrl : '../rest/2.0/enrollOTP',
  enrollPTPUrl : '../rest/1.0/initiatePtp',
  submitPTPPinUrl: '../rest/1.0/submitPtp', // TODO update with correct endpoint
  getQuizUrl : '../rest/3.0/getQuiz',
  validatePinUrl: '../rest/2.0/validatePin',
  getCaptchaUrl: '../rest/1.0/captchaSiteKey',
  emergencyBrakeUrl: '../rest/1.0/initiateEmergencyBreak',
  keepAliveUrl: '../rest/1.0/keepalive',
  timeoutUrl: '../rest/1.0/timeout',
  isRouteGuardEnabled: true,
  isPtpPinSubmissionEnabled: true
};
