import { KarmaBaseConfigFor } from '../../common/karma.base.conf';

declare var module: any;
module.exports = function (config) {
    config.set(KarmaBaseConfigFor('LA-US', config));
};
