// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';

// Angular
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatRadioModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog
} from '@angular/material';
import { Router, Route } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

// Third Party
import { Observable, Subscriber } from 'rxjs';


// Modules
import { SharedModule } from '@shared/shared.module';
import { PersonalInfoModule } from '@app/personal-info/personal-info.module';

// Services
import { PtpService } from '@app/ptp/ptp.service';
import { KbaQuizService } from '@services/kba-quiz.service';
import { MockKbaQuizService, MockPtpService } from '@app/app.mock-services';
import { OtpSubmitPinService } from '@app/shared/services/otp-submit-pin.service';
import { RoutingService } from '../shared/services/routing.service';

// Components
import { KbaQuizComponent } from './kba-quiz.component';

// Models
import { AnswerChoice } from '@models/answer-choice.model';
import { AppConfig } from '@app/app.config';

// Routes accessible by this component to be tested
import { RouteNames } from '@app/app.route-names';
import { KbaQuizRoutes } from './kba-quiz.routes';
const limitedRoutes: Route[] = BaseRoutesWith(KbaQuizRoutes);

let mockMatDialog = {
  open: function(a, b) {},
  close: function(a, b) {}
};

let sampleAnswer = new AnswerChoice('1', 'answer1');

describe('KbaQuizComponent', () => {
  let component: KbaQuizComponent,
    fixture: ComponentFixture<KbaQuizComponent>,
    router: Router,
    kbaQuizService: KbaQuizService,
    ptpService: PtpService,
    routes: RouteNames,
    routingService: RoutingService,
    config: AppConfig;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [KbaQuizComponent],
      imports: [
        SharedModule,
        TestBedModule,
        MatRadioModule,
        PersonalInfoModule,
        RouterTestingModule.withRoutes(limitedRoutes)
      ],
      providers: [
        { provide: KbaQuizService, useClass: MockKbaQuizService },
        { provide: PtpService, useClass: MockPtpService },
        { provide: MatDialog, useValue: mockMatDialog },
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        OtpSubmitPinService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KbaQuizComponent);
    component = fixture.componentInstance;
    kbaQuizService = TestBed.get(KbaQuizService);
    ptpService = TestBed.get(PtpService);
    routingService = TestBed.get(RoutingService);
    router = TestBed.get(Router);
    routes = TestBed.get(RouteNames);
    config = TestBed.get(AppConfig);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have questions', async(() => {
    component.ngOnInit();
    expect(component.questions).toBe(kbaQuizService.questions);
  }));

  it('should add new answer on selection change', () => {
    const questions = component['kbaQuizService'].getQuiz();
    expect(component.answers).toEqual([]);
    component.onSelectionChange(questions[0], sampleAnswer);
    expect(component.answers).toEqual([
      {
        questionId: questions[0].questionId,
        choiceId: sampleAnswer.answerChoiceId
      }
    ]);
  });

  it('should change answer on selection change', () => {
    const questions = component['kbaQuizService'].getQuiz();
    component.answers = [
      {
        questionId: questions[0].questionId,
        choiceId: sampleAnswer.answerChoiceId
      }
    ];
    expect(component.answers[0].choiceId).toEqual(sampleAnswer.answerChoiceId);

    sampleAnswer.answerChoiceId = '2';
    component.onSelectionChange(questions[0], sampleAnswer);
    expect(component.answers).toEqual([
      {
        questionId: questions[0].questionId,
        choiceId: '2'
      }
    ]);
  });

  const validateRouteFromResponse = (statusCode, destinationPage) => {
    component['routeFromResponse']({ statusCode });
    expect(ptpService.ptpEligible).toBeFalsy();
    expect(router.navigate).toHaveBeenCalledWith([destinationPage]);
  };
  it('should route from response', () => {
    spyOn(router, 'navigate').and.stub();
    validateRouteFromResponse(
      config.kbaSubmissionTimeout,
      routes.callCenterTimeout
    );
    validateRouteFromResponse(
      config.kbaSuccessEligibilityFail,
      routes.callCenter
    );
    validateRouteFromResponse(config.kbaSubmissionError, routes.callCenterPtp);
    validateRouteFromResponse(config.kbaSystemError, routes.callCenterPtp);
  });
  it('should submit form route to call center when null', () => {
    const response = new Observable<any>((subscriber: Subscriber<any>) =>
      subscriber.next(null)
    );
    spyOn(kbaQuizService, 'submitAnswers').and.returnValue(response);
    spyOn(router, 'navigate').and.stub();
    component.submitForm();
    expect(kbaQuizService.submitAnswers).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([routes.callCenter]);
  });
  it('should submit form route to call center when error is null', () => {
    const response = new Observable<any>((subscriber: Subscriber<any>) =>
      subscriber.error()
    );
    spyOn(kbaQuizService, 'submitAnswers').and.returnValue(response);
    spyOn(router, 'navigate').and.stub();
    component.submitForm();
    expect(kbaQuizService.submitAnswers).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([routes.callCenter]);
  });
  it('should submit form route to call center ptp when error is returned', () => {
    const error = { error: { statusCode: 'testStatusCode' } };
    const response = new Observable<any>((subscriber: Subscriber<any>) =>
      subscriber.error(error)
    );
    spyOn(kbaQuizService, 'submitAnswers').and.returnValue(response);
    spyOn(router, 'navigate').and.stub();
    spyOn(ptpService, 'setPtpEligible').and.stub();
    component.submitForm();
    expect(kbaQuizService.submitAnswers).toHaveBeenCalled();
    expect(ptpService.setPtpEligible).toHaveBeenCalledWith(false);
    expect(router.navigate).toHaveBeenCalledWith([routes.callCenterPtp]);
  });
});
