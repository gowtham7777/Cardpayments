import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { KbaQuizComponent } from './kba-quiz.component';
import { MatRadioModule } from '@angular/material/radio';

@NgModule({
  declarations: [
    KbaQuizComponent
  ],
  imports: [
    CommonModule,
    MatRadioModule,
    SharedModule
  ],
  providers: [], // services go here
  exports: [
    KbaQuizComponent
  ]
})
export class KbaQuizModule { }
