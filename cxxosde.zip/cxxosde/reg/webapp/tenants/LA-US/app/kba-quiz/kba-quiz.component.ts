import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, Input, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { SharedModule } from '@app/shared/shared.module';
import { Question } from '@models/question.model';
import { AnswerChoice } from '@models/answer-choice.model';
import { Answer } from '@models/answer.model';
import { KbaQuizService } from '@services/kba-quiz.service';
import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfig } from '../app.config';
import { PtpService } from '../ptp/ptp.service';
import { OtpSubmitPinService } from '@services/otp-submit-pin.service';
import { RouteNames } from '@app/app.route-names';
import { RoutingService } from '@services/routing.service';
import { AppConfigService } from '@common/services/app-config.service';

@Component({
  selector: 'kba-quiz',
  templateUrl: './kba-quiz.component.html'
})

export class KbaQuizComponent implements OnInit {
  loadingRequest = false;
  otpFailed = false;
  otpPinFailed = false;
  kbaQuizForm: FormGroup;
  questions: Question[];
  answers: Answer[] = [];
  private translateService;

  constructor(
    translate: TranslateService,
    private kbaQuizService: KbaQuizService,
    private analyticsService: AnalyticsService,
    private appConfigService: AppConfigService,
    private fb: FormBuilder,
    private router: Router,
    private ptpService: PtpService,
    private otpSubmitPinService: OtpSubmitPinService,
    private otpSubmitPinService1: OtpSubmitPinService,
    private config: AppConfig,
    private routes: RouteNames,
    private routingService: RoutingService,
    private titleService: Title
  ) {
    this.translateService = translate;
    this.updatePageTitle();
  }

  ngOnInit() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.kbaQuiz.pageLoad.eventName,
        pageName: this.config.analytics.kbaQuiz.pageLoad.pageName
      },
      eventIds: this.config.analytics.kbaQuiz.pageLoad.eventIds
    });
    this.otpFailed = this.otpSubmitPinService.getOtpFailed();
    this.otpPinFailed = this.otpSubmitPinService1.getPinAuthFailed();
    this.fetchQuiz();
  }

  fetchQuiz() {
    // verify we have a quiz
    if (
      this.kbaQuizService.quizIdentifier &&
      this.kbaQuizService.questions
    ) {
      this.questions = this.kbaQuizService.getQuiz();
      this.createForm();
    } else {
      this.router.navigate([this.routes.callCenter])
    }
  }

  createForm = () => {
    const controlsConfig = {};
    this.questions.forEach( (question) => {
      controlsConfig['choice' + question.questionId] = ['', [
        Validators.required
      ] ];
    });
    this.kbaQuizForm = this.fb.group(controlsConfig);
  }

  onSelectionChange(question: Question, answerChoice: AnswerChoice): void {
    let foundQuestionId = false;
    this.answers.forEach( (answer) => {
      if (answer.questionId === question.questionId) {
        answer.choiceId = answerChoice.answerChoiceId;
        foundQuestionId = true;
      }
    });
    if (foundQuestionId === false) {
      this.answers.push({questionId: question.questionId, choiceId: answerChoice.answerChoiceId});
    }
  }

  submitForm = () => {
    if (!this.loadingRequest) {
      this.loadingRequest = true;
      this.answers.sort((a: Answer, b: Answer) => Number(a.questionId) - Number(b.questionId));
      const kbaForm: Answer[] = Object.assign([], this.answers);
      this.analyticsService.appendEvent({
        eventData: {
          eventName: this.config.analytics.kbaQuiz.kbaAuthAttempt.eventName,
          pageName: this.config.analytics.kbaQuiz.kbaAuthAttempt.pageName,
          attributes: this.config.analytics.kbaQuiz.kbaAuthAttempt.attributes
        },
        eventIds: this.config.analytics.kbaQuiz.kbaAuthAttempt.eventIds
      });
      this.kbaQuizService.submitAnswers(kbaForm)
      .subscribe(
        // Successful responses call the first callback.
        data => {
          if (data) {
            this.routeFromResponse(data);
          } else {
            this.router.navigate([this.routes.callCenter]);
          }
        },
        // Errors will call this callback instead:
        err => {
        // Reset the status of the request
          this.loadingRequest = false;
          if (err && err.error && err.error.statusCode && err.error.statusCode !== this.config.validationError) {
          // not sure if this.config.validationError can be reproduced, since the question and choice ids are system generated
            this.ptpService.setPtpEligible(false);
            this.router.navigate([this.routes.callCenterPtp]);
          } else {
            this.router.navigate([this.routes.callCenter]);
          }
        }
      );
    }
  }

  private routeFromResponse = (data) => {
    const routesMap = this.ptpService.routesMap;
    routesMap[this.config.kbaSubmissionSuccess] = () => {
      window.location.href = this.appConfigService.updateUrlForMobileParam(data.destinationUrl);
    };
    routesMap[this.config.kbaSubmissionTimeout] = () => {
      this.ptpService.setPtpEligible(false);
      this.router.navigate([this.routes.callCenterTimeout]);
    };
    routesMap[this.config.kbaSuccessEligibilityFail] = () => {
      this.ptpService.setPtpEligible(false);
      this.router.navigate([this.routes.callCenter]);
    };
    routesMap[this.config.kbaSubmissionError] = () => {
      this.ptpService.setPtpEligible(false);
      this.router.navigate([this.routes.callCenterPtp]);
    };
    routesMap[this.config.kbaSystemError] = () => {
      this.ptpService.setPtpEligible(false);
      this.router.navigate([this.routes.callCenterPtp]);
    };

    const defaultRoute = () => { this.router.navigate([this.routes.callCenter]); };
    (routesMap[data.statusCode] || defaultRoute)();
  }

  updatePageTitle() {
    if (this.otpSubmitPinService1.getPinAuthFailed()) {
          this.translateService.get('kba-quiz.browserTitle.otpFailedEventTitle').subscribe((result: string) => {
            this.titleService.setTitle(result);
      });
    } else {
        this.translateService.get('kba-quiz.browserTitle.pageLoadTitle').subscribe((result: string) => {
          this.titleService.setTitle(result);
      });
    }
  }
}

