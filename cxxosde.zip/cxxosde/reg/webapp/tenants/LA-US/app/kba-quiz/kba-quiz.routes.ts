import { Route } from '@angular/router';
import { KbaQuizComponent } from './kba-quiz.component';
import { KbaQuizGuard } from '@app/guards/kba-quiz.guard';

export const KbaQuizRoutes: Route[] = [
  {
    path: 'kba-quiz',
    component: KbaQuizComponent,
    canActivate: [KbaQuizGuard]
  }
];
