import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'message-banner',
  templateUrl: './message-banner.component.html',
  styleUrls: ['./message-banner.component.scss']
})
export class MessageBannerComponent implements OnInit {
  @Input()
  showBanner = true;
  @Output()
  showBannerChange = new EventEmitter<Boolean>();

  constructor() {
    
  }

  ngOnInit() {
  }

  close() {
    this.showBanner = false;
    this.showBannerChange.emit(false);
  }
}
