import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppConfig } from '@app/app.config';

import { BrowserCheckService } from './browser-check.service';

let config: AppConfig;
let service: BrowserCheckService;

let currentBrowser = {
  browser: 'chrome',
  browser_version: 57 // todo: would like to pull this from a config
}

describe('BrowserCheckService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BrowserCheckService,
        { provide: DeviceDetectorService, useValue: currentBrowser }
      ],
      imports: [
        TestBedModule
      ],
    });
    config = TestBed.get(AppConfig);
    service = TestBed.get(BrowserCheckService);
  });

  it('can fetch the fromApp flag', () => {
    service['fromApp'] = true;
    expect(service.isFromApp()).toBeTruthy();
    service['fromApp'] = false;
    expect(service.isFromApp()).toBeFalsy();
  });

  it('can fetch the unknownBrowser flag', () => {
    service['unknownBrowser'] = true;
    expect(service.isUnknownBrowser()).toBeTruthy();
    service['unknownBrowser'] = false;
    expect(service.isUnknownBrowser()).toBeFalsy();
  });

  it('can fetch the validBrowser flag', () => {
    service['validBrowser'] = true;
    expect(service.isValidBrowser()).toBeTruthy();
    service['validBrowser'] = false;
    expect(service.isValidBrowser()).toBeFalsy();
  });

  it('can fetch the browserMessageVisible flag', () => {
    service['browserMessageVisible'] = true;
    expect(service.isBrowserMessageVisible()).toBeTruthy();
    service['browserMessageVisible'] = false;
    expect(service.isBrowserMessageVisible()).toBeFalsy();
  });

  it('can fetch the version flag', () => {
    const mockVersion = 'MockBrowserVersion';
    service['version'] = mockVersion;
    expect(service.getBrowserVersion()).toBe(mockVersion);
  });

  it('can fetch the supportedVersion flag', () => {
    const mockSupportedVersion = 1;
    service['supportedVersion'] = mockSupportedVersion;
    expect(service.getMinimumVersion()).toBe(mockSupportedVersion);
  });

  it('can set the browser message visibility flag to false', () => {
    service['browserMessageVisible'] = true;
    service.hideBrowserMessage();
    expect(service['browserMessageVisibile']).toBeFalsy();
  });

  // ==========================================================================
  // Browser check scenarios
  // ==========================================================================

  it('valid chrome browser (min version)', () => {
    service.detectBrowserVersion();
    expect(service.getBrowserVersion().toString()).toEqual(config.minimumBrowserVersions.chrome.toString());
    expect(service.isValidBrowser()).toBeTruthy();
    expect(service.getMinimumVersion()).toEqual(config.minimumBrowserVersions.chrome);
  });

  it('set the "valid" flag to true when we came from the mobile app', () => {
    spyOn(service as any, 'checkIfFromMobileApp').and.returnValue(true);
    service.detectBrowserVersion();
    expect(service['validBrowser']).toBeTruthy();
  });

  it('set the "unknown" flag to true and "valid" flag to false when browser is unknown', () => {
    service['deviceDetector']['browser'] = 'unknown';
    service.detectBrowserVersion();
    expect(service['unknownBrowser']).toBeTruthy();
    expect(service['validBrowser']).toBeFalsy();
  });
});
