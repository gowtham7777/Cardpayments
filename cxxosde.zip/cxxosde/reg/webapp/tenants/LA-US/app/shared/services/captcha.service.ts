import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams, HttpClient, HttpClientModule } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable()
export class CaptchaService {

  retrieveCaptchaSiteKey() {
    return this.http.get(environment.getCaptchaUrl
    );
      }

      constructor(private http: HttpClient) {
     }

}
