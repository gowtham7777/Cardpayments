export class Address {
    'addressLine1': string;
    'addressLine2': string;
    'cityName': string;
    'stateAbbreviation': string;
    'zipCode': string;
}