import { Injectable } from '@angular/core';
import { HttpHeaders,  HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../models/account.model';
import { environment } from '../../../environments/environment';
import { AppConfigService } from '@common/services/app-config.service';
import { AppConfig } from '@app/app.config';

@Injectable()
export class AccountCreationService {
  results: object;

  // Add the header to prevent default spinner interception
  // Account creation should have a custom spinner implementation
  private headers: HttpHeaders;

  constructor(
    private appConfigService: AppConfigService,
    private config: AppConfig,
    private http: HttpClient,
  ) {
    this.headers = new HttpHeaders()
      .set('Accept', 'application/json')
      .set('Content-Type', 'application/json')
      .set(this.config.noSpinnerHeader, 'true');
  }

  // tslint:disable-next-line:one-line
  createAccount(account: Account): Observable<any>{
      const userbody = {
        'username': account.username,
        'password': account.password,
        'blackBox': account.blackBox
      };

      return this.http
      .post<any>(environment.accountCreationUrl, userbody, {
        headers: this.headers
      });
  }

  validatePin(pin: string): Observable<any> {
    const userbody = {
      'pin': pin
    };
    return this.http
    .post<any>(environment.validatePinUrl, userbody, {
      headers: this.headers
    });
  }

  getMCLoginUrl = () => {
    return this.appConfigService.configurationData.successMCLoginUrl;
  }
}
