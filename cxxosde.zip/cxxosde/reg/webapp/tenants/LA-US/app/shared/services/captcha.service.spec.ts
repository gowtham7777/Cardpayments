import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';

import { CaptchaService } from './captcha.service';

describe('CaptchaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CaptchaService],
      imports: [TestBedModule]
    });
  });

  it('should be created', inject([CaptchaService], (service: CaptchaService) => {
    expect(service).toBeTruthy();
  }));
});
