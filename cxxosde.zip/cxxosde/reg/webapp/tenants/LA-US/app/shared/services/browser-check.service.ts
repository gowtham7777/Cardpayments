import { Injectable } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppConfig } from '@app/app.config';

@Injectable()
export class BrowserCheckService {
  private fromApp: boolean = false;
  private unknownBrowser: boolean = false;
  private validBrowser: boolean = false;
  private browserMessageVisible: boolean = false;
  private browser: string;
  private version: string;
  private supportedVersion: number;

  constructor(
    private deviceDetector: DeviceDetectorService,
    private config: AppConfig
  ) { }

  isFromApp = () => this.fromApp;
  isUnknownBrowser = () => this.unknownBrowser;
  isValidBrowser = () => this.validBrowser;
  isBrowserMessageVisible = () => this.browserMessageVisible;
  getBrowserVersion = () => this.version;
  getMinimumVersion = () => this.supportedVersion;

  // Version is detected when first hitting the site to check if the browser version is supported
  detectBrowserVersion = () => {
    this.fromApp = this.checkIfFromMobileApp();
    this.browser = this.deviceDetector.browser;
    this.version =  this.deviceDetector.browser_version;

    if (this.fromApp) {
      // Do not show warning if we came from the mobile app
      this.validBrowser = true;

    } else if (this.browser === 'unknown') {
      // If we're using an unrecognized browser, then show the warning
      this.unknownBrowser = true;
      this.validBrowser = false;

    } else {
      // If we recognize the browser, but it's too old, show the warning
      this.supportedVersion = this.config.minimumBrowserVersions[this.browser];
      this.validBrowser = !!this.supportedVersion && parseInt(this.version, 10) >= this.supportedVersion;
    }
    this.browserMessageVisible = !this.validBrowser;
  }

  hideBrowserMessage = () => this.browserMessageVisible = false;

  // Check if we've detected that the user came from the mobile app in index.html
  private checkIfFromMobileApp() {
    return window['isFromMobileApp'] || false; // returns false if variable is undefined
  }
}
