// Angular
import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpHeaders } from '@angular/common/http';

// Modules
import { TestBedModule } from '@shared/test-bed.module';
import { MatDialogModule } from '@angular/material';

// Services
import { AccountCreationService } from './account-creation.service';
import { BaseRoutesWith } from '@app/shared/test-bed.module';
import { AppConfig } from '@app/app.config';

let service: AccountCreationService;

describe('AccountCreationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([])) // no routes needed for now
      ],
      providers: [
        AccountCreationService,
        AppConfig
      ]
    });

    service = TestBed.get(AccountCreationService);
  });

  it('should be created', inject([AccountCreationService], (service: AccountCreationService) => {
    expect(service).toBeTruthy();
  }));

  it('should send request to create account end point', ()  => {
   const config = TestBed.get(AppConfig);
    const mockUser = {
        'username': 'test@gmail.com',
        'password': 'P@sswrd12',
        'blackBox': 'testBox'
    };

    const mockHeaders = new HttpHeaders()
    .set('Accept', 'application/json')
    .set('Content-Type', 'application/json')
    .set(config['noSpinnerHeader'], 'true');

    const mockUrl = '../rest/1.0/createAccount';
    spyOn(service['http'], 'post').and.stub();
    service.createAccount(mockUser);
    expect(service['http'].post).toHaveBeenCalledWith(mockUrl, mockUser, {headers: mockHeaders});
  });

  it('should sent request to right path to validate the pin', () => {
    const config = TestBed.get(AppConfig);
    const mockPin = '123456';
    const mockUserBody = {
          'pin': mockPin
      };
      const mockPinUrl = '../rest/2.0/validatePin';
      const mockHeaders = new HttpHeaders()
      .set('Accept', 'application/json')
      .set('Content-Type', 'application/json')
      .set(config['noSpinnerHeader'], 'true');
      spyOn(service['http'], 'post').and.stub();
      service.validatePin(mockPin);
      expect(service['http'].post).toHaveBeenCalledWith(mockPinUrl, mockUserBody, {headers: mockHeaders});
  });
});
