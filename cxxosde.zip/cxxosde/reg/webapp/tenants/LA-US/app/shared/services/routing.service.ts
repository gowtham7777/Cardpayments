import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AppConfig } from '@app/app.config';
import { environment } from '../../../environments/environment';
import { RouteNames } from '@app/app.route-names';

// Route guards can be disabled in the environment.ts file (isRouteGuardEnabled)
@Injectable()
export class RoutingService {

  constructor(
    private location: Location,
    private routeNames: RouteNames,
    private config: AppConfig,
    private router: Router
  ) { }

  // All App pages - track where you can navigate FROM to get to each page and whether navigation is allowed
  // Add an entry into this map for any new pages that need to be behind a route guard
  private navigatingTo = {
    [this.routeNames.personalInfo]: {
      from: [], allowed: true
    },
    [this.routeNames.accountCreation]: {
      from: [this.routeNames.personalInfo], allowed: false
    },
    [this.routeNames.otpOptIn]: {
      from: [this.routeNames.accountCreation], allowed: false
    },
    [this.routeNames.otpSubmit]: {
      from: [this.routeNames.otpOptIn], allowed: false
    },
    [this.routeNames.ptpOptIn]: {
      from: [
        this.routeNames.accountCreation,
        this.routeNames.otpOptIn,
        this.routeNames.otpSubmit,
        this.routeNames.kbaQuiz],
      allowed: false
    },
    [this.routeNames.ptpSuccess]: {
      from: [this.routeNames.ptpOptIn, this.routeNames.callCenterPtp], allowed: false
    },
    [this.routeNames.accountIsSetup]: {
      from: [this.routeNames.ptpSubmitPin], allowed: false
    },
    [this.routeNames.kbaQuiz]: {
      from: [
        this.routeNames.accountCreation,
        this.routeNames.otpOptIn,
        this.routeNames.otpSubmit],
      allowed: false
    },
    [this.routeNames.emergencyBrakeMailOptions]: {
      from: [
        this.routeNames.accountCreation
      ],
      allowed: false
    },
    [this.routeNames.emergencyBrakeNextSteps]: {
      from: [
        this.routeNames.emergencyBrakeMailOptions
      ],
      allowed: false
    }
  };

  // Routes to pages for different types of errors
  private errorRouteMap = {
    [this.config.systemError]: () => {
      this.router.navigateByUrl(this.routeNames.systemError);
    },
    [this.config.callCenterError]: () => {
      this.router.navigateByUrl(this.routeNames.callCenter);
    }
  };

  // Block all pages and allow navigation to specific pages in the registration flow
  public enableNavigationTo = (destination: string) => {
    this.clear();
    this.navigatingTo[destination].allowed = true;
  }

  // Turn off navigation to a page (not currently used, may be useful in the future)
  public disableNavigationTo = (destination: string) => {
    this.navigatingTo[destination].allowed = false;
  }

  // Set all navigation pages to false (disables manual navigation to any page except Personal Info page)
  private clear() {
    Object.keys(this.navigatingTo).forEach(v => {
      if (v !== this.routeNames.personalInfo) { this.navigatingTo[v].allowed = false; }
    });
  }

  // Verify whether a page can be navigated to (used in route guards)
  public canNavigateTo = (destination: string) => {
    if (!environment.isRouteGuardEnabled) { return true; }

    const navigationAllowed = this.navigatingTo[destination].allowed;
    const onValidPage =
      (this.navigatingTo[destination].from.length === 0) ||
      (this.navigatingTo[destination].from.indexOf(this.location.path()) > -1);

    const routeIsGuarded = () => { this.router.navigateByUrl(this.routeNames.personalInfo); return false; };
    return !!onValidPage && !!navigationAllowed || routeIsGuarded();
  }

  // ** For use after the customer account is created **
  // We should route any user with an account to the call center unless the system error response code
  // is explicitly sent from the back-end
  // Error responses are structure as so:
  // response : {
  //    error: {
  //      statusCode: 'STATUS_CODE_HERE'
  //    }
  // }
  public handleErrorResponse = (err) => {
    const defaultRoute = () => { this.router.navigateByUrl(this.routeNames.callCenter); };
    if (err && err.error && err.error.statusCode) {
      const statusCode = err.error.statusCode;
      (this.errorRouteMap[statusCode] || defaultRoute)();
    } else {
      defaultRoute();
    }
  }
}
