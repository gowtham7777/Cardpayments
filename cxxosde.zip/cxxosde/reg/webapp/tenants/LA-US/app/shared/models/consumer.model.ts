import {Address} from './address.model';
export class Consumer {
  'firstName': string;
  'lastName': string;
  'dateOfBirth': string;
  'ssn': string;
  'address': Address;
  'standardizedAddress'?: Address;
  'phoneNumber': string;
  'reCaptchaResponse': string;
}
