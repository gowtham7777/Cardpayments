import { Observable } from 'rxjs';
import { HttpHeaders,  HttpClient, HttpClientModule } from '@angular/common/http';
import { Consumer } from '../models/consumer.model';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';


@Injectable()
export class OtpGetPinService {
  public consumer: Consumer;
  results: object;
  displayNewPinRequest = true;
  showNewCodeBanner = false;

  constructor(private http: HttpClient) {
  }

  enrollOTP(): Observable<any> {
    return this.http.get<any>(environment.enrollOTPUrl);
   }

  getDisplayNewPinRequest() {
    return this.displayNewPinRequest;
  }

  setDisplayNewPinRequest(displayNewPinRequest: boolean) {
    this.displayNewPinRequest = displayNewPinRequest;
  }

  getShowNewCodeBanner() {
    return this.showNewCodeBanner;
  }

  setShowNewCodeBanner(showNewCodeBanner: boolean) {
    this.showNewCodeBanner = showNewCodeBanner;
  }
}
