import { Injectable } from '@angular/core';
import { HttpHeaders,  HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class EmergencyBrakeService {
  results: object;
  private headers = new HttpHeaders(
    {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  );

  constructor(private http: HttpClient) {
  }

  // tslint:disable-next-line:one-line
  postEmergencyBreak(optIn: boolean): Observable<any>{
      const userbody = {
        'optedForPinToPost': optIn
      };

      return this.http
        .post<any>(environment.emergencyBrakeUrl, userbody, {
          headers: this.headers
        });
  }
}
