import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';

import { ConsumerService } from './consumer.service';

describe('ConsumerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ TestBedModule ],
      providers: [ConsumerService]
    });
  });

  it('should be created', inject([ConsumerService], (service: ConsumerService) => {
    expect(service).toBeTruthy();
  }));
});
