export class AnswerChoice {
	answerChoiceId: string;
	answerChoiceText: string;
	
	constructor(answerChoiceId: string, answerChoiceText: string) {
		this.answerChoiceId = answerChoiceId;
		this.answerChoiceText = answerChoiceText;
	}
	
}