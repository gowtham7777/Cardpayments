import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';
import { RouterTestingModule } from '@angular/router/testing';

import { EmergencyBrakeService } from './emergency-brake.service';

let service: EmergencyBrakeService;

describe('EmergencyBrakeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule, RouterTestingModule.withRoutes(BaseRoutesWith([]))],
      providers: [
        EmergencyBrakeService
      ]
    });
    service = TestBed.get(EmergencyBrakeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
