import { MatDialogModule } from '@angular/material';
// Collection of shared declarations/imports/providers the majority of tests will use
// This includes material libraries, configurations, services/tools
// Routing seems to be tricky to generalize, so keep that in each test

// Angular
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { HttpModule } from '@angular/http';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { Location } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';



// Third Party
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';

// Modules
import { CallCenterModule } from '@app/call-center/call-center.module';
import { HttpLoaderFactory } from '@app/shared/shared.module';
import { RouterTestingModule } from '@angular/router/testing';
import { SystemErrorModule } from '@app/system-error/system-error.module';

// Services
import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfigService } from '@common/services/app-config.service';
import { ConsumerService } from '@services/consumer.service';
import { MockAnalyticsService, MockAppConfigService } from '@app/app.mock-services.ts';
import { RoutingService } from '@services/routing.service';
import { TimeoutService } from '@app/timeout/timeout.service';
import { SpinnerInterceptor } from '@common/components/http-interceptors/spinner-interceptor';

// Models
import { AppConfig } from '@app/app.config';

// Routes accessible by this component to be tested
import { RouteNames } from '@app/app.route-names';


// Reset the TestBedRoutes with new routes!
import { CallCenterRoutes } from '@app/call-center/call-center.routes';
import { SystemErrorRoutes } from '@app/system-error/system-error.routes';
export function BaseRoutesWith(routes) {
  const baseRoutes = [...SystemErrorRoutes, ...CallCenterRoutes];
  baseRoutes.unshift(...routes);
  return baseRoutes;
}

// Start off with just the base routes
@NgModule({
  declarations: [],
  imports: [
    BrowserAnimationsModule,
    // HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgIdleKeepaliveModule.forRoot(),
    SystemErrorModule,
    CallCenterModule,
    MatDialogModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    RouterTestingModule.withRoutes([])
  ],
  providers: [
    {provide: AnalyticsService, useClass: MockAnalyticsService},
    AppConfig,
    {provide: AppConfigService, useClass: MockAppConfigService},
    ConsumerService,
    RouteNames,
    RoutingService,
    TimeoutService,
    SpinnerInterceptor
  ]
})
export class TestBedModule {}
