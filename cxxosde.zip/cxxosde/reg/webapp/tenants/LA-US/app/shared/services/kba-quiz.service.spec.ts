import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Third Party
import { Observable, Subscriber } from 'rxjs';

import { RouteNames } from '@app/app.route-names.ts';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';
import { PtpService } from '@app/ptp/ptp.service';
import { MockPtpService } from '@app/app.mock-services';
import { KbaQuizService } from './kba-quiz.service';

let kbaQuizService: KbaQuizService;
let mockRouter: Router;
let mockRoutes: RouteNames;

describe('KbaQuizService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule, RouterTestingModule.withRoutes(BaseRoutesWith([]))],
      providers: [
        KbaQuizService,
        {provide: PtpService, useClass: MockPtpService}
      ]
    });
    kbaQuizService = TestBed.get(KbaQuizService);
    mockRoutes = TestBed.get(RouteNames);
    mockRouter = TestBed.get(Router);
  });

  it('should be created', inject([KbaQuizService], (service: KbaQuizService) => {
    expect(service).toBeTruthy();
  }));

  it('should save quiz', () => {
    const quizId = '123';
    const questions = [{
      questionId: '123',
      questionText: '123text',
      answerChoices: [{
        answerChoiceId: '123',
        answerChoiceText: '123text'
      }]}
    ];
    kbaQuizService.saveQuiz(quizId, questions);
    expect(kbaQuizService.quizIdentifier).toEqual(quizId);
    expect(kbaQuizService.questions).toEqual(questions);
  });

  it('should get quiz', () => {
    const quizId = '123';
    const questions = [{
      questionId: '123',
      questionText: '123text',
      answerChoices: [{
        answerChoiceId: '123',
        answerChoiceText: '123text'
      }]}
    ];
    kbaQuizService.saveQuiz(quizId, questions);
    expect(kbaQuizService.getQuiz()).toEqual(questions);
  });

  it('should submit answers to endpoint with right params', () => {
    const mockUrl = '../rest/3.0/submitAnswers';
    const mockAnswers = [{
     questionId: '123',
     choiceId: '123Text'
     }];
     kbaQuizService['quizIdentifier'] = '124';
     const mockHeaders = new HttpHeaders()
     .set('Accept', 'application/json')
     .set('Content-Type', 'application/json');
     const mockBody = {
         quizIdentifier: kbaQuizService['quizIdentifier'],
         answers: mockAnswers
     };
     spyOn(kbaQuizService['http'], 'post').and.stub();
     kbaQuizService.submitAnswers(mockAnswers);
     expect(kbaQuizService['http'].post).toHaveBeenCalledWith(mockUrl, mockBody, {headers: mockHeaders});
   });

  it('should fetch the quiz and route to KBA page', () => {
    const quizIdentifier = '124';
   const  questions = [{
       questionId: '123',
       questionText: '123text',
       answerChoices: [{
       answerChoiceId: '123',
       answerChoiceText: '123text'
     }]}
   ];
   const mockQuizData = new Observable<any>( (subscriber: Subscriber<any>) => subscriber.next(
    {
        'quizIdentifier': quizIdentifier,
        'questions': questions,
        'statusCode': 'KBA_QUIZ_SUCCESS'
    }));
   spyOn(kbaQuizService['http'], 'get').and.returnValue(mockQuizData);
   spyOn(kbaQuizService['router'], 'navigate').and.stub();
   kbaQuizService.fetchQuiz();
   expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.kbaQuiz]);
  });

  it('should route to error page', () => {
    const mockQuizData = new Observable<any>( (subscriber: Subscriber<any>) => subscriber.next(null));
    spyOn(kbaQuizService['http'], 'get').and.returnValue(mockQuizData);
    spyOn(kbaQuizService['router'], 'navigate').and.stub();
    kbaQuizService.fetchQuiz();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

});

