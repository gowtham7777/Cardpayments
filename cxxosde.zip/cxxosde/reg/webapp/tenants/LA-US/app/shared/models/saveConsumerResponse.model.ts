export class SaveConsumerResponse {
  customerId: string;
  status: string;
  statusCode: string;
  statusMessage: string;
}
