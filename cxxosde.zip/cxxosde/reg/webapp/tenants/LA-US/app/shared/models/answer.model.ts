export class Answer {
	questionId: string;
	choiceId: string;

	constructor(questionId: string, choiceId: string) {
		this.questionId = questionId;
		this.choiceId = choiceId;
	}

}
