import { environment } from '../../../environments/environment';
import { HttpHeaders,  HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OtpSubmitPinResponse, OtpSubmitPinStatusCode } from '../models/otp-submit-pin-response.model';

@Injectable()
export class OtpSubmitPinService {
  private otpFailed = false;
  private otpPinFailed = false;

  private headers = new HttpHeaders(
    {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  );

  constructor(private http: HttpClient) {
  }

  validatePin(pin: string) {
    const userbody = {
      pin
    };

    const observable = this.http
      .post<OtpSubmitPinResponse>(environment.validatePinUrl, userbody, {
        headers: this.headers
      });

    return observable;
  }

  getOtpFailed() {
    return this.otpFailed;
  }

  setOtpFailed(otpFailed: boolean) {
    this.otpFailed = otpFailed;
  }

  getPinAuthFailed() {
    return this.otpPinFailed;
  }

  setPinAuthFailed(otpPinFailed: boolean) {
    this.otpPinFailed = otpPinFailed;
  }
}
