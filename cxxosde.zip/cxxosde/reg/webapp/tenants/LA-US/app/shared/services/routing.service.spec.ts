// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';

// Angular
import { Location } from '@angular/common';
import { Router, Route } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject, fakeAsync, async, tick } from '@angular/core/testing';

// Third Party

// Modules - Add an entry here for any newly guarded routes with modules
import { PersonalInfoModule } from '@app/personal-info/personal-info.module';
import { AccountCreationModule } from '@app/account-creation/account-creation.module';
import { CallCenterModule } from '@app/call-center/call-center.module';
import { EmergencyBrakeModule } from '@app/emergency-brake/emergency-brake.module';
import { KbaQuizModule } from '@app/kba-quiz/kba-quiz.module';
import { OtpIdentifyVerifyGetPinModule } from '@app/otp-identity-verify-get-pin/otp-identity-verify-get-pin.module';
import { OtpIdentityVerifySubmitPinModule } from '@app/otp-identity-verify-submit-pin/otp-identity-verify-submit-pin.module';

// Routes - add an entry for any newly guarded routes
import * as Guards from '@app/guards/index.ts';
import { AppConfig } from '@app/app.config';
import { RoutingService } from './routing.service';
import { RouteNames } from '@app/app.route-names';
import { AccountCreationRoutes } from '@app/account-creation/account-creation.routes';
import { CallCenterRoutes } from '@app/call-center/call-center.routes';
import { EmergencyBreakRoutes } from '@app/emergency-brake/emergency-brake.routes';
import { KbaQuizRoutes } from '@app/kba-quiz/kba-quiz.routes';
import { OtpIdentifyVerifyGetPinRoutes } from '@app/otp-identity-verify-get-pin/otp-identity-verify-get-pin.routes';
import { OtpIdentityVerifySubmitPinRoutes } from '@app/otp-identity-verify-submit-pin/otp-identity-verify-submit-pin.routes';
import { PersonalInfoRoutes } from '@app/personal-info/personal-info.routes';

let service: RoutingService;
let location: Location;
let routeNames: RouteNames;
let router: Router;
let config: AppConfig;
let allRoutes: string[];

const appRoutes: Route[] = BaseRoutesWith([
  ...AccountCreationRoutes,
  ...CallCenterRoutes,
  ...EmergencyBreakRoutes,
  ...KbaQuizRoutes,
  ...OtpIdentifyVerifyGetPinRoutes,
  ...OtpIdentityVerifySubmitPinRoutes,
  ...PersonalInfoRoutes
]);

describe('RoutingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        PersonalInfoModule,
        AccountCreationModule,
        CallCenterModule,
        EmergencyBrakeModule,
        KbaQuizModule,
        OtpIdentifyVerifyGetPinModule,
        OtpIdentityVerifySubmitPinModule,
        RouterTestingModule.withRoutes(appRoutes),
      ],
      providers: [
        RoutingService,
        Guards.AccountCreationGuard,
        Guards.EmergencyBrakeMailOptionGuard,
        Guards.EmergencyBrakeNextStepsGuard,
        Guards.KbaQuizGuard,
        Guards.OtpOptInGuard,
        Guards.OtpSubmitGuard,
        Guards.PiiGuard,
        Guards.PtpOptInGuard,
        Guards.PtpSuccessGuard,
        Guards.AccountIsSetupGuard
      ]
    });
    location = TestBed.get(Location);
    router = TestBed.get(Router);
    routeNames = TestBed.get(RouteNames);
    config = TestBed.get(AppConfig);
    service = TestBed.get(RoutingService);
    // All site routes in order to test invalid routing
    // We take EVERY route, then remove valid routes, then test each route that is left in the list
    allRoutes = [
      routeNames.personalInfo,
      routeNames.accountCreation,
      routeNames.otpOptIn,
      routeNames.otpSubmit,
      routeNames.kbaQuiz,
      routeNames.ptpSuccess,
      routeNames.accountIsSetup,
      routeNames.ptpOptIn,
      routeNames.systemError,
      routeNames.callCenter,
      routeNames.callCenterNoHit,
      routeNames.callCenterPtp,
      routeNames.callCenterTimeout,
      routeNames.emergencyBrakeNextSteps,
      routeNames.emergencyBrakeMailOptions
    ];
  });

  // ===============================================================
  // Helper Methods
  // ===============================================================

  const testValidNavigation = (destinationPage, spy) => {
    // navigatingTo is a list of all routes - we pull the route we're testing, and get the "from" property
    // which contains every page that is valid for navigating to the targeted route
    const validRoutes = service['navigatingTo'][destinationPage].from;

    validRoutes.forEach(currentPage => {
      // Spoof the location.path() call so the RoutingService will use value from the currentPages
      spy.and.returnValue(currentPage);

      // Test that we can't navigate to the destination page at first
      service.disableNavigationTo(destinationPage);
      expect(service.canNavigateTo(destinationPage)).toBeFalsy();

      // With a valid currentPage, canNavigateTo will return true after enabling navigation
      service.enableNavigationTo(destinationPage);
      expect(service.canNavigateTo(destinationPage)).toBeTruthy(`should be able to navigate to ${destinationPage} from ${currentPage}`);
    });
  };

  const testInvalidNavigation = (destinationPage, spy) => {
    // Getting the list of routes we can't navigate to
    const invalidRoutes = allRoutes.filter((item) => {
      return service['navigatingTo'][destinationPage].from.indexOf(item) < 0
        && item !== destinationPage;
      }
    );

    invalidRoutes.forEach((currentPage) => {
      // Spoof the location.path() call so the RoutingService will use value from the currentPage
      spy.and.returnValue(currentPage);

      // Check that we cannot navigate
      service.disableNavigationTo(destinationPage);
      expect(service.canNavigateTo(destinationPage)).toBeFalsy();

      // With an invalid currentPage, canNavigateTo will return false, even after enabling navigation
      service.enableNavigationTo(destinationPage);
      expect(service.canNavigateTo(destinationPage)).toBeFalsy(`should not be able to navigate to ${destinationPage} from ${currentPage}`);
    });
  };

  const testOpenRouteNavigation = (destinationPage, spy) => {
    const pageEntryInRoutingService = service['navigatingTo'][destinationPage];

    // Validate there is no entry or no "from" in the routing service for the destination page
    const noEntry = pageEntryInRoutingService && pageEntryInRoutingService.from.length > 0;
    expect(noEntry).toBeFalsy();

    allRoutes.forEach((currentPage) => {
      // Spoof the location.path() to ensure all router.navigate calls have the starting location
      spy.and.returnValue(currentPage);
      router.navigate([destinationPage]);
      tick();

      // Allow the location.path() to continue through the spy so we can validate the current page
      spy.and.callThrough();
      expect(location.path()).toEqual(destinationPage, `should navigate to ${destinationPage} from any page`);
    });
  };

  const validateErrorRoutes = (statusCode, targetPage) => {
    const data = { error: { statusCode } };
    service['handleErrorResponse'](data);
    expect(router.navigateByUrl).toHaveBeenCalledWith(targetPage);
  };

  // ===============================================================
  // Test Cases
  // ===============================================================

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // ---------------------------------------------------------------
  // Valid Navigations

  it('should navigate to valid routes', () => {
    const spy = spyOn(location, 'path').and.returnValue('/');
    testValidNavigation(routeNames.accountCreation, spy);
    testValidNavigation(routeNames.otpOptIn, spy);
    testValidNavigation(routeNames.otpSubmit, spy);
    testValidNavigation(routeNames.ptpOptIn, spy);
    testValidNavigation(routeNames.ptpSuccess, spy);
    testValidNavigation(routeNames.accountIsSetup, spy);
    testValidNavigation(routeNames.kbaQuiz, spy);
    testValidNavigation(routeNames.emergencyBrakeMailOptions, spy);
    testValidNavigation(routeNames.emergencyBrakeNextSteps, spy);
  });

  // ---------------------------------------------------------------
  // Invalid Navigations

  it('should not navigate to invalid routes', () => {
    const spy = spyOn(location, 'path').and.returnValue('/');
    testInvalidNavigation(routeNames.accountCreation, spy);
    testInvalidNavigation(routeNames.otpOptIn, spy);
    testInvalidNavigation(routeNames.otpSubmit, spy);
    testInvalidNavigation(routeNames.ptpOptIn, spy);
    testInvalidNavigation(routeNames.ptpSuccess, spy);
    testInvalidNavigation(routeNames.accountIsSetup, spy);
    testInvalidNavigation(routeNames.kbaQuiz, spy);
    testInvalidNavigation(routeNames.emergencyBrakeMailOptions, spy);
    testInvalidNavigation(routeNames.emergencyBrakeNextSteps, spy);
  });

  // ---------------------------------------------------------------
  // Open Routes

  it('should allow navigation to open pages with no guards', fakeAsync(() => {
    const spy = spyOn(location, 'path').and.returnValue('/');
    testOpenRouteNavigation(routeNames.personalInfo, spy);
    testOpenRouteNavigation(routeNames.systemError, spy);
    testOpenRouteNavigation(routeNames.callCenterPtp, spy);
    testOpenRouteNavigation(routeNames.callCenterPtp, spy);
    testOpenRouteNavigation(routeNames.callCenterNoHit, spy);
    testOpenRouteNavigation(routeNames.callCenterTimeout, spy);
  }));

  // ---------------------------------------------------------------
  // Error Routes

  it('should route errors to system error', () => {
    const spy = spyOn(router, 'navigateByUrl').and.stub();
    validateErrorRoutes(config.systemError, routeNames.systemError);
    validateErrorRoutes(config.callCenterError, routeNames.callCenter);
    validateErrorRoutes(config.kbaQuizError, routeNames.callCenter);
  });

  // ---------------------------------------------------------------
  // Call Center Routes

  it('should default errors to call center', () => {
    const spy = spyOn(router, 'navigateByUrl').and.stub();
    const data = { };
    service['handleErrorResponse'](data);
    expect(router.navigateByUrl).toHaveBeenCalledWith(routeNames.callCenter);
  });
});
