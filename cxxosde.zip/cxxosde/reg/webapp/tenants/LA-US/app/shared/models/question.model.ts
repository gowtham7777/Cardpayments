import { AnswerChoice } from './answer-choice.model';

export class Question {
	questionId: string;
	questionText: string;
	answerChoices: AnswerChoice[];
	
	constructor(questionId: string, questionText: string, answerChoices: AnswerChoice[]) {
		this.questionId = questionId;
		this.questionText = questionText;
		this.answerChoices = answerChoices;
	}
	
}