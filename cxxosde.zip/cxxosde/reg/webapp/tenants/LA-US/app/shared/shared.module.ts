import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { MessageBannerComponent } from './components/message-banner/message-banner.component';
import { UnsupportedBrowserComponent } from '@common/components/unsupported-browser/unsupported-browser.component';
import { StringSanitizePipe } from "@common/pipes/string-sanitize-pipe";

// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, 'assets/locales/', '.json');
}

@NgModule({
  declarations: [
    MessageBannerComponent,
    UnsupportedBrowserComponent,
    StringSanitizePipe
  ],
  imports: [
    CommonModule,
    TranslateModule,
  ],
  providers: [],
  exports: [
    CommonModule,
    TranslateModule,
    ReactiveFormsModule,
    MessageBannerComponent,
    UnsupportedBrowserComponent,
    StringSanitizePipe,
  ]
})
export class SharedModule {}
