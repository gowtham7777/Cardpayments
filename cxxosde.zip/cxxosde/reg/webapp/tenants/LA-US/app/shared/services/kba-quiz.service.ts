import { Observable } from 'rxjs';
import { HttpHeaders,  HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Question } from '../models/question.model';
import { Answer } from '../models/answer.model';
import { RouteNames } from '@app/app.route-names';
import { RoutingService } from '@services/routing.service';
import { PtpService } from '@app/ptp/ptp.service';
import { AppConfig } from '@app/app.config';
import { environment } from '../../../environments/environment';

@Injectable()
export class KbaQuizService {
  results: object;
  headers: HttpHeaders;
  public showOtpFailedBanner = false;

  private submitAnswersUrl = environment.submitAnswersUrl;

  quizIdentifier: String;
  questions: Question[];

   // Inject HttpClient into your component or service.
   constructor(
     private http: HttpClient,
     private router: Router,
     private routes: RouteNames,
     private routingService: RoutingService,
     private ptpService: PtpService,
     private config: AppConfig
   ) {
      this.headers = new HttpHeaders()
        .set('Accept', 'application/json')
        .set('Content-Type', 'application/json');
   }

   fetchQuiz() {
    const errorRoute = this.routes.callCenter;
    this.http.get<any>(environment.getQuizUrl).subscribe(
      // Successful responses call the first callback
      data => {
        if (data) {
          let routesMap = this.ptpService.routesMap;
          routesMap[this.config.kbaQuizSuccess] = () => {
            if (data.quizIdentifier && data.questions) {
              this.saveQuiz(data.quizIdentifier, data.questions as Question[]);
              this.routingService.enableNavigationTo(this.routes.kbaQuiz);
              this.router.navigate([this.routes.kbaQuiz]);
            } else {
              this.router.navigate([errorRoute]);
            }
          };
          const defaultRoute = () => { this.router.navigate([errorRoute]); };
          (routesMap[data.statusCode] || defaultRoute)();
        } else {
          this.router.navigate([errorRoute]);
        }
      },
      // Errors will call this callback instead
      err => {
        this.router.navigate([errorRoute]);
      }
    );
   }

   saveQuiz(quizIdentifier: String, questions: Question[]): void {
     this.quizIdentifier = quizIdentifier;
     this.questions = questions;
   }

   getQuiz(): Question[] {
    return this.questions;
   }

   submitAnswers(answers: Answer[]): Observable<any> {
    const body = {quizIdentifier: this.quizIdentifier,
                  answers: answers};
    return this.http
      .post<any>(environment.submitAnswersUrl, body, {
        headers: this.headers
      });
  }
}
