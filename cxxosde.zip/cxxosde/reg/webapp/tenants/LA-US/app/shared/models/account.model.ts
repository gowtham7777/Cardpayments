export class Account {
    'username': string;
    'password': string;
    'blackBox': string;
}
