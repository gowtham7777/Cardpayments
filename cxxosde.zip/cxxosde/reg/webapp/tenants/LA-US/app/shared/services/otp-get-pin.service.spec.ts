import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';

import { OtpGetPinService } from './otp-get-pin.service';

let service: OtpGetPinService;
describe('OtpGetPinService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule],
      providers: [OtpGetPinService]
    });

    service = TestBed.get(OtpGetPinService);
  });

  it('should be created', inject([OtpGetPinService], (service: OtpGetPinService) => {
    expect(service).toBeTruthy();
  }));

  it('should get new pin request', () => {
    expect(service.getDisplayNewPinRequest()).toBeTruthy();
  });

  it('should not get new pin request', () => {
    service.setDisplayNewPinRequest(false);
    expect(service.getDisplayNewPinRequest()).toBeFalsy();
  });

  it('should show new code banner', () => {
    service.setShowNewCodeBanner(true);
    expect(service.getShowNewCodeBanner()).toBeTruthy();
  });
});
