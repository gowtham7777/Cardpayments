import { SaveConsumerResponse } from '../models/saveConsumerResponse.model';
import { Observable } from 'rxjs';
import { Consumer } from '../models/consumer.model';
import { HttpHeaders, HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable()
export class ConsumerService {
  results: object;
  headers: HttpHeaders;
  consumer: Consumer;
  otpEmail: string;

   // Inject HttpClient into your component or service.
   constructor(private http: HttpClient) {
      this.headers = new HttpHeaders()
        .set('Accept', 'application/json')
        .set('Content-Type', 'application/json');
   }

  saveConsumer(body: Consumer): Observable<any> {
    this.consumer = body;
    return this.http
    .post<SaveConsumerResponse>(environment.registrationUrl, body, {
      headers: this.headers
    });
  }
}
