import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';

import { OtpSubmitPinService } from './otp-submit-pin.service';

let service: OtpSubmitPinService;
describe('OtpSubmitPinService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule],
      providers: [OtpSubmitPinService]
    });

    service = TestBed.get(OtpSubmitPinService);
  });

  it('should be created', inject([OtpSubmitPinService], (service: OtpSubmitPinService) => {
    expect(service).toBeTruthy();
  }));

  it('validate get pin', () => {
    expect(service.getOtpFailed()).toBeFalsy();
  });

  it('validate set pin', () => {
    service.setOtpFailed(true);
    expect(service.getOtpFailed()).toBeTruthy();
  });
});
