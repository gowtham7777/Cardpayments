import * as dbJson from '../server/rest/db.json';
import { Question } from '@models/question.model';

import { Consumer } from '@models/consumer.model';
import { Observable, Subscriber } from 'rxjs';
import { Injectable } from '@angular/core';

import { AppConfig } from '@app/app.config';
import { AppConfiguration } from '@common/models/app-configuration.model';


export class MockKbaQuizService {
  quizIdentifier: String = 'testQuizIdentifier';
  questions: Question[] = (<any>dbJson).getQuiz.questions as Question[];
  getQuiz = () => {
    return this.questions;
  };
  fetchQuiz = () => {
    return this.getQuiz();
  };
  saveQuiz = (quizIdentifier: String, questions: Question[]): void => {
    this.quizIdentifier = quizIdentifier;
    this.questions = questions;
  };
  submitAnswers = form => {}; // empty for now so we can spyOn the method
}

export class MockAnalyticsService {
  appendEvent(eventSet: object) {}

  createDigitalDataEvent(eventData) {}

  updatePageName(pageName: string) {}

  fireEventTracking(eventDetail: object) {}

  callcenterBeacon() {}
}

export class MockConsumerService {
  consumer: Consumer;

  saveConsumer(body: Consumer) {
    return (<any>dbJson).saveConsumer;
  }
}

export class MockCaptchaService {
  retrieveCaptchaSiteKey(): Observable<string> {
    return new Observable<string>((subscriber: Subscriber<string>) =>
      subscriber.next('string')
    );
  }
}

@Injectable()
export class MockPtpService {
  public routesMap;
  private ptpService;
  public ptpEligible: boolean = false;
  public ptpOnly: boolean = false;
  constructor(private config: AppConfig) {
    this.routesMap = {
      [this.config.ptpEligiblePrimary]: () => {
        // do nothing
      },
      [this.config.ptpEligibleSecondary]: () => {
        // do nothing
      },
      [this.config.kbaQuizError]: () => {
        // do nothing
      },
      [this.config.ptpOnly]: () => {
        // do nothing
      }
    };
  }

  enrollPTP() {}
  isPtpEligible() {
    return this.ptpEligible;
  }

  setPtpEligible(eligible: boolean) {
    this.ptpEligible = eligible;
  }

  isPtpOnly() {
    return this.ptpOnly;
  }

  setPtpOnly(ptpOnly: boolean) {
    this.ptpOnly = ptpOnly;
  }

  submitPtpPin() {
    return true;
  }

  memberCenterRedirect() {
    return true;
  }
}

export class MockOtpGetPinService {
  displayNewPinRequest: boolean = true;
  showNewCodeBanner: boolean = false;
  enrollOTP() {
    return new Observable<string>((subscriber: Subscriber<string>) =>
      subscriber.next('string')
    );
  }
  getDisplayNewPinRequest() {
    return this.displayNewPinRequest;
  }
  setDisplayNewPinRequest(displayNewPinRequest: boolean) {
    this.displayNewPinRequest = displayNewPinRequest;
  }
  getShowNewCodeBanner() {
    return this.showNewCodeBanner;
  }
  setShowNewCodeBanner(showNewCodeBanner: boolean) {
    this.showNewCodeBanner = showNewCodeBanner;
  }
}

export class MockOtpSubmitPinService {
  otpFailed: boolean = false;
  otpPinFailed: boolean = false;

  validatePin(pin: string) {
    return new Observable<string>((subscriber: Subscriber<string>) =>
      subscriber.next('string')
    );
  }

  getOtpFailed() {
    return this.otpFailed;
  }

  setOtpFailed(otpFailed: boolean) {
    this.otpFailed = otpFailed;
  }

  setPinAuthFailed(otpPinFailed: boolean) {
    this.otpPinFailed = otpPinFailed;
  }
}

export class MockEmergencyBrakeService {
  postEmergencyBreak(optIn: boolean) {
    return new Observable<string>((subscriber: Subscriber<string>) =>
      subscriber.next('string')
    );
  }
}

export class MockAppConfigService {
  getAppConfiguration() {}
  getConfigurationData$() {
    return new Observable<AppConfiguration>(
      (subscriber: Subscriber<AppConfiguration>) =>
        subscriber.next((<any>dbJson).appConfig)
    );
  }
}
