import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';

import { throwIfAlreadyLoaded } from './module.import.guard';
import { AppConfigService } from '@common/services/app-config.service';
import { AnalyticsService } from '@common/services/analytics.service';
import { EmergencyBrakeService } from '../shared/services/emergency-brake.service';


@NgModule({
  imports: [
    CommonModule
  ],
  exports: [],
  declarations: [],
  providers: [
    // singleton service(s) go here
    AppConfigService,
    AnalyticsService,
    EmergencyBrakeService
  ]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}
