import { Route } from '@angular/router';
import { AccountIsSetupComponent } from './account-is-setup.component';
import { AccountIsSetupGuard } from '@app/guards/account-is-setup.guard';

export const AccountIsSetupRoutes: Route[] = [
  {
    path: 'account-is-setup',
    component: AccountIsSetupComponent,
    canActivate: [AccountIsSetupGuard]
  }
];
