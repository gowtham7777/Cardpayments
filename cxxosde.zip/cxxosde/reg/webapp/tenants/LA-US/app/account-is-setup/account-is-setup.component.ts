import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { AppConfig } from '@app/app.config';
import { AnalyticsService } from '@common/services/analytics.service';
import { RoutingService } from '@app/shared/services/routing.service';
import { Router } from '@angular/router';
import { RouteNames } from '@app/app.route-names';
import { AppConfigService } from '@common/services/app-config.service';

@Component({
    selector: 'app-account-is-setup',
    templateUrl: './account-is-setup.component.html',
    styleUrls: ['./account-is-setup.component.scss']
})
export class AccountIsSetupComponent implements OnInit {
    loadingRequest = false;
    private translateService;
    public memberCenterURL;
    public isMobileApp;
    public mobileQueryParamValue;
    public mobileQueryParam;
    constructor(
        private config: AppConfig,
        private analyticsService: AnalyticsService,
        private translate: TranslateService,
        private routingService: RoutingService,
        private router: Router,
        private routes: RouteNames,
        private titleService: Title,
        private appConfigService: AppConfigService,
    ) {
        this.translateService = translate;
        this.appConfigService.getConfigurationData$().subscribe(appConfig => (this.memberCenterURL = appConfig.successMCLoginUrl));
    }

    ngOnInit() {
        this.analyticsService.appendEvent({
            eventData: {
                eventName: this.config.analytics.accountIsSetup.pageLoad
                    .eventName,
                pageName: this.config.analytics.accountIsSetup.pageLoad.pageName
            },
            eventIds: this.config.analytics.accountIsSetup.pageLoad.eventIds
        });
        this.translate
            .get('account-is-setup.browserTitle.pageLoadTitle')
            .subscribe((result: string) => {
                this.titleService.setTitle(result);
            });
    }


    onLogin() {
       if (this.memberCenterURL) {
        window.location.href = this.appConfigService.updateUrlForMobileParam(this.memberCenterURL);
       } else {
        this.router.navigate([this.routes.callCenter]);
       }
    }
}
