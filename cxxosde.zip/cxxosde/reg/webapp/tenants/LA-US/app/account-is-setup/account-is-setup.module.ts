// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

// Custom
import { SharedModule } from '../shared/shared.module';
import { AccountIsSetupComponent } from './account-is-setup.component';

@NgModule({
  declarations: [
    AccountIsSetupComponent
  ],

  imports: [
    CommonModule,
    SharedModule
  ],
  providers: [], // services go here
  exports: [
    AccountIsSetupComponent
  ]
})
export class AccountIsSetupModule { }
