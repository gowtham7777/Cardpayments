import { Route } from '@angular/router';
import { SystemErrorComponent } from './system-error.component';

export const SystemErrorRoutes: Route[] = [
  {
    path: 'system-error',
    component: SystemErrorComponent
  }
];

