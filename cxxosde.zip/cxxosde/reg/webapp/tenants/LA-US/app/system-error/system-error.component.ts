import { Component, Input, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { AppConfig } from '@app/app.config';
import { SharedModule } from '@app/shared/shared.module';
import { AnalyticsService } from '@common/services/analytics.service';
import { RoutingService } from '@services/routing.service';
import { RouteNames } from '@app/app.route-names';

@Component({
  selector: 'system-error',
  templateUrl: './system-error.component.html'
})
export class SystemErrorComponent implements OnInit {
private translateService;

  constructor(
    private analyticsService: AnalyticsService,
    private config: AppConfig,
    private routingService: RoutingService,
    private routes: RouteNames,
    private translate: TranslateService,
    private titleService: Title
  ) {
    this.translateService = translate;
    this.routingService.enableNavigationTo(this.routes.personalInfo);
  }

  ngOnInit () {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.systemError.pageLoad.eventName,
        pageName: this.config.analytics.systemError.pageLoad.pageName
      },
      eventIds: this.config.analytics.systemError.pageLoad.eventIds
    });
    this.translateService.get('system-error.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
  });

}

}
