import { Injectable } from '@angular/core';

// Properties are not static to allow for injection of the app.config
// By injecting, we do not generate an instance of the app.config for each component (singleton)
@Injectable()
export class AppConfig {

    public callCenterError = 'CALL_CENTER_ERROR';
    public cidUnavailable = 'CID_UNAVAILABLE';

    public emergencyBrakeOn = 'EMERGENCY_BREAK_ON';
    public emergencyBrakePtpOptIn = 'EMERGENCY_BREAK_P2P_OPTED_IN';
    public emergencyBrakePtpOptOut = 'EMERGENCY_BREAK_P2P_OPTED_OUT';


    public errorDisplay = '';

    public getPinToText = 'GET_PIN_TO_TEXT';
    public getPinToEmail = 'GET_PIN_TO_EMAIL';

    public indirectEnrollmentSystemError = 'INDIRECT_ENROLLMENT_SYSTEM_ERROR';

    public kbaSubmissionSuccess = 'KBA_SUBMIT_ANSWERS_SUCCESS';
    public kbaSubmissionTimeout = 'KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT';
    public kbaSubmissionError = 'KBA_SUBMIT_ANSWERS_ERROR';
    public kbaQuizSuccess = 'KBA_QUIZ_SUCCESS';
    public kbaQuizError = 'KBA_QUIZ_ERROR';
    public kbaSystemError = 'KBA_SUBMIT_ANSWERS_SYSTEM_ERROR';
    public kbaOtpEnrollAllowed = 'ENROLL_OTP_RESEND_ALLOWED';
    public kbaOtpAtMax = 'ENROLL_OTP_RESEND_MAX';
    public kbaFailureEligibilityFail = 'KBA_FAILURE_ELIGIBILITY_FAIL';
    public kbaSuccessEligibilityFail = 'KBA_SUCCESS_ELIGIBILITY_FAIL';
    public kbaGetQuizSuccessOtpPinRetryMax = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_RETRY_MAX';
    public kbaGetQuizSuccessOtpPinInitiationFail = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_INITIATION_FAIL';
    public kbaGetQuizSuccessOtpPinValidationFailUnknown = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_VALIDATION_FAIL_UNKNOWN';

    public mobileQueryParam = 'adobe_mc';

    public noSpinnerHeader = 'No-Spinner-Flag';

    public otpEligibilityNoHit = 'ELIGIBILITY_CHECK_NO_HIT';
    public otpValidateResubmitWithResendMax = 'OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX';
    public otpEnrollResendAllowedInit = 'ENROLL_OTP_RESEND_ALLOWED_INIT';
    public otpEnrollResendAllowed = 'ENROLL_OTP_RESEND_ALLOWED';
    public otpEnrollResendMax = 'ENROLL_OTP_RESEND_MAX';
    public otpValidatePinSuccess = 'OTP_VALIDATE_PIN_SUCCESS';

    public personalInfoConfirmation = 'CONFIRMATION';
    public personalInfoRecaptcha = 'RECAPTCHA_ERROR';
    public ptpInitiated = 'INITIATE_PTP_SUCCESS';
    public ptpInitiateSystemError = 'INITIATE_PTP_SYSTEM_ERROR';
    public ptpOnly = 'PIN_TO_POST_ONLY'; // Can be use to display only PTP (for instance - during emergency break)
    public ptpEligiblePrimary = 'PIN_TO_POST_PRIMARY';
    public ptpEligibleSecondary = 'PIN_TO_POST_SECONDARY';
    public ptpSubmitPinSuccess = 'VALIDATE_PTP_SUCCESS';
    public ptpSubmitPinError = 'VALIDATE_PTP_ERROR';
    public ptpSubmitPinExpire = 'VALIDATE_PTP_EXPIRE';
    public ptpSubmitPinRecaptcha = 'VALIDATE_PTP_RECAPTCHA_ERROR';
    public ptpValidateResubmitAllowed = 'VALIDATE_PTP_ERROR_RESUBMIT_ALLOWED';


    public saveConsumerExist = 'SAVE_CONSUMER_EXIST';
    public systemError = 'SYSTEM_ERROR';

    public tenantName = 'LnA';
    public consumerSavePartialSuccessSystemError = 'CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR';
    public duplicateEnrollment = 'DUPLICATE_ENROLLMENT';
    public validationError = 'VALIDATION_ERROR';

    public productInfo = {
      'productID': 'LockAlert.2018.01',
      'productName': 'LockAlert.2018.01',
      'description': 'LockAlert.2018.01'
    };

    public errorKeys = {
      ageInvalid: '',
      duplicateEnroll: '',
      invalidPassword: '',
      noObject: '',
      pinIncorrect: ''
    };

    public analytics = {
    createAccount: {
      emailInUse: {
        eventName: 'emailInUsePageLoad',
        eventIds: ['emailAlreadyInUse']
      },
      pageLoad: {
        eventName: 'createAccountPageLoad',
        pageName: 'lock alert - create account',
        eventIds: ['ajaxPageLoad', 'lockAlertCreateAccount']
      }
    },
    callCenter: {
      generic: {
        eventName: 'genericCallCenterPageLoad',
        pageName: 'lock alert - call cc or pin to mail',
        eventIds: ['ajaxPageLoad']
      },
      kbaTimeOut: {
        eventName: 'kbaTimeOutPageLoad',
        pageName: 'lock alert - kba timeout',
        eventIds: ['sessionTimeOut']
      },
      noHit: {
        eventName: 'noHitPageLoad',
        pageName: 'lock alert - no file in acro',
        eventIds: ['ajaxPageLoad']
      },
      callCustomerCare: {
        eventName: 'customerCareCallAttempt',
        eventIds: ['customerCareCallAttempt']
      }
    },
    emergencyBrake: {
      mailOption: {
        eventName: 'mailOptInPageLoad',
        pageName: 'lock alert - emergency brake - mail opt in',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailInit: {
        eventName: 'pinToMailInitiated',
        pageName: 'lock alert - emergency brake - mail opt in',
        eventIds: ['pinToMailInitiated']
      },
      nextSteps: {
        eventName: 'nextStepsPageLoad',
        pageName: 'lock alert - emergency brake - next steps',
        eventIds: ['ajaxPageLoad']
      }
    },
    kbaQuiz: {
      pageLoad: {
        eventName: 'kbaQuizPageLoad',
        pageName: 'lock alert - kba',
        eventIds: ['ajaxPageLoad', 'lockAlertCollectKBA']
      },
      kbaAuthAttempt: {
        eventName: 'kbaAuthAttempt',
        pageName: 'lock alert - kba',
        attributes: {
          authenticationType: 'kba'
        },
        eventIds: ['kbaAuthAttempt']
      }
    },
    otp: {
      text: {
        verifyPin: {
          eventName: 'otpVerifyPinPageLoad',
          pageName: 'lock alert - pin to text - request code',
          eventIds: ['ajaxPageLoad']
        },
        pinRequest: {
          eventName: 'otpSMSNewPinRequest',
          pageName: 'lock alert - pin to text - request code',
          eventIds: ['otpSMSNewPinRequest']
        },
        submitPin: {
          eventName: 'otpSubmitPinPageLoad',
          pageName: 'lock alert - pin to text - enter code',
          eventIds: ['ajaxPageLoad']
        },
        pinAuthAttempt: {
          eventName: 'otpSMSPinAuthAttempt',
          pageName: 'lock alert - pin to text - enter code',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpSMSPinAuthAttempt']
        },
        pinOptOut: {
          eventName: 'otpSMSPinOptOut',
          pageName: 'lock alert - pin to text - enter code',
          eventIds: ['otpSMSPinOptOut']
        },
        pinDidNotReceive: {
          eventName: 'otpDidNotReceivePIN',
          pageName: 'lock alert - pin to text - enter code',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpDidNotReceivePIN']
        },
        pinIncorrect: {
          eventName: 'otpIncorrectCodeEntered',
          pageName: 'lock alert - pin to text - enter code',
          eventIds: ['otpIncorrectCodeEntered']
        }
      },
      email: {
        verifyPin: {
          eventName: 'otpVerifyEmailPinPageLoad',
          pageName: 'pin to email - request code',
          eventIds: ['ajaxPageLoad']
        },
        pinOptOut: {
          eventName: 'otpEmailPinOptOut',
          pageName: 'pin to email - enter code',
          eventIds: ['otpEmailPinOptOut']
        },
        pinRequest: {
          eventName: 'otpEmailNewPinRequest',
          pageName: 'pin to email - request code',
          eventIds: ['otpEmailNewPinRequest']
        },
        submitPin: {
          eventName: 'otpEmailSubmitPinPageLoad',
          pageName: 'pin to email - enter code',
          eventIds: ['ajaxPageLoad']
        },
        pinDidNotReceive: {
          eventName: 'otpDidNotReceivePIN',
          pageName: 'pin to email - enter code',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpDidNotReceivePIN']
        },
        pinAuthAttempt: {
          eventName: 'otpEmailPinAuthAttempt',
          pageName: 'pin to email - enter code',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpEmailPinAuthAttempt']
        },
        pinIncorrect: {
          eventName: 'otpIncorrectCodeEntered',
          pageName: 'pin to email - enter code',
          eventIds: ['otpIncorrectCodeEntered']
        }
      }
    },
    personalInfo: {
      pageLoad: {
        eventName: 'personalInfoPageLoad',
        pageName: 'lock alert - personal info',
        eventIds: ['ajaxPageLoad', 'lockAlertPersonalInfo']
      }
    },
    accountIsSetup: {
      pageLoad: {
        eventName: 'accountSetupSuccessPageLoad',
        pageName: 'lock alert - account is ready',
        eventIds: ['ajaxPageLoad', 'lockAlertAccountCreated']
      }
    },

    ptp: {
      pinNotAvailable: {
        eventName: 'ptpNotAvailable',
        pageName: 'lock alert - pin to mail not available',
        eventIds: ['ajaxPageLoad']
      },
      callCcOrPinToMail: {
        eventName: 'callCcOrPinToMail',
        pageName: 'lock alert - call CC or pin to mail',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailOrCallCc: {
        eventName: 'pinToMailOrCallCc',
        pageName: 'lock alert - pin to mail or call CC',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailOnly: {
        eventName: 'pinToMailOnly',
        pageName: 'lock alert - pin to mail Only',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailInitiated: {
        eventName: 'pinToMailInitiated',
        eventIds: ['pinToMailInitiated']
      },
      pinToMailAuthSuccess: {
        eventName: 'pinToMailAuthSuccess',
        pageName: 'lock alert - pin to mail confirmation',
        eventIds: ['ajaxPageLoad']
      },
      pinToMail: {
        eventName: 'pinToMailAuthPageLoad',
        pageName: 'pin to mail - authentication',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailAuthAttempt: {
        eventName: 'pinToMailAuthAttempt',
        pageName: 'pin to mail - authentication',
        attributes: {
          authenticationType: 'pinToMail'
         },
        eventIds: ['pinToMailAuthAttempt']
      }
    },
    systemError: {
      pageLoad: {
        eventName: 'systemErrorPageLoad',
        pageName: 'lock alert - server error',
        eventIds: ['ajaxPageLoad']
      }
    },
    timeout: {
      pageLoad: {
        eventName: 'sessionTimeOut',
        pageName: 'lock alert - session timeout',
        eventIds: ['sessionTimeOut']
      }
    }
  };

  // Current major version minus 2 versions as of 12/19/2017
  public minimumBrowserVersions = {
    chrome: 57, // 03/2017
    firefox: 55, // 03/2017
    safari: 10, // 09/2016
    opera: 44, // 03/2017
    'ms-edge': 14, // 08/2016
    ie: 11, // Latest version of IE from 2015
  };

  public regex= {
    dottedEmailAddress: '(?=^\\S+@\\S+\\.\\S+$)',
    allowedEmailCharacters: '(?=^[A-Za-z0-9@$\\._-]+$)', // allows alphanumeric, '@', '.', '_', '-'
    startsWithAlphanumeric: '(?=^[A-Za-z0-9].*$)', // cannot start with special character
    minAndMaxEmailLength: '(?=^.{5,100}$)',  // between 5 and 100 characters
    oneAtMark: '(^(?!.*[@].*[@]).*$)',
    notNineOrMoreNumbers : '(?=^((?!([0-9]{9,}\\1)).)*$)',
    allowedPinCharacters:  '^[A-Z0-9]{10}$',
    length8to20: '(?=^.{8,20}$)',
    atLeastOneLowercase: '(?=.*[a-z])',
    atLeastOneUppercase: '(?=.*[A-Z])',
    atLeastOneNumber: '(?=.*[0-9])',
    atLeastOneSpecialCharacter: '(?=.*[!@$*+\\-])',
    notNineNumbersInARow: '(?=^((?!([0-9]{9,}\\1)).)*$)',
    noTwoRepeatingCharacters: '(?=^(?!.*(.)\\1{2,}).*$)',
    noSpaces: '(?=^(?!.*\\s).*$)',
    onlyValidCharacters: '(?=^[a-zA-Z0-9!@$*+\\-]+$)',

    betweenLengths : '(?=^.{8,20}$)', // between 8 - 20 characters
    oneLowercase : '(?=.*[a-z])', // at least one lowcase letters
    oneUppercase : '(?=.*[A-Z])', // at least one uppercase letters
    oneNumber : '(?=.*[0-9])', // at least least 1 number
    oneSpecialChar : '(?=.*[!@$*+\\-])', // at least one special characters
    notTwoRepeactChar : '(?=^(?!.*(.)\\1{2,}).*$)', // cannot contain more than 2 repeating characters
    notSpaces : '(?=^(?!.*\\s).*$)',
    notAnyOtherChars : '(?=^[a-zA-Z0-9!@$*+\\-]+$)' // cannot contain any other characters beside those listed above
  };
}
