import { Injectable } from "@angular/core";

// .routes files require hard-coded strings since this cannot be injected into those constants
// Adding a new route will require an update in this file to centralize the route name
@Injectable()
export class RouteNames {
    public personalInfo = '/personal-info';
    public accountCreation = '/account-creation';
    public accountIsSetup = '/account-is-setup';

    public otpOptIn = '/otp-verify-get-pin';
    public otpSubmit = '/otp-verify-submit-pin';

    public ptpOptIn = '/ptp-opt-in';
    public ptpSuccess = '/ptp-success';
    public ptpSubmitPin = '/ptp-submit-pin';

    public kbaQuiz = '/kba-quiz';

    public systemError = '/system-error';

    public callCenter = '/call-center-generic';
    public callCenterPtp = '/call-center-ptp';
    public callCenterTimeout = '/call-center-kba-timeout';
    public callCenterNoHit = '/call-center-nohit';

    public emergencyBrakeMailOptions = '/emergency-brake-mail-option';
    public emergencyBrakeNextSteps = '/emergency-brake-next-steps';
}
