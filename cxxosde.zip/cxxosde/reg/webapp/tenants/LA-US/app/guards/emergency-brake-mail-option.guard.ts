import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { RoutingService } from '@services/routing.service';
import { RouteNames } from '@app/app.route-names';

@Injectable()
export class EmergencyBrakeMailOptionGuard implements CanActivate {
  constructor(
    private routingService: RoutingService,
    private routes: RouteNames
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      return this.routingService.canNavigateTo(this.routes.emergencyBrakeMailOptions);
  }
}
