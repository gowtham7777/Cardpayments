import { TestBed, async, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

import { PiiGuard } from './pii.guard';

describe('PiiGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PiiGuard],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ]
    });
  });

  // All routing is tested in the routing.service.spec, this test simply ensures the guards are instantiated correctly
  it('should ...', inject([PiiGuard], (guard: PiiGuard) => {
    expect(guard).toBeTruthy();
  }));
});
