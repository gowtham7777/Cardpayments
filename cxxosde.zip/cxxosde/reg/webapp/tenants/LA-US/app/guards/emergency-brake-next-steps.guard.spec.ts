import { TestBed, async, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

import { EmergencyBrakeNextStepsGuard } from './emergency-brake-next-steps.guard';

describe('EmergencyBrakeNextStepsGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmergencyBrakeNextStepsGuard],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ]
    });
  });

  // All routing is tested in the routing.service.spec, this test simply ensures the guards are instantiated correctly
  it('should ...', inject([EmergencyBrakeNextStepsGuard], (guard: EmergencyBrakeNextStepsGuard) => {
    expect(guard).toBeTruthy();
  }));
});
