import { TestBed, async, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

import { KbaQuizGuard } from './kba-quiz.guard';

describe('KbaQuizGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [KbaQuizGuard],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ]
    });
  });

  // All routing is tested in the routing.service.spec, this test simply ensures the guards are instantiated correctly
  it('should ...', inject([KbaQuizGuard], (guard: KbaQuizGuard) => {
    expect(guard).toBeTruthy();
  }));
});
