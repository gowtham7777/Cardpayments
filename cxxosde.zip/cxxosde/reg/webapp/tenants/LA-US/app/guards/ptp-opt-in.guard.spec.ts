import { TestBed, async, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

import { PtpOptInGuard } from './ptp-opt-in.guard';

describe('PtpOptInGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PtpOptInGuard],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ]
    });
  });

  // All routing is tested in the routing.service.spec, this test simply ensures the guards are instantiated correctly
  it('should ...', inject([PtpOptInGuard], (guard: PtpOptInGuard) => {
    expect(guard).toBeTruthy();
  }));
});
