import { TestBed, inject } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { SharedModule } from '@shared/shared.module';
import { Idle } from '@ng-idle/core';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { AppConfiguration } from '@common/models/app-configuration.model';
import { Keepalive } from '@ng-idle/keepalive';

import { TimeoutService } from './timeout.service';
import { AnalyticsService } from '@common/services/analytics.service';

const mockMatDialog = {
  open: function(a, b) {},
  close: function(a, b) {},
  closeAll: function(a, b) {}
};

const mockAppConfig = {
  'captchaSiteKey': 'rcsk',
  'idleDuration': 10,
  'idleWarningDuration': 9,
  'minAgeToRegister': 18,
  'resourceBundle': '',
  'spinnerMillisecondDelay': 2000,
  'successMCLoginUrl': 'tidlurl',
  'tenantPartner': 'la-us',
  'termsUrl': 'turl',
  'timeoutPageUrl': 'topurl',
  'defaultLocale': 'en',
  'touDisabled': false
};

let service: TimeoutService;

describe('TimeoutService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        SharedModule
      ],
      providers: [
        TimeoutService,
        {provide: MatDialog, useValue: mockMatDialog},
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    });
    service = TestBed.get(TimeoutService);
  });

  it('should be created', inject([TimeoutService], () => {
    expect(service).toBeTruthy();
  }));

  it('should set configuration', inject([Idle, Keepalive], (idle: Idle, keepAlive: Keepalive) => {
    spyOn(keepAlive, 'request').and.stub();
    spyOn(idle, 'setIdle').and.stub();
    spyOn(idle, 'setTimeout').and.stub();
    spyOn(idle, 'setInterrupts').and.stub();
    spyOn(idle, 'setKeepaliveEnabled').and.stub();
    service.setConfiguration(mockAppConfig);
    expect(keepAlive.request).toHaveBeenCalled();
    expect(idle.setIdle).toHaveBeenCalledWith(mockAppConfig.idleDuration);
    expect(idle.setTimeout).toHaveBeenCalledWith(mockAppConfig.idleWarningDuration);
    expect(service.timeoutPageUrl).toEqual(mockAppConfig.timeoutPageUrl);
    expect(idle.setKeepaliveEnabled).toHaveBeenCalledWith(true);
  }));

  it('idle start', inject([MatDialog], (dialog: MatDialog) => {
    spyOn(window, 'scrollTo').and.stub();
    spyOn(dialog, 'open').and.stub();
    service.onIdleStart();
    expect(window.scrollTo).toHaveBeenCalledWith(0, 0);
    expect(dialog.open).toHaveBeenCalled();
  }));

  it('idle timeout', inject([Idle, MatDialog, AnalyticsService],
    (idle: Idle, dialog: MatDialog, analytics: AnalyticsService) => {
    spyOn(idle, 'ngOnDestroy').and.stub();
    spyOn(dialog, 'closeAll').and.stub();
    spyOn(analytics, 'appendEvent').and.stub();
    service.onIdleTimeout();
    expect(idle.ngOnDestroy).toHaveBeenCalled();
    expect(dialog.closeAll).toHaveBeenCalled();
    expect(analytics.appendEvent).toHaveBeenCalled();
  }));

  it('keep alive ping', () => {
    spyOn(service, 'onKeepalivePing').and.stub();
    service.onKeepalivePing();
    expect(service.onKeepalivePing).toHaveBeenCalled();
  })
});
