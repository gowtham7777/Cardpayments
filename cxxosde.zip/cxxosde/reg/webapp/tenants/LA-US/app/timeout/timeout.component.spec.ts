import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { SharedModule } from '@shared/shared.module';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { TimeoutComponent } from './timeout.component';
import { TimeoutModule } from './timeout.module';


describe('TimeoutComponent', () => {
  let component: TimeoutComponent;
  let fixture: ComponentFixture<TimeoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule, SharedModule, MatDialogModule],
      declarations: [ TimeoutComponent ],
      providers: [
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
