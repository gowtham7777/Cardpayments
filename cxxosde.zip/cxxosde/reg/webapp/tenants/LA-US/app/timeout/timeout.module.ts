import { MatDialogModule } from '@angular/material';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { TimeoutComponent } from './timeout.component';

@NgModule({
  declarations: [
    TimeoutComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    MatDialogModule
  ],
  providers: [], // services go here
  exports: [
    TimeoutComponent
  ]
})
export class TimeoutModule { }
