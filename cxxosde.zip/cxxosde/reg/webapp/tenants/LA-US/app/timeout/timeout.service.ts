import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Title } from '@angular/platform-browser';

import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { TranslateService } from '@ngx-translate/core';

import { environment } from '../../environments/environment';
import { TimeoutComponent } from './timeout.component';
import { AppConfiguration } from '@common/models/app-configuration.model';
import { AppConfig } from '@app/app.config';
import { AnalyticsService } from '@common/services/analytics.service';

@Injectable()
export class TimeoutService {
    dialogRef: MatDialogRef<TimeoutComponent>;
    timeoutPageUrl: string;
    myPageTitle: string;

  constructor(
    private idle: Idle,
    private keepalive: Keepalive,
    private dialog: MatDialog,
    private http: HttpClient,
    private analyticsService: AnalyticsService,
    private config: AppConfig,
    private translate: TranslateService,
    private titleService: Title
  ) {}

  setConfiguration(configurationData: AppConfiguration) {
    this.idle.setIdle(configurationData.idleDuration); // in seconds.
    this.idle.setTimeout(configurationData.idleWarningDuration); // in seconds.
    this.timeoutPageUrl = configurationData.timeoutPageUrl;
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.setKeepaliveEnabled(true);
    this.keepalive.request(environment.keepAliveUrl);

    this.idle.watch();
  }

  onIdleStart() {
    window.scrollTo(0, 0);
    this.dialogRef = this.dialog.open(TimeoutComponent, {
        data: {counter: this.idle.getTimeout()}
      });
    this.myPageTitle = this.titleService.getTitle();
      this.updatePageTitle();
  }

  onIdleWarning(countdown: number) {
    this.dialogRef.componentInstance.data.counter = countdown;
  }

  onIdleEnd() {
    this.dialogRef.close();
    this.titleService.setTitle(this.myPageTitle);
  }

  onIdleTimeout() {
    this.idle.ngOnDestroy(); // includes both idle.stop() and idle.clearInterrupts()
    this.dialog.closeAll();
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.timeout.pageLoad.eventName,
        pageName: this.config.analytics.timeout.pageLoad.pageName,
      },
      eventIds: this.config.analytics.timeout.pageLoad.eventIds
    });
    this.http.get<any>(environment.timeoutUrl)
    .subscribe(
      data => {
        window.location.href = this.timeoutPageUrl;
      },
      error => {}
    );
  }

  onKeepalivePing() {
  }

  updatePageTitle() {
    this.translate.get('timeout.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
