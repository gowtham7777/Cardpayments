import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Route } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { AccountCreationWaitComponent } from './account-creation-wait.component';

describe('AccountCreationWaitComponent', () => {
  let component: AccountCreationWaitComponent;
  let fixture: ComponentFixture<AccountCreationWaitComponent>;
  let rootElem: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AccountCreationWaitComponent,
      ],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ]
    })
    .compileComponents()
    .then(() => {
      fixture = TestBed.createComponent(AccountCreationWaitComponent);
      component = fixture.debugElement.componentInstance;
      rootElem = fixture.debugElement.nativeElement;
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('message changes', () => {
    expect(component.initialLoad).toBeTruthy();
    component['changeToNextMessage']();
    expect(component.initialLoad).toBeFalsy();
  });

  it('message changes after wait time', () => {
    // Attempted to use jasmine.clock() and jasmine.clock().tick() to mock
    // the setTimeout within the beginCounter function. however, this messed
    // up the timing of all other tests and had to be removed.
    spyOn(window, 'setTimeout').and.stub();   
    expect(component.initialLoad).toBeTruthy();
    component['beginCounter']();
    expect(window.setTimeout).toHaveBeenCalled();
  });
});
