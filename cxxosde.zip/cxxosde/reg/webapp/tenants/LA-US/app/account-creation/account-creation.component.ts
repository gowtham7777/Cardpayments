import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy
} from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { MatDialogRef } from '@angular/material';

import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';


import { Account } from '@models/account.model';
import { AccountCreationService } from '@services/account-creation.service';
import { CompareValidator } from '../validators/compare.validator';
import { Question } from '@models/question.model';
import { PasswordContainsUsernameValidator } from '../validators/password.validator';
import { InputValidator } from '../validators/input.validator';
import { ConsumerService } from '@services/consumer.service';
import { KbaQuizService } from '../shared/services/kba-quiz.service';
import { EmailInUseComponent } from '../email-in-use/email-in-use.component';

import { AnalyticsService } from '@common/services/analytics.service';
import { RoutingService } from '@services/routing.service';
import { RouteNames } from '@app/app.route-names';
import { AppConfig } from '@app/app.config';
import { AppConfiguration } from '@common/models/app-configuration.model';
import { AppConfigService } from '@common/services/app-config.service';
import { PtpService } from '../ptp/ptp.service';
import { AccountCreationWaitComponent } from './account-creation-wait.component';
import { IovationDirective } from '@common/directives/iovation/iovation.directive';

@Component({

  selector: 'account-creation',
  templateUrl: './account-creation.component.html'
})
export class AccountCreationComponent implements OnInit, OnDestroy {
  loadingRequest = false;

  // define reusable RegEx Constants based on requirement scenarios
  BETWEEN_LENGTHS = this.config.regex.betweenLengths;
  ONE_LOWERCASE = this.config.regex.oneLowercase;
  ONE_UPPERCASE = this.config.regex.oneUppercase;
  ONE_LOWERCASE_AND_UPPERCASE = this.ONE_UPPERCASE + this.ONE_LOWERCASE; // combined
  ONE_NUMBER = this.config.regex.oneNumber;
  ONE_SPECIAL_CHAR = this.config.regex.oneSpecialChar;
  NOT_NINE_OR_MORE_NUMBERS = this.config.regex.notNineOrMoreNumbers;
  NOT_TWO_REPEAT_CHAR = this.config.regex.notTwoRepeactChar;
  NOT_SPACES = this.config.regex.notSpaces;
  NOT_ANY_OTHER_CHARS = this.config.regex.notAnyOtherChars;

  // Validators.email allows non-external emails (like admin@localhost). This pattern is from TrustedID
  DOTTED_EMAIL = this.config.regex.dottedEmailAddress;
  ALLOWED_EMAIL_CHARACTERS = this.config.regex.allowedEmailCharacters;
  STARTS_WITH_ALPHANUMERIC = this.config.regex.startsWithAlphanumeric;
  MIN_AND_MAX_EMAIL_LENGTH = this.config.regex.minAndMaxEmailLength;
  ONE_ATMARK = this.config.regex.oneAtMark;

  hideRequiredMessage: boolean;
  accountForm: FormGroup;
  waitDialogRef: MatDialogRef<AccountCreationWaitComponent>;
  configurationData$: Subscription;
  termsOfUseUrl: string;
  @ViewChild(IovationDirective, { static: false })
  childIovationDirective: IovationDirective;
  private translateService;
  configurationData: AppConfiguration;
  termsOfUseElement: string;

  constructor(
    translate: TranslateService,
    private fb: FormBuilder,
    private accountCreationService: AccountCreationService,
    private consumerService: ConsumerService,
    private kbaQuizService: KbaQuizService,
    private analyticsService: AnalyticsService,
    private router: Router,
    private dialog: MatDialog,
    private routes: RouteNames,
    private routingService: RoutingService,
    private config: AppConfig,
    private configService: AppConfigService,
    private ptpService: PtpService,
    private titleService: Title
  ) {
    this.createForm();
    this.translateService = translate;
    this.updatePageTitle();
  }

  validatePasswordDoesNotContainUsername() {
    if (
      this.accountForm &&
      this.accountForm.controls &&
      this.accountForm.controls['emailAcct'] &&
      this.accountForm.controls['password'] &&
      this.accountForm.controls['emailAcct'].value &&
      this.accountForm.controls['password'].value
    ) {
      const email = this.accountForm.controls['emailAcct'].value;
      let password = this.accountForm.controls['password'].value;
      const emailArray = email.split('@');
      if (emailArray.length > 0) {
        let username = emailArray[0];

        username = username.toLowerCase();
        password = password.toLowerCase();

        return !password.includes(username) ? 'success' : 'error';
      }
    }
    return null;
  }

  getValidationStyles(controlName: string, pattern: string) {
    if (
      this.accountForm &&
      this.accountForm.controls &&
      this.accountForm.controls[controlName] &&
      this.accountForm.controls[controlName].value
    ) {
      const regex = new RegExp(pattern, 'g');
      const results = regex.exec(this.accountForm.controls[controlName].value);
      return results ? 'success' : 'error';
    }
    return null;
  }

  getUsernameFromEmail() {
    if (
      this.accountForm &&
      this.accountForm.controls['emailAcct'] &&
      this.accountForm.controls['emailAcct'].value
    ) {
      const splitArray = this.accountForm.controls['emailAcct'].value.split(
        '@',
        1
      );
      if (splitArray && splitArray.length > 0) {
        return splitArray[0];
      }
    }
    return null;
  }

  getUserNameExpressionString() {
    const username = this.getUsernameFromEmail();
    // dynamically build regExp with username.  if username is empty this will always fail (which is good).
    return username !== null ? '(?=^((?!' + username + ').)*$)' : '';
  }

  clearConfirmPassword() {
    // when password is changed we have to force clear the confirmPass and revalidate
    this.accountForm.controls['confirmPassword'].reset();
    this.accountForm.controls['confirmPassword'].updateValueAndValidity();
  }

  clearPassword() {
    this.accountForm.controls['password'].reset();
    this.accountForm.controls['password'].updateValueAndValidity();
  }

  clearConfirmEmail() {
    // when confirm email is changed we have to force clear the confirmEmailAcct and revalidate
    this.accountForm.controls['confirmEmailAcct'].reset();
    this.accountForm.controls['confirmEmailAcct'].updateValueAndValidity();
  }

  clearAll() {
    this.clearConfirmEmail();
    this.clearPassword();
    this.clearConfirmPassword();
  }

  ngOnInit() {
    this.hideRequiredMessage = true;
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.createAccount.pageLoad.eventName,
        pageName: this.config.analytics.createAccount.pageLoad.pageName
      },
      eventIds: this.config.analytics.createAccount.pageLoad.eventIds
    });
    this.configurationData$ = this.configService
      .getConfigurationData$()
      .subscribe(config => {
        this.termsOfUseUrl = config.termsUrl;
      });
  }

  ngOnDestroy(): void {
    if (this.configurationData$) {
      this.configurationData$.unsubscribe();
    }
  }

  getEmailValueCallback = () => {
    // we need a callback method to always pick up updated values
    return this.accountForm && this.accountForm.get('emailAcct')
      ? this.accountForm.get('emailAcct').value
      : null;
  };

  submitForm = () => {
    this.loadingRequest = true;
    this.openWaitDialog();
    const accountForm: Account = {
      username: this.accountForm.controls.emailAcct.value,
      password: this.accountForm.controls.password.value,
      blackBox: this.childIovationDirective.combineBlackboxes()
    };

    this.accountCreationService.createAccount(accountForm).subscribe(
      data => {
        this.closeWaitDialog();
        if (data) {
          if (data.statusCode === this.config.emergencyBrakeOn) {
            this.routingService.enableNavigationTo(
              this.routes.emergencyBrakeMailOptions
            );
            this.router.navigate([this.routes.emergencyBrakeMailOptions]);
          } else if (data.statusCode === this.config.getPinToText) {
            this.consumerService.otpEmail = null;
            this.routingService.enableNavigationTo(this.routes.otpOptIn);
            this.router.navigate([this.routes.otpOptIn]);
          } else if (
            data.statusCode === this.config.kbaQuizSuccess &&
            data.quizIdentifier &&
            data.questions
          ) {
            this.kbaQuizService.saveQuiz(
              data.quizIdentifier,
              data.questions as Question[]
            );
            this.routingService.enableNavigationTo(this.routes.kbaQuiz);
            this.router.navigate([this.routes.kbaQuiz]);
          } else if (data.statusCode === this.config.duplicateEnrollment) {
            this.openEmailInUseDialog();
          } else if (data.statusCode === this.config.otpEligibilityNoHit) {
            this.router.navigate([this.routes.callCenterNoHit]);
          } else if (
            data.statusCode ===
            this.config.consumerSavePartialSuccessSystemError
          ) {
            this.router.navigate([this.routes.callCenter]);
          } else if (data.statusCode === this.config.getPinToEmail) {
            this.consumerService.otpEmail = this.accountForm.controls.emailAcct.value;
            this.routingService.enableNavigationTo(this.routes.otpOptIn);
            this.router.navigate([this.routes.otpOptIn]);
          } else {
            const defaultRoute = () => {
              this.router.navigate([this.routes.systemError]);
            };
            (this.ptpService.routesMap[data.statusCode] || defaultRoute)();
          }
        } else {
          this.router.navigate([this.routes.systemError]);
        }
      },
      errors => {
        this.closeWaitDialog();
        this.router.navigate([this.routes.systemError]);
      },
      // Reset the loading status of the request
      () => {
        this.loadingRequest = false;
      }
    );
  };

  getEmailPattern = () => {
    return (
      this.DOTTED_EMAIL +
      this.ALLOWED_EMAIL_CHARACTERS +
      this.STARTS_WITH_ALPHANUMERIC +
      this.MIN_AND_MAX_EMAIL_LENGTH +
      this.NOT_NINE_OR_MORE_NUMBERS +
      this.ONE_ATMARK
    );
  };

  getPwdPattern = () => {
    // concat all expected regexp patterns together;
    return (
      this.BETWEEN_LENGTHS +
      this.ONE_LOWERCASE_AND_UPPERCASE +
      this.ONE_NUMBER +
      this.ONE_SPECIAL_CHAR +
      this.NOT_TWO_REPEAT_CHAR +
      this.getUserNameExpressionString() +
      this.NOT_NINE_OR_MORE_NUMBERS +
      this.NOT_SPACES +
      this.NOT_ANY_OTHER_CHARS
    );
  };

  createForm = () => {
    this.accountForm = this.fb.group({
      emailAcct: [
        '',
        [Validators.required, InputValidator(this.getEmailPattern)]
      ],
      confirmEmailAcct: [
        '',
        [Validators.required, CompareValidator(this.getEmailValueCallback)]
      ],
      password: [
        '',
        Validators.compose([
          Validators.required,
          PasswordContainsUsernameValidator(this.getEmailValueCallback),
          InputValidator(this.getPwdPattern)
        ])
      ],
      confirmPassword: [
        '',
        [Validators.required, CompareValidator(this.getPasswordValueCallback)]
      ],
      termsOfUse: ['', [Validators.requiredTrue]]
    });
  };

  isControlValid = (controlName: string) => {
    // first check if control has been touched
    if (!this.accountForm.get(controlName).dirty) {
      // supress error until control recieved input
      return true;
    } else {
      // test using FormControl validators
      return this.accountForm.get(controlName).status !== 'INVALID'
        ? true
        : false;
    }
  };

  isEmailAddrEmpty = (controlName: string) => {
    // first check if control has been touched
    if (
      this.accountForm !== undefined &&
      this.accountForm.controls !== undefined &&
      this.accountForm.controls.emailAcct !== undefined
    ) {
      return this.accountForm.controls.emailAcct.value === null ||
        this.accountForm.controls.emailAcct.value === ''
        ? true
        : false;
    } else {
      return true;
    }
  };

  isFormValid = () => {
    return (
      this.accountForm.status !== 'VALID' ||
      this.accountForm.controls.termsOfUse.value !== true
    );
  };

  returnValidatorErrors = (controlName: string) => {
    // first check if control has been touched
    if (!this.accountForm.get(controlName).dirty) {
      // supress error until control recieved input
      return false;
    } else if (this.accountForm.get(controlName).errors) {
      // be careful we don't throw a null error to the view
      return this.accountForm.get(controlName).errors;
    }
  };

  getPasswordValueCallback = () => {
    return this.accountForm && this.accountForm.get('password')
      ? this.accountForm.get('password').value
      : null;
  };

  updatePageTitle() {
    this.translateService
      .get('account-creation.browserTitle.pageLoadTitle')
      .subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
  }

  openEmailInUseDialog = () => {
    window.scrollTo(0, 0);
    const dialogRef = this.dialog.open(EmailInUseComponent, {
      data: { email: this.accountForm.controls.emailAcct.value }
    });

    this.translateService
      .get('account-creation.browserTitle.emailInuseLoadTitle')
      .subscribe((result: string) => {
        this.titleService.setTitle(result);
      });

    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.createAccount.emailInUse.eventName
      },
      eventIds: this.config.analytics.createAccount.emailInUse.eventIds
    });

    dialogRef.afterClosed().subscribe(result => {
      this.translateService
        .get('account-creation.browserTitle.pageLoadTitle')
        .subscribe((result1: string) => {
          this.titleService.setTitle(result1);
        });
      if (result === 'login') {
        if (this.accountCreationService.getMCLoginUrl()) {
          window.location.href = this.configService.updateUrlForMobileParam(
            this.accountCreationService.getMCLoginUrl()
          );
        } else {
          this.router.navigate([this.routes.systemError]);
        }
      } else if (result === 'tryAgain') {
        window.scrollTo(0, 0);
        this.accountForm.controls.emailAcct.reset();
        this.accountForm.controls.confirmEmailAcct.reset();
        this.accountForm.controls.password.reset();
        this.accountForm.controls.confirmPassword.reset();
        this.translateService
          .get('account-creation.browserTitle.pageLoadTitle')
          .subscribe((result1: string) => {
            this.titleService.setTitle(result1);
          });
      }
    });
  };

  openWaitDialog = () => {
    window.scrollTo(0, 0);
    this.waitDialogRef = this.dialog.open(AccountCreationWaitComponent, {
      disableClose: true
    });
    this.waitDialogRef
      .afterOpen()
      .subscribe(() => this.waitDialogRef.componentInstance.beginCounter());
  };

  closeWaitDialog = () => {
    this.waitDialogRef.close(AccountCreationWaitComponent);
  };
}
