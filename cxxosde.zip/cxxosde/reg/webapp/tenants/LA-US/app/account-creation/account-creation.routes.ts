import { Route } from '@angular/router';
import { AccountCreationComponent } from './account-creation.component';
import { AccountCreationGuard } from '@app/guards/account-creation.guard';

export const AccountCreationRoutes: Route[] = [
  {
    path: 'account-creation',
    component: AccountCreationComponent,
    canActivate: [AccountCreationGuard]
  }
];
