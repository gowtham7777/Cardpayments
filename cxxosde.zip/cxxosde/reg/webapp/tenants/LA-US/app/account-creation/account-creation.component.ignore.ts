// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

// Angular
import { AppConfig } from '@app/app.config';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RouteNames } from '@app/app.route-names';
import { Route, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

// Third Party
import { Observable, Subscriber } from 'rxjs';


// Modules
import { AccountCreationModule } from './account-creation.module';
import { KbaQuizModule } from '@app/kba-quiz/kba-quiz.module';
import { OtpIdentifyVerifyGetPinModule } from '@app/otp-identity-verify-get-pin/otp-identity-verify-get-pin.module';

// Services
import { AccountCreationService } from '@services/account-creation.service';
import { KbaQuizService } from '@app/shared/services/kba-quiz.service';
import { MockKbaQuizService, MockPtpService } from '@app/app.mock-services';
import { PasswordContainsUsernameValidator } from '@app/validators/password.validator';
import { InputValidator } from '../validators/input.validator';
import { PtpService } from '@app/ptp/ptp.service';
import { RoutingService } from '@services/routing.service';

// Components
import { AccountCreationComponent } from './account-creation.component';
import { EmailInUseComponent } from '@app/email-in-use/email-in-use.component';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';

// Not testing routes within the component.
// Just providing a mock routes/router to compile the component
const limitedRoutes: Route[] = BaseRoutesWith([]);
let emailValidator;
let passwordPattern;
let passwordValidator;
let config: AppConfig;
let service: AccountCreationService;
let routes: RouteNames;
let router: Router;
let routingService: RoutingService;
const userNameInPasswordTest = 'aB1test1@yahoo.com';

describe('AccountCreationComponent', () => {
  let component: AccountCreationComponent;
  let fixture: ComponentFixture<AccountCreationComponent>;
  let rootElem: any;
  let dialog: MatDialog;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        TestBedModule,
        AccountCreationModule,
        KbaQuizModule,
        OtpIdentifyVerifyGetPinModule,
        RouterTestingModule.withRoutes(limitedRoutes)
      ],
      providers: [
        {provide: KbaQuizService, useClass: MockKbaQuizService},
        {provide: PtpService, useClass: MockPtpService},
        MatDialog,
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents()
    .then(() => {
      fixture = TestBed.createComponent(AccountCreationComponent);
      component = fixture.debugElement.componentInstance;
      rootElem = fixture.debugElement.nativeElement;
      emailValidator = InputValidator(component.getEmailPattern);
      component.accountForm.controls['emailAcct'].patchValue(userNameInPasswordTest);
      passwordPattern = component.getPwdPattern();
      passwordValidator = InputValidator(() => passwordPattern);
      config = TestBed.get(AppConfig);
      service = TestBed.get(AccountCreationService);
      router = TestBed.get(Router);
      routingService = TestBed.get(RoutingService);
      routes = TestBed.get(RouteNames);
      dialog = TestBed.get(MatDialog);
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should init', () => {
    component.ngOnInit();
    expect(component.hideRequiredMessage).toBeTruthy();
    expect(component.configurationData$).toBeDefined();
  });


  it('should destroy', () => {
    component.ngOnDestroy();
    expect(component.configurationData$).toBeUndefined();
  });

  // ========================================================
  // Validating emails
  // ========================================================

  // Valid Emails
  it('valid email ghtest1@yahoo.com', () => {
    expect(emailValidator(new FormControl('ghtest1@yahoo.com'))).toBeNull();
  });

  it('valid email email.with.dot@example.com', () => {
    expect(emailValidator(new FormControl('email.with.dot@example.com'))).toBeNull();
  });

  it('valid email email-with-dash@example.com', () => {
    expect(emailValidator(new FormControl('email-with-dash@example.com'))).toBeNull();
  });

  // Invalid Emails
  const invalidEmails = [
    'invalidEmail',
    'invalid@',
    'invalid@email',
    'invalid@email.',
    'invalid123invalid123invalid123invalid123invalid123invalid123invalid123invalid123invalid123invalid123@email.com',
    'ghtest1%@yahoo.com',
    'ghtest123456789@yahoo.com',
    '_ghtest1@yahoo.com',
    'gh test1@yahoo.com',
    'gh@test1@yahoo.com',
  ];

  const invalidEmail = (email) => {
    expect(emailValidator(new FormControl(email))).toEqual({
      'invalidPatternValidation': {
        'value': email,
        'regpatternValue': component.getEmailPattern()
      }
    }, `invalid email ${email}`);
  };

  it('should reject invalid emails', () => {
    invalidEmails.forEach((email) => {
      console.log('email ' + email);
      invalidEmail(email);
    });
  });

  // ========================================================
  // Validating passwords
  // ========================================================

  // Valid Passwords
  it('valid password aB1!CDEF', () => {
    expect(passwordValidator(new FormControl('aB1!CDEF'))).toBeNull();
  });

  it('valid password Letmein!1', () => {
    expect(passwordValidator(new FormControl('Letmein!1'))).toBeNull();
  });
  it('password does not contain username is valid', () => {
    const form = new FormGroup({
      emailAcct: new FormControl('username@email.com'),
      password: new FormControl('unique1234')
    });
    const passwordContainsUsernameValidator = PasswordContainsUsernameValidator(() => form.get('emailAcct').value);
    expect(passwordContainsUsernameValidator(form.get('password'))).toBeNull();
  });

  // Invalid Passwords
  it('password contains username is invalid', () => {
    const form = new FormGroup({
      emailAcct: new FormControl('username@email.com'),
      password: new FormControl('uSeRnamE1234')
    });
    const passwordContainsUsernameValidator = PasswordContainsUsernameValidator(() => form.get('emailAcct').value);
    expect(passwordContainsUsernameValidator(form.get('password'))).toEqual({
      'invalidPatternValidation': {
        value: 'uSeRnamE1234',
        reason: 'password cannot contain username'
      }});
  });

  // ========================================================
  // Validating password criteria styles
  // ========================================================

  const invalidPasswords = [
    { password: ' ', failure: 'blank password is invalid' },
    { password: 'aB1!', failure: 'invalid password aB1! - too short' },
    { password: 'aB1!&$*#(%dlf#9d31503', failure: 'invalid password aB1!&$*#(%dlf#9d31503 - too long' },
    { password: 'AB1!CDEF', failure: 'invalid password AB1!CDEF - no lower case' },
    { password: 'ab1!cdef', failure: 'invalid password ab1!cdef - no upper case' },
    { password: 'aBc!defg', failure: 'invalid password aBc!defg - no numbers' },
    { password: 'aB12cdef', failure: 'invalid password aB12cdef - no special characters' },
    { password: 'aB1!CCCD', failure: 'invalid password aB1!CCCD - too many repeating characters' },
    { password: 'aB1234567890!CDEF', failure: 'invalid password aB1234567890!CDEF - 9 repeating numbers' },
    { password: 'aB1!CDEF ', failure: 'invalid password aB1!CDEF  - no spaces allowed' },
    { password: userNameInPasswordTest, failure: `invalid password ${userNameInPasswordTest} - no username in password` }
  ];

  const invalidPassword = (pw) => {
    expect(passwordValidator(new FormControl(pw.password))).toEqual({
      'invalidPatternValidation': {
          value: pw.password,
          regpatternValue: passwordPattern
        }
      }, pw.failure);
  };

  it('should reject invalid passwords', () => {
    invalidPasswords.forEach((pw) => {
      invalidPassword(pw);
    });
  });

  // Validation Styles
  it('should update password validation styles', () => {
    const password = component.accountForm.controls['password'];
    password.patchValue('TestPassword');
    expect(component.getValidationStyles('password', component.BETWEEN_LENGTHS)).toEqual('success', 'should show success styles');
    password.patchValue('123');
    expect(component.getValidationStyles('password', component.BETWEEN_LENGTHS)).toEqual('error', 'error styles');
    password.patchValue(null);
    expect(component.getValidationStyles('password', component.BETWEEN_LENGTHS)).toBeNull('null styles');
    component.clearConfirmPassword();
    expect(password.value).toBeNull();
  });

  it('password does not contain email', () => {
    component.createForm();
    const email = 'theemail@email.com';
    const password = 'thepassword';
    component.accountForm.controls['emailAcct'].patchValue(email);
    component.accountForm.controls['password'].patchValue(password);
    expect(component.getValidationStyles('password', component.getUserNameExpressionString())).toEqual('success');
    expect(component.validatePasswordDoesNotContainUsername()).toEqual('success');
  });

  it('password contains email', () => {
    component.createForm();
    const email = 'email@email.com';
    const password = 'passwordemail';
    component.accountForm.controls['emailAcct'].patchValue(email);
    component.accountForm.controls['password'].patchValue(password);
    expect(component.getValidationStyles('password', component.getUserNameExpressionString())).toEqual('error');
    expect(component.validatePasswordDoesNotContainUsername()).toEqual('error');
  });

  // ========================================================
  // Input field checks / manipulation
  // ========================================================

  it('clear confirm password', () => {
    component.createForm();
    component.clearConfirmPassword();
    expect(component.accountForm.controls['confirmPassword'].value).toBeNull();
  });

  it('clear confirm email', () => {
    component.createForm();
    const testEmail = 'test@test.com';
    component.accountForm.controls['confirmEmailAcct'].patchValue(testEmail);
    component.clearConfirmEmail();
    expect(component.accountForm.controls['confirmEmailAcct'].value).toBeNull();
  });

  it('should get email value', () => {
    const testEmail = 'test@test.com';
    component.accountForm.controls['emailAcct'].patchValue(testEmail);
    expect(component.getEmailValueCallback()).toEqual(testEmail);
  });

  it('get null email value', () => {
    component.accountForm.controls['emailAcct'].patchValue(null);
    expect(component.getEmailValueCallback()).toBeNull();
  });

  it('should clear email and password values', () => {
    const mockVal = 'test';
    component.accountForm.controls['emailAcct'].patchValue(null);
    component.accountForm.controls['confirmEmailAcct'].patchValue(mockVal);
    component.accountForm.controls['password'].patchValue(mockVal);
    component.accountForm.controls['confirmPassword'].patchValue(mockVal);

    expect(component.getEmailValueCallback()).toBeNull();
    expect(component.isEmailAddrEmpty('emailAcct')).toBeTruthy();

    component.clearAll();
    expect(component.accountForm.controls['confirmEmailAcct'].value).toBeFalsy();
    expect(component.accountForm.controls['password'].value).toBeFalsy();
    expect(component.accountForm.controls['confirmPassword'].value).toBeFalsy();
  });

  // ========================================================
  // Form submission
  // ========================================================

  const validateSubmitForm = (statusCode: string, destinationPage: string, spy, isClosedRoute: boolean) => {
    // Set up the observable so our 'subscribe' in the account-creation.component can get a response
    const createAccountResponse = new Observable<any>((subscriber: Subscriber<any>) => subscriber.next({statusCode}));
    spy.and.returnValue(createAccountResponse);
    component.submitForm();
    if (!!isClosedRoute && validateClosedRoute(destinationPage)) {
      // Validate we attempt to route to our expected destination
      expect(router.navigate).toHaveBeenCalledWith(destinationPage);
      expect(component.openWaitDialog).toHaveBeenCalled();
      expect(component.closeWaitDialog).toHaveBeenCalled();
    }
  };

  const validateClosedRoute = (destinationPage) => {
    // expect(router.navigate).toHaveBeenCalledWith(destinationPage);
  };

  it('should submit form', () => {
    // Stub the dialog calls as we just need to validate they are called.
    spyOn(component, 'openWaitDialog').and.stub();
    spyOn(component, 'closeWaitDialog').and.stub();
    // Set up a spy to later define an observable with the status code
    const spy = spyOn(service, 'createAccount').and.returnValue('');
    spyOn(router, 'navigate').and.stub();
    spyOn(routingService, 'enableNavigationTo').and.stub();
    validateSubmitForm(config.emergencyBrakeOn, routes.emergencyBrakeMailOptions, spy, true);
    validateSubmitForm(config.getPinToText, routes.otpOptIn, spy, true);
    validateSubmitForm(config.otpEligibilityNoHit, routes.callCenterNoHit, spy, false);
    validateSubmitForm(config.consumerSavePartialSuccessSystemError, routes.callCenter, spy, false);
    validateSubmitForm(config.getPinToEmail, routes.otpOptIn, spy, true);
    validateSubmitForm('testDefault', routes.systemError, spy, false);
  });

  it('submit form kba quiz success', (inject([KbaQuizService], (kbaQuiz: KbaQuizService) => {
    const statusCode = config.kbaQuizSuccess;
    const destinationPage = routes.kbaQuiz;
    const data = {
      statusCode,
      quizIdentifier: 'test',
      questions: 'test'
    };
    const createAccountResponse = new Observable<any>((subscriber: Subscriber<any>) => subscriber.next(data));
    spyOn(component, 'openWaitDialog').and.stub();
    spyOn(component, 'closeWaitDialog').and.stub();
    spyOn(kbaQuiz, 'saveQuiz').and.stub();
    spyOn(service, 'createAccount').and.returnValue(createAccountResponse);
    spyOn(router, 'navigate').and.stub();
    spyOn(routingService, 'enableNavigationTo').and.stub();
    component.submitForm();
    expect(routingService.enableNavigationTo).toHaveBeenCalledWith(destinationPage);
    expect(router.navigate).toHaveBeenCalledWith([destinationPage]);
  })));

  it('submit form tid duplicate enrollment', () => {
    const statusCode = config.duplicateEnrollment;
    const response = new Observable<any>((subscriber: Subscriber<any>) => subscriber.next({statusCode}));
    spyOn(component, 'openEmailInUseDialog').and.stub();
    spyOn(service, 'createAccount').and.returnValue(response);
    component.submitForm();
    expect(component.openEmailInUseDialog).toHaveBeenCalled();
  });

  it('submit form null data', () => {
    const response = new Observable<any>((subscriber: Subscriber<any>) => subscriber.next(null));
    spyOn(router, 'navigate').and.stub();
    spyOn(service, 'createAccount').and.returnValue(response);
    component.submitForm();
    expect(router.navigate).toHaveBeenCalledWith([routes.systemError]);
  });

  it('submit form error', () => {
    const response = new Observable<any>((subscriber: Subscriber<any>) => subscriber.error());
    spyOn(router, 'navigate').and.stub();
    spyOn(service, 'createAccount').and.returnValue(response);
    component.submitForm();
    expect(router.navigate).toHaveBeenCalledWith([routes.systemError]);
  });

  it('is control valid', () => {
    expect(component.isControlValid('emailAcct')).toBeTruthy();
    expect(component.isControlValid('password')).toBeTruthy();
  });

  it('is form valid', () => {
    expect(component.isFormValid()).toBeTruthy();
  });

  it('returnValidatorErrors', () => {
    component.accountForm.controls['password'].markAsDirty();
    expect(component.returnValidatorErrors('password')).not.toBeFalsy();
    expect(component.returnValidatorErrors('emailAcct')).toBeFalsy();
  });

  // ========================================================
  // Email in Use Dialog
  // ========================================================

  const mockEmailInUseDialogWithAction = (action: string) => {
    const actionAttempt = new Observable<string>( (subscriber: Subscriber<string>) => subscriber.next(action));
    const mockDialogRef = dialog.open(EmailInUseComponent, {data: {email: 'test@test.com'}});
    spyOn(component['dialog'], 'open').and.returnValue(mockDialogRef);
    spyOn(mockDialogRef, 'afterClosed').and.returnValue(actionAttempt);
  };

  it('should open the email in use dialog', () => {
    const mockDialogRef = dialog.open(EmailInUseComponent, {data: {email: 'test@test.com'}});
    spyOn(component['dialog'], 'open').and.returnValue(mockDialogRef);

    component.openEmailInUseDialog();
    expect(component['dialog'].open).toHaveBeenCalled();
  });

  // We aren't testing the success case for "login" because it does a redirect by modifying window.location.href

  it('should handle the error case for "login" on the email-in-use dialog', () => {
    mockEmailInUseDialogWithAction('login');
    spyOn(component['accountCreationService'], 'getMCLoginUrl').and.returnValue(null);
    spyOn(component['router'], 'navigate').and.stub();

    // Unsuccessful MC login
    component.openEmailInUseDialog();
    expect(component['router'].navigate).toHaveBeenCalledWith([routes.systemError]);
  });

  it('should handle the user choosing "tryAgain" on the email-in-use dialog', () => {
    mockEmailInUseDialogWithAction('tryAgain');

    // Reset the fields if try again was pressed
    component.openEmailInUseDialog();
    expect(component.accountForm.controls['emailAcct'       ].value).toBeFalsy();
    expect(component.accountForm.controls['confirmEmailAcct'].value).toBeFalsy();
    expect(component.accountForm.controls['password'        ].value).toBeFalsy();
    expect(component.accountForm.controls['confirmPassword' ].value).toBeFalsy();
  });
});
