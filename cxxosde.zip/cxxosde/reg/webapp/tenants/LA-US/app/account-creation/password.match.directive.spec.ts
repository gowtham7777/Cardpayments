import { EqualValidator } from './password.match.directive';
import { FormControl } from '@angular/forms';

let compareString = 'test';
describe('EqualValidator', () => {
  it('should create an instance', () => {
    const directive = new EqualValidator(compareString);
    expect(directive).toBeTruthy();
  });
  it('valid password aB1!CDEF', () => {
    const directive = new EqualValidator('aB1!CDEF');
    expect(directive.validate(new FormControl('aB1!CDEF'))).toBeNull();
  });
});
