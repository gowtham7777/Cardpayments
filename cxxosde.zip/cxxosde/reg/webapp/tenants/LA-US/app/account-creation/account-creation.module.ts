import { EmailInUseComponent } from '@app/email-in-use/email-in-use.component';
import { EmailInUseModule } from '@app/email-in-use/email-in-use.module';
import { AccountCreationService } from '../shared/services/account-creation.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';
import { AccountCreationComponent } from './account-creation.component';
import { EqualValidator } from './password.match.directive';
import { IovationDirective } from '@common/directives/iovation/iovation.directive';
import { MatInputModule } from '@angular/material/input';
import { AccountCreationWaitComponent } from './account-creation-wait.component';

@NgModule({
  declarations: [
    AccountCreationComponent,
    AccountCreationWaitComponent,
    EqualValidator,
    IovationDirective,
  ],
  entryComponents: [EmailInUseComponent, AccountCreationWaitComponent],
  imports: [
    CommonModule,
    MatInputModule,
    SharedModule,
    EmailInUseModule
  ],
  providers: [AccountCreationService], // services go here
  exports: [
    AccountCreationComponent
  ]
})
export class AccountCreationModule { }
