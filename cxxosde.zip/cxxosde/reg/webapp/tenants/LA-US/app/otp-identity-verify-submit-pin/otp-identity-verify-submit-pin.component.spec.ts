// Angular
import {
  async,
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import {  MatInputModule, MatDialogModule } from '@angular/material';
import { Observable, Subscriber } from 'rxjs';
import { Routes, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';


// Modules
import { SharedModule } from '@app/shared/shared.module';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

// Services
import { KbaQuizService } from '@services/kba-quiz.service';
import { OtpGetPinService } from '@services/otp-get-pin.service';
import { OtpSubmitPinService } from '@services/otp-submit-pin.service';
import { PtpService } from '@app/ptp/ptp.service';
import { RoutingService } from '@services/routing.service';
import {
  MockOtpGetPinService,
  MockOtpSubmitPinService,
  MockKbaQuizService,
  MockPtpService
} from '@app/app.mock-services';

// Components
import { OtpIdentityVerifySubmitPinComponent } from './otp-identity-verify-submit-pin.component';

// Misc
import { RouteNames } from '@app/app.route-names';
const limitedRoutes: Routes = BaseRoutesWith([]);
const MOCK_ERROR = 'error';

describe('OtpIdentityVerifySubmitPinComponent', () => {
  let component: OtpIdentityVerifySubmitPinComponent;
  let fixture: ComponentFixture<OtpIdentityVerifySubmitPinComponent>;
  let mockOtpGetPinService: OtpGetPinService;
  let mockOtpSubmitPinService: OtpSubmitPinService;
  let mockKbaQuizService: KbaQuizService;
  let mockRoutingService: RoutingService;
  let mockRoutes: RouteNames;
  let mockRouter: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OtpIdentityVerifySubmitPinComponent],
      providers: [
        { provide: OtpGetPinService, useClass: MockOtpGetPinService },
        { provide: OtpSubmitPinService, useClass: MockOtpSubmitPinService },
        { provide: KbaQuizService, useClass: MockKbaQuizService },
        { provide: PtpService, useClass: MockPtpService }
      ],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(limitedRoutes),
        SharedModule,
        MatDialogModule,
        MatInputModule
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    mockOtpGetPinService = TestBed.get(OtpGetPinService);
    mockOtpSubmitPinService = TestBed.get(OtpSubmitPinService);
    mockKbaQuizService = TestBed.get(KbaQuizService);
    mockRoutingService = TestBed.get(RoutingService);
    mockRoutes = TestBed.get(RouteNames);
    mockRouter = TestBed.get(Router);
    fixture = TestBed.createComponent(OtpIdentityVerifySubmitPinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  function mockPinResponse(responseMap) {
    return responseMap === MOCK_ERROR
      ? new Observable<Error>((subscriber: Subscriber<Error>) =>
          subscriber.error()
        )
      : new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next(responseMap)
        );
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // ==========================================================================
  // Handle Pin Tests
  // ==========================================================================

  // AnalyticsService is being mocked and was provided in the TestBedModule
  it('should attempt to append analytics event when fetching pin', () => {
    spyOn(component['analyticsService'], 'appendEvent').and.stub();
    component.fetchNewPin();
    expect(component['analyticsService'].appendEvent).toHaveBeenCalled();
  });

  it('should attempt to handle the pin request', () => {
    spyOn(component as any, 'handlePinRequest').and.stub();
    component.fetchNewPin();
    expect(component['handlePinRequest']).toHaveBeenCalled();
  });

  // We're spying on the enrollOTP call and throwing an error
  it('should attempt to handle bad responses from pin requests', () => {
    spyOn(component['routingService'], 'handleErrorResponse').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse(MOCK_ERROR)
    );

    component.fetchNewPin();
    expect(component['routingService'].handleErrorResponse).toHaveBeenCalled();
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendAllowedInit
  it('should display "new pin" request and no "new code" banner on the first time they see OTP', () => {
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpEnrollResendAllowedInit
      })
    );

    component.fetchNewPin();
    expect(component.displayNewPinRequest).toBeTruthy();
    expect(component.showNewCodeBanner).toBeFalsy();
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendAllowed
  it('should display "new pin" request and a "new code" banner on subsequent times seeing OTP', () => {
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpEnrollResendAllowed
      })
    );

    component.fetchNewPin();
    expect(component.displayNewPinRequest).toBeTruthy();
    expect(component.showNewCodeBanner).toBeTruthy();
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendMax
  it('should not display "new pin" request and a "new code" banner after max resends', () => {
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({ statusCode: component['config'].otpEnrollResendMax })
    );

    component.fetchNewPin();
    expect(component.displayNewPinRequest).toBeFalsy();
    expect(component.showNewCodeBanner).toBeTruthy();
  });

  // We're spying on the enrollOTP call and sending kbaGetQuizSuccessOtpPinInitiationFail
  it('should reload kba quiz if kba quiz was good, but OTP initiation failed', () => {
    spyOn(component, 'routeToKbaPage').and.stub();
    spyOn(mockKbaQuizService, 'saveQuiz').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].kbaGetQuizSuccessOtpPinInitiationFail
      })
    );

    component.fetchNewPin();
    expect(mockKbaQuizService.saveQuiz).toHaveBeenCalled();
    expect(component.routeToKbaPage).toHaveBeenCalled();
  });

  // We're spying on the enrollOTP call and sending undefined
  it('should go to call center if no data from OTP request', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse(undefined)
    );

    component.fetchNewPin();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

  // ==========================================================================
  // Validate Pin Tests
  // ==========================================================================

  it('should handle pin validation after submitting form', () => {
    spyOn(component as any, 'handlePinValidation').and.stub();
    component.submitForm();
    expect(component['handlePinValidation']).toHaveBeenCalled();
  });

  it('should handle errors after submitting form', () => {
    spyOn(component['routingService'], 'handleErrorResponse').and.stub();
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse(MOCK_ERROR)
    );

    component.submitForm();
    expect(component['routingService'].handleErrorResponse).toHaveBeenCalled();
  });

  // // TODO: Change handlePinValidation method to indirectly change window.location.href
  // // Otherwise, this scenario cannot be tested
  // it('should redirect to the url coming from the OtpSubmitPinResponse after pin success', () => {});

  it('should send analytics, tell pin service about failure, and reload kba quiz after max pin retries', () => {
    spyOn(component, 'incorrectPinAnalytics').and.stub();
    spyOn(component, 'routeToKbaPage').and.stub();
    spyOn(mockKbaQuizService, 'saveQuiz').and.stub();
    spyOn(mockOtpSubmitPinService, 'setOtpFailed').and.stub();
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].kbaGetQuizSuccessOtpPinRetryMax
      })
    );

    component.submitForm();
    expect(component.incorrectPinAnalytics).toHaveBeenCalled();
    expect(component.routeToKbaPage).toHaveBeenCalled();
    expect(mockKbaQuizService.saveQuiz).toHaveBeenCalled();
    expect(mockOtpSubmitPinService.setOtpFailed).toHaveBeenCalledWith(true);
  });

  it('should send analytics and reload kba quiz after failing pin validation', () => {
    spyOn(component, 'incorrectPinAnalytics').and.stub();
    spyOn(component, 'routeToKbaPage').and.stub();
    spyOn(mockKbaQuizService, 'saveQuiz').and.stub();
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse({
        statusCode:
          component['config'].kbaGetQuizSuccessOtpPinValidationFailUnknown
      })
    );

    component.submitForm();
    expect(component.incorrectPinAnalytics).toHaveBeenCalled();
    expect(component.routeToKbaPage).toHaveBeenCalled();
    expect(mockKbaQuizService.saveQuiz).toHaveBeenCalled();
  });

  it('should not display "new pin" request and no "new code" banner upon retry', () => {
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpValidateResubmitWithResendMax
      })
    );

    component.submitForm();
    expect(component.displayNewPinRequest).toBeFalsy();
    expect(component.showNewCodeBanner).toBeFalsy();
  });

  it('should let user try to submit pin again if they have more retries', () => {
    const mockRemainingAttempts = 3;
    spyOn(component.optVerifySubmitPinForm.controls['pin'], 'reset');
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpValidateResubmitWithResendMax,
        remainingAttempts: mockRemainingAttempts
      })
    );

    component.submitForm();
    expect(component.remainingAttempts).toBe(mockRemainingAttempts);
    expect(
      component.optVerifySubmitPinForm.controls['pin'].reset
    ).toHaveBeenCalled();
  });

  it('should go to call center if no data after submitting pin', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpSubmitPinService, 'validatePin').and.returnValue(
      mockPinResponse(undefined)
    );

    component.submitForm();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

  // ==========================================================================
  // Helper Method Tests
  // ==========================================================================

  it('should be able to fetch the kba quiz', () => {
    spyOn(mockKbaQuizService, 'fetchQuiz').and.stub();
    component.showQuiz();
    expect(mockKbaQuizService.fetchQuiz).toHaveBeenCalled();
  });

  it('should be able to route to kba page', () => {
    spyOn(mockRoutingService, 'enableNavigationTo').and.stub();
    spyOn(mockRouter, 'navigate').and.stub();
    component.routeToKbaPage();

    // expect(mockRoutingService.enableNavigationTo).toHaveBeenCalledWith(mockRoutes.kbaQuiz);
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.kbaQuiz]);
  });

  // Findings
  //  - The function isValidNumber is not used.
  //  - handlePinValidation method should indirectly change window.location.href to be testable
});
