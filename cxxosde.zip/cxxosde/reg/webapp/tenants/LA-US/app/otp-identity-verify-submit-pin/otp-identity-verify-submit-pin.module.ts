import { OtpSubmitPinService } from '../shared/services/otp-submit-pin.service';
import { OtpIdentityVerifySubmitPinComponent } from './otp-identity-verify-submit-pin.component';
import { OtpGetPinService } from '../shared/services/otp-get-pin.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { MatInputModule } from '@angular/material/input';

@NgModule({
  declarations: [
    OtpIdentityVerifySubmitPinComponent
  ],
  imports: [
    CommonModule,
    MatInputModule,
    SharedModule
  ],
  providers: [OtpGetPinService, OtpSubmitPinService], // services go here
  exports: [
    OtpIdentityVerifySubmitPinComponent
  ]
})
export class OtpIdentityVerifySubmitPinModule { }
