import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';


import { KbaQuizService } from '../shared/services/kba-quiz.service';
import { ConsumerService } from '../shared/services/consumer.service';
import { Question } from '../shared/models/question.model';
import { OtpGetPinService } from '../shared/services/otp-get-pin.service';
import { OtpSubmitPinService } from '../shared/services/otp-submit-pin.service';
import { AppConfig } from '../app.config';
import { AnalyticsService } from '@common/services/analytics.service';
import { OtpSubmitPinResponse, OtpSubmitPinStatusCode } from '../shared/models/otp-submit-pin-response.model';
import { RoutingService } from '@services/routing.service';
import { PtpService } from '@app/ptp/ptp.service';
import { RouteNames } from '@app/app.route-names';
import { AppConfigService } from '@common/services/app-config.service';
@Component({
  selector: 'app-otp-identity-verify-submit-pin',
  templateUrl: './otp-identity-verify-submit-pin.component.html',
  styleUrls: ['./otp-identity-verify-submit-pin.component.scss']
})
export class OtpIdentityVerifySubmitPinComponent implements OnInit {
  loadingRequest = false;
  remainingAttempts;
  showNewCodeBanner = false;

  optVerifySubmitPinForm: FormGroup;
  displayNewPinRequest: boolean;
  translationKey = 'Text';
  analyticsObj: object;
  private translateService;

  constructor(
    translate: TranslateService,
    private fb: FormBuilder,
    private consumerService: ConsumerService,
    private otpGetPinService: OtpGetPinService,
    private otpSubmitPinService: OtpSubmitPinService,
    private kbaQuizService: KbaQuizService,
    private analyticsService: AnalyticsService,
    private appConfigService: AppConfigService,
    private router: Router,
    private config: AppConfig,
    private routes: RouteNames,
    private routingService: RoutingService,
    private ptpService: PtpService,
    private titleService: Title
  ) {
    this.createForm();
    this.translateService = translate;
    this.updatePageTitle();
  }

  ngOnInit() {
    if (this.consumerService.otpEmail) {
      this.translationKey = 'Email';
      this.analyticsObj = this.config.analytics.otp.email;
    } else {
      // by default use text based analytics
      this.analyticsObj = this.config.analytics.otp.text;
    }
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsObj['submitPin'].eventName,
        pageName: this.analyticsObj['submitPin'].pageName
      },
      eventIds: this.analyticsObj['submitPin'].eventIds
    });

    this.displayNewPinRequest = this.otpGetPinService.displayNewPinRequest;
    this.showNewCodeBanner = this.otpGetPinService.showNewCodeBanner;
  }

  fetchNewPin() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsObj['pinDidNotReceive'].eventName,
        pageName: this.analyticsObj['pinDidNotReceive'].pageName,
        attributes: this.analyticsObj['pinDidNotReceive'].attributes
      },
      eventIds: this.analyticsObj['pinDidNotReceive'].eventIds
    });

    this.otpGetPinService.enrollOTP().subscribe(
        data => this.handlePinRequest(data),
        err => this.routingService.handleErrorResponse(err));
  }

  private handlePinRequest(data) {
    if (data) {
      if (data.statusCode === this.config.otpEnrollResendAllowedInit) {
        this.displayNewPinRequest = true;
        this.showNewCodeBanner = false;
      } else if (data.statusCode === this.config.otpEnrollResendAllowed) {
        this.displayNewPinRequest = true;
        this.showNewCodeBanner = true;
      } else if (data.statusCode === this.config.otpEnrollResendMax) {
        this.displayNewPinRequest = false;
        this.showNewCodeBanner = true;
        this.translateService.get('otp-verify-submit-pin.browserTitle.newPinEventTitle').subscribe((result: string) => {
          this.titleService.setTitle(result);
        });
      } else if (data.statusCode === this.config.kbaGetQuizSuccessOtpPinInitiationFail) {
        this.kbaQuizService.saveQuiz(data.quizIdentifier, data.questions as Question[]);
        this.routeToKbaPage();
      } else {
        const defaultRoute = () => { this.router.navigate([this.routes.callCenter]); };
        (this.ptpService.routesMap[data.statusCode] || defaultRoute)();
      }
    } else {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  createForm = () => {
    this.optVerifySubmitPinForm = this.fb.group({
      pin: ['', [
        Validators.required,
        // tslint:disable-next-line:quotemark
        Validators.pattern("^[0-9]{6}$")
      ] ]
    });
  }

  isControlValid = (controlName: string) => {
    // first check if control has been touched
    if (!this.optVerifySubmitPinForm.get(controlName).dirty) {
      // supress error until control recieved input
      return true;
    } else {
      // test using FormControl validators
      return (this.optVerifySubmitPinForm.get(controlName).status !== 'INVALID') ? true : false;
    }
  }

  submitForm = () => {
    this.loadingRequest = true;
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsObj['pinAuthAttempt'].eventName,
        pageName: this.analyticsObj['pinAuthAttempt'].pageName,
        attributes: this.analyticsObj['pinAuthAttempt'].attributes,
      },
      eventIds: this.analyticsObj['pinAuthAttempt'].eventIds
    });
    this.otpSubmitPinService
      .validatePin(this.optVerifySubmitPinForm.get('pin').value)
      .subscribe (
        data => this.handlePinValidation(data),
        err => this.routingService.handleErrorResponse(err),
        () => this.loadingRequest = false
      );
  }

  private handlePinValidation(data: OtpSubmitPinResponse) {
    if (data) {
      if (data.statusCode === this.config.otpValidatePinSuccess) {
        window.location.href = this.appConfigService.updateUrlForMobileParam(data.destinationUrl);
      } else if (data.statusCode === this.config.kbaGetQuizSuccessOtpPinRetryMax) {
        this.incorrectPinAnalytics();
        this.kbaQuizService.saveQuiz(data.quizIdentifier, data.questions as Question[]);
        this.otpSubmitPinService.setOtpFailed(true);
        this.otpSubmitPinService.setPinAuthFailed(true);
        this.routeToKbaPage();
      } else if (data.statusCode === this.config.kbaGetQuizSuccessOtpPinValidationFailUnknown) {
        this.incorrectPinAnalytics();
        this.kbaQuizService.saveQuiz(data.quizIdentifier, data.questions as Question[]);
        this.routeToKbaPage();
        this.otpSubmitPinService.setPinAuthFailed(true);
      } else if (data.statusCode === this.config.otpValidateResubmitWithResendMax) {
        // PIN failed handle remaining tries
        this.incorrectPinAnalytics();
        if (data.remainingAttempts) {
          this.remainingAttempts = data.remainingAttempts;
          this.optVerifySubmitPinForm.controls['pin'].reset();
          if (data.remainingAttempts === 2) {
            this.translateService.get('otp-verify-submit-pin.browserTitle.firstRetryPinEventTitle').subscribe((result: string) => {
              this.titleService.setTitle(result);
            });
          } else if (data.remainingAttempts === 1) {
            this.translateService.get('otp-verify-submit-pin.browserTitle.secondRetryPinEventTitle').subscribe((result: string) => {
              this.titleService.setTitle(result);
            });
          }
        } else {
          this.remainingAttempts = 0;
        }
        this.displayNewPinRequest = false; // As Resend Max
        this.showNewCodeBanner = false;
      } else {
        const defaultRoute = () => { this.router.navigate([this.routes.callCenter]); };
        (this.ptpService.routesMap[data.statusCode] || defaultRoute)();
      }
    } else {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  incorrectPinAnalytics() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsObj['pinIncorrect'].eventName,
        pageName: this.analyticsObj['pinIncorrect'].pageName,
      },
      eventIds: this.analyticsObj['pinIncorrect'].eventIds
    });
  }

  showQuiz() {
    this.kbaQuizService.fetchQuiz();
  }

  routeToKbaPage() {
    this.routingService.enableNavigationTo(this.routes.kbaQuiz);
    this.router.navigate([this.routes.kbaQuiz]);
  }

  updatePageTitle() {
    this.translateService.get('otp-verify-submit-pin.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
