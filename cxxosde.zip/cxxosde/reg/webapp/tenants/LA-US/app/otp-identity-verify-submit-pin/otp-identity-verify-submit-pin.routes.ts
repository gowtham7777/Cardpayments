import { OtpIdentityVerifySubmitPinComponent } from './otp-identity-verify-submit-pin.component';
import { Route } from '@angular/router';
import { OtpSubmitGuard } from '@app/guards/otp-submit.guard';

export const OtpIdentityVerifySubmitPinRoutes: Route[] = [
  {
    path: 'otp-verify-submit-pin',
    component: OtpIdentityVerifySubmitPinComponent,
    canActivate: [OtpSubmitGuard]
  }
];
