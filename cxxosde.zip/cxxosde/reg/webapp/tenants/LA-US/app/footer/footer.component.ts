import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { AppConfigService } from '@common/services/app-config.service';
import { version } from '../../../../../package.json';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent {
  termsOfUseUrl: string;
  today: number = Date.now();
  public version = version;
  constructor(
    public translate: TranslateService,
    public appConfig: AppConfigService
  ) {
     this.appConfig
            .getConfigurationData$()
            .subscribe((res: any) => (this.termsOfUseUrl = res.termsUrl));
  }

  getLinkTarget = () => {
    return (this.appConfig.isMobileApp) ? '' : '_blank';
  }

}
