// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';

// Angular
import {
  async,
  ComponentFixture,
  TestBed,
  tick,
  fakeAsync,
  inject
} from '@angular/core/testing';
import { Router, Route } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Location } from '@angular/common';

// Third Party
import { Observable, Subscriber } from 'rxjs';


// Modules
import { EmergencyBrakeModule } from './emergency-brake.module';
import { PersonalInfoModule } from '@app/personal-info/personal-info.module';

// Services
import { EmergencyBrakeService } from '@services/emergency-brake.service';
import { MockEmergencyBrakeService } from '@app/app.mock-services';
import { RoutingService } from '@services/routing.service';
import { AnalyticsService } from '@common/services/analytics.service';

// Components
import { EmergencyBrakeMailOptionComponent } from './emergency-brake-mail-option.component';

// Routes accessible by this component to be tested
import { RouteNames } from '@app/app.route-names';
import { EmergencyBreakRoutes } from './emergency-brake.routes';
import { EmergencyBrakeNextStepsGuard } from '@app/guards';
const limitedRoutes: Route[] = BaseRoutesWith(EmergencyBreakRoutes);

describe('EmergencyBrakeMailOptionComponent', () => {
  let component: EmergencyBrakeMailOptionComponent;
  let fixture: ComponentFixture<EmergencyBrakeMailOptionComponent>;
  let location: Location;
  let analytics: AnalyticsService;
  let emergencyBrakeService: EmergencyBrakeService;
  let routingService: RoutingService;
  let router: Router;
  let routes: RouteNames;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        EmergencyBrakeModule,
        PersonalInfoModule,
        RouterTestingModule.withRoutes(limitedRoutes)
      ],
      providers: [
        { provide: EmergencyBrakeService, useClass: MockEmergencyBrakeService }
      ]
    })
      .compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(EmergencyBrakeMailOptionComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        location = TestBed.get(Location);
        emergencyBrakeService = TestBed.get(EmergencyBrakeService);
        analytics = TestBed.get(AnalyticsService);
        routingService = TestBed.get(RoutingService);
        router = TestBed.get(Router);
        routes = TestBed.get(RouteNames);
      });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run next steps with valid data', () => {
    spyOn(analytics, 'appendEvent').and.stub();
    const response = new Observable<any>((subscriber: Subscriber<any>) =>
      subscriber.next('test')
    );
    spyOn(emergencyBrakeService, 'postEmergencyBreak').and.returnValue(
      response
    );
    spyOn(routingService, 'enableNavigationTo').and.stub();
    spyOn(router, 'navigate').and.stub();

    component.nextSteps(true);

    expect(analytics.appendEvent).toHaveBeenCalled();
    expect(emergencyBrakeService.postEmergencyBreak).toHaveBeenCalledWith(true);
    expect(routingService.enableNavigationTo).toHaveBeenCalledWith(
      routes.emergencyBrakeNextSteps
    );
    expect(router.navigate).toHaveBeenCalledWith([
      routes.emergencyBrakeNextSteps
    ]);
  });
  it('should run next steps with error', () => {
    spyOn(analytics, 'appendEvent').and.stub();
    const response = new Observable<any>((subscriber: Subscriber<any>) =>
      subscriber.error('test')
    );
    spyOn(emergencyBrakeService, 'postEmergencyBreak').and.returnValue(
      response
    );
    spyOn(router, 'navigateByUrl').and.stub();

    component.nextSteps(false);

    expect(analytics.appendEvent).toHaveBeenCalled();
    expect(emergencyBrakeService.postEmergencyBreak).toHaveBeenCalledWith(
      false
    );
    expect(router.navigateByUrl).toHaveBeenCalledWith(routes.callCenter);
  });
});
