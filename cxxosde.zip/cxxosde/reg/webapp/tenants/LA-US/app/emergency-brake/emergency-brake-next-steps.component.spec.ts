import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { SharedModule, HttpLoaderFactory } from '../shared/shared.module';
import { EmergencyBrakeNextStepsComponent } from './emergency-brake-next-steps.component';

describe('EmergencyBrakeComponent', () => {
  let component: EmergencyBrakeNextStepsComponent;
  let fixture: ComponentFixture<EmergencyBrakeNextStepsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmergencyBrakeNextStepsComponent ],
      imports: [
        HttpClientModule,
        TestBedModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }
        })
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmergencyBrakeNextStepsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
