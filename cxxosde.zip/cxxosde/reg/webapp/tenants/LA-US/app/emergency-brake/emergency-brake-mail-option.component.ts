import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { AppConfig } from '@app/app.config';
import { SharedModule } from '@app/shared/shared.module';
import { RouteNames } from '@app/app.route-names';
import { RoutingService } from '@services/routing.service';
import { AnalyticsService } from '@common/services/analytics.service';
import { EmergencyBrakeService } from '@services/emergency-brake.service';

@Component({
  selector: 'emergency-brake-mail-option',
  templateUrl: './emergency-brake-mail-option.html'
})
export class EmergencyBrakeMailOptionComponent implements OnInit {
private translateService;

  constructor(
    private router: Router,
    private emergencyBrakeService: EmergencyBrakeService,
    private analyticsService: AnalyticsService,
    private config: AppConfig,
    private routes: RouteNames,
    private routingService: RoutingService,
    private translate: TranslateService,
    private titleService: Title
  ) {
    this.translateService = translate;
    this.updatePageTitle();
  }

  ngOnInit () {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.emergencyBrake.mailOption.eventName,
        pageName: this.config.analytics.emergencyBrake.mailOption.pageName
      },
      eventIds: this.config.analytics.emergencyBrake.mailOption.eventIds
    });
  }

  nextSteps (optIn: boolean) {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.emergencyBrake.pinToMailInit.eventName,
        pageName: this.config.analytics.emergencyBrake.pinToMailInit.pageName
      },
      eventIds: this.config.analytics.emergencyBrake.pinToMailInit.eventIds
    });
    this.emergencyBrakeService.postEmergencyBreak(optIn).subscribe (
      data => {
        // Response code can be config.emergencyBrakeOptIn or config.emergencyBrakeOptOut, for now, there is no UI difference
        // so we handle any response the same in this block
        this.routingService.enableNavigationTo(this.routes.emergencyBrakeNextSteps);
        this.router.navigate([this.routes.emergencyBrakeNextSteps]);
      },
      // Errors will call this callback instead:
      err => {
        this.routingService.handleErrorResponse(err);
      });
  }

  updatePageTitle() {
    this.translateService.get('emergency-brake.browserTitle.pageLoadEventTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
