import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { EmergencyBrakeMailOptionComponent } from './emergency-brake-mail-option.component';
import { EmergencyBrakeNextStepsComponent } from './emergency-brake-next-steps.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [
    EmergencyBrakeMailOptionComponent,
    EmergencyBrakeNextStepsComponent
  ],
  providers: [], // services go here
  exports: [
    EmergencyBrakeMailOptionComponent,
    EmergencyBrakeNextStepsComponent
  ]
})
export class EmergencyBrakeModule { }
