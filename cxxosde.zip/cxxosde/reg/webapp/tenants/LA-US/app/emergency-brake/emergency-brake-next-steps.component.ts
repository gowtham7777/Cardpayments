import { Component, Input, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';


import { TranslateService } from '@ngx-translate/core';

import { SharedModule } from '@app/shared/shared.module';
import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfig } from '@app/app.config';

@Component({
  selector: 'emergency-brake-next-steps',
  templateUrl: './emergency-brake-next-steps.html'
})
export class EmergencyBrakeNextStepsComponent implements OnInit {
private translateService;

  constructor(
    private analyticsService: AnalyticsService,
    private config: AppConfig,
    private translate: TranslateService,
    private titleService: Title
  ) {
    this.translateService = translate;
    this.updatePageTitle();
  }

  ngOnInit () {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.emergencyBrake.nextSteps.eventName,
        pageName: this.config.analytics.emergencyBrake.nextSteps.pageName
      },
      eventIds: this.config.analytics.emergencyBrake.nextSteps.eventIds
    });
  }

  updatePageTitle() {
    this.translateService.get('emergency-brake.browserTitle.nextStepsEventTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
