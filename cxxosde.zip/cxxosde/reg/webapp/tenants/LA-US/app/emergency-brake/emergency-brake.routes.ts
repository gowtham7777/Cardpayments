import { Route } from '@angular/router';

import { EmergencyBrakeMailOptionComponent } from './emergency-brake-mail-option.component';
import { EmergencyBrakeNextStepsComponent } from './emergency-brake-next-steps.component';
import { EmergencyBrakeMailOptionGuard } from '@app/guards/emergency-brake-mail-option.guard';
import { EmergencyBrakeNextStepsGuard } from '@app/guards/emergency-brake-next-steps.guard';

export const EmergencyBreakRoutes: Route[] = [
  {
    path: 'emergency-brake-mail-option',
    component: EmergencyBrakeMailOptionComponent,
    canActivate: [EmergencyBrakeMailOptionGuard]
  },
  {
    path: 'emergency-brake-next-steps',
    component: EmergencyBrakeNextStepsComponent,
    canActivate: [EmergencyBrakeNextStepsGuard]
  }
];

