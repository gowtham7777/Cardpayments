import { TranslateService } from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { SharedModule } from '../shared/shared.module';

@Component({
  selector: 'verify-identity-duplicate',
  templateUrl: './verify-identity-duplicate.component.html'
})

export class VerifyIdentityDuplicateComponent {

}
