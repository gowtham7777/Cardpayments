import { Route } from '@angular/router';
import { VerifyIdentityDuplicateComponent } from './verify-identity-duplicate.component';

export const VerifyIdentityDuplicateRoutes: Route[] = [
  {
    path: 'verify-identity-duplicate',
    component: VerifyIdentityDuplicateComponent,
  }
];
