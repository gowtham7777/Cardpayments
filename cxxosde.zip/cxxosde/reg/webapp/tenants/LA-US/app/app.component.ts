import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';

import { AppConfigService } from '@common/services/app-config.service';
import { TimeoutService } from './timeout/timeout.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'app';

  constructor(
    private router: Router,
    public appConfigService: AppConfigService,
    private idle: Idle,
    private keepalive: Keepalive,
    private timeoutService: TimeoutService,
  ) {

    this.idle.onIdleStart.subscribe(() => this.timeoutService.onIdleStart());
    this.idle.onTimeoutWarning.subscribe((countdown: number) => this.timeoutService.onIdleWarning(countdown));
    this.idle.onIdleEnd.subscribe(() => this.timeoutService.onIdleEnd());
    this.idle.onTimeout.subscribe(() => this.timeoutService.onIdleTimeout());
    this.keepalive.onPing.subscribe(() => this.timeoutService.onKeepalivePing());

    // scroll page to top on route change
    this.router.events.subscribe(
      () => window.scrollTo(0, 0)
    );
  }
}
