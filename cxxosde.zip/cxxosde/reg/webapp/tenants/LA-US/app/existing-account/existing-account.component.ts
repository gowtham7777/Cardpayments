import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { AnalyticsService } from '@common/services/analytics.service';

@Component({
  selector: 'app-existing-account',
  templateUrl: './existing-account.component.html',
  styleUrls: ['./existing-account.component.scss']
})
export class ExistingAccountComponent implements OnInit {

  constructor(
    translate: TranslateService,
    public analyticsService: AnalyticsService,
    private dialogRef: MatDialogRef<ExistingAccountComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

     }

     onNoClick(): void {
      this.dialogRef.close();
    }

    onLogin(): void {
      this.dialogRef.close('login');
    }


    ngOnInit() {
    }

}
