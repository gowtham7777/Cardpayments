import { MatDialogModule } from '@angular/material';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { ExistingAccountComponent } from './existing-account.component';

@NgModule({
  declarations: [
    ExistingAccountComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    MatDialogModule
  ],
  providers: [], // services go here
  exports: [
    ExistingAccountComponent
  ]
})
export class ExistingAccountModule { }
