import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedModule } from '@shared/shared.module';

import { ExistingAccountComponent } from './existing-account.component';

describe('WhereIsMyPinComponent', () => {
  let component: ExistingAccountComponent;
  let fixture: ComponentFixture<ExistingAccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingAccountComponent ],
      imports: [
        TestBedModule,
        SharedModule,
        MatDialogModule
      ],
      providers: [
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

