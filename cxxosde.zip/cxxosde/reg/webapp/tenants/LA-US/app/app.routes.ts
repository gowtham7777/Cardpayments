import { Routes } from '@angular/router';
import { AccountCreationRoutes } from './account-creation/account-creation.routes';
import { PersonalInfoRoutes } from './personal-info/personal-info.routes';
import { AccountIsSetupRoutes} from './account-is-setup/account-is-setup.routes';
import { VerifyIdentityDuplicateRoutes } from './verify-identity-duplicate/verify-identity-duplicate.routes';
import { SystemErrorRoutes } from './system-error/system-error.routes';
import { KbaQuizRoutes } from './kba-quiz/kba-quiz.routes';
import { PersonalInfoComponent } from './personal-info/personal-info.component';
import { OtpIdentityVerifySubmitPinRoutes } from './otp-identity-verify-submit-pin/otp-identity-verify-submit-pin.routes';
import { OtpIdentifyVerifyGetPinRoutes } from './otp-identity-verify-get-pin/otp-identity-verify-get-pin.routes';
import { PtpRoutes } from './ptp/ptp.routes';
import { CallCenterRoutes } from './call-center/call-center.routes';
import { EmergencyBreakRoutes } from './emergency-brake/emergency-brake.routes';

export const routes: Routes = [
  ...VerifyIdentityDuplicateRoutes,
  ...SystemErrorRoutes,
  ...AccountCreationRoutes,
  ...KbaQuizRoutes,
  ...PersonalInfoRoutes,
  ...AccountIsSetupRoutes,
  ...OtpIdentifyVerifyGetPinRoutes,
  ...OtpIdentityVerifySubmitPinRoutes,
  ...PtpRoutes,
  ...CallCenterRoutes,
  ...EmergencyBreakRoutes,

  {
    path: '',
    redirectTo: '/personal-info',
    pathMatch: 'full'
  },
  {
    path: '**',
    component: PersonalInfoComponent
  }
];
