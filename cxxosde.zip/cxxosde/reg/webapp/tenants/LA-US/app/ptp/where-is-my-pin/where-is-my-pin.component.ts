import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { AnalyticsService } from '@common/services/analytics.service';

@Component({
  selector: 'app-where-is-my-pin',
  templateUrl: './where-is-my-pin.component.html',
  styleUrls: ['./where-is-my-pin.component.scss']
})
export class WhereIsMyPinComponent implements OnInit {

  constructor(
    translate: TranslateService,
    public analyticsService: AnalyticsService,
    private dialogRef: MatDialogRef<WhereIsMyPinComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

     }

    onNoClick(): void {
      this.dialogRef.close();
    }

    onTryAgain(): void {
      this.dialogRef.close('tryAgain');
    }


    ngOnInit() {
    }

}
