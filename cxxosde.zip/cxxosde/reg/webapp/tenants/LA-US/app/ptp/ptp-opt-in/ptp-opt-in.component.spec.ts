import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';
import { SharedModule } from '@shared/shared.module';
import { PtpService } from '@app/ptp/ptp.service';
import { MockPtpService } from '@app/app.mock-services';
import { RouterTestingModule } from '@angular/router/testing';
import { PtpOptInComponent } from './ptp-opt-in.component';

describe('PtpOptInComponent', () => {
  let component: PtpOptInComponent;
  let fixture: ComponentFixture<PtpOptInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        SharedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ],
      declarations: [ PtpOptInComponent ],
      providers: [
        {provide: PtpService, useClass: MockPtpService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtpOptInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
