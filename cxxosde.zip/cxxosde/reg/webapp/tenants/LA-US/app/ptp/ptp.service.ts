import { Injectable, Inject } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { environment } from '../../environments/environment';
import { AppConfig } from '@app/app.config';
import { RouteNames } from '@app/app.route-names';
import { RoutingService } from '@services/routing.service';

// Pin-to-post Service which is used to send a random PIN to users through the mail
@Injectable()
export class PtpService {
  results: object;
  headers: HttpHeaders;
  private submitAnswersUrl = environment.submitAnswersUrl;
  public ptpEligible = false;
  public ptpOnly = false;

  routesMap = {
    [this.config.ptpEligiblePrimary]: () => {
      this.setPtpEligible(true);
      this.routingService.enableNavigationTo(this.routes.ptpOptIn);
      this.router.navigate([this.routes.ptpOptIn]);
    },
    [this.config.ptpEligibleSecondary]: () => {
      this.setPtpEligible(true);
      this.router.navigate([this.routes.callCenterPtp]);
      this.translate.get('ptp.browserTitle.ptpSecondaryEventTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    },
    [this.config.kbaQuizError]: () => {
      this.setPtpEligible(false);
      this.router.navigate([this.routes.callCenterPtp]);
    },
    [this.config.kbaFailureEligibilityFail]: () => {
      this.setPtpEligible(false);
      this.router.navigate([this.routes.callCenterPtp]);
    },
    [this.config.ptpOnly]: () => {
      this.setPtpOnly(true);
      this.routingService.enableNavigationTo(this.routes.ptpOptIn);
      this.router.navigate([this.routes.ptpOptIn]);
    }
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private config: AppConfig,
    private routes: RouteNames,
    private routingService: RoutingService,
    private translate: TranslateService,
    private titleService: Title
  ) {
    this.headers = new HttpHeaders()
      .set('Accept', 'application/json')
      .set('Content-Type', 'application/json');
  }

  enrollPTP() {
    this.http.get<any>(environment.enrollPTPUrl).subscribe(
      // Successful responses call the first callback
      data => {
        this.routeFromResponse(data);
      },
      // Errors will call this callback instead
      err => {
        this.router.navigate([this.routes.callCenter]);
      }
    );
  }

  private routeFromResponse = (data) => {
    const routesMap = {
      [this.config.ptpInitiated]: () => {
        this.routingService.enableNavigationTo(this.routes.ptpSuccess);
        this.router.navigate([this.routes.ptpSuccess]);
      },
      [this.config.ptpInitiateSystemError]: () => {
        this.router.navigate([this.routes.callCenter]);
      }
    };

    let defaultRoute = () => { this.router.navigate([this.routes.systemError]); }
    (routesMap[data.statusCode] || defaultRoute)();
  }

  isPtpEligible() {
    return this.ptpEligible;
  }

  setPtpEligible(eligible: boolean) {
    this.ptpEligible = eligible;
  }

  isPtpOnly() {
    return this.ptpOnly;
  }

  setPtpOnly(ptpOnly: boolean) {
    this.ptpOnly = ptpOnly;
  }

  submitPtpPin(email, pin, reCaptchaResponse) {
    const body = {email, pin, reCaptchaResponse};
    return this.http
      .post<any>(environment.submitPTPPinUrl, body, {
        headers: this.headers
      });
  }

  memberCenterRedirect(){
    return this.http
      .get<any>(environment.appConfigUrl, {
        headers: this.headers
      });
  }
}
