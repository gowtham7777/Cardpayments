import { Route } from '@angular/router';
import { PtpOptInComponent } from './ptp-opt-in/ptp-opt-in.component';
import { PtpSuccessComponent } from './ptp-success/ptp-success.component';
import { PtpSubmitPinComponent } from './ptp-submit-pin/ptp-submit-pin.component';

import { PtpOptInGuard } from '@app/guards/ptp-opt-in.guard';
import { PtpSuccessGuard } from '@app/guards/ptp-success.guard';
import { PtpSubmitPinGuard } from '@app/guards/ptp-submit-pin.guard';



export const PtpRoutes: Route[] = [
  {
    path: 'ptp-opt-in',
    component: PtpOptInComponent,
    canActivate: [PtpOptInGuard]
  },
  {
    path: 'ptp-success',
    component: PtpSuccessComponent,
    canActivate: [PtpSuccessGuard]
  },
  {
    path: 'ptp-submit-pin',
    component: PtpSubmitPinComponent,
    canActivate: [PtpSubmitPinGuard]
  }
];
