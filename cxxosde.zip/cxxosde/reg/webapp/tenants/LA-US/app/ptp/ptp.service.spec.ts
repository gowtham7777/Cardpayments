// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@app/shared/test-bed.module';

// Angular
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Location } from '@angular/common';
import { Route, Router } from '@angular/router';

// Services
import { PtpService } from './ptp.service';
import { RoutingService } from '@shared/services/routing.service';

// Models
import { AppConfig } from '@app/app.config';

// Routes accessible by this component to be tested
import { RouteNames } from '@app/app.route-names';
import { PtpOptInGuard, PiiGuard } from '@app/guards';

let service: PtpService;
let router: Router;
let routes: RouteNames;
let routingService: RoutingService;
let location: Location;
let config: AppConfig;

describe('PtpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(BaseRoutesWith([]))
      ],
      providers: [PtpService, PtpOptInGuard, PiiGuard]
    });

    service = TestBed.get(PtpService);
    router = TestBed.get(Router);
    routes = TestBed.get(RouteNames);
    routingService = TestBed.get(RoutingService);
    config = TestBed.get(AppConfig);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialize variables to false', () => {
    expect(service.isPtpEligible()).toBeFalsy();
    expect(service.isPtpOnly()).toBeFalsy();
  });

  it('should update variables correctly', () => {
    service.setPtpEligible(true);
    expect(service.isPtpEligible()).toBeTruthy();
    service.setPtpEligible(false);
    expect(service.isPtpEligible()).toBeFalsy();
    service.setPtpOnly(true);
    expect(service.isPtpOnly()).toBeTruthy();
    service.setPtpOnly(false);
    expect(service.isPtpOnly()).toBeFalsy();
  });

  let validateRoutesMap = (response, targetPage) => {
    service.routesMap[response]();
    expect(router.navigate).toHaveBeenCalledWith([targetPage]);
  };

  it('should validate routes map', fakeAsync(() => {
    spyOn(router, 'navigate').and.stub();
    validateRoutesMap(config.ptpEligiblePrimary, routes.ptpOptIn);
    validateRoutesMap(config.ptpEligibleSecondary, routes.callCenterPtp);
    validateRoutesMap(config.kbaQuizError, routes.callCenterPtp);
    validateRoutesMap(config.ptpOnly, routes.ptpOptIn);
  }));

  let validateRouteFromResonse = (response, targetPage) => {
    let data = { statusCode: response };
    service['routeFromResponse'](data);
    expect(router.navigate).toHaveBeenCalledWith([targetPage]);
  };

  it('should reoute from response', fakeAsync(() => {
    spyOn(router, 'navigate').and.stub();
    validateRouteFromResonse(config.ptpInitiated, routes.ptpSuccess);
    validateRouteFromResonse(config.ptpInitiateSystemError, routes.callCenter);
  }));


  it('should call enrollPTP', () => {
    service.enrollPTP();
  });

  // it('should call submitPtpPin', () => {
  //   const body = {xyz.com, 124124124124, awdfweqwerq235235235235235235};
  //   service.submitPtpPin(body);
  // });

  it('should call memberCenterRedirect', () => {
    service.memberCenterRedirect();
  });
});
