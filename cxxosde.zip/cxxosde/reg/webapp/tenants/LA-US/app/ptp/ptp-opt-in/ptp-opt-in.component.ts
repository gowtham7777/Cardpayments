import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { PtpService } from '../ptp.service';
import { AppConfig } from '@app/app.config';
import { AnalyticsService } from '@common/services/analytics.service';

@Component({
  selector: 'app-ptp-opt-in',
  templateUrl: './ptp-opt-in.component.html',
  styleUrls: ['./ptp-opt-in.component.scss']
})
export class PtpOptInComponent implements OnInit {
  ptpOnly = false;
  private translateService;

  constructor(
    translate: TranslateService,
    private ptpService: PtpService,
    private router: Router,
    private config: AppConfig,
    public analyticsService: AnalyticsService,
    private titleService: Title
  ) {
    this.ptpOnly = this.ptpService.isPtpOnly();
    this.translateService = translate;
  }

  ngOnInit() {
    if (this.ptpOnly) {
      // if pinToMailOnly
      this.analyticsService.appendEvent({
        eventData: {
          eventName: this.config.analytics.ptp.pinToMailOnly.eventName,
          pageName: this.config.analytics.ptp.pinToMailOnly.pageName,
        },
        eventIds: this.config.analytics.ptp.pinToMailOnly.eventIds
      });
      this.translateService.get('ptp.browserTitle.pinToMailOnlyEventTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    } else {
      // or if pinToMailOrCallCc
      this.analyticsService.appendEvent({
        eventData: {
          eventName: this.config.analytics.ptp.pinToMailOrCallCc.eventName,
          pageName: this.config.analytics.ptp.pinToMailOrCallCc.pageName,
        },
        eventIds: this.config.analytics.ptp.pinToMailOrCallCc.eventIds
      });
      this.translateService.get('ptp.browserTitle.pageLoadTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    }
  }

  optIn() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.ptp.pinToMailInitiated.eventName,
      },
      eventIds: this.config.analytics.ptp.pinToMailInitiated.eventIds
    });
    this.ptpService.enrollPTP();
  }

}
