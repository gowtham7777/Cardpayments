import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedModule } from '@shared/shared.module';

import { WhereIsMyPinComponent } from './where-is-my-pin.component';

describe('WhereIsMyPinComponent', () => {
  let component: WhereIsMyPinComponent;
  let fixture: ComponentFixture<WhereIsMyPinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhereIsMyPinComponent ],
      imports: [
        TestBedModule,
        SharedModule,
        MatDialogModule
      ],
      providers: [
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhereIsMyPinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

