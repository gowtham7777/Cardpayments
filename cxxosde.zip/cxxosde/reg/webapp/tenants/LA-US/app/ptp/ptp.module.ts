import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { PtpOptInComponent } from './ptp-opt-in/ptp-opt-in.component';
import { PtpSuccessComponent } from './ptp-success/ptp-success.component';
import { PtpService } from './ptp.service';
import { PtpSubmitPinComponent } from './ptp-submit-pin/ptp-submit-pin.component';
import { MatInputModule } from '@angular/material/input';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha';
import { WhereIsMyPinComponent } from './where-is-my-pin/where-is-my-pin.component';
import { MatDialogModule } from '@angular/material';
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    SharedModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    MatDialogModule
  ],
  declarations: [
    PtpOptInComponent,
    PtpSuccessComponent,
    PtpSubmitPinComponent,
    WhereIsMyPinComponent
  ],
  entryComponents: [ WhereIsMyPinComponent ],
  providers: [
    PtpService
  ],
  exports: [
    PtpOptInComponent,
    PtpSuccessComponent,
    PtpSubmitPinComponent,
    WhereIsMyPinComponent
  ],
})
export class PtpModule { }
