import { Component, OnInit } from '@angular/core';
import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfig } from '@app/app.config';

@Component({
  selector: 'app-ptp-success',
  templateUrl: './ptp-success.component.html',
  styleUrls: ['./ptp-success.component.scss']
})
export class PtpSuccessComponent implements OnInit {

  constructor(
    private config: AppConfig,
    private analyticsService: AnalyticsService
  ) { }

  ngOnInit() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.ptp.pinToMailAuthSuccess.eventName,
        pageName: this.config.analytics.ptp.pinToMailAuthSuccess.pageName,
      },
      eventIds: this.config.analytics.ptp.pinToMailAuthSuccess.eventIds
    });
  }

}
