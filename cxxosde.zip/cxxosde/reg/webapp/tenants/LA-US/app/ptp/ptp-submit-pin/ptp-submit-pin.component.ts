import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { CaptchaService } from '@services/captcha.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { AppConfig } from '@app/app.config';
import { TranslateService } from '@ngx-translate/core';
import { AnalyticsService } from '@common/services/analytics.service';
import { PtpService } from '../ptp.service';
import { RoutingService } from '@app/shared/services/routing.service';
import { Router } from '@angular/router';
import { RouteNames } from '@app/app.route-names';
import { MatDialog } from '@angular/material';
import { WhereIsMyPinComponent } from '../where-is-my-pin/where-is-my-pin.component';
@Component({
  selector: 'app-ptp-submit-pin',
  templateUrl: './ptp-submit-pin.component.html',
  styleUrls: ['./ptp-submit-pin.component.scss']
})
export class PtpSubmitPinComponent implements OnInit, OnDestroy {
  loadingRequest = false;
  ptpSubmitPinForm: FormGroup;
  remainingAttempts;
  private translateService;
  public siteKey$;
  public showCaptchaError = false;
  constructor(
    translate: TranslateService,
    private captchaService: CaptchaService,
    private formBuilder: FormBuilder,
    private config: AppConfig,
    private analyticsService: AnalyticsService,
    private changeDetector: ChangeDetectorRef,
    private ptpService: PtpService,
    private routingService: RoutingService,
    private router: Router,
    private routes: RouteNames,
    private titleService: Title,
    private dialog: MatDialog
  ) {
    this.createForm();
    this.translateService = translate;
    this.updatePageTitle();
  }

  ngOnInit() {
    this.createCaptchaTestingHook();
    this.captchaService.retrieveCaptchaSiteKey()
    .subscribe(data => {
      this.siteKey$ = data['siteKey'];
      },
      error => {
    });

    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.ptp.pinToMail.eventName,
        pageName: this.config.analytics.ptp.pinToMail.pageName
      },
      eventIds: this.config.analytics.ptp.pinToMail.eventIds
    });
  }

  ngOnDestroy(): void {
    delete window['setCaptchaValue'];
  }

  createForm = () => {
    this.ptpSubmitPinForm = this.formBuilder.group({
      emailAddress: ['', [
        // TODO - verify and update validators
        Validators.required,
        Validators.pattern(
            this.config.regex.dottedEmailAddress +
            this.config.regex.allowedEmailCharacters +
            this.config.regex.startsWithAlphanumeric +
            this.config.regex.minAndMaxEmailLength +
            this.config.regex.notNineOrMoreNumbers +
            this.config.regex.oneAtMark
        )
      ]],
      pin: ['', [
        // Accepting characters and number only.
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern(this.config.regex.allowedPinCharacters)
      ]],
      reCaptcha: ['', [
        Validators.required
      ]]
    });
  }



  remainingAttemptsStatus(data) {
    this.remainingAttempts = data.remainingAttempts;
    this.ptpSubmitPinForm.controls['emailAddress'].reset();
    this.ptpSubmitPinForm.controls['pin'].reset();
    if (data.remainingAttempts > 0) {
      if (data.remainingAttempts === 2) {
        this.translateService.get('ptp.browserTitle.firstRetryPinEventTitle').subscribe((result: string) => {
          this.titleService.setTitle(result);
        });
      } else if (data.remainingAttempts === 1) {
        this.translateService.get('ptp.browserTitle.secondRetryPinEventTitle').subscribe((result: string) => {
          this.titleService.setTitle(result);
        });
      }
    } else {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  handleSubmitPinResponse(data) {
     if (data) {
      if (data.statusCode === this.config.ptpSubmitPinSuccess) {
        this.routingService.enableNavigationTo(this.routes.accountIsSetup);
        this.router.navigate([this.routes.accountIsSetup]);
      } else if ( data.statusCode === this.config.ptpValidateResubmitAllowed) {
        this.remainingAttemptsStatus(data);
      } else if (data.statusCode === this.config.ptpSubmitPinRecaptcha) {
        // reCaptcha error to show blue banner
        this.showCaptchaError = true;
        this.ptpSubmitPinForm.controls['pin'].reset();
      } else {
        this.router.navigate([this.routes.callCenter]);
      }

    } else {
       this.router.navigate([this.routes.callCenter]);
    }
  }

  submitForm() {
    this.loadingRequest = true;
    this.showCaptchaError = false;
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.ptp.pinToMailAuthAttempt.eventName,
        pageName: this.config.analytics.ptp.pinToMailAuthAttempt.pageName,
        attributes: this.config.analytics.ptp.pinToMailAuthAttempt.attributes
      },
      eventIds: this.config.analytics.ptp.pinToMailAuthAttempt.eventIds
    });

    const pin = this.ptpSubmitPinForm.get('pin').value;
    const email = this.ptpSubmitPinForm.get('emailAddress').value;
    const reCaptchaResponse = this.ptpSubmitPinForm.get('reCaptcha').value;
    this.ptpService.submitPtpPin(email, pin, reCaptchaResponse)
      .subscribe(
        data => this.handleSubmitPinResponse(data),
        err =>  this.router.navigate([this.routes.callCenter]),
        () => this.loadingRequest = false
      );
  }

  isControlValid = (controlName: string) => {
    const formHasNotBeenTouched = !this.ptpSubmitPinForm.get(controlName).dirty;
    if (formHasNotBeenTouched) {
      return true;
    } else {
      const controlIsValid = this.ptpSubmitPinForm.get(controlName).status !== 'INVALID';
      return !!controlIsValid;
    }
  }

  // Required for reCaptcha
  resolved(captchaResponse: string) {
  }

  createCaptchaTestingHook() {
    window['setCaptchaValue'] = (val) => {
      this.ptpSubmitPinForm.get('reCaptcha').patchValue(val);
      this.changeDetector.detectChanges();
    };
  }

  updatePageTitle() {
    this.translateService.get('ptp.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
  openModal() {
    const dialogRef = this.dialog.open(WhereIsMyPinComponent);
  }


}
