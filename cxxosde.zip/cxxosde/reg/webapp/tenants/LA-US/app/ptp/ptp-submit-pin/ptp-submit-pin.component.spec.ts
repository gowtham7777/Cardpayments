import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatError, MatInputModule, MatDialogModule, MatDialog } from '@angular/material';
import { Observable } from 'rxjs';
import { Routes, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Subscriber } from 'rxjs';
import { RouteNames } from '@app/app.route-names';

import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { AppConfig } from '@app/app.config';

// Modules
import { SharedModule, HttpLoaderFactory } from '@app/shared/shared.module';
import { RecaptchaFormsModule } from 'ng-recaptcha';
import { RecaptchaModule } from 'ng-recaptcha';
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';
import { TextMaskModule } from 'angular2-text-mask';

// Services
import { CaptchaService } from '@services/captcha.service';
import { TranslateService } from '@ngx-translate/core';
import { PtpService } from '@app/ptp/ptp.service';
import { AnalyticsService } from '@common/services/analytics.service';
import { RoutingService } from '@services/routing.service';
import { WhereIsMyPinComponent } from '../where-is-my-pin/where-is-my-pin.component';

import { MockConsumerService, MockCaptchaService, MockPtpService } from '@app/app.mock-services';

// Components
import { PtpSubmitPinComponent } from './ptp-submit-pin.component';

// Misc
const limitedRoutes: Routes = BaseRoutesWith([]);
const MOCK_ERROR = 'error';
const data = { 'remainingAttempts': 1 };

describe('PtpSubmitPinComponent', () => {
  let component: PtpSubmitPinComponent;
  let fixture: ComponentFixture<PtpSubmitPinComponent>;
  let mockPtpService: PtpService;
  let mockRoutes: RouteNames;
  let mockRouter: Router;
  let mockRoutingService: RoutingService;
  const mockEmail = 'test@gmail.com';
  const mockPin = '1234567890';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtpSubmitPinComponent ],
      providers: [
        {provide: PtpService, useClass: MockPtpService},
        {provide: CaptchaService, useClass: MockCaptchaService}
      ],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(limitedRoutes),
        SharedModule,
        MatDialogModule,
        MatInputModule,
        RecaptchaModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    mockPtpService = TestBed.get(PtpService);
    mockRoutes = TestBed.get(RouteNames);
    mockRouter = TestBed.get(Router);
    fixture = TestBed.createComponent(PtpSubmitPinComponent);
    mockRoutingService = TestBed.get(RoutingService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  function mockPinResponse(responseMap) {
    return (responseMap === MOCK_ERROR)
      ? new Observable<Error>( (subscriber: Subscriber<Error>) => subscriber.error())
      : new Observable<any> ((subscriber: Subscriber<any>) =>
          subscriber.next(responseMap)
        );
  }


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // ==========================================================================
  // Validate Pin Tests
  // ==========================================================================


  it('should handle submit pin reponse after submitting form', () => {
    spyOn(component as any, 'handleSubmitPinResponse').and.stub();
    spyOn(mockPtpService, 'submitPtpPin').and.returnValue(
      mockPinResponse({statusCode: component['config'].ptpSubmitPinSuccess})
    );
    component.submitForm();
    expect(component['handleSubmitPinResponse']).toHaveBeenCalled();
  });

 

  it('should handle errors after submitting form', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockPtpService, 'submitPtpPin').and.returnValue(
      mockPinResponse(MOCK_ERROR)
    );
    component.submitForm();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });


  it('should handle submit pin reponse for pin success', () => {
    spyOn(mockRoutingService, 'enableNavigationTo').and.stub();
    spyOn(mockRouter, 'navigate').and.stub();
    const new_data = {statusCode: component['config'].ptpSubmitPinSuccess};
    component.handleSubmitPinResponse(new_data);
    expect(mockRoutingService.enableNavigationTo).toHaveBeenCalledWith(mockRoutes.accountIsSetup);
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.accountIsSetup]);
  });

  it('should handle submit pin reponse for ptp remaining attempts', () => {
    const new_data = {statusCode: component['config'].ptpValidateResubmitAllowed};
    component.handleSubmitPinResponse(new_data);
  });

  it('should handle submit pin reponse for pin recaptch error', () => {
    const new_data = {statusCode: component['config'].ptpSubmitPinRecaptcha};
    component.handleSubmitPinResponse(new_data);
  });

  it('should handle submit pin reponse for other status', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    const new_data = {statusCode: 'other'};
    component.handleSubmitPinResponse(new_data);
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

  it('should handle submit pin no data', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    const new_data = '';
    component.handleSubmitPinResponse(new_data);
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

  // it('should attempt to incorrectPin function', () => {
  //   spyOn(component['analyticsService'], 'appendEvent').and.stub();
  //   component.incorrectPinAnalytics();
  //   expect(component['analyticsService'].appendEvent).toHaveBeenCalled();
  // });


  it('should attempt to 2 remaining Attempts', () => {
    const new_data = {remainingAttempts: 2}
    component.remainingAttemptsStatus(new_data);

  });

  it('should attempt to 1 remaining Attempts', () => {
    const new_data = {remainingAttempts: 1}
    component.remainingAttemptsStatus(new_data);

  });

  it('should attempt to 0 remaining Attempts', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    const new_data = {remainingAttempts: 0}
    component.remainingAttemptsStatus(new_data);
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });

});
