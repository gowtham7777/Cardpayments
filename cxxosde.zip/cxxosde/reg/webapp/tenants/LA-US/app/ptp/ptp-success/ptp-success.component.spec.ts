import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';

import { PtpSuccessComponent } from './ptp-success.component';

describe('PtpSuccessComponent', () => {
  let component: PtpSuccessComponent;
  let fixture: ComponentFixture<PtpSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ TestBedModule ],
      declarations: [ PtpSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtpSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
}); 
