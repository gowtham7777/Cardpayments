// Angular
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgModule } from '@angular/core';

// Third party
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha';
import { TextMaskModule } from 'angular2-text-mask';

// Custom
import { SharedModule } from '../shared/shared.module';
import { PersonalInfoComponent } from './personal-info.component';
import { LimitedInputDirective } from '@common/directives/limited-input/limited-input.directive';
import { ExistingAccountModule } from '../existing-account/existing-account.module';
import { ExistingAccountComponent } from '../existing-account/existing-account.component';
import { MatDialogModule } from '@angular/material';


@NgModule({
  declarations: [
    PersonalInfoComponent,
    LimitedInputDirective,
  ],
  entryComponents: [ExistingAccountComponent],
  imports: [
    CommonModule,
    MatInputModule,
    MatSelectModule,
    SharedModule,
    ExistingAccountModule,
    RecaptchaModule.forRoot(),
    RecaptchaFormsModule,
    TextMaskModule,
    MatDialogModule
  ],
  providers: [], // services go here
  exports: [
    PersonalInfoComponent
  ]
})
export class PersonalInfoModule { }
