// Angular
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
    Component,
    Input,
    OnInit,
    OnDestroy,
    ChangeDetectorRef,
    AfterViewInit
} from '@angular/core';

import { Title } from '@angular/platform-browser';
import { MatDialog } from '@angular/material';

// Third-Party

import { TranslateService } from '@ngx-translate/core';

// Common
import { AnalyticsService } from '@common/services/analytics.service';
import { StringSanitizePipe } from '@common/pipes/string-sanitize-pipe';

// Models
import { Address } from '@models/address.model';
import { Consumer } from '@models/consumer.model';

// Services
import { ConsumerService } from '@services/consumer.service';
import { RoutingService } from '@services/routing.service';
import { CaptchaService } from '@services/captcha.service';

// Misc
import { AgeValidator } from '@app/validators/age.validator';
import { AppConfig } from '@app/app.config';

import { dateValidator } from '@app/validators/date.validator';
import { RouteNames } from '@app/app.route-names';

import { ExistingAccountComponent } from '../existing-account/existing-account.component';
import { AppConfigService } from '@common/services/app-config.service';

@Component({
    selector: 'personal-info',
    templateUrl: './personal-info.component.html'
})
export class PersonalInfoComponent implements OnInit, OnDestroy, AfterViewInit {
    public loadingRequest = false;
    public maxLenName = 25;
    public maxLenStreet = 60;
    public maxLenCity = 25;
    public maxLenZip = 5;
    regexFirstName =
        "^[a-zA-ZáàâãæèéëêẽíïîóôỡœúùüûữçñÁÀÂÃÆÈÉËÊẼÍÏÎÓÔỠŒÚÙÜÛỮÇÑ'-\\s.]{1," +
        this.maxLenName +
        '}$';
    regexLastName =
        "^[a-zA-ZáàâãæèéëêẽíïîóôỡœúùüûữçñÁÀÂÃÆÈÉËÊẼÍÏÎÓÔỠŒÚÙÜÛỮÇÑ'-\\s.\\/]{1," +
        this.maxLenName +
        '}$';
    regexStreetAddr =
        "^[0-9a-zA-ZáàâæèéëêíïîóôœúùüûçñÁÀÂÆÈÉËÊÍÏÎÓÔŒÚÙÜÛÇÑ'-\\s/.,#]{1," +
        this.maxLenStreet +
        '}$';
    regexCityAddr =
        "^[a-zA-ZáàâæèéëêíïîóôœúùüûçñÁÀÂÆÈÉËÊÍÏÎÓÔŒÚÙÜÛÇÑ'-\\s.]{1," +
        this.maxLenCity +
        '}$';
    regexSSN = '^[0-9]{9}$';
    regexSSNMasked = '^XXX-XX-[0-9]{4}$';
    regexPhoneNumber = '^[0-9]{10}$';
    regexPhoneNumberMasked = '^[0-9]{3}-[0-9]{3}-XXXX$';
    regexZipCode = '^[0-9]{5}$';

    private setCaptchaFunctionName = 'setCaptchaValue';
    showCaptchaError = false;
    hideRequiredMessage: boolean;
    personalInfoForm: FormGroup;
    public siteKey$;
    public zipMask = [/\d/, /\d/, /\d/, /\d/, /\d/];
    public title: string;
    private translateService;

    // Used for dynamic masking of SSN and phone number
    private hideSsn = false;
    private hideNum = false;
    public phoneNumberMask = [
        /[1-9]/,
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        /\d/
    ];
    public phoneNumberHideMask = [
        /[1-9]/,
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        '-',
        /[X]/,
        /[X]/,
        /[X]/,
        /[X]/
    ];
    public ssnMask = [
        /\d/,
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        /\d/
    ];
    public ssnHideMask = [
        /[X]/,
        /[X]/,
        /[X]/,
        '-',
        /[X]/,
        /[X]/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        /\d/
    ];

    public memberCenterURL;
    public isMobileApp;
    public minAgeToRegister;
    public mobileQueryParamValue;
    public mobileQueryParam;

    constructor(
        translate: TranslateService,
        private fb: FormBuilder,
        private consumerService: ConsumerService,
        private analyticsService: AnalyticsService,
        private captchaService: CaptchaService,
        private router: Router,
        private routingService: RoutingService,
        private titleService: Title,
        private routeNames: RouteNames,
        private config: AppConfig,
        private ref: ChangeDetectorRef,
        private dialog: MatDialog,
        private configService: AppConfigService
    ) {
        this.createForm();
        this.configService.getConfigurationData$().subscribe(config => {
            this.memberCenterURL = config.successMCLoginUrl;
            this.minAgeToRegister = config.minAgeToRegister;
            this.updateAgeValidator();
        });
        this.translateService = translate;
        this.updatePageTitle();
        this.isMobileApp = this.configService.isMobileApp;
        this.mobileQueryParamValue = this.configService.mobileQueryParamValue;
        this.mobileQueryParam = this.config.mobileQueryParam;
    }

    ngOnInit() {
        this.createCaptchaTestingHook();
        this.hideRequiredMessage = true;
        this.captchaService.retrieveCaptchaSiteKey().subscribe(
            data => {
                this.siteKey$ = data['siteKey'];
            },
            error => {}
        );
        this.analyticsService.appendEvent({
            eventData: {
                eventName: this.config.analytics.personalInfo.pageLoad
                    .eventName,
                pageName: this.config.analytics.personalInfo.pageLoad.pageName
            },
            eventIds: this.config.analytics.personalInfo.pageLoad.eventIds
        });
    }

    // Drop this web accessibility fix for Angular 8 update
    ngAfterViewInit() {
        document.getElementById('state').setAttribute('role', 'combobox');
    }

    ngOnDestroy(): void {
        delete window[this.setCaptchaFunctionName];
    }

    resolved(captchaResponse: string) {}

    getMinAgeError = () => {
        return this.translateService.get(
            'personal-info.form.dateOfBirth.error',
            { minAge: this.minAgeToRegister }
        ).value;
    };

    createForm = () => {
        this.personalInfoForm = this.fb.group({
            firstName: [
                '',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(this.maxLenName),
                    Validators.pattern(this.regexFirstName)
                ]
            ],

            lastName: [
                '',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(this.maxLenName),
                    Validators.pattern(this.regexLastName)
                ]
            ],
            dateOfBirth: ['', [Validators.required, dateValidator('US')]],
            socialSecurity: [
                '',
                [Validators.required, Validators.pattern(this.regexSSN)]
            ],
            socialSecurityMasked: [
                '',
                [
                    // Validator set in ssnEditing / ssnEdited
                ]
            ],
            address: [
                '',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(this.maxLenStreet),
                    Validators.pattern(this.regexStreetAddr)
                ]
            ],
            address2: [
                '',
                [
                    Validators.minLength(1),
                    Validators.maxLength(this.maxLenStreet),
                    Validators.pattern(this.regexStreetAddr)
                ]
            ],
            city: [
                '',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(this.maxLenCity),
                    Validators.pattern(this.regexCityAddr)
                ]
            ],
            state: ['', [Validators.required]],
            zip: [
                '',
                [
                    Validators.required,
                    Validators.maxLength(this.maxLenZip),
                    Validators.pattern(this.regexZipCode)
                ]
            ],
            phoneNumber: ['', [Validators.pattern(this.regexPhoneNumber)]],
            phoneNumberMasked: [
                '',
                [
                    // Validator set in phoneNumberEditing / phoneNumberEdited
                ]
            ],
            reCaptcha: ['', [Validators.required]]
        });
    };

    isControlValid = (controlName: string) => {
        // first check if control has been touched
        if (!this.personalInfoForm.get(controlName).dirty) {
            // supress error until control recieved input
            return true;
        } else {
            // test using FormControl validators
            return this.personalInfoForm.get(controlName).status !== 'INVALID'
                ? true
                : false;
        }
    };

    returnValidatorErrors = (controlName: string) => {
        // first check if control has been touched
        if (!this.personalInfoForm.get(controlName).dirty) {
            // supress error until control recieved input
            return false;
        } else if (this.personalInfoForm.get(controlName).errors) {
            // be careful we don't throw a null error to the view
            return this.personalInfoForm.get(controlName).errors;
        }
    };

    getMonthMask(firstDigit) {
        return firstDigit === '0'
            ? [/[01]/, /[1-9]/] // 01-09
            : [/[01]/, /[0-2]/]; // 10-12
    }

    getDayMask(firstDigit) {
        return firstDigit === '0'
            ? [/[0-3]/, /[1-9]/] // 01-09
            : firstDigit === '3'
            ? [/[0-3]/, /[0-1]/] // 30-31
            : [/[0-3]/, /[0-9]/]; // 10-29
    }

    getYearMask(firstDigit) {
        return firstDigit === '1'
            ? [/[12]/, /[9]/, /[0-9]/, /[0-9]/] // 1900s
            : [/[12]/, /[0-9]/, /[0-9]/, /[0-9]/]; // 2000s
    }

    // Returns the char-by-char text mask for DoB as the user is typing
    dobMask(rawValue) {
        if (rawValue) {
            const monthPos = 0,
                dayPos = 3,
                yearPos = 6;
            let monthMask = [/[01]/, /[0-9]/];
            let dayMask = [/[0-3]/, /[0-9]/];
            let yearMask = [/[12]/, /[0-9]/, /[0-9]/, /[0-9]/];

            if (rawValue.length > monthPos) {
                monthMask = this.getMonthMask(rawValue[monthPos]);
            }
            if (rawValue.length > dayPos) {
                dayMask = this.getDayMask(rawValue[dayPos]);
            }
            if (rawValue.length > yearPos) {
                yearMask = this.getYearMask(rawValue[yearPos]);
            }
            return [...monthMask, '/', ...dayMask, '/', ...yearMask];
        }

        return false;
    }

    updateAgeValidator() {
        const dobControl = this.personalInfoForm.controls['dateOfBirth'];
        dobControl.setValidators([
            AgeValidator(this.minAgeToRegister),
            dateValidator('US')
        ]);
    }

    ssnEdited() {
        this.hideSsn = true;
        const ssn = this.personalInfoForm.controls['socialSecurity'];
        const ssnMasked = this.personalInfoForm.controls[
            'socialSecurityMasked'
        ];
        const ssnValue = ssnMasked.value.replace(/-/g, '');

        // Mark socialSecurity form as dirty if SSN has value
        if (ssnValue !== '') {
            this.personalInfoForm.get('socialSecurity').markAsDirty();
        }

        // Update SSN values (both hidden input and the masked input)
        this.personalInfoForm.patchValue({
            socialSecurity: ssnValue,
            socialSecurityMasked: 'XXX-XX-' + ssnValue.slice(5)
        });

        // Revalidate after the update
        ssn.updateValueAndValidity();

        // If all is good, change validator to check for masked SSN
        ssnMasked.setValidators(
            Validators.pattern(ssn.valid ? this.regexSSNMasked : this.regexSSN)
        );
        ssnMasked.updateValueAndValidity();
    }

    ssnEditing() {
        this.hideSsn = false;
        const ssn = this.personalInfoForm.controls['socialSecurity'];
        const ssnMasked = this.personalInfoForm.controls[
            'socialSecurityMasked'
        ];

        // While editing, validator should check for unmasked SSN
        ssnMasked.setValidators(Validators.pattern(this.regexSSN));

        this.personalInfoForm.patchValue({
            socialSecurityMasked: ssn.value
        });
    }

    dynamicSsnMask() {
        return this.hideSsn ? this.ssnHideMask : this.ssnMask;
    }

    phoneNumberEdited() {
        this.hideNum = true;
        const phoneNumber = this.personalInfoForm.controls['phoneNumber'];
        const phoneNumberMasked = this.personalInfoForm.controls[
            'phoneNumberMasked'
        ];
        const phoneNumberVal = phoneNumberMasked.value.replace(/-/g, '');

        // Mark form as dirty if phone number input has value
        if (phoneNumberVal !== '') {
            this.personalInfoForm.get('phoneNumber').markAsDirty();
        }

        // Update phone number values (both hidden input and the masked input)
        this.personalInfoForm.patchValue({
            phoneNumber: phoneNumberVal,
            phoneNumberMasked: this.maskPhoneNumber(phoneNumberVal)
        });

        // Revalidate after the update
        phoneNumber.updateValueAndValidity();

        // If all is good, change validator to check for masked number
        let validator;

        if (!phoneNumber.value) {
            // Phone number is optional, so no validator needed if phoneNumber blank
            validator = null;
        } else if (phoneNumber.valid) {
            validator = this.regexPhoneNumberMasked;
        } else if (!phoneNumber.valid) {
            validator = this.regexPhoneNumber;
        }

        phoneNumberMasked.setValidators(Validators.pattern(validator));
        phoneNumberMasked.updateValueAndValidity();
    }

    phoneNumberEditing() {
        this.hideNum = false;
        const phoneNumber = this.personalInfoForm.controls['phoneNumber'];
        const phoneNumberMasked = this.personalInfoForm.controls[
            'phoneNumberMasked'
        ];

        // While editing, validator should check for unmasked #
        phoneNumberMasked.setValidators(
            Validators.pattern(this.regexPhoneNumber)
        );

        this.personalInfoForm.patchValue({
            phoneNumberMasked: phoneNumber.value
        });
    }

    dynamicPhoneNumberMask() {
        return this.hideNum ? this.phoneNumberHideMask : this.phoneNumberMask;
    }

    maskPhoneNumber(number) {
        const partOne = number.substring(0, 3);
        const partTwo = number.substring(3, 6);
        return `${partOne}-${partTwo}-XXXX`;
    }

    updatePageTitle() {
        // Using stream() because PII is the starting page. It is displayed before the translate service lang is set.
        // The stream method updates the translation when the language is changed.
        this.translateService
            .stream('personal-info.browserTitle.pageLoadTitle')
            .subscribe((result: string) => {
                this.titleService.setTitle(result);
            });
    }

    submitForm = () => {
        this.loadingRequest = true;
        const addressForm: Address = {
            addressLine1: this.personalInfoForm.controls.address.value,
            addressLine2: this.personalInfoForm.controls.address2.value,
            cityName: this.personalInfoForm.controls.city.value,
            stateAbbreviation: this.personalInfoForm.controls.state.value,
            zipCode: this.personalInfoForm.controls.zip.value
        };
        const consumerForm: Consumer = {
            firstName: this.personalInfoForm.controls.firstName.value,
            lastName: this.personalInfoForm.controls.lastName.value,
            dateOfBirth: this.personalInfoForm.controls.dateOfBirth.value,
            ssn: this.personalInfoForm.controls.socialSecurity.value,
            address: addressForm,
            phoneNumber: this.personalInfoForm.controls.phoneNumber.value,
            reCaptchaResponse: this.personalInfoForm.controls.reCaptcha.value
        };
        this.consumerService.saveConsumer(consumerForm).subscribe(
            // Successful responses call the first callback.
            data => {
                if (data.statusCode === this.config.personalInfoConfirmation) {
                    this.routingService.enableNavigationTo(
                        this.routeNames.accountCreation
                    );
                    this.router.navigate([this.routeNames.accountCreation]);
                } else if (
                    data.statusCode === this.config.personalInfoRecaptcha
                ) {
                    this.showCaptchaError = true;
                    window.scrollTo(0, 0);
                } else if (data.statusCode === this.config.saveConsumerExist) {
                    this.openExistingAccountDialog();
                } else if (data.statusCode === this.config.cidUnavailable) {
                    this.router.navigate([this.routeNames.callCenterNoHit]);
                } else if (
                    data.statusCode ===
                    this.config.indirectEnrollmentSystemError
                ) {
                    this.router.navigate([this.routeNames.systemError]);
                } else {
                    this.router.navigate([this.routeNames.systemError]);
                }
            },
            // Errors will call this callback instead:
            err => {
                this.router.navigate([this.routeNames.systemError]);
            },
            // Reset the loading status of the request
            () => {
                this.loadingRequest = false;
            }
        );
    };

    openExistingAccountDialog = () => {
        window.scrollTo(0, 0);
        const dialogRef = this.dialog.open(ExistingAccountComponent);

        this.translateService
            .get('existing-account.title')
            .subscribe((result: string) => {
                this.titleService.setTitle(result);
            });

        // this.analyticsService.appendEvent({
        //   eventData: {
        //     eventName: this.config.analytics.createAccount.emailInUse.eventName
        //   },
        //   eventIds: this.config.analytics.createAccount.emailInUse.eventIds
        // });

        dialogRef.afterClosed().subscribe(result => {
            this.translateService
                .get('personal-info.browserTitle.pageLoadTitle')
                .subscribe((result1: string) => {
                    this.titleService.setTitle(result1);
                });
            if (result === 'login') {
                if (this.memberCenterURL) {
                    window.location.href = this.configService.updateUrlForMobileParam(
                        this.memberCenterURL
                    );
                } else {
                    this.router.navigate([this.routeNames.systemError]);
                }
            }
        });
    };

    createCaptchaTestingHook() {
        // For automated testing, when test captcha key is used
        // prepopulate reCaptcha value to allow form to proceed
        // Open to a better solution
        window[this.setCaptchaFunctionName] = val => {
            this.personalInfoForm.get('reCaptcha').patchValue(val);
            this.ref.detectChanges();
        };
    }

    sanitizePiiField(piiFieldName: string) {
        const piiField = this.personalInfoForm.controls[piiFieldName];
        const regex =
            "[^0-9a-zA-ZáàâæèéëêíïîóôœúùüûçñÁÀÂÆÈÉËÊÍÏÎÓÔŒÚÙÜÛÇÑ\\ \\-.#',/\\\\]";

        this.personalInfoForm.patchValue({
            [piiFieldName]: StringSanitizePipe.prototype.transform(
                piiField.value,
                regex
            )
        });
    }
}