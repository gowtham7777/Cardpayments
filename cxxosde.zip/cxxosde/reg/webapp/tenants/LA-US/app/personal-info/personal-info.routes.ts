import { Route } from '@angular/router';
import { PersonalInfoComponent } from './personal-info.component';
import { PiiGuard } from '@app/guards/pii.guard';

export const PersonalInfoRoutes: Route[] = [
  {
    path: 'personal-info',
    component: PersonalInfoComponent,
    canActivate: [PiiGuard]
  }
];
