// Angular
import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import {

  MatFormFieldModule,
  MatSelectModule,
  MatInputModule,
  MatDialogModule
} from '@angular/material';
import { Observable, Subscriber } from 'rxjs';
import { Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';


// Modules
import { RecaptchaFormsModule } from 'ng-recaptcha';
import { RecaptchaModule } from 'ng-recaptcha';
import { SharedModule } from '../shared/shared.module';
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';
import { TextMaskModule } from 'angular2-text-mask';

// Services
import { CaptchaService } from '@services/captcha.service';
import { ConsumerService } from '@services/consumer.service';
import {
  MockConsumerService,
  MockCaptchaService
} from '@app/app.mock-services';
import { RoutingService } from '@services/routing.service';

// Components
import { PersonalInfoComponent } from './personal-info.component';
import { LimitedInputDirective } from '@common/directives/limited-input/limited-input.directive';

// Misc
import { RouteNames } from '@app/app.route-names';
import { PersonalInfoRoutes } from './personal-info.routes';
const limitedRoutes: Routes = BaseRoutesWith(PersonalInfoRoutes);

describe('PersonalInfoComponent', () => {
  let component: PersonalInfoComponent;
  let fixture: ComponentFixture<PersonalInfoComponent>;
  const mockSsn = '123-45-6789';
  const mockNumber = '123-456-7890';
  const mockSsnMasked = 'XXX-XX-6789';
  const mockNumberMasked = '123-456-XXXX';
  const maskedSsnControlName = 'socialSecurityMasked';
  const maskedNumberControlName = 'phoneNumberMasked';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PersonalInfoComponent, LimitedInputDirective],
      imports: [
        SharedModule,
        TestBedModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        TextMaskModule,
        RecaptchaModule,
        MatDialogModule,
        RouterTestingModule.withRoutes(limitedRoutes)
      ],
      providers: [
        { provide: ConsumerService, useClass: MockConsumerService },
        { provide: CaptchaService, useClass: MockCaptchaService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // ==========================================================================
  // Masking
  // ==========================================================================

  // Date of birth
  it('should mask DoB according to date regex', () => {
    expect(component.getMonthMask('0')).toEqual(
      [/[01]/, /[1-9]/],
      '0 dob first month digit should allow 1-9 second digit'
    );
    expect(component.getMonthMask('1')).toEqual(
      [/[01]/, /[0-2]/],
      '1 dob first month digit should allow 0-2 second digit'
    );
    expect(component.getDayMask('0')).toEqual(
      [/[0-3]/, /[1-9]/],
      '0 dob first day digit should allow 1-9 second digit'
    );
    expect(component.getDayMask('1')).toEqual(
      [/[0-3]/, /[0-9]/],
      '1 dob first day digit should allow 0-9 second digit'
    );
    expect(component.getDayMask('2')).toEqual(
      [/[0-3]/, /[0-9]/],
      '2 dob first day digit should allow 0-9 second digit'
    );
    expect(component.getDayMask('3')).toEqual(
      [/[0-3]/, /[0-1]/],
      '3 dob first day digit should allow 0-1 second digit'
    );
    expect(component.getYearMask('1')).toEqual(
      [/[12]/, /[9]/, /[0-9]/, /[0-9]/],
      '1 dob first year digit should restrict to 1900s'
    );
    expect(component.getYearMask('2')).toEqual(
      [/[12]/, /[0-9]/, /[0-9]/, /[0-9]/],
      '2 dob first year digit should restrict to 2000s'
    );
    expect(component.dobMask('01/01/1980')).toEqual(
      [
        /[01]/,
        /[1-9]/,
        '/',
        /[0-3]/,
        /[1-9]/,
        '/',
        /[12]/,
        /[9]/,
        /[0-9]/,
        /[0-9]/
      ],
      'dob mask 01/01/1980 should return return valid mask'
    );
  });

  // SSN
  it('should mask 123-45-6789 as XXX-XX-6789', () => {
    component.personalInfoForm.controls[maskedSsnControlName].patchValue(
      mockSsn
    );
    component.ssnEdited();

    // We will test the actual form since it's tightly coupled to the ssnEdited function
    const maskedSsnControlValue = component.personalInfoForm.get(
      maskedSsnControlName
    ).value;
    expect(maskedSsnControlValue).toBe(
      mockSsnMasked,
      `Masked SSN is ${maskedSsnControlValue}`
    );
  });

  it('should not mask the input value while editing ssn', () => {
    component.ssnEditing();
    component.personalInfoForm.controls[maskedSsnControlName].patchValue(
      mockSsn
    );

    const maskedSsnControlValue = component.personalInfoForm.get(
      maskedSsnControlName
    ).value;
    expect(maskedSsnControlValue).toBe(
      mockSsn,
      `Masked SSN is ${maskedSsnControlValue}`
    );
  });

  // Phone number
  it('should mask the phone number 123-456-7890 as 123-456-XXXX', () => {
    component.personalInfoForm.controls[maskedNumberControlName].patchValue(
      mockNumber
    );
    component.phoneNumberEdited();

    // We will test the actual form since it's tightly coupled to the phoneNumberEdited function
    const maskedNumberControlValue = component.personalInfoForm.get(
      maskedNumberControlName
    ).value;
    expect(maskedNumberControlValue).toBe(
      mockNumberMasked,
      `Masked number is ${maskedNumberControlValue}`
    );
  });

  it('should not mask the input value while editing phone number', () => {
    component.phoneNumberEditing();
    component.personalInfoForm.controls[maskedNumberControlName].patchValue(
      mockNumber
    );

    const maskedNumberControlValue = component.personalInfoForm.get(
      maskedNumberControlName
    ).value;
    expect(maskedNumberControlValue).toBe(
      mockNumber,
      `Masked number is ${maskedNumberControlValue}`
    );
  });

  it('should mask the last 4 digits of a phone number', () => {
    expect(component.maskPhoneNumber('1234567890')).toBe(
      '123-456-XXXX',
      '1234567890 should be 123-456-XXXX'
    );
    expect(component.maskPhoneNumber('123')).toBe(
      '123--XXXX',
      '123 should be 123--XXXX'
    );
    expect(component.maskPhoneNumber('')).toBe(
      '--XXXX',
      'empty value should be --XXXX'
    );
  });

  // ==========================================================================
  // Input regex testing
  // ==========================================================================

  // First name
  it('should correctly validate the first name', () => {
    expect('Bo').toMatch(component.regexFirstName, 'Bo should be valid');
    expect('Ricky Bobby').toMatch(
      component.regexFirstName,
      'Ricky Bobby should be valid'
    );
    expect('Ricky-Bobby').toMatch(
      component.regexFirstName,
      'Ricky-Bobby should be valid'
    );
    expect('AbraKadabraAlakazamPlease').toMatch(
      component.regexFirstName,
      'AbraKadabraAlakazamPlease should be valid'
    );
    expect('AbraKadabraAlakazamPleaseNo').not.toMatch(
      component.regexFirstName,
      'AbraKadabraAlakazamPleaseNo should not be valid'
    );
    expect('Eve--Evans/Mike').not.toMatch(
      component.regexFirstName,
      'Eve--Evans/Mike should not be valid'
    );
    expect('1234').not.toMatch(
      component.regexFirstName,
      '1234 should not be valid'
    );
    expect('').not.toMatch(
      component.regexFirstName,
      'empty value should not be valid'
    );
  });

  // Last Name
  it('should correctly validate the last name', () => {
    expect('Bo').toMatch(component.regexLastName, 'Bo should be valid');
    expect('Ricky Bobby').toMatch(
      component.regexLastName,
      'Ricky Bobby should be valid'
    );
    expect('Eve--Evans/Mike').toMatch(
      component.regexLastName,
      'Eve--Evans/Mike should be valid'
    );
    expect('AbraKadabraAlakazamPlease').toMatch(
      component.regexLastName,
      'AbraKadabraAlakazamPlease should be valid'
    );
    expect('AbraKadabraAlakazamPleaseNo').not.toMatch(
      component.regexLastName,
      'AbraKadabraAlakazamPleaseNo should not be valid'
    );
    expect('1234').not.toMatch(
      component.regexLastName,
      '1234 should not be valid'
    );
    expect('').not.toMatch(
      component.regexLastName,
      'empty last name should not be valid'
    );
  });

  // SSN
  it('should correctly validate the ssn', () => {
    expect('123456789').toMatch(
      component.regexSSN,
      '123456789 should be valid'
    );
    expect('12345678a').not.toMatch(
      component.regexSSN,
      '12345678a should not be valid'
    );
    expect('').not.toMatch(component.regexSSN, 'blank SSN should not be valid');
  });

  // Phone Number
  it('should correctly validate the phone number', () => {
    expect('1234567890').toMatch(
      component.regexPhoneNumber,
      '1234567890 should be a valid phone number'
    );
    expect('12345678a').not.toMatch(
      component.regexPhoneNumber,
      '123456789a should not be a valid phone number'
    );
  });

  // Zip Code
  it('should correctly validate the zip code', () => {
    expect('12345').toMatch(component.regexZipCode, '12345 should be valid');
    expect('1234a').not.toMatch(
      component.regexZipCode,
      '1234a should not be valid'
    );
    expect('1234566798').not.toMatch(
      component.regexZipCode,
      '1234566798 should not be valid'
    );
    expect('').not.toMatch(
      component.regexZipCode,
      'blank zip should not be valid'
    );
  });

  // ==========================================================================
  // Form
  // ==========================================================================

  it('should detect a clean form', () => {
    expect(
      component.returnValidatorErrors(maskedNumberControlName)
    ).toBeFalsy();
  });

  it('should find form errors', () => {
    component.personalInfoForm.controls['zip'].patchValue('1234567');
    component.personalInfoForm.controls['zip'].updateValueAndValidity();
    component.personalInfoForm.controls['zip'].markAsDirty();
    expect(component.returnValidatorErrors('zip')).toBeTruthy();
  });

  it('should route to account creation after form is successfully submitted', inject(
    [Router, RoutingService],
    (router: Router, routingService: RoutingService) => {
      const mockRoutes = TestBed.get(RouteNames);
      const mockConsumerService = TestBed.get(ConsumerService);
      spyOn(router, 'navigate').and.stub();
      spyOn(routingService, 'enableNavigationTo').and.stub();
      spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
        new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next({
            statusCode: component['config'].personalInfoConfirmation
          })
        )
      );
      component.submitForm();
      expect(routingService.enableNavigationTo).toHaveBeenCalledWith(
        mockRoutes.accountCreation
      );
      expect(router.navigate).toHaveBeenCalledWith([
        mockRoutes.accountCreation
      ]);
    }
  ));

  it('should show captcha error if response status had an issue with the recaptcha', () => {
    const mockConsumerService = TestBed.get(ConsumerService);
    spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
      new Observable<any>((subscriber: Subscriber<any>) =>
        subscriber.next({
          statusCode: component['config'].personalInfoRecaptcha
        })
      )
    );
    component.submitForm();
    expect(component.showCaptchaError).toBeTruthy();
  });

  it('should show captcha error if response status had an issue with the customer exists', () => {
    spyOn(component as any, 'openExistingAccountDialog').and.stub();
    const mockConsumerService = TestBed.get(ConsumerService);
    spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
      new Observable<any>((subscriber: Subscriber<any>) =>
        subscriber.next({ statusCode: component['config'].saveConsumerExist })
      )
    );
    component.submitForm();
    expect(component['openExistingAccountDialog']).toHaveBeenCalled();
  });

  it('should route to call-center noHit page when CID is not available', inject(
    [Router, RoutingService],
    (router: Router, routingService: RoutingService) => {
      const mockRoutes = TestBed.get(RouteNames);
      const mockConsumerService = TestBed.get(ConsumerService);
      spyOn(router, 'navigate').and.stub();
      spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
        new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next({ statusCode: component['config'].cidUnavailable })
        )
      );
      component.submitForm();
      expect(router.navigate).toHaveBeenCalledWith([
        mockRoutes.callCenterNoHit
      ]);
    }
  ));

  it('should route to system error page if no data ', inject(
    [Router, RoutingService],
    (router: Router, routingService: RoutingService) => {
      const mockRoutes = TestBed.get(RouteNames);
      const mockConsumerService = TestBed.get(ConsumerService);
      spyOn(router, 'navigate').and.stub();
      spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
        new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next({})
        )
      );
      component.submitForm();
      expect(router.navigate).toHaveBeenCalledWith([mockRoutes.systemError]);
    }
  ));

  it('should route to system error page if submission failed', inject(
    [Router, RoutingService],
    (router: Router, routingService: RoutingService) => {
      const mockRoutes = TestBed.get(RouteNames);
      const mockConsumerService = TestBed.get(ConsumerService);
      spyOn(router, 'navigate').and.stub();
      spyOn(mockConsumerService, 'saveConsumer').and.returnValue(
        new Observable<Error>((subscriber: Subscriber<Error>) =>
          subscriber.error()
        )
      );
      component.submitForm();
      expect(router.navigate).toHaveBeenCalledWith([mockRoutes.systemError]);
    }
  ));
});
