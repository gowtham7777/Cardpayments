import { MatDialogModule } from '@angular/material';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { EmailInUseComponent } from './email-in-use.component';

@NgModule({
  declarations: [
    EmailInUseComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    MatDialogModule
  ],
  providers: [], // services go here
  exports: [
    EmailInUseComponent
  ]
})
export class EmailInUseModule { }
