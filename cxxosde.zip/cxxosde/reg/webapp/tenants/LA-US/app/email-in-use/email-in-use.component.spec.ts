import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedModule } from '@shared/shared.module';

import { EmailInUseComponent } from './email-in-use.component';

describe('EmailInUseComponent', () => {
  let component: EmailInUseComponent;
  let fixture: ComponentFixture<EmailInUseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailInUseComponent ],
      imports: [
        TestBedModule,
        SharedModule,
        MatDialogModule
      ],
      providers: [
        {provide: MatDialogRef, useValue: {}},
        {provide: MAT_DIALOG_DATA, useValue: {}}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailInUseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
