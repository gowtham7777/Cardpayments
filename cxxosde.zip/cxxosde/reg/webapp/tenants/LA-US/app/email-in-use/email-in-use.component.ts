import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { AnalyticsService } from '@common/services/analytics.service';

@Component({
  selector: 'email-in-use',
  templateUrl: './email-in-use.component.html',
  styleUrls: ['./email-in-use.component.scss']
})
export class EmailInUseComponent implements OnInit {
  constructor(
    translate: TranslateService,
    public analytics: AnalyticsService,
    private dialogRef: MatDialogRef<EmailInUseComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

     }

    onNoClick(): void {
      this.dialogRef.close();
    }

    onTryAgain(): void {
      this.dialogRef.close('tryAgain');
    }

    onLogin(): void {
      this.dialogRef.close('login');
    }

    ngOnInit() {
    }
}
