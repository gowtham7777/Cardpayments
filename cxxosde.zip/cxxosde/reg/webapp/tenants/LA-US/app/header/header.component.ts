import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RouteNames } from '@app/app.route-names';
import { RoutingService } from '@services/routing.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  constructor(
    private router: Router,
    private routes: RouteNames,
    private routingService: RoutingService
  ) { }

  ngOnInit() {
  }

  routeToHome(){
    this.routingService.enableNavigationTo(this.routes.personalInfo);
    this.router.navigate([this.routes.personalInfo]);
  }
}
