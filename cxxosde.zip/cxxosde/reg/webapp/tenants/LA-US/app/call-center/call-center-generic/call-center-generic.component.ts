import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { AppConfig } from '@app/app.config';
import { AnalyticsService } from '@common/services/analytics.service';


@Component({
  selector: 'app-call-center-generic',
  templateUrl: './call-center-generic.component.html',
  styleUrls: ['./call-center-generic.component.scss']
})
export class CallCenterGenericComponent implements OnInit {

  constructor(
    public analyticsService: AnalyticsService,
    private config: AppConfig,
    private translate: TranslateService,
    private titleService: Title
  ) {}

  ngOnInit() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.callCenter.generic.eventName,
        pageName: this.config.analytics.callCenter.generic.pageName
      },
      eventIds: this.config.analytics.callCenter.generic.eventIds
    });
    this.translate.get('call-center.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
