import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { CallCenterModule } from '@app/call-center/call-center.module';
import { PtpService } from '@app/ptp/ptp.service';
import { MockPtpService } from '@app/app.mock-services';

import { CallCenterPtpComponent } from './call-center-ptp.component';
import { AnalyticsService } from '@common/services/analytics.service';

describe('CallCenterPtpComponent', () => {
  let component: CallCenterPtpComponent;
  let fixture: ComponentFixture<CallCenterPtpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        CallCenterModule
      ],
      providers: [
        {provide: PtpService, useClass: MockPtpService},
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCenterPtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should opt in', () => {
    const mockPtpService = TestBed.get(PtpService);
    const mockAnalyticsService = TestBed.get(AnalyticsService);
    spyOn(mockPtpService, 'enrollPTP').and.stub();
    spyOn(mockAnalyticsService, 'appendEvent').and.stub();
    component.optIn();
    expect(mockPtpService.enrollPTP).toHaveBeenCalled();
    expect(mockAnalyticsService.appendEvent).toHaveBeenCalled();
  })
});
