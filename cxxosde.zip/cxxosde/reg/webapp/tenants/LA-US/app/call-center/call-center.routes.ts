import { CallCenterNohitComponent } from './call-center-nohit/call-center-nohit.component';
import { CallCenterGenericComponent } from './call-center-generic/call-center-generic.component';
import { Route } from '@angular/router';
import { CallCenterPtpComponent  } from './call-center-ptp/call-center-ptp.component';
import { CallCenterKbaTimeoutComponent } from './call-center-kba-timeout/call-center-kba-timeout.component';

export const CallCenterRoutes: Route[] = [
  {
    path: 'call-center-ptp',
    component: CallCenterPtpComponent
  },
  {
    path: 'call-center-kba-timeout',
    component: CallCenterKbaTimeoutComponent
  },
  {
    path: 'call-center-generic',
    component: CallCenterGenericComponent
  },
  {
    path: 'call-center-nohit',
    component: CallCenterNohitComponent
  }
];
