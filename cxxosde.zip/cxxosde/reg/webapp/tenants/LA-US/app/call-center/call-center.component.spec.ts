import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { CallCenterModule } from '@app/call-center/call-center.module';

import { CallCenterComponent } from './call-center.component';

describe('CallCenterComponent', () => {
  let component: CallCenterComponent;
  let fixture: ComponentFixture<CallCenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        CallCenterModule
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
