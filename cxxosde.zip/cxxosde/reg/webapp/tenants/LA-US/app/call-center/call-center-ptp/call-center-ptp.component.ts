import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { PtpService } from '@app/ptp/ptp.service';
import { AppConfig } from '@app/app.config';
import { AnalyticsService } from '@common/services/analytics.service';

@Component({
  selector: 'app-call-center-ptp',
  templateUrl: './call-center-ptp.component.html',
  styleUrls: ['./call-center-ptp.component.scss']
})
export class CallCenterPtpComponent implements OnInit {
  ptpEligible = false;

  constructor(
    private ptpService: PtpService,
    public analyticsService: AnalyticsService,
    private config: AppConfig,
    private titleService: Title,
    private translate: TranslateService
  ) {
    this.ptpEligible = this.ptpService.isPtpEligible();
  }

  ngOnInit() {
    if (this.ptpEligible) {
      this.analyticsService.appendEvent({
        eventData: {
          eventName: this.config.analytics.ptp.callCcOrPinToMail.eventName,
          pageName: this.config.analytics.ptp.callCcOrPinToMail.pageName,
        },
        eventIds: this.config.analytics.ptp.callCcOrPinToMail.eventIds
      });
    } else {
      this.analyticsService.appendEvent({
        eventData: {
          eventName: this.config.analytics.ptp.pinNotAvailable.eventName,
          pageName: this.config.analytics.ptp.pinNotAvailable.pageName,
        },
        eventIds: this.config.analytics.ptp.pinNotAvailable.eventIds
      });
      this.translate.get('call-center.browserTitle.pageLoadTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    }
  }

  optIn() {
    this.ptpService.enrollPTP();
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.ptp.pinToMailInitiated.eventName,
      },
      eventIds: this.config.analytics.ptp.pinToMailInitiated.eventIds
    });
  }
}
