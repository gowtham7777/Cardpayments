import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { CallCenterModule } from '@app/call-center/call-center.module';

import { CallCenterNohitComponent } from './call-center-nohit.component';

describe('CallCenterNohitComponent', () => {
  let component: CallCenterNohitComponent;
  let fixture: ComponentFixture<CallCenterNohitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        CallCenterModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCenterNohitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
