import { Component } from '@angular/core';

import { RoutingService } from '@services/routing.service';
import { RouteNames } from '@app/app.route-names';

@Component({
  selector: 'app-call-center',
  templateUrl: './call-center.component.html',
  styleUrls: ['./call-center.component.scss']
})
export class CallCenterComponent {
    constructor(
        private routingService: RoutingService,
        private routes: RouteNames
    ) {
        this.routingService.enableNavigationTo(this.routes.personalInfo);
    }
}
