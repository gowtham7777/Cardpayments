import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { CallCenterModule } from '@app/call-center/call-center.module';

import { CallCenterKbaTimeoutComponent } from './call-center-kba-timeout.component';

describe('CallCenterKbaTimeoutComponent', () => {
  let component: CallCenterKbaTimeoutComponent;
  let fixture: ComponentFixture<CallCenterKbaTimeoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        CallCenterModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCenterKbaTimeoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
