import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfig } from '@app/app.config';

@Component({
  selector: 'app-call-center-kba-timeout',
  templateUrl: './call-center-kba-timeout.component.html',
  styleUrls: ['./call-center-kba-timeout.component.scss']
})
export class CallCenterKbaTimeoutComponent implements OnInit {

  constructor(
    public  analyticsService: AnalyticsService,
    private config: AppConfig,
    private translate: TranslateService,
    private titleService: Title
  ) {}

  ngOnInit() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.callCenter.kbaTimeOut.eventName,
        pageName: this.config.analytics.callCenter.kbaTimeOut.pageName
      },
      eventIds: this.config.analytics.callCenter.kbaTimeOut.eventIds
    });
    this.translate.get('call-center.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
