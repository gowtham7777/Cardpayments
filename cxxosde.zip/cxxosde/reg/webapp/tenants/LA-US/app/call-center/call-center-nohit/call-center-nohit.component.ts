import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { AnalyticsService } from '@common/services/analytics.service';
import { AppConfig } from '@app/app.config';

@Component({
  selector: 'app-call-center-nohit',
  templateUrl: './call-center-nohit.component.html',
  styleUrls: ['./call-center-nohit.component.scss']
})
export class CallCenterNohitComponent implements OnInit {

  constructor(
    public analyticsService:  AnalyticsService,
    private config: AppConfig,
    private translate: TranslateService,
    private titleService: Title
  ) {}

  ngOnInit() {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.config.analytics.callCenter.noHit.eventName,
        pageName: this.config.analytics.callCenter.noHit.pageName
      },
      eventIds: this.config.analytics.callCenter.noHit.eventIds
    });
    this.translate.get('call-center.browserTitle.pageLoadTitle').subscribe((result: string) => {
      this.titleService.setTitle(result);
    });
  }
}
