import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@shared/test-bed.module';
import { CallCenterModule } from '@app/call-center/call-center.module';

import { CallCenterGenericComponent } from './call-center-generic.component';

describe('CallCenterGenericComponent', () => {
  let component: CallCenterGenericComponent;
  let fixture: ComponentFixture<CallCenterGenericComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TestBedModule,
        CallCenterModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCenterGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
