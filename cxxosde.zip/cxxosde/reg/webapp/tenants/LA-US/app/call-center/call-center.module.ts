import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { CallCenterComponent } from './call-center.component';
import { CallCenterPtpComponent } from './call-center-ptp/call-center-ptp.component';
import { CallCenterKbaTimeoutComponent } from './call-center-kba-timeout/call-center-kba-timeout.component';
import { CallCenterGenericComponent } from './call-center-generic/call-center-generic.component';
import { CallCenterNohitComponent } from './call-center-nohit/call-center-nohit.component';

@NgModule({
  declarations: [
    CallCenterComponent,
    CallCenterPtpComponent,
    CallCenterKbaTimeoutComponent,
    CallCenterGenericComponent,
    CallCenterNohitComponent
  ],
  imports: [
    CommonModule,
    SharedModule
  ],
})
export class CallCenterModule { }
