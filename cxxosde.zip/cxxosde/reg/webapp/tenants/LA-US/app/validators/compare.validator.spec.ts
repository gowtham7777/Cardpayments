import { TestBed, async } from '@angular/core/testing';
import { CompareValidator } from './compare.validator';
import { FormControl } from '@angular/forms';
  
describe('CompareValidator', () => {
    it('equal values', () => {
        let value = 'testValue';
        let compareValidator = CompareValidator(() => value);
        expect(compareValidator(new FormControl(value))).toBeNull();
    });
    it('not equal values', () => {
        let value = 'testValue';
        let compareValidator = CompareValidator(() => value);
        expect(compareValidator(new FormControl('testValue2'))).toEqual({
            'invalidComparison': {
                value: 'testValue2',
                comparedValue: value
            }
        });
    });
})
