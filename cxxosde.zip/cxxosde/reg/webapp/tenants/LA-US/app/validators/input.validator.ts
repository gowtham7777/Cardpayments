import { ValidatorFn, AbstractControl, FormGroup } from '@angular/forms';

/** Validate the control.value matches the pattern of a callback value in a Validator for Reactive Forms */
export function InputValidator(inputValueFnc: any): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} => {
    const regpatternValue = inputValueFnc();
    const regpattern = new RegExp(regpatternValue);
    return control.value && regpatternValue &&
          !regpattern.test(control.value) ?
           {'invalidPatternValidation': {
              value: control.value,
              regpatternValue: regpatternValue
            }} : null;
  };
}
