import { TestBed, async } from '@angular/core/testing';
import { AgeValidator } from './age.validator';
import { FormControl } from '@angular/forms';

const minYears = 18;
const now = new Date();
const currentMonth = Number(now.getMonth() + 1); // month is 0-based
const currentDay = now.getDate();
const currentYear = now.getFullYear();
const validYears = currentYear - (minYears + 5);
const invalidYears = currentYear - (minYears - 5);
const exactYears = currentYear - minYears;
const validDate = `01/01/${validYears}`;
const invalidDate = `01/01/${invalidYears}`;
const padNum = (num) => { return (`0${num}`.slice(-2)); };
const validByOneMonth = `${padNum(Number(currentMonth - 1))}/01/${exactYears}`;
const exactDate = `${padNum(currentMonth)}/${padNum(currentDay)}/${exactYears}`;
const invalidByOneMonth = `${padNum(Number(currentMonth + 1))}/01/${exactYears}`;
const invalidByOneDay = `${padNum(currentMonth)}/${padNum(Number(currentDay + 1))}/${exactYears}`;
const ageValidator = AgeValidator(minYears);

describe('AgeValidator', () => {
    it('valid age', () => {
        expect(ageValidator(new FormControl(validDate))).toBeNull();
    });

    it('exact age', () => {
        expect(ageValidator(new FormControl(exactDate))).toBeNull();
    });

    it('valid by one month', () => {
        expect(ageValidator(new FormControl(validByOneMonth))).toBeNull();
    });

    it('invalid age', () => {
        expect(ageValidator(new FormControl(invalidDate))).toEqual({
            'invalidAge': {
                value: invalidDate,
                minimumAge: minYears
            }
        });
    });
    it('invalid by one month', () => {
        expect(ageValidator(new FormControl(invalidByOneMonth))).toEqual({
            'invalidAge': {
                value: invalidByOneMonth,
                minimumAge: minYears
            }
        });
    });
    it('invalid by one day', () => {
        expect(ageValidator(new FormControl(invalidByOneDay))).toEqual({
            'invalidAge': {
                value: invalidByOneDay,
                minimumAge: minYears
            }
        });
    });
})