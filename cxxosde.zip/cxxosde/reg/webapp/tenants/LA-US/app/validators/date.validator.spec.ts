import { TestBed, async } from '@angular/core/testing';
import { dateValidator } from './date.validator';
import { FormControl } from '@angular/forms';

const dateValidatorUS = dateValidator('US');

describe('DateValidator', () => {
    // Valid Dates
    it('valid 01/01/1985', () => {
        expect(dateValidatorUS(new FormControl('01/01/1985'))).toBeNull();
    });
    it('valid 02/02/1986', () => {
        expect(dateValidatorUS(new FormControl('02/02/1986'))).toBeNull();
    });
    it('valid 03/03/1987', () => {
        expect(dateValidatorUS(new FormControl('03/03/1987'))).toBeNull();
    });
    it('valid 04/04/1988', () => {
        expect(dateValidatorUS(new FormControl('04/04/1988'))).toBeNull();
    });
    it('valid 05/05/1989', () => {
        expect(dateValidatorUS(new FormControl('05/05/1989'))).toBeNull();
    });
    it('valid 06/06/1990', () => {
        expect(dateValidatorUS(new FormControl('06/06/1990'))).toBeNull();
    });
    it('valid 07/07/1991', () => {
        expect(dateValidatorUS(new FormControl('07/07/1991'))).toBeNull();
    });
    it('valid 08/08/1992', () => {
        expect(dateValidatorUS(new FormControl('08/08/1992'))).toBeNull();
    });
    it('valid 09/09/1993', () => {
        expect(dateValidatorUS(new FormControl('09/09/1993'))).toBeNull();
    });
    it('valid 10/10/1994', () => {
        expect(dateValidatorUS(new FormControl('10/10/1994'))).toBeNull();
    });
    it('valid 11/11/1995', () => {
        expect(dateValidatorUS(new FormControl('11/11/1995'))).toBeNull();
    });
    it('valid 12/12/1996', () => {
        expect(dateValidatorUS(new FormControl('12/12/1996'))).toBeNull();
    });
    it('valid 02/28/2018', () => {
        expect(dateValidatorUS(new FormControl('02/28/2018'))).toBeNull();
    });
    it('valid 03/31/1950', () => {
        expect(dateValidatorUS(new FormControl('03/31/1950'))).toBeNull();
    });
    it('valid 05/15/3030', () => {
        expect(dateValidatorUS(new FormControl('05/15/3030'))).toBeNull();
    });
    it('should valid leap year date 02/29/2000', () => {
        expect(dateValidatorUS(new FormControl('02/29/2000'))).toBeNull();
    });
    it('should valid leap year date 02/29/1996', () => {
        expect(dateValidatorUS(new FormControl('02/29/1996'))).toBeNull();
    });

    // Invalid Dates
        it('invalid 02/30/2018', () => {
        expect(dateValidatorUS(new FormControl('02/30/2018'))).toEqual({
            'invalidDate': { value: '02/30/2018' }
        });
    });
    it('invalid 13/15/2000', () => {
        expect(dateValidatorUS(new FormControl('13/15/2000'))).toEqual({
            'invalidDate': { value: '13/15/2000' }
        });
    });
    it('invalid 06/50/2000', () => {
        expect(dateValidatorUS(new FormControl('06/50/2000'))).toEqual({
            'invalidDate': { value: '06/50/2000' }
        });
    });
    it('invalid 11111111', () => {
        expect(dateValidatorUS(new FormControl('11111111'))).toEqual({
            'invalidDate': { value: '11111111' }
        });
    });
    it('invalid 123456789', () => {
        expect(dateValidatorUS(new FormControl('123456789'))).toEqual({
            'invalidDate': { value: '123456789' }
        });
    });
    it('invalid 12/12/19911', () => {
        expect(dateValidatorUS(new FormControl('12/12/19911'))).toEqual({
            'invalidDate': { value: '12/12/19911' }
        });
    });
    it('invalid 122/12/1991', () => {
        expect(dateValidatorUS(new FormControl('122/12/1991'))).toEqual({
            'invalidDate': { value: '122/12/1991' }
        });
    });
    it('invalid 12/122/1991', () => {
        expect(dateValidatorUS(new FormControl('12/122/1991'))).toEqual({
            'invalidDate': { value: '12/122/1991' }
        });
    });
    it('invalid 04/31/2000', () => {
        expect(dateValidatorUS(new FormControl('04/31/2000'))).toEqual({
            'invalidDate': { value: '04/31/2000' }
        });
    });
    it('invalid leap year 02/29/1990', () => {
        expect(dateValidatorUS(new FormControl('02/29/1990'))).toEqual({
            'invalidDate': { value: '02/29/1990' }
        });
    });
});
