import { ValidatorFn, AbstractControl } from '@angular/forms';

/** Compare the control.value with a callback value in a Validator for Reactive Forms */
export function dateValidator(format: string): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} => {
    const valid = dates[format].test(control.value);
    return valid ? null : {'invalidDate': {value: control.value}};
  };


}

const dates = {
  'US': /^((((0[13578])|([13578])|(1[02]))[\/](([1-9])|([0-2][0-9])|(3[01])))|(((0[469])|([469])|(11))[\/](([1-9])|([0-2][0-9])|(30)))|(2|02)[\/](([1-9])|(0[1-9])|(1[0-9])|(2[0-8])))[\/]\d{4}$|^(2|02)[\/]29[\/](([1-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))$/
  // Additional date regex can be added here
};
