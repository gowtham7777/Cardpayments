import { ValidatorFn, AbstractControl } from '@angular/forms';

/** Compare the control.value with a callback value in a Validator for Reactive Forms */
export function CompareValidator(compareValueFnc: any): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} => {
    const compareValue = compareValueFnc();
    return control.value &&
           compareValue &&
           control.value !== compareValue ? {'invalidComparison': {
      value: control.value,
      comparedValue: compareValue
    }} : null;
  };
}
