import { ValidatorFn, AbstractControl } from '@angular/forms';

/** Validate our age against a minimum value for Reactive Forms */
export function AgeValidator(minimumYears: number): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} => {
    const validAge = isDateAgeValid(control.value, minimumYears);
    return validAge ? {'invalidAge': {
      value: control.value,
      minimumAge: minimumYears
    }} : null;
  };
}

const isDateAgeValid = (dateString: string, yearsToValidate: number) => {
  // insert our date string into Date object
  const t = dateString.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (t !== null) {
    const y = t[3];
    const dateNow = new Date();
    const currentMonth = Number(dateNow.getMonth()) + 1; // Month is 0-based
    if (Number(t[3]) !== null) {
      // test year
      const calculatedYears = dateNow.getFullYear() - Number(t[3]);
      if (calculatedYears > yearsToValidate && (Number(t[3]) > 1900)) {
        return false;
      } else if (calculatedYears === yearsToValidate) {
        // test month
        if (currentMonth > Number(t[1]) ) {
          return false;
        } else if (currentMonth === Number(t[1])) {
          // test day
          if (dateNow.getDate() >= Number(t[2]) ) {
              return false;
          }
        }
      }
    }
  }
  return true;
};
