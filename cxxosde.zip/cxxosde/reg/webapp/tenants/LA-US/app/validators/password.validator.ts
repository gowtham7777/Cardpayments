import { ValidatorFn, AbstractControl, FormGroup } from '@angular/forms';

export function PasswordContainsUsernameValidator(email: any): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const username = email();
    if (control.value && username) {
      return passwordContainsUsername(username, control.value) ? {
        'invalidPatternValidation': {
          value: control.value,
          reason: 'password cannot contain username'
        }} : null;
    }
  };
}

function passwordContainsUsername(email: string, password: string) {
  const emailArray = email.split('@');
  if (emailArray.length > 0) {
    let username = emailArray[0];

    username = username.toLowerCase();
    password = password.toLowerCase();

    return password.includes(username);
  }
}
