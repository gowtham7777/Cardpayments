import { OtpGetPinService } from './shared/services/otp-get-pin.service';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { RouterModule, Routes } from '@angular/router';
// import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule, MatDialog } from '@angular/material';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
// this includes the core NgIdleModule but includes keepalive providers for easy wireup
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { SharedModule, HttpLoaderFactory } from './shared/shared.module';
import { PersonalInfoModule } from './personal-info/personal-info.module';
import { AccountIsSetupModule } from './account-is-setup/account-is-setup.module';
import { KbaQuizModule } from './kba-quiz/kba-quiz.module';
import { AccountCreationModule } from './account-creation/account-creation.module';
import { PtpModule } from './ptp/ptp.module';
import { AppConfig } from './app.config';
import { RouteNames } from './app.route-names';
import { CallCenterModule } from './call-center/call-center.module';
import {  DeviceDetectorService } from 'ngx-device-detector';

import { SystemErrorModule } from './system-error/system-error.module';
import { VerifyIdentityDuplicateModule } from './verify-identity-duplicate/verify-identity-duplicate.module';
import { routes } from './app.routes';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ConsumerService } from './shared/services/consumer.service';
import { AccountCreationService } from './shared/services/account-creation.service';
import { KbaQuizService } from './shared/services/kba-quiz.service';
import { EmailInUseModule } from './email-in-use/email-in-use.module';
import { TimeoutModule } from './timeout/timeout.module';
import { TimeoutComponent } from './timeout/timeout.component';
import { OtpIdentityVerifySubmitPinModule } from './otp-identity-verify-submit-pin/otp-identity-verify-submit-pin.module';
import { OtpIdentifyVerifyGetPinModule } from './otp-identity-verify-get-pin/otp-identity-verify-get-pin.module';
import { EmergencyBrakeModule } from './emergency-brake/emergency-brake.module';
import { CaptchaService } from './shared/services/captcha.service';
import { TimeoutService } from './timeout/timeout.service';
import { RoutingService } from '@services/routing.service';
import { BrowserCheckService } from '@services/browser-check.service';
import { httpInterceptorProviders } from '@common/components/http-interceptors';
import { GlobalSpinnerComponent } from '@common/components/http-interceptors/global-spinner/global-spinner.component';
import { SpinnerInterceptor } from '@common/components/http-interceptors/spinner-interceptor';
import { TranslateService } from '@ngx-translate/core';
import { Location } from '@angular/common';
import { LanguageService } from '@common/services/language.service';

import {
  AccountCreationGuard,
  AccountIsSetupGuard,
  KbaQuizGuard,
  OtpOptInGuard,
  OtpSubmitGuard,
  PiiGuard,
  PtpOptInGuard,
  PtpSuccessGuard,
  PtpSubmitPinGuard,
  EmergencyBrakeMailOptionGuard,
  EmergencyBrakeNextStepsGuard
} from './guards/index';
import { environment } from '../environments/environment';
import { ServiceWorkerModule } from '@angular/service-worker';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    GlobalSpinnerComponent,
  ],
  entryComponents: [
    TimeoutComponent,
    GlobalSpinnerComponent
  ],
  imports: [
    CoreModule,
    BrowserModule,
    SharedModule,
    HttpClientModule,
    // HttpModule,
    BrowserAnimationsModule,
    MatDialogModule,
    PersonalInfoModule,
    AccountIsSetupModule,
    KbaQuizModule,
    AccountCreationModule,
    SystemErrorModule,
    VerifyIdentityDuplicateModule,
    OtpIdentifyVerifyGetPinModule,
    OtpIdentityVerifySubmitPinModule,
    EmailInUseModule,
    TimeoutModule,
    PtpModule,
    CallCenterModule,
    EmergencyBrakeModule,
    RouterModule.forRoot(
      routes,
      {useHash: true}
    ),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    NgIdleKeepaliveModule.forRoot(),
    ServiceWorkerModule.register('/consumer-registration/LA-US/ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    MatDialog,
    ConsumerService,
    AccountCreationService,
    KbaQuizService,
    OtpGetPinService,
    AppConfig,
    CaptchaService,
    TimeoutService,
    RoutingService,
    BrowserCheckService,
    DeviceDetectorService,
    AccountCreationGuard,
    KbaQuizGuard,
    OtpOptInGuard,
    OtpSubmitGuard,
    PiiGuard,
    AccountIsSetupGuard,
    PtpOptInGuard,
    PtpSuccessGuard,
    EmergencyBrakeMailOptionGuard,
    EmergencyBrakeNextStepsGuard,
    PtpSubmitPinGuard,
    RouteNames,
    httpInterceptorProviders,
    LanguageService,
    SpinnerInterceptor
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
