import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { TranslateService } from '@ngx-translate/core';

import { Question } from '@models/question.model';
import { KbaQuizService } from '@services/kba-quiz.service';
import { ConsumerService } from '@services/consumer.service';
import { AnalyticsService } from '@common/services/analytics.service';
import { RoutingService} from '@services/routing.service';
import { RouteNames } from '@app/app.route-names';
import { AppConfig } from '@app/app.config';
import { PtpService } from '../ptp/ptp.service';
import { OtpGetPinService } from '../shared/services/otp-get-pin.service';


@Component({
  selector: 'app-otp-identity-verify-get-pin',
  templateUrl: './otp-identity-verify-get-pin.component.html'
})
export class OtpIdentifyVerifyGetPinComponent implements OnInit {
  number: string;
  email: string;
  isOtpEmail = false;
  translationKey = 'Text';
  analyticsOtp: object;
  private translateService;

  constructor(
    translate: TranslateService,
    private consumerService: ConsumerService,
    private kbaQuizService: KbaQuizService,
    private otpGetPinService: OtpGetPinService,
    private analyticsService: AnalyticsService,
    private ptpService: PtpService,
    private router: Router,
    private routes: RouteNames,
    private routingService: RoutingService,
    private config: AppConfig,
    private titleService: Title
  ) {
    this.translateService = translate;
  }

  ngOnInit() {
        if ( this.consumerService.otpEmail) {
          this.isOtpEmail = true;
          this.translationKey = 'Email';
          this.email = this.consumerService.otpEmail;
          this.analyticsOtp = this.config.analytics.otp.email;
        } else {
          if (this.consumerService.consumer !== undefined &&
            this.consumerService.consumer.phoneNumber !== undefined ) {
            const phone = this.consumerService.consumer.phoneNumber;
            const ph = phone.substr(phone.length - 4, phone.length);
            this.number = ph;
          }

          // by default use text based analytics
          this.analyticsOtp = this.config.analytics.otp.text;
        }
        this.analyticsService.appendEvent({
          eventData: {
            eventName: this.analyticsOtp['verifyPin'].eventName,
            pageName: this.analyticsOtp['verifyPin'].pageName
          },
          eventIds: this.analyticsOtp['verifyPin'].eventIds
        });
        this.updatePageTitle();
    }


  isControlValid = () => {
    // test using FormControl validators
    return this.number || (this.email && this.isOtpEmail);
  }

  getKbaQuiz = () => {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsOtp['pinOptOut'].eventName,
        pageName: this.analyticsOtp['pinOptOut'].pageName
         },
      eventIds: this.analyticsOtp['pinOptOut'].eventIds
    });
    this.kbaQuizService.fetchQuiz();
  }

  requestPin = () => {
    this.analyticsService.appendEvent({
      eventData: {
        eventName: this.analyticsOtp['pinRequest'].eventName,
        pageName: this.analyticsOtp['pinRequest'].pageName
      },
      eventIds: this.analyticsOtp['pinRequest'].eventIds
    });
    this.otpGetPinService.enrollOTP().subscribe(
      // Successful responses call the first callback
        data => this.handlePinRequest(data),
        err => this.routingService.handleErrorResponse(err));
  }

  private handlePinRequest(data) {
    if (data) {
      if (data.statusCode === this.config.otpEnrollResendAllowedInit ) {
        this.otpGetPinService.setDisplayNewPinRequest(true);
        this.otpGetPinService.setShowNewCodeBanner (false);
        this.routingService.enableNavigationTo(this.routes.otpSubmit);
        this.router.navigate([this.routes.otpSubmit])
      } else if (data.statusCode === this.config.otpEnrollResendAllowed) {
        this.otpGetPinService.setDisplayNewPinRequest(true);
        this.otpGetPinService.setShowNewCodeBanner(true);
        this.routingService.enableNavigationTo(this.routes.otpSubmit);
        this.router.navigate([this.routes.otpSubmit])
      } else if (data.statusCode === this.config.otpEnrollResendMax) {
        this.otpGetPinService.setDisplayNewPinRequest(false);
        this.otpGetPinService.setShowNewCodeBanner(true);
        this.routingService.enableNavigationTo(this.routes.otpSubmit);
        this.router.navigate([this.routes.otpSubmit])
      } else if (data.statusCode === this.config.kbaGetQuizSuccessOtpPinInitiationFail) {
        this.kbaQuizService.saveQuiz(data.quizIdentifier, data.questions as Question[]);
        this.routingService.enableNavigationTo(this.routes.kbaQuiz);
        this.router.navigate([this.routes.kbaQuiz])
      } else {
        const defaultRoute = () => { this.router.navigate([this.routes.callCenter]); };
        (this.ptpService.routesMap[data.statusCode] || defaultRoute)();
      }
    } else {
      this.router.navigate([this.routes.callCenter]);
    }
  }

  updatePageTitle() {
    if (this.isOtpEmail) {
          this.translateService.get('otp-verify-get-pin.browserTitle.pinToEmailLoadTitle').subscribe((result: string) => {
            this.titleService.setTitle(result);
      });
    } else if (!this.isOtpEmail) {
      this.translateService.get('otp-verify-get-pin.browserTitle.pinToTextLoadTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    }
  }
}
