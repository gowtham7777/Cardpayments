import { OtpGetPinService } from '../shared/services/otp-get-pin.service';
import { OtpIdentifyVerifyGetPinComponent } from './otp-identity-verify-get-pin.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule} from '@angular/router';

@NgModule({
  declarations: [
    OtpIdentifyVerifyGetPinComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule
  ],
  providers: [OtpGetPinService], // services go here
  exports: [
    OtpIdentifyVerifyGetPinComponent
  ]
})
export class OtpIdentifyVerifyGetPinModule { }
