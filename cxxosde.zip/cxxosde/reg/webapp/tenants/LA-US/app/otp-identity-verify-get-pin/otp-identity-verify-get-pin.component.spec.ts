// Collection of shared declarations/imports/providers the majority of tests will use
import { TestBedModule, BaseRoutesWith } from '@shared/test-bed.module';

// Angular
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Routes, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

// Third Party
import { Observable, Subscriber } from 'rxjs';


// Modules
import { SharedModule } from '@shared/shared.module';

// Services
import { KbaQuizService } from '@services/kba-quiz.service';
import { RoutingService } from '@services/routing.service';
import { PtpService } from '@app/ptp/ptp.service';
import { OtpGetPinService } from '@app/shared/services/otp-get-pin.service';
import { ConsumerService } from '@app/shared/services/consumer.service';
import {
  MockKbaQuizService,
  MockConsumerService,
  MockPtpService,
  MockOtpGetPinService
} from '@app/app.mock-services';

// Components
import { OtpIdentifyVerifyGetPinComponent } from './otp-identity-verify-get-pin.component';

// Models
import { Consumer } from '@app/shared/models/consumer.model';

// Routes
import { RouteNames } from '@app/app.route-names';
const limitedRoutes: Routes = BaseRoutesWith([]);
const MOCK_ERROR = 'error';

describe('OtpIdentifyVerifyGetPinComponent', () => {
  let component: OtpIdentifyVerifyGetPinComponent;
  let fixture: ComponentFixture<OtpIdentifyVerifyGetPinComponent>;
  let mockOtpGetPinService: OtpGetPinService;
  let mockKbaQuizService: KbaQuizService;
  let mockConsumerService: ConsumerService;
  let mockRoutingService: RoutingService;
  let mockRoutes: RouteNames;
  let mockRouter: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OtpIdentifyVerifyGetPinComponent],
      imports: [
        TestBedModule,
        RouterTestingModule.withRoutes(limitedRoutes),
        SharedModule
      ],
      providers: [
        { provide: KbaQuizService, useClass: MockKbaQuizService },
        { provide: PtpService, useClass: MockPtpService },
        { provide: OtpGetPinService, useClass: MockOtpGetPinService },
        { provide: ConsumerService, useClass: MockConsumerService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    mockOtpGetPinService = TestBed.get(OtpGetPinService);
    mockKbaQuizService = TestBed.get(KbaQuizService);
    mockRoutingService = TestBed.get(RoutingService);
    mockConsumerService = TestBed.get(ConsumerService);
    mockRoutes = TestBed.get(RouteNames);
    mockRouter = TestBed.get(Router);
    fixture = TestBed.createComponent(OtpIdentifyVerifyGetPinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  function mockPinResponse(responseMap) {
    return responseMap === MOCK_ERROR
      ? new Observable<Error>((subscriber: Subscriber<Error>) =>
          subscriber.error()
        )
      : new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next(responseMap)
        );
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // ==================================================
  // Handle Tests related to Pin
  // ==================================================
  it('should attempt to append analytics event when fetching pin', () => {
    spyOn(component['analyticsService'], 'appendEvent').and.stub();
    component.requestPin();
    expect(component['analyticsService'].appendEvent).toHaveBeenCalled();
  });

  it('should attempt to handle the pin request', () => {
    spyOn(component as any, 'handlePinRequest').and.stub();
    component.requestPin();
    expect(component['handlePinRequest']).toHaveBeenCalled();
  });

  // ===========================================================================
  // Handle Tests to display Page content to distinguish Pin2text from pin2email
  // ===========================================================================

  it('should display content for pin2Email screen', () => {
    const mockEmail = 'testemail@example.com';
    component['consumerService'].otpEmail = mockEmail;
    component.ngOnInit();
    expect(component['isOtpEmail']).toBeTruthy();
    expect(component['translationKey']).toBe('Email');
    expect(component['email']).toBe(mockEmail);
  });

  it('should display content for pin2Text screen', () => {
    const phone = '1234567890';
    const mockNumber = phone.substr(phone.length - 4, phone.length);
    const mockConsumer = new Consumer();
    mockConsumer.phoneNumber = phone;
    mockConsumerService.consumer = mockConsumer;
    component.ngOnInit();
    expect(component['isOtpEmail']).toBeFalsy();
    expect(component['translationKey']).toBe('Text');
    expect(component['number']).toBe(mockNumber);
  });

  // We're spying on the enrollOTP call and throwing an error
  it('should attempt to handle bad responses from pin requests', () => {
    spyOn(component['routingService'], 'handleErrorResponse').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse(MOCK_ERROR)
    );

    component.requestPin();
    expect(component['routingService'].handleErrorResponse).toHaveBeenCalled();
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendAllowedInit
  it('should display "new pin" request and no "new code" banner on the first time they see OTP', () => {
    spyOn(mockOtpGetPinService, 'setDisplayNewPinRequest').and.stub();
    spyOn(mockOtpGetPinService, 'setShowNewCodeBanner').and.stub();
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpEnrollResendAllowedInit
      })
    );

    component.requestPin();
    expect(mockOtpGetPinService.setDisplayNewPinRequest).toHaveBeenCalledWith(
      true
    );
    expect(mockOtpGetPinService.setShowNewCodeBanner).toHaveBeenCalledWith(
      false
    );
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.otpSubmit]);
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendAllowed
  it('should display "new pin" request and a "new code" banner on subsequent times seeing OTP', () => {
    spyOn(mockOtpGetPinService, 'setDisplayNewPinRequest').and.stub();
    spyOn(mockOtpGetPinService, 'setShowNewCodeBanner').and.stub();
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].otpEnrollResendAllowed
      })
    );

    component.requestPin();
    expect(mockOtpGetPinService.setDisplayNewPinRequest).toHaveBeenCalledWith(
      true
    );
    expect(mockOtpGetPinService.setShowNewCodeBanner).toHaveBeenCalledWith(
      true
    );
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.otpSubmit]);
  });

  // We're spying on the enrollOTP call and sending otpEnrollResendMax
  it('should not display "new pin" request and a "new code" banner after max resends', () => {
    spyOn(mockOtpGetPinService, 'setDisplayNewPinRequest').and.stub();
    spyOn(mockOtpGetPinService, 'setShowNewCodeBanner').and.stub();
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({ statusCode: component['config'].otpEnrollResendMax })
    );

    component.requestPin();
    expect(mockOtpGetPinService.setDisplayNewPinRequest).toHaveBeenCalledWith(
      false
    );
    expect(mockOtpGetPinService.setShowNewCodeBanner).toHaveBeenCalledWith(
      true
    );
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.otpSubmit]);
  });

  // We're spying on the enrollOTP call and sending kbaGetQuizSuccessOtpPinInitiationFail
  it('should reload kba quiz if kba quiz was good, but OTP initiation failed', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockKbaQuizService, 'saveQuiz').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse({
        statusCode: component['config'].kbaGetQuizSuccessOtpPinInitiationFail
      })
    );

    component.requestPin();
    expect(mockKbaQuizService.saveQuiz).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalled();
  });

  // We're spying on the enrollOTP call and sending undefined
  it('should go to call center if no data from OTP request', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    spyOn(mockOtpGetPinService, 'enrollOTP').and.returnValue(
      mockPinResponse(undefined)
    );

    component.requestPin();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });
});
