import { Route } from '@angular/router';
import { OtpIdentifyVerifyGetPinComponent } from './otp-identity-verify-get-pin.component';
import { OtpOptInGuard } from '@app/guards/otp-opt-in.guard';

export const OtpIdentifyVerifyGetPinRoutes: Route[] = [
  {
    path: 'otp-verify-get-pin',
    component: OtpIdentifyVerifyGetPinComponent,
    canActivate: [OtpOptInGuard]
  }
];
