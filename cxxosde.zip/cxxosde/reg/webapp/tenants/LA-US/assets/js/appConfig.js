function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}

// 'adobe_mc' param is provided by the mobile app to indicate that users came from there
window['isFromMobileApp'] = window.location.href.indexOf('adobe_mc') > -1;
window['mobileQueryParamValue'] = getParameterByName('adobe_mc');

window['isAnalyticsConfigured'] = false;
// load the analytics config as json
jQuery.ajax({
    url: '../rest/1.0/analyticsConfig',
    type: "GET",
    datatype: 'application/json',
    async: false,
    beforeSend: setHeader,
    success: function(data) {
        createDigitalDataObject(data);
        loadAnalytics(data);
        loadIovation(data);
    },
    error: function() {
    }
});

function setHeader(xhr) {
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.setRequestHeader('Accept', 'application/json');
  xhr.setRequestHeader('Mobile-App', window['isFromMobileApp'].toString());
}

function createDigitalDataObject(data) {
  if (data && data.dataLayer) {
    window['digitalData'] = data.dataLayer;
    applyBrowserEnrichment();
  }
};

function loadAnalytics(data) {
  if (data && data.ensightenUrl) {
    var script = document.createElement("script");
    script.type = "text/javascript";
    if (script.readyState){  //IE
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" ||
                    script.readyState == "complete"){
                script.onreadystatechange = null;
                window['isAnalyticsConfigured'] = true;
            }
        };
    } else {  //Others
        script.onload = function(){
          window['isAnalyticsConfigured'] = true;
        };
    }
    script.src = data.ensightenUrl;
    document.getElementsByTagName("head")[0].appendChild(script);
  } else {
  }
};

function applyBrowserEnrichment() {
  if (window['digitalData'].page) {
    if (window['digitalData'].page.pageInfo) {
      window['digitalData'].page.pageInfo.pageName = 'SPA Constructor'; // default until the intial route loads
      window['digitalData'].page.pageInfo.referringURL = document.referrer;
      window['digitalData'].page.pageInfo.destinationURL = window.location.href;
    }
    if (window['digitalData'].page.attributes) {
      window['digitalData'].page.attributes.supportCookies = navigator.cookieEnabled;
      window['digitalData'].page.attributes.supportJavascript = true;
      window['digitalData'].page.attributes.browserWidth = window['digitalData'].page.attributes.screenWidth = window['innerWidth'];
      window['digitalData'].page.attributes.browserHeight = window['digitalData'].page.attributes.screenHeight = window['innerHeight'];
      // set fixed meta data
      window['digitalData'].page.attributes.equifaxBusinessUnit = 'gcs';
      window['digitalData'].page.attributes.contextProduct = 'lockalert';
    }
    // set fixed meta data
    if (window['digitalData'].page.hasOwnProperty('category')) {
      if (typeof window['digitalData'].page.category !== 'object') {
        window['digitalData'].page.category = {};
      }
      window['digitalData'].page.category.pageType = 'lockAlertFunnel';
    }
  }
  // add product IDs
  window['digitalData']['productId'] = "LockAlert.2018.01";
  window['digitalData']['productName'] = "LockAlert.2018.01";
  window['digitalData']['productDescription'] = "LockAlert.2018.01";
}

function loadIovation(data) {
  // Include third-party Iovation JavaScripts
  if (data && data.iOvationUrl) {
    // basic configurations must be on page before script load
    window.io_install_stm       = false,        // do not install Active X
    window.io_exclude_stm       = 12,           // do not run Active X
    window.io_install_flash     = false,        // do not install Flash
    window.io_enable_rip        = true;         // collect Real IP information

    var script = document.createElement("script");
    script.type = "text/javascript";
    if (script.readyState){  //IE
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" ||
                    script.readyState == "complete"){
                script.onreadystatechange = null;
            }
        };
    } else {  //Others
        script.onload = function(){
        };
    }
    script.src = data.iOvationUrl;
    document.getElementsByTagName("head")[0].appendChild(script);
  }
  /**
   * Include first-party Iovation JavaScripts
   * IMPORTANT: Include the full path to static_wdp and dyn_wdp to prevent errors with Internet Explorer
   */
  var originUrl = window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
  var fpStaticScript = document.createElement("script");
  fpStaticScript.type = "text/javascript";
  fpStaticScript.src = originUrl +  '/iojs/latest/static_wdp.js';
  document.getElementsByTagName("head")[0].appendChild(fpStaticScript);
  var fpDynScript = document.createElement("script");
  fpDynScript.type = "text/javascript";
  fpDynScript.src = originUrl +  '/iojs/latest/dyn_wdp.js';
  document.getElementsByTagName("head")[0].appendChild(fpDynScript);
};