import { Component, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'account-creation-wait',
  templateUrl: './account-creation-wait.component.html',
})

export class AccountCreationWaitComponent implements OnDestroy {
  initialLoad: boolean = true;
  nextMessageTimer: any;

  constructor(
    private translateService: TranslateService,
    private titleService: Title
  ) {
    this.updatePageTitle();
  }

  ngOnDestroy() {
    clearTimeout(this.nextMessageTimer);
  }

  beginCounter = () => {
    this.nextMessageTimer = setTimeout(this.changeToNextMessage, 5000);
  }

  private changeToNextMessage= () => {
    this.initialLoad = false;
    this.updatePageTitle();
  }

  updatePageTitle() {
    if (this.initialLoad) {
      // sets the title for first spinner
      this.translateService.get('account-creation.browserTitle.pleaseWaitInitialEventTitle').subscribe((result: string) => {
        this.titleService.setTitle(result);
      });
    } else {
      // sets the title for second spinner comes after 5 seconds
        this.translateService.get('account-creation.browserTitle.pleaseWaitNextEventTitle').subscribe((result: string) => {
          this.titleService.setTitle(result);
      });
    }
  }
}
