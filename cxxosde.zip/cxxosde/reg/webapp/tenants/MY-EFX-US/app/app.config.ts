import { Injectable } from '@angular/core';

// Properties are not static to allow for injection of the app.config
// By injecting, we do not generate an instance of the app.config for each component (singleton)
@Injectable()
export class AppConfig {

    public callCenterError = 'CALL_CENTER_ERROR';
    public cidUnavailable = 'CID_UNAVAILABLE';

    public emergencyBrakeOn = 'EMERGENCY_BREAK_ON';
    public emergencyBrakePtpOptIn = 'EMERGENCY_BREAK_P2P_OPTED_IN';
    public emergencyBrakePtpOptOut = 'EMERGENCY_BREAK_P2P_OPTED_OUT';

    public errorDisplay = 'errorDisplayed';

    public getPinToText = 'GET_PIN_TO_TEXT';
    public getPinToEmail = 'GET_PIN_TO_EMAIL';
    public getPinToEmailText = 'GET_PIN_TO_TEXT_EMAIL';

    public indirectEnrollmentSystemError = 'INDIRECT_ENROLLMENT_SYSTEM_ERROR';

    public kbaSubmissionSuccess = 'KBA_SUBMIT_ANSWERS_SUCCESS';
    public kbaSubmissionTimeout = 'KBA_SUBMIT_ANSWERS_ERROR_TIMEDOUT';
    public kbaSubmissionError = 'KBA_SUBMIT_ANSWERS_ERROR';
    public kbaQuizSuccess = 'KBA_QUIZ_SUCCESS';
    public kbaQuizError = 'KBA_QUIZ_ERROR';
    public kbaSystemError = 'KBA_SUBMIT_ANSWERS_SYSTEM_ERROR';
    public kbaOtpEnrollAllowed = 'ENROLL_OTP_RESEND_ALLOWED';
    public kbaOtpAtMax = 'ENROLL_OTP_RESEND_MAX';
    public kbaFailureEligibilityFail = 'KBA_FAILURE_ELIGIBILITY_FAIL';
    public kbaSuccessEligibilityFail = 'KBA_SUCCESS_ELIGIBILITY_FAIL';
    public kbaGetQuizSuccessOtpPinRetryMax = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_RETRY_MAX';
    public kbaGetQuizSuccessOtpPinInitiationFail = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_INITIATION_FAIL';
    public kbaGetQuizSuccessOtpPinValidationFailUnknown = 'KBA_GET_QUIZ_SUCCESS_OTP_PIN_VALIDATION_FAIL_UNKNOWN';

    public mobileQueryParam = 'adobe_mc';

    public noSpinnerHeader = 'No-Spinner-Flag';

    public otpEligibilityNoHit = 'ELIGIBILITY_CHECK_NO_HIT';
    public otpValidateResubmitWithResendMax = 'OTP_VALIDATE_RESUBMIT_WITH_RESEND_MAX';
    public otpEnrollResendAllowedInit = 'ENROLL_OTP_RESEND_ALLOWED_INIT';
    public otpEnrollResendAllowed = 'ENROLL_OTP_RESEND_ALLOWED';
    public otpEnrollResendMax = 'ENROLL_OTP_RESEND_MAX';
    public otpValidatePinSuccess = 'OTP_VALIDATE_PIN_SUCCESS';

    public personalInfoConfirmation = 'CONFIRMATION';
    public personalInfoRecaptcha = 'RECAPTCHA_ERROR';
    public ptpInitiated = 'INITIATE_PTP_SUCCESS';
    public ptpInitiateSystemError = 'INITIATE_PTP_SYSTEM_ERROR';
    public ptpOnly = 'PIN_TO_POST_ONLY'; // Can be use to display only PTP (for instance - during emergency break)
    public ptpEligiblePrimary = 'PIN_TO_POST_PRIMARY';
    public ptpEligibleSecondary = 'PIN_TO_POST_SECONDARY';
    public ptpSubmitPinSuccess = 'VALIDATE_PTP_SUCCESS';
    public ptpSubmitPinError = 'VALIDATE_PTP_ERROR';
    public ptpSubmitPinExpire = 'VALIDATE_PTP_EXPIRE';
    public ptpSubmitPinRecaptcha = 'VALIDATE_PTP_RECAPTCHA_ERROR';
    public ptpValidateResubmitAllowed = 'VALIDATE_PTP_ERROR_RESUBMIT_ALLOWED';

    public saveConsumerExist = 'SAVE_CONSUMER_EXIST';
    public systemError = 'SYSTEM_ERROR';

    public tenantName = 'MY-EFX-US';
    public consumerSavePartialSuccessSystemError = 'CONSUMER_SAVE_PARTIAL_SUCCESS_SYSTEM_ERROR';
    public duplicateEnrollment = 'DUPLICATE_ENROLLMENT';

    public validationError = 'VALIDATION_ERROR';

    public productInfo = {
      'productID': 'MVP2155.2018.09',
      'productName': 'MVP2155.2018.09',
      'description': 'MVP2155.2018.09'
    };

    public errorKeys = {
      ageRequirement: 'OF0001',
      duplicateEnroll: 'OF0006',
      invalidPassword: 'OF0002',
      noObject: 'OF0005',
      pinIncorrect: 'OF0003'
    };

    public analytics = {
    createAccount: {
      emailInUse: {
        eventName: 'emailInUsePageLoad',
        pageName: 'error - email  in use',
        eventIds: ['ajaxPageLoad', 'ajaxFunnelError'],
        pageType: 'funnel'
      },
      pageLoad: {
        pageType: 'funnel',
        eventName: 'createAccountPageLoad',
        pageName: 'registration - create account',
        eventIds: ['ajaxPageLoad', 'registrationCreateAccount']
      }
    },
    callCenter: {
      generic: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      kbaTimeOut: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      noHit: {
        eventName: 'noHitPageLoad',
        pageName: 'error - no file in acro',
        eventIds: ['ajaxPageLoad', 'ajaxFunnelError'],
        pageType: 'funnel'
      },
      callCustomerCare: {
        eventName: '',
        eventIds: ['']
      }
    },
    emergencyBrake: {
      mailOption: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      pinToMailInit: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      nextSteps: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      }
    },
    kbaQuiz: {
      pageLoad: {
        pageType: 'authentication',
        eventName: 'kbaQuizPageLoad',
        pageName: 'registration - collect KBA',
        attributes: {
          authenticationType: 'kba'
        },
        eventIds: ['ajaxPageLoad', 'registrationCollectKBA']
      },
      kbaAuthAttempt: {
        eventName: 'registrationKBAAuthAttempt',
        pageName: 'registration - collect KBA',
        attributes: {
          authenticationType: 'kba'
        },
        eventIds: ['registrationKBAAuthAttempt']
      },
      kbaPinAuthFailed: {
        pageType: 'authentication',
        eventName: 'pinTooManyAttemptsErrorDisplayed',
        pageName: 'registration - collect KBA',
        attributes: {
          authenticationType: 'kba'
        },
        eventIds: ['pinTooManyAttemptsErrorDisplayed']
      }
    },
    otp: {
      text: {
        verifyPinEmail: {
          pageType: 'authentication Hamilton',
          eventName: 'otpRequestEmailPinPageLoad',
          pageName: '"pin to text or pin to email',
          eventIds: ['ajaxPageLoad']
        },
        verifyPin: {
          pageType: 'authentication',
          eventName: 'otpRequestTextPinPageLoad',
          pageName: 'pin to text - request code',
          eventIds: ['ajaxPageLoad']
        },
        pinRequest: {
          eventName: 'otpNewPinRequest',
          pageName: 'pin to text - request code',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpNewPinRequest']
        },
        submitPin: {
          pageType: 'authentication',
          eventName: 'otpSubmitPinPageLoad',
          pageName: 'registration - verify pin',
          eventIds: ['ajaxPageLoad']
        },
        pinAuthAttempt: {
          eventName: 'otpPinAuthAttempt',
          pageName: 'registration - verify pin',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpPinAuthAttempt']
        },
        pinOptOut: {
          eventName: 'otpPinOptOut',
          pageName: 'pin to text - request code',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpPinOptOut']
        },
        pinDidNotReceive: {
          eventName: 'otpNoPinReceived',
          pageName: 'registration - verify pin',
          attributes: {
            authenticationType: 'otp sms pin'
          },
          eventIds: ['otpNoPinReceived']
        }
      },
      email: {
        verifyPin: {
          pageType: 'authentication',
          eventName: 'otpRequestEmailPinPageLoad',
          pageName: 'pin to email - request code',
          eventIds: ['ajaxPageLoad']
        },
        pinOptOut: {
          eventName: 'otpPinOptOut',
          pageName: 'pin to email - request code',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpPinOptOut']
        },
        pinRequest: {
          eventName: 'otpNewPinRequest',
          pageName: 'pin to email - request code',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpNewPinRequest']
        },
        submitPin: {
          pageType: 'authentication',
          eventName: 'otpEmailSubmitPinPageLoad',
          pageName: 'registration - verify pin',
          eventIds: ['ajaxPageLoad']
        },
        pinDidNotReceive: {
          eventName: 'otpNoPinReceived',
          pageName: 'registration - verify pin',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpNoPinReceived']
        },
        pinAuthAttempt: {
          eventName: 'otpPinAuthAttempt',
          pageName: 'registration - verify pin',
          attributes: {
            authenticationType: 'otp email pin'
          },
          eventIds: ['otpPinAuthAttempt']
        }
      }
    },
    personalInfo: {
      pageLoad: {
        pageType: 'funnel',
        eventName: 'personalInfoPageLoad',
        pageName: 'registration - personal info',
        eventIds: ['ajaxPageLoad', 'registrationPersonalInfo']
      },
      accountInUse: {
        pageType: 'funnel',
        eventName: 'accountInUsePageLoad',
        pageName: 'error - account in use',
        eventIds: ['ajaxPageLoad', 'ajaxFunnelError']
      },
      enrollmentFailure: {
        pageType: 'funnel',
        eventName: 'enrollmentErrorPageLoad',
        pageName: 'error - enrollment failed',
        eventIds: ['ajaxPageLoad', 'ajaxFunnelError']
      }
    },
    accountIsSetup: {
      pageLoad: {
        pageType: 'funnel',
        eventName: 'accountIsReadyPageLoad',
        pageName: 'registration - account is ready',
        eventIds: ['ajaxPageLoad', 'my-efx-usAccountCreated']
      }
    },

    ptp: {
      pinNotAvailable: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      callCcOrPinToMail: {
        eventName: '',
        pageName: '',
        eventIds: ['']
      },
      pinToMailOrCallCc: {
        pageType: 'authentication',
        eventName: 'pinToMailOrCallCc',
        pageName: 'pin to mail or call CC',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailOnly: {
        pageType: 'authentication',
        eventName: 'pinToMailOnly',
        pageName: 'pin to mail Only',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailInitiated: {
        eventName: 'pinToMailStarted',
        attributes: {
          authenticationType: 'post'
        },
        eventIds: ['pinToMailStarted']
      },
      pinToMailAuthSuccess: {
        pageType: 'authentication',
        eventName: 'pinToMailConfirmation',
        pageName: 'pin to mail confirmation',
        attributes: {
            authenticationType: 'post'
        },
        eventIds: ['ajaxPageLoad', 'pinToMailConfirmation']
      },
      pinToMail: {
        pageType: 'authentication',
        eventName: 'pinToMailLoad',
        pageName: 'registration - verify pin',
        eventIds: ['ajaxPageLoad']
      },
      pinToMailAuthAttempt: {
        eventName: 'pinToMailAuthAttempt',
        pageName: 'registration - verify pin',
        attributes: {
          authenticationType: 'post'
         },
        eventIds: ['otpPinAuthAttempt']
      }
    },
    systemError: {
      pageLoad: {
        eventName: 'systemErrorPageLoad',
        pageName: 'error - enrollment failed',
        eventIds: ['ajaxPageLoad', 'ajaxFunnelError']
      }
    },
    timeout: {
      pageLoad: {
        eventName: 'sessionTimeOutErrorDisplayed',
        pageName: '',
        errorKey: 'G0002',
        eventIds: ['sessionTimeOutErrorDisplayed']
      }
    }
  };

  // Current major version minus 2 versions as of 12/19/2017
  public minimumBrowserVersions = {
    chrome: 57, // 03/2017
    firefox: 55, // 03/2017
    safari: 10, // 09/2016
    opera: 44, // 03/2017
    'ms-edge': 14, // 08/2016
    ie: 11, // Latest version of IE from 2015
  };

  public regex= {
    dottedEmailAddress: '(?=^\\S+@\\S+\\.\\S+$)',
    allowedEmailCharacters: '(?=^[A-Za-z0-9@$\\._-]+$)', // allows alphanumeric, '@', '.', '_', '-'
    startsWithAlphanumeric: '(?=^[A-Za-z0-9].*$)', // cannot start with special character
    minAndMaxEmailLength: '(?=^.{5,100}$)',  // between 5 and 100 characters
    oneAtMark: '(^(?!.*[@].*[@]).*$)',
    notNineOrMoreNumbers : '(?=^((?!([0-9]{9,}\\1)).)*$)',
    allowedPinCharacters:  '^[A-Z0-9]{10}$',
    length8to20: '(?=^.{8,20}$)',
    atLeastOneLowercase: '(?=.*[a-z])',
    atLeastOneUppercase: '(?=.*[A-Z])',
    atLeastOneNumber: '(?=.*[0-9])',
    atLeastOneSpecialCharacter: '(?=.*[!@$*+\\-])',
    notNineNumbersInARow: '(?=^((?!([0-9]{9,}\\1)).)*$)',
    noTwoRepeatingCharacters: '(?=^(?!.*(.)\\1{2,}).*$)',
    noSpaces: '(?=^(?!.*\\s).*$)',
    onlyValidCharacters: '(?=^[a-zA-Z0-9!@$*+\\-]+$)',

    betweenLengths : '(?=^.{8,20}$)', // between 8 - 20 characters
    oneLowercase : '(?=.*[a-z])', // at least one lowcase letters
    oneUppercase : '(?=.*[A-Z])', // at least one uppercase letters
    oneNumber : '(?=.*[0-9])', // at least least 1 number
    oneSpecialChar : '(?=.*[!@$*+\\-])', // at least one special characters
    notTwoRepeactChar : '(?=^(?!.*(.)\\1{2,}).*$)', // cannot contain more than 2 repeating characters
    notSpaces : '(?=^(?!.*\\s).*$)',
    notAnyOtherChars : '(?=^[a-zA-Z0-9!@$*+\\-]+$)' // cannot contain any other characters beside those listed above
  };
}
