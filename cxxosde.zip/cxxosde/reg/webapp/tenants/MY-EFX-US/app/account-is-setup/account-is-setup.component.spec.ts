import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TestBedModule } from '@app/shared/test-bed.module';
import { SharedModule } from '@app/shared/shared.module';
import { Observable, Subscriber } from 'rxjs';
import { AccountIsSetupComponent } from './account-is-setup.component';
import { Router } from '@angular/router';
import { RouteNames } from '@app/app.route-names';

const MOCK_ERROR = 'error';

describe('AccountIsSetupComponent', () => {
  let component: AccountIsSetupComponent;
  let fixture: ComponentFixture<AccountIsSetupComponent>;
  let mockRoutes: RouteNames;
  let mockRouter: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestBedModule, SharedModule],
      declarations: [AccountIsSetupComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountIsSetupComponent);
    component = fixture.componentInstance;
    mockRoutes = TestBed.get(RouteNames);
    mockRouter = TestBed.get(Router);
    fixture.detectChanges();
  });

  function mockPinResponse(responseMap) {
    return responseMap === MOCK_ERROR
      ? new Observable<Error>((subscriber: Subscriber<Error>) =>
          subscriber.error()
        )
      : new Observable<any>((subscriber: Subscriber<any>) =>
          subscriber.next(responseMap)
        );
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should attempt to on login with error', () => {
    spyOn(mockRouter, 'navigate').and.stub();
    component.memberCenterURL = '';
    component.onLogin();
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRoutes.callCenter]);
  });
});
